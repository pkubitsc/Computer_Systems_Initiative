<div id="footer-container">
	<div id="footer">
                <p>Made by: Corey Geesey, Paul Kubitschek, Mai Van Pham, Bryce Cooper</p>
	</div>
</div> 