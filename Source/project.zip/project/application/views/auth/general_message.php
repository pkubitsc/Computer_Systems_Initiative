<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
        <link rel="stylesheet" type="text/css" href="style.css" media="all" />
        <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>css/register/demo.php?url=<?php echo $base_url; ?>" media="all" />
        <link href="<?php echo $base_url; ?>css/register/style.php?url=<?php echo $base_url; ?>" rel="stylesheet" type="text/css" media="screen" />
   <script src="<?php echo $base_url; ?>css/register/script.js"></script>
        
    </head>
<body>
<div class="container">
			<!-- freshdesignweb top bar -->
            <div class="freshdesignweb-top">
              <div class="clr"></div>
            </div><!--/ freshdesignweb top bar -->
			<header>
				<h1>Message</h1>
            </header>       
      <div  class="form">
            <?php echo $message; ?>
            You will be moved to the next page in 10 seconds.
        </div>      
</div>
<br/><br/><br/><br/><br/>
</body>
</html>