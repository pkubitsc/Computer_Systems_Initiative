<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-11-27 19:53:53 --> Config Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:53:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:53:53 --> URI Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Router Class Initialized
DEBUG - 2013-11-27 19:53:53 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:53:53 --> Output Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Security Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Input Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:53:53 --> Language Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Loader Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Session Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:53:53 --> Session routines successfully run
DEBUG - 2013-11-27 19:53:53 --> Controller Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:53:53 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:53:53 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Model Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Model Class Initialized
DEBUG - 2013-11-27 19:53:53 --> Helper loaded: password_hash_helper
DEBUG - 2013-11-27 19:53:53 --> File loaded: application/views/login_view.php
DEBUG - 2013-11-27 19:53:53 --> Final output sent to browser
DEBUG - 2013-11-27 19:53:53 --> Total execution time: 0.2730
DEBUG - 2013-11-27 19:55:36 --> Config Class Initialized
DEBUG - 2013-11-27 19:55:36 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:55:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:55:37 --> URI Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Router Class Initialized
DEBUG - 2013-11-27 19:55:37 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:55:37 --> Output Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Security Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Input Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:55:37 --> Language Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Loader Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Database Driver Class Initialized
ERROR - 2013-11-27 19:55:37 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-11-27 19:55:37 --> Session Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:55:37 --> Session routines successfully run
DEBUG - 2013-11-27 19:55:37 --> Controller Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:55:37 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:55:37 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:55:37 --> Model Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Model Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 19:55:37 --> Upload Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:55:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:55:37 --> Config Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:55:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:55:37 --> URI Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Router Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Output Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Security Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Input Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:55:37 --> Language Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Loader Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Session Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:55:37 --> Session routines successfully run
DEBUG - 2013-11-27 19:55:37 --> Controller Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:55:37 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:55:37 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:55:37 --> Model Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Model Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 19:55:37 --> Upload Class Initialized
DEBUG - 2013-11-27 19:55:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:55:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:55:37 --> Model Class Initialized
DEBUG - 2013-11-27 19:55:38 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-27 19:55:38 --> Final output sent to browser
DEBUG - 2013-11-27 19:55:38 --> Total execution time: 0.5920
DEBUG - 2013-11-27 19:56:14 --> Config Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:56:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:56:14 --> URI Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Router Class Initialized
DEBUG - 2013-11-27 19:56:14 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:56:14 --> Output Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Security Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Input Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:56:14 --> Language Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Loader Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Session Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:56:14 --> Session routines successfully run
DEBUG - 2013-11-27 19:56:14 --> Controller Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:56:14 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:56:14 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:56:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:56:14 --> Model Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Model Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 19:56:14 --> Upload Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:56:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:56:14 --> Config Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:56:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:56:14 --> URI Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Router Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Output Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Security Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Input Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:56:14 --> Language Class Initialized
DEBUG - 2013-11-27 19:56:14 --> Loader Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Session Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:56:15 --> Session routines successfully run
DEBUG - 2013-11-27 19:56:15 --> Controller Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:56:15 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:56:15 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:56:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:56:15 --> Model Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Model Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 19:56:15 --> Upload Class Initialized
DEBUG - 2013-11-27 19:56:15 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:56:15 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:56:15 --> Model Class Initialized
DEBUG - 2013-11-27 19:56:15 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-27 19:56:15 --> Final output sent to browser
DEBUG - 2013-11-27 19:56:15 --> Total execution time: 0.3580
DEBUG - 2013-11-27 19:57:14 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:14 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:14 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:14 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:14 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:15 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:15 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:15 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:15 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 19:57:15 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:15 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-27 19:57:15 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-11-27 19:57:15 --> Severity: Notice  --> Undefined index: ip_address C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-11-27 19:57:15 --> Severity: Notice  --> Undefined index: user_agent C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-11-27 19:57:15 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-11-27 19:57:15 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 288
ERROR - 2013-11-27 19:57:15 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 289
DEBUG - 2013-11-27 19:57:15 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:15 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:15 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:15 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:15 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:15 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:15 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:15 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 19:57:15 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:15 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:15 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:15 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:15 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:15 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:16 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:16 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:16 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:16 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:16 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 19:57:16 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:16 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:16 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:16 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-27 19:57:16 --> Final output sent to browser
DEBUG - 2013-11-27 19:57:16 --> Total execution time: 0.3560
DEBUG - 2013-11-27 19:57:21 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:21 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:21 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:21 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:21 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:21 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:21 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:21 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 19:57:21 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:21 --> XSS Filtering completed
DEBUG - 2013-11-27 19:57:21 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-27 19:57:21 --> XSS Filtering completed
DEBUG - 2013-11-27 19:57:21 --> XSS Filtering completed
DEBUG - 2013-11-27 19:57:22 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:22 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:22 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:22 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:22 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:22 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:22 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:22 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:22 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:22 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:22 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:22 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:22 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:22 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:22 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:22 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:22 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:22 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:22 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:23 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:23 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:23 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:23 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:23 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:23 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:23 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:23 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:23 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:23 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:23 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:23 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:23 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:23 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:23 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:23 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:23 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:23 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:23 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:23 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:23 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:23 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:24 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:24 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:24 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:24 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:24 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:24 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:24 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:24 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:24 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:24 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:24 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:24 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:24 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:24 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:24 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:24 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:24 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:24 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:25 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:25 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:25 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:25 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:25 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:25 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:25 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:25 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:25 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:25 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:25 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:25 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:25 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:25 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:25 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:25 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:25 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:25 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:26 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:26 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:26 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:26 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:26 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:26 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:26 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:26 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:26 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:26 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:26 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:26 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:26 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:26 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:26 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:26 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:26 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:27 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:27 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:27 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:27 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:27 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:27 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:27 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:27 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:27 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:27 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:27 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:27 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:27 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:27 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:27 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:27 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:27 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:27 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:28 --> Session garbage collection performed.
DEBUG - 2013-11-27 19:57:28 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:28 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:28 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:28 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:28 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:28 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:28 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:28 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:28 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:28 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:28 --> Session garbage collection performed.
DEBUG - 2013-11-27 19:57:28 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:28 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:28 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:28 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:28 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:28 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:29 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:29 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:29 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:29 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:29 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:29 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:29 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:29 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:29 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:29 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:29 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:29 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:29 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:29 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:29 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:29 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:30 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:30 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:30 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:30 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:30 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:30 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:30 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:30 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:30 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:30 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:30 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:30 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:30 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:31 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:31 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:31 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:31 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:31 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:31 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:31 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:31 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:31 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:31 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:31 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:31 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:32 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:32 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:32 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:32 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:32 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:32 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:32 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:32 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:32 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:32 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:32 --> No URI present. Default controller set.
DEBUG - 2013-11-27 19:57:32 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:32 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:33 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:33 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:33 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:33 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:33 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:57:33 --> Config Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:57:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:57:33 --> URI Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Router Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Output Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Security Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Input Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:57:33 --> Language Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Loader Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Session Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:57:33 --> Session routines successfully run
DEBUG - 2013-11-27 19:57:33 --> Controller Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:57:33 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:57:33 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:33 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Model Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Upload Class Initialized
DEBUG - 2013-11-27 19:57:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:57:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:58:30 --> Config Class Initialized
DEBUG - 2013-11-27 19:58:30 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:58:30 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:58:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:58:30 --> URI Class Initialized
DEBUG - 2013-11-27 19:58:30 --> Router Class Initialized
DEBUG - 2013-11-27 19:58:30 --> Output Class Initialized
DEBUG - 2013-11-27 19:58:30 --> Security Class Initialized
DEBUG - 2013-11-27 19:58:30 --> Input Class Initialized
DEBUG - 2013-11-27 19:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:58:30 --> Language Class Initialized
DEBUG - 2013-11-27 19:58:30 --> Loader Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Database Driver Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Session Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Helper loaded: string_helper
DEBUG - 2013-11-27 19:58:31 --> Session garbage collection performed.
DEBUG - 2013-11-27 19:58:31 --> Session routines successfully run
DEBUG - 2013-11-27 19:58:31 --> Controller Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Helper loaded: form_helper
DEBUG - 2013-11-27 19:58:31 --> Helper loaded: url_helper
DEBUG - 2013-11-27 19:58:31 --> Form Validation Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 19:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:58:31 --> Model Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Model Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Image Lib Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Upload Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 19:58:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 19:58:31 --> Config Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Hooks Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Utf8 Class Initialized
DEBUG - 2013-11-27 19:58:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 19:58:31 --> URI Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Router Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Output Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Security Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Input Class Initialized
DEBUG - 2013-11-27 19:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 19:58:31 --> Language Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Config Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Hooks Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Utf8 Class Initialized
DEBUG - 2013-11-27 22:57:23 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 22:57:23 --> URI Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Router Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Output Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Security Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Input Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 22:57:23 --> Language Class Initialized
DEBUG - 2013-11-27 22:57:23 --> Loader Class Initialized
DEBUG - 2013-11-27 22:57:24 --> Database Driver Class Initialized
ERROR - 2013-11-27 22:57:24 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-11-27 22:57:24 --> Session Class Initialized
DEBUG - 2013-11-27 22:57:24 --> Helper loaded: string_helper
DEBUG - 2013-11-27 22:57:24 --> Session routines successfully run
DEBUG - 2013-11-27 22:57:24 --> Controller Class Initialized
DEBUG - 2013-11-27 22:57:24 --> Helper loaded: form_helper
DEBUG - 2013-11-27 22:57:24 --> Helper loaded: url_helper
DEBUG - 2013-11-27 22:57:24 --> Form Validation Class Initialized
DEBUG - 2013-11-27 22:57:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 22:57:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 22:57:24 --> Model Class Initialized
DEBUG - 2013-11-27 22:57:24 --> Model Class Initialized
DEBUG - 2013-11-27 22:57:24 --> Image Lib Class Initialized
DEBUG - 2013-11-27 22:57:24 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 22:58:03 --> Config Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Hooks Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Utf8 Class Initialized
DEBUG - 2013-11-27 22:58:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 22:58:03 --> URI Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Router Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Output Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Security Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Input Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 22:58:03 --> Language Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Loader Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Database Driver Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Session Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Helper loaded: string_helper
DEBUG - 2013-11-27 22:58:03 --> Session routines successfully run
DEBUG - 2013-11-27 22:58:03 --> Controller Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Helper loaded: form_helper
DEBUG - 2013-11-27 22:58:03 --> Helper loaded: url_helper
DEBUG - 2013-11-27 22:58:03 --> Form Validation Class Initialized
DEBUG - 2013-11-27 22:58:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 22:58:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 22:58:03 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:04 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:04 --> Image Lib Class Initialized
DEBUG - 2013-11-27 22:58:04 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 22:58:04 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 22:58:15 --> Config Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Hooks Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Utf8 Class Initialized
DEBUG - 2013-11-27 22:58:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 22:58:15 --> URI Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Router Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Output Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Security Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Input Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 22:58:15 --> Language Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Loader Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Database Driver Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Session Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Helper loaded: string_helper
DEBUG - 2013-11-27 22:58:15 --> Session routines successfully run
DEBUG - 2013-11-27 22:58:15 --> Controller Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Helper loaded: form_helper
DEBUG - 2013-11-27 22:58:15 --> Helper loaded: url_helper
DEBUG - 2013-11-27 22:58:15 --> Form Validation Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 22:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 22:58:15 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Image Lib Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 22:58:15 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:15 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: use_username C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 13
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 26
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 27
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 28
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: confirm_password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 31
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: confirm_password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 32
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: confirm_password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 33
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 36
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 37
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 38
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 41
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 42
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 43
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: biography C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: biography C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 47
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: biography C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 48
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: profile_image C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 51
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: profile_image C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 53
ERROR - 2013-11-27 22:58:15 --> Severity: Notice  --> Undefined variable: captcha_registration C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 56
DEBUG - 2013-11-27 22:58:15 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 22:58:15 --> Final output sent to browser
DEBUG - 2013-11-27 22:58:15 --> Total execution time: 0.8941
DEBUG - 2013-11-27 22:58:33 --> Config Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Hooks Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Utf8 Class Initialized
DEBUG - 2013-11-27 22:58:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 22:58:33 --> URI Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Router Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Output Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Security Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Input Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 22:58:33 --> Language Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Loader Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Database Driver Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Session Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Helper loaded: string_helper
DEBUG - 2013-11-27 22:58:33 --> Session routines successfully run
DEBUG - 2013-11-27 22:58:33 --> Controller Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Helper loaded: form_helper
DEBUG - 2013-11-27 22:58:33 --> Helper loaded: url_helper
DEBUG - 2013-11-27 22:58:33 --> Form Validation Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 22:58:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 22:58:33 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Image Lib Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 22:58:33 --> Model Class Initialized
DEBUG - 2013-11-27 22:58:33 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: use_username C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 13
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 26
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 27
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 28
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: confirm_password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 31
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: confirm_password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 32
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: confirm_password C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 33
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 36
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 37
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 38
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 41
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 42
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 43
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: biography C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: biography C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 47
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: biography C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 48
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: profile_image C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 51
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: profile_image C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 53
ERROR - 2013-11-27 22:58:33 --> Severity: Notice  --> Undefined variable: captcha_registration C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 56
DEBUG - 2013-11-27 22:58:33 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 22:58:33 --> Final output sent to browser
DEBUG - 2013-11-27 22:58:33 --> Total execution time: 0.8810
DEBUG - 2013-11-27 23:02:51 --> Config Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:02:51 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:02:51 --> URI Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Router Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Output Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Security Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Input Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:02:51 --> Language Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Loader Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Session Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:02:51 --> Session routines successfully run
DEBUG - 2013-11-27 23:02:51 --> Controller Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:02:51 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:02:51 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:02:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:02:51 --> Model Class Initialized
DEBUG - 2013-11-27 23:02:51 --> Model Class Initialized
DEBUG - 2013-11-27 23:02:52 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:02:52 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:02:52 --> Model Class Initialized
DEBUG - 2013-11-27 23:02:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:02:52 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:02:52 --> Final output sent to browser
DEBUG - 2013-11-27 23:02:52 --> Total execution time: 1.0291
DEBUG - 2013-11-27 23:04:41 --> Config Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:04:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:04:41 --> URI Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Router Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Output Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Security Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Input Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:04:41 --> Language Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Loader Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Session Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:04:41 --> Session routines successfully run
DEBUG - 2013-11-27 23:04:41 --> Controller Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:04:41 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:04:41 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:04:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:04:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:04:41 --> Model Class Initialized
DEBUG - 2013-11-27 23:04:42 --> Model Class Initialized
DEBUG - 2013-11-27 23:04:42 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:04:42 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:04:42 --> Model Class Initialized
DEBUG - 2013-11-27 23:04:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:04:42 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:04:42 --> Final output sent to browser
DEBUG - 2013-11-27 23:04:42 --> Total execution time: 0.6470
DEBUG - 2013-11-27 23:10:24 --> Config Class Initialized
DEBUG - 2013-11-27 23:10:24 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:10:24 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:10:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:10:25 --> URI Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Router Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Output Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Security Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Input Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:10:25 --> Language Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Loader Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Session Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:10:25 --> Session routines successfully run
DEBUG - 2013-11-27 23:10:25 --> Controller Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:10:25 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:10:25 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:10:25 --> Model Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Model Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:10:25 --> Model Class Initialized
DEBUG - 2013-11-27 23:10:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:10:25 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:10:25 --> Final output sent to browser
DEBUG - 2013-11-27 23:10:25 --> Total execution time: 0.6750
DEBUG - 2013-11-27 23:16:19 --> Config Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:16:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:16:19 --> URI Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Router Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Output Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Security Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Input Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:16:19 --> Language Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Loader Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Session Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:16:19 --> Session routines successfully run
DEBUG - 2013-11-27 23:16:19 --> Controller Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:16:19 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:16:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:16:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:16:19 --> Model Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Model Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:16:19 --> Model Class Initialized
DEBUG - 2013-11-27 23:16:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:16:33 --> Config Class Initialized
DEBUG - 2013-11-27 23:16:33 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:16:33 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:16:33 --> URI Class Initialized
DEBUG - 2013-11-27 23:16:33 --> Router Class Initialized
DEBUG - 2013-11-27 23:16:33 --> Output Class Initialized
DEBUG - 2013-11-27 23:16:33 --> Security Class Initialized
DEBUG - 2013-11-27 23:16:33 --> Input Class Initialized
DEBUG - 2013-11-27 23:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:16:34 --> Language Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Loader Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Session Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:16:34 --> Session routines successfully run
DEBUG - 2013-11-27 23:16:34 --> Controller Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:16:34 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:16:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:16:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:16:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:16:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:16:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:16:34 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:16:34 --> Final output sent to browser
DEBUG - 2013-11-27 23:16:34 --> Total execution time: 0.9261
DEBUG - 2013-11-27 23:17:33 --> Config Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:17:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:17:33 --> URI Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Router Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Output Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Security Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Input Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:17:33 --> Language Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Loader Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Session Class Initialized
DEBUG - 2013-11-27 23:17:33 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:17:33 --> Session routines successfully run
DEBUG - 2013-11-27 23:17:33 --> Controller Class Initialized
DEBUG - 2013-11-27 23:17:34 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:17:34 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:17:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:17:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:17:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:17:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:17:34 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:17:34 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:17:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:17:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:17:34 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:17:34 --> Final output sent to browser
DEBUG - 2013-11-27 23:17:34 --> Total execution time: 0.6130
DEBUG - 2013-11-27 23:17:36 --> Config Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:17:36 --> URI Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Router Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Output Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Security Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Input Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:17:36 --> Language Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Loader Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Session Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:17:36 --> Session routines successfully run
DEBUG - 2013-11-27 23:17:36 --> Controller Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:17:36 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:17:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:17:36 --> Model Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Model Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:17:36 --> Model Class Initialized
DEBUG - 2013-11-27 23:17:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:17:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:17:36 --> Final output sent to browser
DEBUG - 2013-11-27 23:17:36 --> Total execution time: 0.6380
DEBUG - 2013-11-27 23:17:59 --> Config Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:17:59 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:17:59 --> URI Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Router Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Output Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Security Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Input Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:17:59 --> Language Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Loader Class Initialized
DEBUG - 2013-11-27 23:17:59 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:18:00 --> Session Class Initialized
DEBUG - 2013-11-27 23:18:00 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:18:00 --> Session routines successfully run
DEBUG - 2013-11-27 23:18:00 --> Controller Class Initialized
DEBUG - 2013-11-27 23:18:00 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:18:00 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:18:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:00 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:18:00 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:18:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:18:00 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:18:00 --> Final output sent to browser
DEBUG - 2013-11-27 23:18:00 --> Total execution time: 0.6310
DEBUG - 2013-11-27 23:18:02 --> Config Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:18:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:18:02 --> URI Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Router Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Output Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Security Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Input Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:18:02 --> Language Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Loader Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Session Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:18:02 --> Session routines successfully run
DEBUG - 2013-11-27 23:18:02 --> Controller Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:18:02 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:18:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:18:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:02 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:18:02 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:18:02 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:18:02 --> Final output sent to browser
DEBUG - 2013-11-27 23:18:02 --> Total execution time: 0.6610
DEBUG - 2013-11-27 23:18:16 --> Config Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:18:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:18:16 --> URI Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Router Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Output Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Security Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Input Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:18:16 --> Language Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Loader Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Session Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:18:16 --> Session routines successfully run
DEBUG - 2013-11-27 23:18:16 --> Controller Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:18:16 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:18:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:16 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:18:16 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:18:16 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:18:16 --> Final output sent to browser
DEBUG - 2013-11-27 23:18:16 --> Total execution time: 0.6770
DEBUG - 2013-11-27 23:18:19 --> Config Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:18:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:18:19 --> URI Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Router Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Output Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Security Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Input Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:18:19 --> Language Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Loader Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Session Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:18:19 --> Session routines successfully run
DEBUG - 2013-11-27 23:18:19 --> Controller Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:18:19 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:18:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:18:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:19 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:18:19 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:18:19 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:18:19 --> Final output sent to browser
DEBUG - 2013-11-27 23:18:19 --> Total execution time: 0.6470
DEBUG - 2013-11-27 23:18:25 --> Config Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:18:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:18:25 --> URI Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Router Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Output Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Security Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Input Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:18:25 --> Language Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Loader Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Session Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:18:25 --> Session routines successfully run
DEBUG - 2013-11-27 23:18:25 --> Controller Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:18:25 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:18:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:18:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:25 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:25 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:18:26 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:18:26 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:18:26 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:18:26 --> Final output sent to browser
DEBUG - 2013-11-27 23:18:26 --> Total execution time: 0.6610
DEBUG - 2013-11-27 23:18:30 --> Config Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:18:30 --> URI Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Router Class Initialized
DEBUG - 2013-11-27 23:18:30 --> No URI present. Default controller set.
DEBUG - 2013-11-27 23:18:30 --> Output Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Security Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Input Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:18:30 --> Language Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Loader Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Session Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:18:30 --> Session routines successfully run
DEBUG - 2013-11-27 23:18:30 --> Controller Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:18:30 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:18:30 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:30 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:18:30 --> Upload Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:18:30 --> Config Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:18:30 --> URI Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Router Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Output Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Security Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Input Class Initialized
DEBUG - 2013-11-27 23:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:18:31 --> Language Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Loader Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Session Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:18:31 --> Session routines successfully run
DEBUG - 2013-11-27 23:18:31 --> Controller Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:18:31 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:18:31 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:31 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:18:31 --> Upload Class Initialized
DEBUG - 2013-11-27 23:18:31 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:18:31 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:31 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-27 23:18:31 --> Final output sent to browser
DEBUG - 2013-11-27 23:18:31 --> Total execution time: 0.7560
DEBUG - 2013-11-27 23:18:38 --> Config Class Initialized
DEBUG - 2013-11-27 23:18:38 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:18:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:18:39 --> URI Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Router Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Output Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Security Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Input Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:18:39 --> Language Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Loader Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Session Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:18:39 --> Session routines successfully run
DEBUG - 2013-11-27 23:18:39 --> Controller Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:18:39 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:18:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:18:39 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:18:39 --> Model Class Initialized
DEBUG - 2013-11-27 23:18:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:18:39 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:18:39 --> Final output sent to browser
DEBUG - 2013-11-27 23:18:39 --> Total execution time: 0.6890
DEBUG - 2013-11-27 23:19:05 --> Config Class Initialized
DEBUG - 2013-11-27 23:19:05 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:19:05 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:19:05 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:19:05 --> URI Class Initialized
DEBUG - 2013-11-27 23:19:05 --> Router Class Initialized
DEBUG - 2013-11-27 23:19:05 --> Output Class Initialized
DEBUG - 2013-11-27 23:19:05 --> Security Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Input Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:19:06 --> Language Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Loader Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Session Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:19:06 --> Session routines successfully run
DEBUG - 2013-11-27 23:19:06 --> Controller Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:19:06 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:19:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:19:06 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:19:06 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:19:06 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:19:06 --> Final output sent to browser
DEBUG - 2013-11-27 23:19:06 --> Total execution time: 0.6790
DEBUG - 2013-11-27 23:19:16 --> Config Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:19:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:19:16 --> URI Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Router Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Output Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Security Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Input Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:19:16 --> Language Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Loader Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Session Class Initialized
DEBUG - 2013-11-27 23:19:16 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:19:17 --> Session routines successfully run
DEBUG - 2013-11-27 23:19:17 --> Controller Class Initialized
DEBUG - 2013-11-27 23:19:17 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:19:17 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:19:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:19:17 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:17 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:17 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:19:17 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:19:17 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:19:17 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:19:17 --> Final output sent to browser
DEBUG - 2013-11-27 23:19:17 --> Total execution time: 0.7060
DEBUG - 2013-11-27 23:19:33 --> Config Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:19:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:19:33 --> URI Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Router Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Output Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Security Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Input Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:19:33 --> Language Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Loader Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Session Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:19:33 --> Session routines successfully run
DEBUG - 2013-11-27 23:19:33 --> Controller Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:19:33 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:19:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:19:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:19:33 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:19:33 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:19:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:19:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:20:38 --> Config Class Initialized
DEBUG - 2013-11-27 23:20:38 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:20:38 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:20:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:20:38 --> URI Class Initialized
DEBUG - 2013-11-27 23:20:38 --> Router Class Initialized
DEBUG - 2013-11-27 23:20:38 --> Output Class Initialized
DEBUG - 2013-11-27 23:20:38 --> Security Class Initialized
DEBUG - 2013-11-27 23:20:38 --> Input Class Initialized
DEBUG - 2013-11-27 23:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:20:39 --> Language Class Initialized
DEBUG - 2013-11-27 23:20:39 --> Loader Class Initialized
DEBUG - 2013-11-27 23:20:39 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:20:39 --> Session Class Initialized
DEBUG - 2013-11-27 23:20:39 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:20:39 --> Session routines successfully run
DEBUG - 2013-11-27 23:20:40 --> Controller Class Initialized
DEBUG - 2013-11-27 23:20:40 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:20:40 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:20:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:20:40 --> Model Class Initialized
DEBUG - 2013-11-27 23:20:40 --> Model Class Initialized
DEBUG - 2013-11-27 23:20:40 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:20:40 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:20:40 --> Model Class Initialized
DEBUG - 2013-11-27 23:20:40 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:20:41 --> Config Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:20:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:20:41 --> URI Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Router Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Output Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Security Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Input Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:20:41 --> Language Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Loader Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Session Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:20:41 --> A session cookie was not found.
DEBUG - 2013-11-27 23:20:41 --> Session routines successfully run
DEBUG - 2013-11-27 23:20:41 --> Controller Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:20:41 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:20:41 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:20:41 --> Model Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Model Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:20:41 --> Upload Class Initialized
DEBUG - 2013-11-27 23:20:41 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:20:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:20:41 --> Model Class Initialized
DEBUG - 2013-11-27 23:20:41 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-27 23:20:41 --> Final output sent to browser
DEBUG - 2013-11-27 23:20:41 --> Total execution time: 0.9341
DEBUG - 2013-11-27 23:21:00 --> Config Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:21:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:21:00 --> URI Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Router Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Output Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Security Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Input Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:21:00 --> Language Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Loader Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Session Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:21:00 --> Session routines successfully run
DEBUG - 2013-11-27 23:21:00 --> Controller Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:21:00 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:21:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:21:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:21:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:21:01 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:21:01 --> Final output sent to browser
DEBUG - 2013-11-27 23:21:01 --> Total execution time: 0.7390
DEBUG - 2013-11-27 23:21:02 --> Config Class Initialized
DEBUG - 2013-11-27 23:21:02 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:21:02 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:21:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:21:02 --> URI Class Initialized
DEBUG - 2013-11-27 23:21:02 --> Router Class Initialized
DEBUG - 2013-11-27 23:21:02 --> Output Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Security Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Input Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:21:03 --> Language Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Loader Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Session Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:21:03 --> Session routines successfully run
DEBUG - 2013-11-27 23:21:03 --> Controller Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:21:03 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:21:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:21:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:03 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:21:03 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:21:03 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:21:03 --> Final output sent to browser
DEBUG - 2013-11-27 23:21:03 --> Total execution time: 0.8050
DEBUG - 2013-11-27 23:21:32 --> Config Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:21:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:21:32 --> URI Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Router Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Output Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Security Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Input Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:21:32 --> Language Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Loader Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Session Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:21:32 --> Session routines successfully run
DEBUG - 2013-11-27 23:21:32 --> Controller Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:21:32 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:21:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:21:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:32 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:21:32 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:21:33 --> Config Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:21:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:21:33 --> URI Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Router Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Output Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Security Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Input Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:21:33 --> Language Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Loader Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Session Class Initialized
DEBUG - 2013-11-27 23:21:33 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:21:33 --> A session cookie was not found.
DEBUG - 2013-11-27 23:21:34 --> Session routines successfully run
DEBUG - 2013-11-27 23:21:34 --> Controller Class Initialized
DEBUG - 2013-11-27 23:21:34 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:21:34 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:21:34 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:21:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:34 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:21:34 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:21:34 --> Upload Class Initialized
DEBUG - 2013-11-27 23:21:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:21:34 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:34 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-27 23:21:34 --> Final output sent to browser
DEBUG - 2013-11-27 23:21:34 --> Total execution time: 1.2241
DEBUG - 2013-11-27 23:21:38 --> Config Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:21:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:21:38 --> URI Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Router Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Output Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Security Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Input Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:21:38 --> Language Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Loader Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Session Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:21:38 --> Session routines successfully run
DEBUG - 2013-11-27 23:21:38 --> Controller Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:21:38 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:21:38 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:21:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:38 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:38 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:39 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:21:39 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:21:39 --> Upload Class Initialized
DEBUG - 2013-11-27 23:21:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:21:39 --> XSS Filtering completed
DEBUG - 2013-11-27 23:21:39 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-27 23:21:39 --> XSS Filtering completed
DEBUG - 2013-11-27 23:21:39 --> XSS Filtering completed
DEBUG - 2013-11-27 23:21:39 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-27 23:21:39 --> Final output sent to browser
DEBUG - 2013-11-27 23:21:39 --> Total execution time: 1.0071
DEBUG - 2013-11-27 23:21:45 --> Config Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:21:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:21:45 --> URI Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Router Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Output Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Security Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Input Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:21:45 --> Language Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Loader Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Session Class Initialized
DEBUG - 2013-11-27 23:21:45 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:21:45 --> Session routines successfully run
DEBUG - 2013-11-27 23:21:45 --> Controller Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:21:46 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:21:46 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:21:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:46 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Helper loaded: cookie_helper
DEBUG - 2013-11-27 23:21:46 --> Upload Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:21:46 --> XSS Filtering completed
DEBUG - 2013-11-27 23:21:46 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-27 23:21:46 --> XSS Filtering completed
DEBUG - 2013-11-27 23:21:46 --> XSS Filtering completed
DEBUG - 2013-11-27 23:21:46 --> Config Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:21:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:21:46 --> URI Class Initialized
DEBUG - 2013-11-27 23:21:46 --> Router Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Output Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Security Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Input Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:21:47 --> Language Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Loader Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Session Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:21:47 --> Session routines successfully run
DEBUG - 2013-11-27 23:21:47 --> Controller Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:21:47 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:21:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:21:47 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Model Class Initialized
DEBUG - 2013-11-27 23:21:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:21:47 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:21:47 --> Final output sent to browser
DEBUG - 2013-11-27 23:21:47 --> Total execution time: 0.8821
DEBUG - 2013-11-27 23:30:37 --> Config Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:30:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:30:37 --> URI Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Router Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Output Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Security Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Input Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:30:37 --> Language Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Loader Class Initialized
DEBUG - 2013-11-27 23:30:37 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:30:38 --> Session Class Initialized
DEBUG - 2013-11-27 23:30:38 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:30:38 --> Session routines successfully run
DEBUG - 2013-11-27 23:30:38 --> Controller Class Initialized
DEBUG - 2013-11-27 23:30:38 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:30:38 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:30:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:30:38 --> Model Class Initialized
DEBUG - 2013-11-27 23:30:38 --> Model Class Initialized
DEBUG - 2013-11-27 23:30:38 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:30:38 --> Model Class Initialized
DEBUG - 2013-11-27 23:30:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:30:38 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:30:38 --> Final output sent to browser
DEBUG - 2013-11-27 23:30:38 --> Total execution time: 1.0461
DEBUG - 2013-11-27 23:30:50 --> Config Class Initialized
DEBUG - 2013-11-27 23:30:50 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:30:50 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:30:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:30:50 --> URI Class Initialized
DEBUG - 2013-11-27 23:30:50 --> Router Class Initialized
DEBUG - 2013-11-27 23:30:50 --> Output Class Initialized
DEBUG - 2013-11-27 23:30:50 --> Security Class Initialized
DEBUG - 2013-11-27 23:30:50 --> Input Class Initialized
DEBUG - 2013-11-27 23:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:30:50 --> Language Class Initialized
DEBUG - 2013-11-27 23:31:04 --> Config Class Initialized
DEBUG - 2013-11-27 23:31:04 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:31:04 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:31:04 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:31:04 --> URI Class Initialized
DEBUG - 2013-11-27 23:31:04 --> Router Class Initialized
DEBUG - 2013-11-27 23:31:04 --> Output Class Initialized
DEBUG - 2013-11-27 23:31:04 --> Security Class Initialized
DEBUG - 2013-11-27 23:31:04 --> Input Class Initialized
DEBUG - 2013-11-27 23:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:31:04 --> Language Class Initialized
DEBUG - 2013-11-27 23:31:16 --> Config Class Initialized
DEBUG - 2013-11-27 23:31:16 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:31:16 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:31:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:31:16 --> URI Class Initialized
DEBUG - 2013-11-27 23:31:16 --> Router Class Initialized
DEBUG - 2013-11-27 23:31:16 --> Output Class Initialized
DEBUG - 2013-11-27 23:31:16 --> Security Class Initialized
DEBUG - 2013-11-27 23:31:16 --> Input Class Initialized
DEBUG - 2013-11-27 23:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:31:16 --> Language Class Initialized
DEBUG - 2013-11-27 23:31:20 --> Config Class Initialized
DEBUG - 2013-11-27 23:31:20 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:31:20 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:31:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:31:20 --> URI Class Initialized
DEBUG - 2013-11-27 23:31:20 --> Router Class Initialized
DEBUG - 2013-11-27 23:31:20 --> Output Class Initialized
DEBUG - 2013-11-27 23:31:20 --> Security Class Initialized
DEBUG - 2013-11-27 23:31:20 --> Input Class Initialized
DEBUG - 2013-11-27 23:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:31:20 --> Language Class Initialized
DEBUG - 2013-11-27 23:31:46 --> Config Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:31:47 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:31:47 --> URI Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Router Class Initialized
DEBUG - 2013-11-27 23:31:47 --> No URI present. Default controller set.
DEBUG - 2013-11-27 23:31:47 --> Output Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Security Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Input Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:31:47 --> Language Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Loader Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Session Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:31:47 --> Session routines successfully run
DEBUG - 2013-11-27 23:31:47 --> Controller Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:31:47 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:31:47 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:31:47 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Upload Class Initialized
DEBUG - 2013-11-27 23:31:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:31:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:31:48 --> Config Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:31:48 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:31:48 --> URI Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Router Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Output Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Security Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Input Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:31:48 --> Language Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Loader Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Session Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:31:48 --> Session routines successfully run
DEBUG - 2013-11-27 23:31:48 --> Controller Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:31:48 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:31:48 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:31:48 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Upload Class Initialized
DEBUG - 2013-11-27 23:31:48 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:31:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:31:49 --> Config Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:31:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:31:49 --> URI Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Router Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Output Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Security Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Input Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:31:49 --> Language Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Loader Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Session Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:31:49 --> Session routines successfully run
DEBUG - 2013-11-27 23:31:49 --> Controller Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:31:49 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:31:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:31:49 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:31:49 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:31:49 --> Final output sent to browser
DEBUG - 2013-11-27 23:31:49 --> Total execution time: 0.8040
DEBUG - 2013-11-27 23:31:55 --> Config Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:31:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:31:55 --> URI Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Router Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Output Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Security Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Input Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:31:55 --> Language Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Loader Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Session Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:31:55 --> Session routines successfully run
DEBUG - 2013-11-27 23:31:55 --> Controller Class Initialized
DEBUG - 2013-11-27 23:31:55 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:31:55 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:31:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:31:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:31:56 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:56 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:56 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:31:56 --> Model Class Initialized
DEBUG - 2013-11-27 23:31:56 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-27 23:31:56 --> Severity: Notice  --> Undefined property: Home::$form_validation C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 54
DEBUG - 2013-11-27 23:34:10 --> Config Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:34:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:34:10 --> URI Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Router Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Output Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Security Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Input Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:34:10 --> Language Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Loader Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Session Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:34:10 --> Session routines successfully run
DEBUG - 2013-11-27 23:34:10 --> Controller Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:34:10 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:34:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:34:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:34:10 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:34:11 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:34:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-27 23:34:11 --> XSS Filtering completed
ERROR - 2013-11-27 23:34:11 --> Severity: Notice  --> Undefined property: Home::$post C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 58
DEBUG - 2013-11-27 23:34:53 --> Config Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:34:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:34:53 --> URI Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Router Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Output Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Security Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Input Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:34:53 --> Language Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Loader Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Session Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:34:53 --> Session routines successfully run
DEBUG - 2013-11-27 23:34:53 --> Controller Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:34:53 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:34:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:34:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:34:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:34:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:34:54 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-27 23:34:54 --> XSS Filtering completed
DEBUG - 2013-11-27 23:34:54 --> Config Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:34:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:34:54 --> URI Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Router Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Output Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Security Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Input Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:34:54 --> Language Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Loader Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Session Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:34:54 --> Session routines successfully run
DEBUG - 2013-11-27 23:34:54 --> Controller Class Initialized
DEBUG - 2013-11-27 23:34:54 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:34:54 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:34:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:34:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:34:55 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:55 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:55 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:34:55 --> Model Class Initialized
DEBUG - 2013-11-27 23:34:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:34:55 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:34:55 --> Final output sent to browser
DEBUG - 2013-11-27 23:34:55 --> Total execution time: 0.9081
DEBUG - 2013-11-27 23:35:27 --> Config Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:35:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:35:27 --> URI Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Router Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Output Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Security Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Input Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:35:27 --> Language Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Loader Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Session Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:35:27 --> Session routines successfully run
DEBUG - 2013-11-27 23:35:27 --> Controller Class Initialized
DEBUG - 2013-11-27 23:35:27 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:35:27 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:35:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:35:28 --> Model Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Model Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Model Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:35:28 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-27 23:35:28 --> XSS Filtering completed
DEBUG - 2013-11-27 23:35:28 --> Config Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:35:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:35:28 --> URI Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Router Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Output Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Security Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Input Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:35:28 --> Language Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Loader Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Session Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:35:28 --> Session routines successfully run
DEBUG - 2013-11-27 23:35:28 --> Controller Class Initialized
DEBUG - 2013-11-27 23:35:28 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:35:29 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:35:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:35:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:35:29 --> Model Class Initialized
DEBUG - 2013-11-27 23:35:29 --> Model Class Initialized
DEBUG - 2013-11-27 23:35:29 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:35:29 --> Model Class Initialized
DEBUG - 2013-11-27 23:35:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:35:29 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:35:29 --> Final output sent to browser
DEBUG - 2013-11-27 23:35:29 --> Total execution time: 1.0351
DEBUG - 2013-11-27 23:36:01 --> Config Class Initialized
DEBUG - 2013-11-27 23:36:01 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:36:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:36:02 --> URI Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Router Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Output Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Security Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Input Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:36:02 --> Language Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Loader Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Session Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:36:02 --> Session routines successfully run
DEBUG - 2013-11-27 23:36:02 --> Controller Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:36:02 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:36:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:36:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:36:02 --> Model Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Model Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Model Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:36:02 --> Form Validation Class Initialized
DEBUG - 2013-11-27 23:36:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-27 23:36:02 --> XSS Filtering completed
DEBUG - 2013-11-27 23:36:03 --> Config Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:36:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:36:03 --> URI Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Router Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Output Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Security Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Input Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:36:03 --> Language Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Loader Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Session Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:36:03 --> Session routines successfully run
DEBUG - 2013-11-27 23:36:03 --> Controller Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:36:03 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:36:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:36:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:36:03 --> Model Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Model Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Model Class Initialized
DEBUG - 2013-11-27 23:36:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:36:03 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:36:03 --> Final output sent to browser
DEBUG - 2013-11-27 23:36:03 --> Total execution time: 0.9481
DEBUG - 2013-11-27 23:43:49 --> Config Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:43:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:43:49 --> URI Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Router Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Output Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Security Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Input Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:43:49 --> Language Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Loader Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Session Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:43:49 --> Session routines successfully run
DEBUG - 2013-11-27 23:43:49 --> Controller Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:43:49 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:43:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:43:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:43:49 --> Model Class Initialized
DEBUG - 2013-11-27 23:43:49 --> Model Class Initialized
DEBUG - 2013-11-27 23:43:50 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:43:50 --> Model Class Initialized
DEBUG - 2013-11-27 23:43:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:44:15 --> Config Class Initialized
DEBUG - 2013-11-27 23:44:15 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:44:15 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:44:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:44:15 --> URI Class Initialized
DEBUG - 2013-11-27 23:44:15 --> Router Class Initialized
DEBUG - 2013-11-27 23:44:15 --> Output Class Initialized
DEBUG - 2013-11-27 23:44:15 --> Security Class Initialized
DEBUG - 2013-11-27 23:44:15 --> Input Class Initialized
DEBUG - 2013-11-27 23:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:44:15 --> Language Class Initialized
DEBUG - 2013-11-27 23:44:15 --> Loader Class Initialized
DEBUG - 2013-11-27 23:44:16 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:44:16 --> Session Class Initialized
DEBUG - 2013-11-27 23:44:16 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:44:16 --> Session routines successfully run
DEBUG - 2013-11-27 23:44:16 --> Controller Class Initialized
DEBUG - 2013-11-27 23:44:16 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:44:16 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:44:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:44:16 --> Model Class Initialized
DEBUG - 2013-11-27 23:44:16 --> Model Class Initialized
DEBUG - 2013-11-27 23:44:16 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:44:16 --> Model Class Initialized
DEBUG - 2013-11-27 23:44:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:46:14 --> Config Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:46:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:46:14 --> URI Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Router Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Output Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Security Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Input Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:46:14 --> Language Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Loader Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Session Class Initialized
DEBUG - 2013-11-27 23:46:14 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:46:15 --> Session routines successfully run
DEBUG - 2013-11-27 23:46:15 --> Controller Class Initialized
DEBUG - 2013-11-27 23:46:15 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:46:15 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:46:15 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:46:15 --> Model Class Initialized
DEBUG - 2013-11-27 23:46:15 --> Model Class Initialized
DEBUG - 2013-11-27 23:46:15 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:46:15 --> Model Class Initialized
DEBUG - 2013-11-27 23:46:15 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:47:03 --> Config Class Initialized
DEBUG - 2013-11-27 23:47:03 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:47:03 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:47:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:47:03 --> URI Class Initialized
DEBUG - 2013-11-27 23:47:03 --> Router Class Initialized
DEBUG - 2013-11-27 23:47:03 --> Output Class Initialized
DEBUG - 2013-11-27 23:47:03 --> Security Class Initialized
DEBUG - 2013-11-27 23:47:03 --> Input Class Initialized
DEBUG - 2013-11-27 23:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:47:03 --> Language Class Initialized
DEBUG - 2013-11-27 23:47:03 --> Loader Class Initialized
DEBUG - 2013-11-27 23:47:04 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:47:04 --> Session Class Initialized
DEBUG - 2013-11-27 23:47:04 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:47:04 --> Session routines successfully run
DEBUG - 2013-11-27 23:47:04 --> Controller Class Initialized
DEBUG - 2013-11-27 23:47:04 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:47:04 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:47:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:47:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:47:04 --> Model Class Initialized
DEBUG - 2013-11-27 23:47:04 --> Model Class Initialized
DEBUG - 2013-11-27 23:47:04 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:47:04 --> Model Class Initialized
DEBUG - 2013-11-27 23:47:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:47:04 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:47:04 --> Final output sent to browser
DEBUG - 2013-11-27 23:47:04 --> Total execution time: 0.9301
DEBUG - 2013-11-27 23:47:24 --> Config Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:47:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:47:24 --> URI Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Router Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Output Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Security Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Input Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:47:24 --> Language Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Loader Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Session Class Initialized
DEBUG - 2013-11-27 23:47:24 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:47:25 --> Session routines successfully run
DEBUG - 2013-11-27 23:47:25 --> Controller Class Initialized
DEBUG - 2013-11-27 23:47:25 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:47:25 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:47:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:47:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:47:25 --> Model Class Initialized
DEBUG - 2013-11-27 23:47:25 --> Model Class Initialized
DEBUG - 2013-11-27 23:47:25 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:47:25 --> Model Class Initialized
DEBUG - 2013-11-27 23:47:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:47:25 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:47:25 --> Final output sent to browser
DEBUG - 2013-11-27 23:47:25 --> Total execution time: 0.8660
DEBUG - 2013-11-27 23:48:59 --> Config Class Initialized
DEBUG - 2013-11-27 23:48:59 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:48:59 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:48:59 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:48:59 --> URI Class Initialized
DEBUG - 2013-11-27 23:48:59 --> Router Class Initialized
DEBUG - 2013-11-27 23:48:59 --> Output Class Initialized
DEBUG - 2013-11-27 23:48:59 --> Security Class Initialized
DEBUG - 2013-11-27 23:48:59 --> Input Class Initialized
DEBUG - 2013-11-27 23:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:49:00 --> Language Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Loader Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Session Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:49:00 --> Session routines successfully run
DEBUG - 2013-11-27 23:49:00 --> Controller Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:49:00 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:49:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:49:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:49:00 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:49:00 --> Final output sent to browser
DEBUG - 2013-11-27 23:49:00 --> Total execution time: 0.9251
DEBUG - 2013-11-27 23:49:43 --> Config Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:49:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:49:43 --> URI Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Router Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Output Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Security Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Input Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:49:43 --> Language Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Loader Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Session Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:49:43 --> Session routines successfully run
DEBUG - 2013-11-27 23:49:43 --> Controller Class Initialized
DEBUG - 2013-11-27 23:49:43 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:49:43 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:49:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:49:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:49:44 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:44 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:44 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:49:44 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:49:44 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:49:44 --> Final output sent to browser
DEBUG - 2013-11-27 23:49:44 --> Total execution time: 0.8760
DEBUG - 2013-11-27 23:49:52 --> Config Class Initialized
DEBUG - 2013-11-27 23:49:52 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:49:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:49:53 --> URI Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Router Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Output Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Security Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Input Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:49:53 --> Language Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Loader Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Session Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:49:53 --> Session routines successfully run
DEBUG - 2013-11-27 23:49:53 --> Controller Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:49:53 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:49:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:49:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:49:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:49:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:49:53 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:49:53 --> Final output sent to browser
DEBUG - 2013-11-27 23:49:53 --> Total execution time: 0.8751
DEBUG - 2013-11-27 23:51:13 --> Config Class Initialized
DEBUG - 2013-11-27 23:51:13 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:51:13 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:51:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:51:13 --> URI Class Initialized
DEBUG - 2013-11-27 23:51:13 --> Router Class Initialized
DEBUG - 2013-11-27 23:51:13 --> Output Class Initialized
DEBUG - 2013-11-27 23:51:13 --> Security Class Initialized
DEBUG - 2013-11-27 23:51:13 --> Input Class Initialized
DEBUG - 2013-11-27 23:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:51:13 --> Language Class Initialized
DEBUG - 2013-11-27 23:51:13 --> Loader Class Initialized
DEBUG - 2013-11-27 23:51:14 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:51:14 --> Session Class Initialized
DEBUG - 2013-11-27 23:51:14 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:51:14 --> Session routines successfully run
DEBUG - 2013-11-27 23:51:14 --> Controller Class Initialized
DEBUG - 2013-11-27 23:51:14 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:51:14 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:51:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:51:14 --> Model Class Initialized
DEBUG - 2013-11-27 23:51:14 --> Model Class Initialized
DEBUG - 2013-11-27 23:51:14 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:51:14 --> Model Class Initialized
DEBUG - 2013-11-27 23:51:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:51:14 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:51:14 --> Final output sent to browser
DEBUG - 2013-11-27 23:51:14 --> Total execution time: 0.9281
DEBUG - 2013-11-27 23:52:05 --> Config Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:52:05 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:52:05 --> URI Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Router Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Output Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Security Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Input Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:52:05 --> Language Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Loader Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Session Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:52:05 --> Session routines successfully run
DEBUG - 2013-11-27 23:52:05 --> Controller Class Initialized
DEBUG - 2013-11-27 23:52:05 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:52:05 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:52:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:52:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:52:06 --> Model Class Initialized
DEBUG - 2013-11-27 23:52:06 --> Model Class Initialized
DEBUG - 2013-11-27 23:52:06 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:52:06 --> Model Class Initialized
DEBUG - 2013-11-27 23:52:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:52:06 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:52:06 --> Final output sent to browser
DEBUG - 2013-11-27 23:52:06 --> Total execution time: 0.9261
DEBUG - 2013-11-27 23:52:30 --> Config Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:52:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:52:31 --> URI Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Router Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Output Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Security Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Input Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:52:31 --> Language Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Loader Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Session Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:52:31 --> Session routines successfully run
DEBUG - 2013-11-27 23:52:31 --> Controller Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:52:31 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:52:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:52:31 --> Model Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Model Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Model Class Initialized
DEBUG - 2013-11-27 23:52:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:52:31 --> DB Transaction Failure
ERROR - 2013-11-27 23:52:31 --> Query error: Unknown column '1' in 'field list'
DEBUG - 2013-11-27 23:52:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-27 23:53:52 --> Config Class Initialized
DEBUG - 2013-11-27 23:53:52 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:53:52 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:53:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:53:53 --> URI Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Router Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Output Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Security Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Input Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:53:53 --> Language Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Loader Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Session Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:53:53 --> Session routines successfully run
DEBUG - 2013-11-27 23:53:53 --> Controller Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:53:53 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:53:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:53:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:53:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:53:53 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:53:53 --> Final output sent to browser
DEBUG - 2013-11-27 23:53:53 --> Total execution time: 0.9441
DEBUG - 2013-11-27 23:56:27 --> Config Class Initialized
DEBUG - 2013-11-27 23:56:27 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:56:27 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:56:27 --> URI Class Initialized
DEBUG - 2013-11-27 23:56:27 --> Router Class Initialized
DEBUG - 2013-11-27 23:56:27 --> Output Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Security Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Input Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:56:28 --> Language Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Loader Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Session Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:56:28 --> Session routines successfully run
DEBUG - 2013-11-27 23:56:28 --> Controller Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:56:28 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:56:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:56:28 --> Model Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Model Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Model Class Initialized
DEBUG - 2013-11-27 23:56:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:56:28 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:56:28 --> Final output sent to browser
DEBUG - 2013-11-27 23:56:28 --> Total execution time: 0.9761
DEBUG - 2013-11-27 23:56:53 --> Config Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:56:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:56:53 --> URI Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Router Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Output Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Security Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Input Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:56:53 --> Language Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Loader Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Session Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:56:53 --> Session routines successfully run
DEBUG - 2013-11-27 23:56:53 --> Controller Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:56:53 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:56:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:56:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:56:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Model Class Initialized
DEBUG - 2013-11-27 23:56:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:56:53 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:56:53 --> Final output sent to browser
DEBUG - 2013-11-27 23:56:54 --> Total execution time: 0.9811
DEBUG - 2013-11-27 23:57:12 --> Config Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:57:12 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:57:12 --> URI Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Router Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Output Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Security Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Input Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:57:12 --> Language Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Loader Class Initialized
DEBUG - 2013-11-27 23:57:12 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:57:13 --> Session Class Initialized
DEBUG - 2013-11-27 23:57:13 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:57:13 --> Session routines successfully run
DEBUG - 2013-11-27 23:57:13 --> Controller Class Initialized
DEBUG - 2013-11-27 23:57:13 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:57:13 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:57:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:57:13 --> Model Class Initialized
DEBUG - 2013-11-27 23:57:13 --> Model Class Initialized
DEBUG - 2013-11-27 23:57:13 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:57:13 --> Model Class Initialized
DEBUG - 2013-11-27 23:57:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:57:13 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:57:13 --> Final output sent to browser
DEBUG - 2013-11-27 23:57:13 --> Total execution time: 0.9481
DEBUG - 2013-11-27 23:57:31 --> Config Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:57:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:57:31 --> URI Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Router Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Output Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Security Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Input Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:57:31 --> Language Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Loader Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Session Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:57:31 --> Session routines successfully run
DEBUG - 2013-11-27 23:57:31 --> Controller Class Initialized
DEBUG - 2013-11-27 23:57:31 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:57:32 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:57:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:57:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:57:32 --> Model Class Initialized
DEBUG - 2013-11-27 23:57:32 --> Model Class Initialized
DEBUG - 2013-11-27 23:57:32 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:57:32 --> Model Class Initialized
DEBUG - 2013-11-27 23:57:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:57:32 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:57:32 --> Final output sent to browser
DEBUG - 2013-11-27 23:57:32 --> Total execution time: 0.9361
DEBUG - 2013-11-27 23:59:28 --> Config Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:59:28 --> URI Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Router Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Output Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Security Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Input Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:59:28 --> Language Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Loader Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Session Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:59:28 --> Session routines successfully run
DEBUG - 2013-11-27 23:59:28 --> Controller Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:59:28 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:59:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:59:28 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:28 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:59:29 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:59:29 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:59:29 --> Final output sent to browser
DEBUG - 2013-11-27 23:59:29 --> Total execution time: 0.9851
DEBUG - 2013-11-27 23:59:35 --> Config Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:59:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:59:35 --> URI Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Router Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Output Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Security Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Input Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:59:35 --> Language Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Loader Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Session Class Initialized
DEBUG - 2013-11-27 23:59:35 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:59:36 --> Session routines successfully run
DEBUG - 2013-11-27 23:59:36 --> Controller Class Initialized
DEBUG - 2013-11-27 23:59:36 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:59:36 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:59:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:59:36 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:36 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:36 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:59:36 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:59:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:59:36 --> Final output sent to browser
DEBUG - 2013-11-27 23:59:36 --> Total execution time: 0.9701
DEBUG - 2013-11-27 23:59:42 --> Config Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:59:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:59:42 --> URI Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Router Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Output Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Security Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Input Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:59:42 --> Language Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Loader Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Session Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:59:42 --> Session routines successfully run
DEBUG - 2013-11-27 23:59:42 --> Controller Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:59:42 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:59:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:59:42 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:42 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:59:43 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:59:43 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:59:43 --> Final output sent to browser
DEBUG - 2013-11-27 23:59:43 --> Total execution time: 1.0241
DEBUG - 2013-11-27 23:59:57 --> Config Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Hooks Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Utf8 Class Initialized
DEBUG - 2013-11-27 23:59:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-27 23:59:57 --> URI Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Router Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Output Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Security Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Input Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-27 23:59:57 --> Language Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Loader Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Database Driver Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Session Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Helper loaded: string_helper
DEBUG - 2013-11-27 23:59:57 --> Session routines successfully run
DEBUG - 2013-11-27 23:59:57 --> Controller Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Helper loaded: form_helper
DEBUG - 2013-11-27 23:59:57 --> Helper loaded: url_helper
DEBUG - 2013-11-27 23:59:57 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-27 23:59:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-27 23:59:57 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Image Lib Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Model Class Initialized
DEBUG - 2013-11-27 23:59:57 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-27 23:59:58 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-27 23:59:58 --> Final output sent to browser
DEBUG - 2013-11-27 23:59:58 --> Total execution time: 0.9991
