<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-12-12 23:37:34 --> Config Class Initialized
DEBUG - 2013-12-12 23:37:34 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:37:34 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:37:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:37:34 --> URI Class Initialized
DEBUG - 2013-12-12 23:37:34 --> Router Class Initialized
DEBUG - 2013-12-12 23:37:34 --> No URI present. Default controller set.
DEBUG - 2013-12-12 23:37:34 --> Output Class Initialized
DEBUG - 2013-12-12 23:37:34 --> Security Class Initialized
DEBUG - 2013-12-12 23:37:34 --> Input Class Initialized
DEBUG - 2013-12-12 23:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:37:34 --> Language Class Initialized
DEBUG - 2013-12-12 23:37:34 --> Loader Class Initialized
DEBUG - 2013-12-12 23:37:34 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:37:35 --> Session Class Initialized
DEBUG - 2013-12-12 23:37:35 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:37:35 --> Session routines successfully run
DEBUG - 2013-12-12 23:37:35 --> Controller Class Initialized
DEBUG - 2013-12-12 23:37:35 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:37:35 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:37:36 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:37:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:37:36 --> Model Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Model Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:37:36 --> Upload Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:37:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:37:36 --> Config Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:37:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:37:36 --> URI Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Router Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Output Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Security Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Input Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:37:36 --> Language Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Loader Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Session Class Initialized
DEBUG - 2013-12-12 23:37:36 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:37:37 --> Session routines successfully run
DEBUG - 2013-12-12 23:37:37 --> Controller Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:37:37 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:37:37 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:37:37 --> Model Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Model Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:37:37 --> Upload Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:37:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:37:37 --> Model Class Initialized
DEBUG - 2013-12-12 23:37:37 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-12 23:37:37 --> Final output sent to browser
DEBUG - 2013-12-12 23:37:37 --> Total execution time: 0.6360
DEBUG - 2013-12-12 23:37:37 --> Config Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:37:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:37:37 --> URI Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Router Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Output Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Security Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Input Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:37:37 --> Language Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Loader Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Session Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:37:37 --> Session routines successfully run
DEBUG - 2013-12-12 23:37:37 --> Controller Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:37:37 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:37:37 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:37:37 --> Model Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Model Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:37:37 --> Upload Class Initialized
DEBUG - 2013-12-12 23:37:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:37:37 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:37:37 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:39:46 --> Config Class Initialized
DEBUG - 2013-12-12 23:39:46 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:39:46 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:39:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:39:46 --> URI Class Initialized
DEBUG - 2013-12-12 23:39:46 --> Router Class Initialized
DEBUG - 2013-12-12 23:39:46 --> Output Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Security Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Input Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:39:47 --> Language Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Loader Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Session Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:39:47 --> Session routines successfully run
DEBUG - 2013-12-12 23:39:47 --> Controller Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:39:47 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:39:47 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:39:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:39:47 --> Model Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Model Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:39:47 --> Upload Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:39:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:39:47 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:39:47 --> Final output sent to browser
DEBUG - 2013-12-12 23:39:47 --> Total execution time: 0.1340
DEBUG - 2013-12-12 23:39:47 --> Config Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:39:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:39:47 --> URI Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Router Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Output Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Security Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Input Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:39:47 --> Language Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Loader Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Session Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:39:47 --> Session routines successfully run
DEBUG - 2013-12-12 23:39:47 --> Controller Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:39:47 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:39:47 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:39:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:39:47 --> Model Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Model Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:39:47 --> Upload Class Initialized
DEBUG - 2013-12-12 23:39:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:39:47 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:39:47 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:39:50 --> Config Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:39:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:39:50 --> URI Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Router Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Output Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Security Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Input Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:39:50 --> Language Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Loader Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Session Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:39:50 --> Session routines successfully run
DEBUG - 2013-12-12 23:39:50 --> Controller Class Initialized
DEBUG - 2013-12-12 23:39:50 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:39:50 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:39:50 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:41:06 --> Config Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:41:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:41:06 --> URI Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Router Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Output Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Security Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Input Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:41:06 --> Language Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Loader Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Session Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:41:06 --> Session routines successfully run
DEBUG - 2013-12-12 23:41:06 --> Controller Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:41:06 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:41:06 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:41:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:41:06 --> Model Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Model Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:41:06 --> Upload Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:41:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:41:06 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:41:06 --> Final output sent to browser
DEBUG - 2013-12-12 23:41:06 --> Total execution time: 1.2581
DEBUG - 2013-12-12 23:41:06 --> Config Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:41:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:41:06 --> URI Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Router Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Output Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Security Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Input Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:41:06 --> Language Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Loader Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Session Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:41:06 --> Session routines successfully run
DEBUG - 2013-12-12 23:41:06 --> Controller Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:41:06 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:41:06 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:41:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:41:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:41:07 --> Model Class Initialized
DEBUG - 2013-12-12 23:41:07 --> Model Class Initialized
DEBUG - 2013-12-12 23:41:07 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:41:07 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:41:07 --> Upload Class Initialized
DEBUG - 2013-12-12 23:41:07 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:41:07 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:41:07 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:41:08 --> Config Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:41:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:41:08 --> URI Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Router Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Output Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Security Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Input Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:41:08 --> Language Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Loader Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Session Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:41:08 --> Session routines successfully run
DEBUG - 2013-12-12 23:41:08 --> Controller Class Initialized
DEBUG - 2013-12-12 23:41:08 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:41:08 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:41:08 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:42:07 --> Config Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:42:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:42:07 --> URI Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Router Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Output Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Security Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Input Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:42:07 --> Language Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Loader Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Session Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:42:07 --> Session routines successfully run
DEBUG - 2013-12-12 23:42:07 --> Controller Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:42:07 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:42:07 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:42:07 --> Model Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Model Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:42:07 --> Upload Class Initialized
DEBUG - 2013-12-12 23:42:07 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:42:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:42:07 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:42:07 --> Final output sent to browser
DEBUG - 2013-12-12 23:42:07 --> Total execution time: 0.1630
DEBUG - 2013-12-12 23:42:08 --> Config Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:42:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:42:08 --> URI Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Router Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Output Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Security Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Input Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:42:08 --> Language Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Loader Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Session Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:42:08 --> Session garbage collection performed.
DEBUG - 2013-12-12 23:42:08 --> Session routines successfully run
DEBUG - 2013-12-12 23:42:08 --> Controller Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:42:08 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:42:08 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:42:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:42:08 --> Model Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Model Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:42:08 --> Upload Class Initialized
DEBUG - 2013-12-12 23:42:08 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:42:08 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:42:08 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:42:32 --> Config Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:42:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:42:32 --> URI Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Router Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Output Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Security Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Input Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:42:32 --> Language Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Loader Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Session Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:42:32 --> Session routines successfully run
DEBUG - 2013-12-12 23:42:32 --> Controller Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:42:32 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:42:32 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:42:32 --> Model Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Model Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:42:32 --> Upload Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:42:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:42:32 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:42:32 --> Final output sent to browser
DEBUG - 2013-12-12 23:42:32 --> Total execution time: 0.1670
DEBUG - 2013-12-12 23:42:32 --> Config Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:42:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:42:32 --> URI Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Router Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Output Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Security Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Input Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:42:32 --> Language Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Loader Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Session Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:42:32 --> Session routines successfully run
DEBUG - 2013-12-12 23:42:32 --> Controller Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:42:32 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:42:32 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:42:32 --> Model Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Model Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:42:32 --> Upload Class Initialized
DEBUG - 2013-12-12 23:42:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:42:32 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:42:32 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:44:33 --> Config Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:44:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:44:33 --> URI Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Router Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Output Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Security Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Input Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:44:33 --> Language Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Loader Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Session Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:44:33 --> Session routines successfully run
DEBUG - 2013-12-12 23:44:33 --> Controller Class Initialized
DEBUG - 2013-12-12 23:44:33 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:44:33 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:44:33 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:44:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:44:34 --> Model Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Model Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:44:34 --> Upload Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:44:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:44:34 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:44:34 --> Final output sent to browser
DEBUG - 2013-12-12 23:44:34 --> Total execution time: 0.1880
DEBUG - 2013-12-12 23:44:34 --> Config Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:44:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:44:34 --> URI Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Router Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Output Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Security Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Input Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:44:34 --> Language Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Loader Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Session Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:44:34 --> Session routines successfully run
DEBUG - 2013-12-12 23:44:34 --> Controller Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:44:34 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:44:34 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:44:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:44:34 --> Model Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Model Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:44:34 --> Upload Class Initialized
DEBUG - 2013-12-12 23:44:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:44:34 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:44:34 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:44:36 --> Config Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:44:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:44:36 --> URI Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Router Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Output Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Security Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Input Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:44:36 --> Language Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Loader Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Session Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:44:36 --> Session routines successfully run
DEBUG - 2013-12-12 23:44:36 --> Controller Class Initialized
DEBUG - 2013-12-12 23:44:36 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:44:36 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:44:36 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:44:49 --> Config Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:44:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:44:49 --> URI Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Router Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Output Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Security Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Input Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:44:49 --> Language Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Loader Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Session Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:44:49 --> Session routines successfully run
DEBUG - 2013-12-12 23:44:49 --> Controller Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:44:49 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:44:49 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:44:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:44:49 --> Model Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Model Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:44:49 --> Upload Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:44:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:44:49 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:44:49 --> Final output sent to browser
DEBUG - 2013-12-12 23:44:49 --> Total execution time: 0.1980
DEBUG - 2013-12-12 23:44:49 --> Config Class Initialized
DEBUG - 2013-12-12 23:44:49 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:44:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:44:50 --> URI Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Router Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Output Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Security Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Input Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:44:50 --> Language Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Loader Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Session Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:44:50 --> Session routines successfully run
DEBUG - 2013-12-12 23:44:50 --> Controller Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:44:50 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:44:50 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:44:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:44:50 --> Model Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Model Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:44:50 --> Upload Class Initialized
DEBUG - 2013-12-12 23:44:50 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:44:50 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:44:50 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:44:51 --> Config Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:44:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:44:51 --> URI Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Router Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Output Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Security Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Input Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:44:51 --> Language Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Loader Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Session Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:44:51 --> Session routines successfully run
DEBUG - 2013-12-12 23:44:51 --> Controller Class Initialized
DEBUG - 2013-12-12 23:44:51 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:44:51 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:44:51 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:45:07 --> Config Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:45:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:45:07 --> URI Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Router Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Output Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Security Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Input Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:45:07 --> Language Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Loader Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Session Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:45:07 --> Session garbage collection performed.
DEBUG - 2013-12-12 23:45:07 --> Session routines successfully run
DEBUG - 2013-12-12 23:45:07 --> Controller Class Initialized
DEBUG - 2013-12-12 23:45:07 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:45:07 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:45:07 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:45:21 --> Config Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:45:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:45:21 --> URI Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Router Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Output Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Security Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Input Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:45:21 --> Language Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Loader Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Session Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:45:21 --> Session routines successfully run
DEBUG - 2013-12-12 23:45:21 --> Controller Class Initialized
DEBUG - 2013-12-12 23:45:21 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:45:21 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:45:21 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:47:00 --> Config Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:47:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:47:00 --> URI Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Router Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Output Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Security Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Input Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:47:00 --> Language Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Loader Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Session Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:47:00 --> Session routines successfully run
DEBUG - 2013-12-12 23:47:00 --> Controller Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:47:00 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:47:00 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:47:00 --> Model Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Model Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:47:00 --> Upload Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:47:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:47:00 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:47:00 --> Final output sent to browser
DEBUG - 2013-12-12 23:47:00 --> Total execution time: 0.1890
DEBUG - 2013-12-12 23:47:00 --> Config Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:47:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:47:00 --> URI Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Router Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Output Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Security Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Input Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:47:00 --> Language Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Loader Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Session Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:47:00 --> Session routines successfully run
DEBUG - 2013-12-12 23:47:00 --> Controller Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:47:00 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:47:00 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:47:00 --> Model Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Model Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:47:00 --> Upload Class Initialized
DEBUG - 2013-12-12 23:47:00 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:47:00 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:47:00 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:47:21 --> Config Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:47:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:47:21 --> URI Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Router Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Output Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Security Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Input Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:47:21 --> Language Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Loader Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Session Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:47:21 --> Session routines successfully run
DEBUG - 2013-12-12 23:47:21 --> Controller Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:47:21 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:47:21 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:47:21 --> Model Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Model Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:47:21 --> Upload Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:47:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:47:21 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:47:21 --> Final output sent to browser
DEBUG - 2013-12-12 23:47:21 --> Total execution time: 0.1880
DEBUG - 2013-12-12 23:47:21 --> Config Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:47:21 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:47:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:47:22 --> URI Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Router Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Output Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Security Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Input Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:47:22 --> Language Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Loader Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Session Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:47:22 --> Session routines successfully run
DEBUG - 2013-12-12 23:47:22 --> Controller Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:47:22 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:47:22 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:47:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:47:22 --> Model Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Model Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:47:22 --> Upload Class Initialized
DEBUG - 2013-12-12 23:47:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:47:22 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:47:22 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:47:23 --> Config Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:47:23 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:47:23 --> URI Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Router Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Output Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Security Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Input Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:47:23 --> Language Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Loader Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Session Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:47:23 --> Session routines successfully run
DEBUG - 2013-12-12 23:47:23 --> Controller Class Initialized
DEBUG - 2013-12-12 23:47:23 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:47:23 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:47:23 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:48:13 --> Config Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Config Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:48:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:48:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:48:13 --> URI Class Initialized
DEBUG - 2013-12-12 23:48:13 --> URI Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Router Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Router Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Output Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Output Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Security Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Security Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Input Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Input Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:48:13 --> Language Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Language Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Loader Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Loader Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Session Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Session Class Initialized
DEBUG - 2013-12-12 23:48:13 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:48:13 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:48:13 --> Session routines successfully run
DEBUG - 2013-12-12 23:48:14 --> Session routines successfully run
DEBUG - 2013-12-12 23:48:14 --> Controller Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Controller Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:48:14 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:48:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:48:14 --> Model Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Model Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Model Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Model Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:48:14 --> Upload Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Upload Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:48:14 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:48:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:48:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:48:14 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:48:14 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:48:14 --> Final output sent to browser
DEBUG - 2013-12-12 23:48:14 --> Final output sent to browser
DEBUG - 2013-12-12 23:48:14 --> Total execution time: 0.2510
DEBUG - 2013-12-12 23:48:14 --> Total execution time: 0.2540
DEBUG - 2013-12-12 23:48:14 --> Config Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:48:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:48:14 --> URI Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Router Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Output Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Security Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Input Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:48:14 --> Language Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Loader Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Session Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:48:14 --> Session routines successfully run
DEBUG - 2013-12-12 23:48:14 --> Controller Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:48:14 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:48:14 --> Model Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Model Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:48:14 --> Upload Class Initialized
DEBUG - 2013-12-12 23:48:14 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:48:14 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:48:14 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:49:55 --> Config Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:49:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:49:55 --> URI Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Router Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Output Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Security Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Input Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:49:55 --> Language Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Loader Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Session Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:49:55 --> Session routines successfully run
DEBUG - 2013-12-12 23:49:55 --> Controller Class Initialized
DEBUG - 2013-12-12 23:49:55 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:49:55 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:49:55 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:51:32 --> Config Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:51:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:51:32 --> URI Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Router Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Output Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Security Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Input Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:51:32 --> Language Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Loader Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Session Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:51:32 --> Session garbage collection performed.
DEBUG - 2013-12-12 23:51:32 --> Session routines successfully run
DEBUG - 2013-12-12 23:51:32 --> Controller Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:51:32 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:51:32 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:51:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:51:32 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:51:32 --> Upload Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:51:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:51:32 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:51:32 --> Final output sent to browser
DEBUG - 2013-12-12 23:51:32 --> Total execution time: 0.2110
DEBUG - 2013-12-12 23:51:32 --> Config Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:51:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:51:32 --> URI Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Router Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Output Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Security Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Input Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:51:32 --> Language Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Loader Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Session Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:51:32 --> Session garbage collection performed.
DEBUG - 2013-12-12 23:51:32 --> Session routines successfully run
DEBUG - 2013-12-12 23:51:32 --> Controller Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:51:32 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:51:32 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:51:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:51:32 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:51:32 --> Upload Class Initialized
DEBUG - 2013-12-12 23:51:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:51:32 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:51:32 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:51:34 --> Config Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:51:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:51:34 --> URI Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Router Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Output Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Security Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Input Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:51:34 --> Language Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Loader Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Session Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:51:34 --> Session routines successfully run
DEBUG - 2013-12-12 23:51:34 --> Controller Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:51:34 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:51:34 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:51:34 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:34 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:34 --> XSS Filtering completed
DEBUG - 2013-12-12 23:51:34 --> Final output sent to browser
DEBUG - 2013-12-12 23:51:34 --> Total execution time: 0.3200
DEBUG - 2013-12-12 23:51:52 --> Config Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:51:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:51:52 --> URI Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Router Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Output Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Security Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Input Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:51:52 --> Language Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Loader Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Session Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:51:52 --> Session routines successfully run
DEBUG - 2013-12-12 23:51:52 --> Controller Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:51:52 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:51:52 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:51:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:51:52 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:51:52 --> Upload Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:51:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:51:52 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:51:52 --> Final output sent to browser
DEBUG - 2013-12-12 23:51:52 --> Total execution time: 0.2130
DEBUG - 2013-12-12 23:51:52 --> Config Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:51:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:51:52 --> URI Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Router Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Output Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Security Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Input Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:51:52 --> Language Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Loader Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Session Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:51:52 --> Session routines successfully run
DEBUG - 2013-12-12 23:51:52 --> Controller Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:51:52 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:51:52 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:51:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:51:52 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Model Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:51:52 --> Upload Class Initialized
DEBUG - 2013-12-12 23:51:52 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:51:52 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:51:52 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:52:04 --> Config Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:52:04 --> URI Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Router Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Output Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Security Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Input Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:52:04 --> Language Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Loader Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Session Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:52:04 --> Session routines successfully run
DEBUG - 2013-12-12 23:52:04 --> Controller Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:52:04 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:52:04 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:52:04 --> Model Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Model Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:52:04 --> Upload Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:52:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-12 23:52:04 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-12 23:52:04 --> Final output sent to browser
DEBUG - 2013-12-12 23:52:04 --> Total execution time: 0.2170
DEBUG - 2013-12-12 23:52:04 --> Config Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:52:04 --> URI Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Router Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Output Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Security Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Input Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:52:04 --> Language Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Loader Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Session Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:52:04 --> Session routines successfully run
DEBUG - 2013-12-12 23:52:04 --> Controller Class Initialized
DEBUG - 2013-12-12 23:52:04 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:52:04 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:52:05 --> Form Validation Class Initialized
DEBUG - 2013-12-12 23:52:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-12 23:52:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:52:05 --> Model Class Initialized
DEBUG - 2013-12-12 23:52:05 --> Model Class Initialized
DEBUG - 2013-12-12 23:52:05 --> Image Lib Class Initialized
DEBUG - 2013-12-12 23:52:05 --> Helper loaded: cookie_helper
DEBUG - 2013-12-12 23:52:05 --> Upload Class Initialized
DEBUG - 2013-12-12 23:52:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-12 23:52:05 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-12 23:52:05 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-12 23:52:11 --> Config Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:52:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:52:11 --> URI Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Router Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Output Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Security Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Input Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:52:11 --> Language Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Loader Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Session Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:52:11 --> Session routines successfully run
DEBUG - 2013-12-12 23:52:11 --> Controller Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:52:11 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:52:11 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:52:11 --> Model Class Initialized
DEBUG - 2013-12-12 23:52:11 --> Model Class Initialized
DEBUG - 2013-12-12 23:52:11 --> XSS Filtering completed
DEBUG - 2013-12-12 23:52:11 --> Final output sent to browser
DEBUG - 2013-12-12 23:52:11 --> Total execution time: 0.1760
DEBUG - 2013-12-12 23:52:14 --> Config Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Hooks Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Utf8 Class Initialized
DEBUG - 2013-12-12 23:52:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-12 23:52:14 --> URI Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Router Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Output Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Security Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Input Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-12 23:52:14 --> Language Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Loader Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Database Driver Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Session Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Helper loaded: string_helper
DEBUG - 2013-12-12 23:52:14 --> Session routines successfully run
DEBUG - 2013-12-12 23:52:14 --> Controller Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Helper loaded: form_helper
DEBUG - 2013-12-12 23:52:14 --> Helper loaded: url_helper
DEBUG - 2013-12-12 23:52:14 --> Helper loaded: security_helper
DEBUG - 2013-12-12 23:52:14 --> Model Class Initialized
DEBUG - 2013-12-12 23:52:14 --> Model Class Initialized
DEBUG - 2013-12-12 23:52:14 --> XSS Filtering completed
DEBUG - 2013-12-12 23:52:14 --> Final output sent to browser
DEBUG - 2013-12-12 23:52:14 --> Total execution time: 0.2010
