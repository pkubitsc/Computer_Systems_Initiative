<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-12-04 01:14:31 --> Config Class Initialized
DEBUG - 2013-12-04 01:14:31 --> Hooks Class Initialized
DEBUG - 2013-12-04 01:14:31 --> Utf8 Class Initialized
DEBUG - 2013-12-04 01:14:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 01:14:31 --> URI Class Initialized
DEBUG - 2013-12-04 01:14:31 --> Router Class Initialized
DEBUG - 2013-12-04 01:14:31 --> Output Class Initialized
DEBUG - 2013-12-04 01:14:31 --> Security Class Initialized
DEBUG - 2013-12-04 01:14:31 --> Input Class Initialized
DEBUG - 2013-12-04 01:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 01:14:31 --> Language Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Loader Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Database Driver Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Session Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Helper loaded: string_helper
DEBUG - 2013-12-04 01:14:32 --> Session routines successfully run
DEBUG - 2013-12-04 01:14:32 --> Controller Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Helper loaded: form_helper
DEBUG - 2013-12-04 01:14:32 --> Helper loaded: url_helper
DEBUG - 2013-12-04 01:14:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 01:14:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:14:32 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Image Lib Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 01:14:32 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 01:14:33 --> Config Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Hooks Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Utf8 Class Initialized
DEBUG - 2013-12-04 01:14:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 01:14:33 --> URI Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Router Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Output Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Security Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Input Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 01:14:33 --> Language Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Loader Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Database Driver Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Session Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Helper loaded: string_helper
DEBUG - 2013-12-04 01:14:33 --> A session cookie was not found.
DEBUG - 2013-12-04 01:14:33 --> Session routines successfully run
DEBUG - 2013-12-04 01:14:33 --> Controller Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Helper loaded: form_helper
DEBUG - 2013-12-04 01:14:33 --> Helper loaded: url_helper
DEBUG - 2013-12-04 01:14:33 --> Form Validation Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 01:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:14:33 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Image Lib Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 01:14:33 --> Upload Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:14:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 01:14:33 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:33 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 01:14:33 --> Final output sent to browser
DEBUG - 2013-12-04 01:14:33 --> Total execution time: 0.2300
DEBUG - 2013-12-04 01:14:33 --> Config Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Hooks Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Utf8 Class Initialized
DEBUG - 2013-12-04 01:14:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 01:14:33 --> URI Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Router Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Output Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Security Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Input Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 01:14:33 --> Language Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Loader Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Database Driver Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Session Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Helper loaded: string_helper
DEBUG - 2013-12-04 01:14:33 --> Session routines successfully run
DEBUG - 2013-12-04 01:14:33 --> Controller Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Helper loaded: form_helper
DEBUG - 2013-12-04 01:14:33 --> Helper loaded: url_helper
DEBUG - 2013-12-04 01:14:33 --> Form Validation Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 01:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:14:33 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Model Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Image Lib Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 01:14:33 --> Upload Class Initialized
DEBUG - 2013-12-04 01:14:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:14:33 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 01:14:33 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 01:58:36 --> Config Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Hooks Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Utf8 Class Initialized
DEBUG - 2013-12-04 01:58:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 01:58:36 --> URI Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Router Class Initialized
DEBUG - 2013-12-04 01:58:36 --> No URI present. Default controller set.
DEBUG - 2013-12-04 01:58:36 --> Output Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Security Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Input Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 01:58:36 --> Language Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Loader Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Database Driver Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Session Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Helper loaded: string_helper
DEBUG - 2013-12-04 01:58:36 --> Session routines successfully run
DEBUG - 2013-12-04 01:58:36 --> Controller Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Helper loaded: form_helper
DEBUG - 2013-12-04 01:58:36 --> Helper loaded: url_helper
DEBUG - 2013-12-04 01:58:36 --> Form Validation Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 01:58:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:58:36 --> Model Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Model Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Image Lib Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 01:58:36 --> Upload Class Initialized
DEBUG - 2013-12-04 01:58:36 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:58:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 01:58:37 --> Config Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Hooks Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Utf8 Class Initialized
DEBUG - 2013-12-04 01:58:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 01:58:37 --> URI Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Router Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Output Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Security Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Input Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 01:58:37 --> Language Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Loader Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Database Driver Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Session Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Helper loaded: string_helper
DEBUG - 2013-12-04 01:58:37 --> Session routines successfully run
DEBUG - 2013-12-04 01:58:37 --> Controller Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Helper loaded: form_helper
DEBUG - 2013-12-04 01:58:37 --> Helper loaded: url_helper
DEBUG - 2013-12-04 01:58:37 --> Form Validation Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 01:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:58:37 --> Model Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Model Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Image Lib Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 01:58:37 --> Upload Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:58:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 01:58:37 --> Model Class Initialized
DEBUG - 2013-12-04 01:58:37 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 01:58:37 --> Final output sent to browser
DEBUG - 2013-12-04 01:58:37 --> Total execution time: 0.1590
DEBUG - 2013-12-04 01:58:37 --> Config Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Hooks Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Utf8 Class Initialized
DEBUG - 2013-12-04 01:58:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 01:58:37 --> URI Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Router Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Output Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Security Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Input Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 01:58:37 --> Language Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Loader Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Database Driver Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Session Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Helper loaded: string_helper
DEBUG - 2013-12-04 01:58:37 --> Session routines successfully run
DEBUG - 2013-12-04 01:58:37 --> Controller Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Helper loaded: form_helper
DEBUG - 2013-12-04 01:58:37 --> Helper loaded: url_helper
DEBUG - 2013-12-04 01:58:37 --> Form Validation Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 01:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:58:37 --> Model Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Model Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Image Lib Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 01:58:37 --> Upload Class Initialized
DEBUG - 2013-12-04 01:58:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 01:58:37 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 01:58:37 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 04:06:42 --> Config Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Hooks Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Utf8 Class Initialized
DEBUG - 2013-12-04 04:06:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 04:06:42 --> URI Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Router Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Output Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Security Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Input Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 04:06:42 --> Language Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Loader Class Initialized
DEBUG - 2013-12-04 04:06:42 --> Database Driver Class Initialized
ERROR - 2013-12-04 04:06:42 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-12-04 04:06:43 --> Session Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Helper loaded: string_helper
DEBUG - 2013-12-04 04:06:43 --> Session routines successfully run
DEBUG - 2013-12-04 04:06:43 --> Controller Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Helper loaded: form_helper
DEBUG - 2013-12-04 04:06:43 --> Helper loaded: url_helper
DEBUG - 2013-12-04 04:06:43 --> Form Validation Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 04:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 04:06:43 --> Model Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Model Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Image Lib Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 04:06:43 --> Upload Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 04:06:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 04:06:43 --> Model Class Initialized
DEBUG - 2013-12-04 04:06:43 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 04:06:43 --> Final output sent to browser
DEBUG - 2013-12-04 04:06:43 --> Total execution time: 0.9981
DEBUG - 2013-12-04 04:06:43 --> Config Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Hooks Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Utf8 Class Initialized
DEBUG - 2013-12-04 04:06:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 04:06:43 --> URI Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Router Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Output Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Security Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Input Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 04:06:43 --> Language Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Loader Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Database Driver Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Session Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Helper loaded: string_helper
DEBUG - 2013-12-04 04:06:43 --> Session routines successfully run
DEBUG - 2013-12-04 04:06:43 --> Controller Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Helper loaded: form_helper
DEBUG - 2013-12-04 04:06:43 --> Helper loaded: url_helper
DEBUG - 2013-12-04 04:06:43 --> Form Validation Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 04:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 04:06:43 --> Model Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Model Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Image Lib Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 04:06:43 --> Upload Class Initialized
DEBUG - 2013-12-04 04:06:43 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 04:06:43 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 04:06:43 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:35:09 --> Config Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:35:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:35:09 --> URI Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Router Class Initialized
DEBUG - 2013-12-04 10:35:09 --> No URI present. Default controller set.
DEBUG - 2013-12-04 10:35:09 --> Output Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Security Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Input Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:35:09 --> Language Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Loader Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Session Class Initialized
DEBUG - 2013-12-04 10:35:09 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:35:10 --> Session routines successfully run
DEBUG - 2013-12-04 10:35:10 --> Controller Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:35:10 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:35:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:35:10 --> Model Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Model Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:35:10 --> Upload Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:35:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:35:10 --> Config Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:35:10 --> URI Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Router Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Output Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Security Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Input Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:35:10 --> Language Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Loader Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Session Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:35:10 --> Session routines successfully run
DEBUG - 2013-12-04 10:35:10 --> Controller Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:35:10 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:35:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:35:10 --> Model Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Model Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:35:10 --> Upload Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:35:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:35:10 --> Model Class Initialized
DEBUG - 2013-12-04 10:35:10 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:35:10 --> Final output sent to browser
DEBUG - 2013-12-04 10:35:10 --> Total execution time: 0.2380
DEBUG - 2013-12-04 10:35:10 --> Config Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:35:10 --> URI Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Router Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Output Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Security Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Input Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:35:10 --> Language Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Loader Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Session Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:35:10 --> Session routines successfully run
DEBUG - 2013-12-04 10:35:10 --> Controller Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:35:10 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:35:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:35:10 --> Model Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Model Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:35:10 --> Upload Class Initialized
DEBUG - 2013-12-04 10:35:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:35:10 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:35:10 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:42:05 --> Config Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:42:05 --> URI Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Router Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Output Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Security Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Input Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:42:05 --> Language Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Loader Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Session Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:42:05 --> Session routines successfully run
DEBUG - 2013-12-04 10:42:05 --> Controller Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:42:05 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:42:05 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:42:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:42:05 --> Model Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Model Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:42:05 --> Upload Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:42:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:42:05 --> Model Class Initialized
DEBUG - 2013-12-04 10:42:05 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:42:05 --> Final output sent to browser
DEBUG - 2013-12-04 10:42:05 --> Total execution time: 0.2240
DEBUG - 2013-12-04 10:42:05 --> Config Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:42:05 --> URI Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Router Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Output Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Security Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Input Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:42:05 --> Language Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Loader Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Session Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:42:05 --> Session routines successfully run
DEBUG - 2013-12-04 10:42:05 --> Controller Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:42:05 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:42:05 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:42:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:42:05 --> Model Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Model Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:42:05 --> Upload Class Initialized
DEBUG - 2013-12-04 10:42:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:42:05 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:42:05 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:43:12 --> Config Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:43:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:43:12 --> URI Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Router Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Output Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Security Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Input Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:43:12 --> Language Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Loader Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Session Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:43:12 --> Session routines successfully run
DEBUG - 2013-12-04 10:43:12 --> Controller Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:43:12 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:43:12 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:43:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:12 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:43:12 --> Upload Class Initialized
DEBUG - 2013-12-04 10:43:12 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:43:12 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:12 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:43:12 --> Final output sent to browser
DEBUG - 2013-12-04 10:43:12 --> Total execution time: 0.1910
DEBUG - 2013-12-04 10:43:13 --> Config Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:43:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:43:13 --> URI Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Router Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Output Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Security Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Input Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:43:13 --> Language Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Loader Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Session Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:43:13 --> Session routines successfully run
DEBUG - 2013-12-04 10:43:13 --> Controller Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:43:13 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:43:13 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:13 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:43:13 --> Upload Class Initialized
DEBUG - 2013-12-04 10:43:13 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:13 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:43:13 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:43:22 --> Config Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:43:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:43:22 --> URI Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Router Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Output Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Security Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Input Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:43:22 --> Language Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Loader Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Session Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:43:22 --> Session garbage collection performed.
DEBUG - 2013-12-04 10:43:22 --> Session routines successfully run
DEBUG - 2013-12-04 10:43:22 --> Controller Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:43:22 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:43:22 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:22 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:43:22 --> Upload Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:43:22 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:22 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:43:22 --> Final output sent to browser
DEBUG - 2013-12-04 10:43:22 --> Total execution time: 0.2310
DEBUG - 2013-12-04 10:43:22 --> Config Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:43:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:43:22 --> URI Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Router Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Output Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Security Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Input Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:43:22 --> Language Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Loader Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Session Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:43:22 --> Session garbage collection performed.
DEBUG - 2013-12-04 10:43:22 --> Session routines successfully run
DEBUG - 2013-12-04 10:43:22 --> Controller Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:43:22 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:43:22 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:43:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:22 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:43:22 --> Upload Class Initialized
DEBUG - 2013-12-04 10:43:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:22 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:43:22 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:43:47 --> Config Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:43:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:43:47 --> URI Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Router Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Output Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Security Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Input Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:43:47 --> Language Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Loader Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Session Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:43:47 --> Session routines successfully run
DEBUG - 2013-12-04 10:43:47 --> Controller Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:43:47 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:43:47 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:43:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:47 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:43:47 --> Upload Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:43:47 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:47 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:43:47 --> Final output sent to browser
DEBUG - 2013-12-04 10:43:47 --> Total execution time: 0.1990
DEBUG - 2013-12-04 10:43:47 --> Config Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:43:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:43:47 --> URI Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Router Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Output Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Security Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Input Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:43:47 --> Language Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Loader Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Session Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:43:47 --> Session routines successfully run
DEBUG - 2013-12-04 10:43:47 --> Controller Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:43:47 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:43:47 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:43:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:47 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Model Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:43:47 --> Upload Class Initialized
DEBUG - 2013-12-04 10:43:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:43:47 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:43:47 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:45:11 --> Config Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:45:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:45:11 --> URI Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Router Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Output Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Security Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Input Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:45:11 --> Language Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Loader Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Session Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:45:11 --> Session routines successfully run
DEBUG - 2013-12-04 10:45:11 --> Controller Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:45:11 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:45:11 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:45:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:11 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:45:11 --> Upload Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:45:11 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:11 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:45:11 --> Final output sent to browser
DEBUG - 2013-12-04 10:45:11 --> Total execution time: 0.1960
DEBUG - 2013-12-04 10:45:11 --> Config Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:45:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:45:11 --> URI Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Router Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Output Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Security Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Input Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:45:11 --> Language Class Initialized
DEBUG - 2013-12-04 10:45:11 --> Loader Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Session Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:45:12 --> Session routines successfully run
DEBUG - 2013-12-04 10:45:12 --> Controller Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:45:12 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:45:12 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:12 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:45:12 --> Upload Class Initialized
DEBUG - 2013-12-04 10:45:12 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:12 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:45:12 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:45:27 --> Config Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:45:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:45:27 --> URI Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Router Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Output Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Security Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Input Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:45:27 --> Language Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Loader Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Session Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:45:27 --> Session routines successfully run
DEBUG - 2013-12-04 10:45:27 --> Controller Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:45:27 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:45:27 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:45:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:27 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:45:27 --> Upload Class Initialized
DEBUG - 2013-12-04 10:45:27 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:45:27 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:27 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:45:27 --> Final output sent to browser
DEBUG - 2013-12-04 10:45:27 --> Total execution time: 0.2030
DEBUG - 2013-12-04 10:45:28 --> Config Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:45:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:45:28 --> URI Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Router Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Output Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Security Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Input Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:45:28 --> Language Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Loader Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Session Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:45:28 --> Session routines successfully run
DEBUG - 2013-12-04 10:45:28 --> Controller Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:45:28 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:45:28 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:45:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:28 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:45:28 --> Upload Class Initialized
DEBUG - 2013-12-04 10:45:28 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:28 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:45:28 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:45:37 --> Config Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:45:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:45:37 --> URI Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Router Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Output Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Security Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Input Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:45:37 --> Language Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Loader Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Session Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:45:37 --> Session routines successfully run
DEBUG - 2013-12-04 10:45:37 --> Controller Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:45:37 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:45:37 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:37 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:45:37 --> Upload Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:45:37 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:37 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:45:37 --> Final output sent to browser
DEBUG - 2013-12-04 10:45:37 --> Total execution time: 0.2170
DEBUG - 2013-12-04 10:45:37 --> Config Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:45:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:45:37 --> URI Class Initialized
DEBUG - 2013-12-04 10:45:37 --> Router Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Output Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Security Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Input Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:45:38 --> Language Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Loader Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Session Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:45:38 --> Session routines successfully run
DEBUG - 2013-12-04 10:45:38 --> Controller Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:45:38 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:45:38 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:45:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:38 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:45:38 --> Upload Class Initialized
DEBUG - 2013-12-04 10:45:38 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:38 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:45:38 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:45:56 --> Config Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:45:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:45:56 --> URI Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Router Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Output Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Security Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Input Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:45:56 --> Language Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Loader Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Session Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:45:56 --> Session garbage collection performed.
DEBUG - 2013-12-04 10:45:56 --> Session routines successfully run
DEBUG - 2013-12-04 10:45:56 --> Controller Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:45:56 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:45:56 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:45:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:45:56 --> Upload Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:45:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:56 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:45:56 --> Final output sent to browser
DEBUG - 2013-12-04 10:45:56 --> Total execution time: 0.2240
DEBUG - 2013-12-04 10:45:56 --> Config Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:45:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:45:56 --> URI Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Router Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Output Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Security Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Input Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:45:56 --> Language Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Loader Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Session Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:45:56 --> Session garbage collection performed.
DEBUG - 2013-12-04 10:45:56 --> Session routines successfully run
DEBUG - 2013-12-04 10:45:56 --> Controller Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:45:56 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:45:56 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:45:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:45:56 --> Upload Class Initialized
DEBUG - 2013-12-04 10:45:56 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:45:56 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:45:56 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:46:05 --> Config Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:46:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:46:05 --> URI Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Router Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Output Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Security Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Input Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:46:05 --> Language Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Loader Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Session Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:46:05 --> Session routines successfully run
DEBUG - 2013-12-04 10:46:05 --> Controller Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:46:05 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:46:05 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:46:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:46:05 --> Model Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Model Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:46:05 --> Upload Class Initialized
DEBUG - 2013-12-04 10:46:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:46:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:46:05 --> Model Class Initialized
DEBUG - 2013-12-04 10:46:05 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:46:05 --> Final output sent to browser
DEBUG - 2013-12-04 10:46:05 --> Total execution time: 0.2210
DEBUG - 2013-12-04 10:46:06 --> Config Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:46:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:46:06 --> URI Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Router Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Output Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Security Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Input Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:46:06 --> Language Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Loader Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Session Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:46:06 --> Session routines successfully run
DEBUG - 2013-12-04 10:46:06 --> Controller Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:46:06 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:46:06 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:46:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:46:06 --> Model Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Model Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:46:06 --> Upload Class Initialized
DEBUG - 2013-12-04 10:46:06 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:46:06 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:46:06 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:47:26 --> Config Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:47:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:47:26 --> URI Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Router Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Output Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Security Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Input Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:47:26 --> Language Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Loader Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Session Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:47:26 --> Session routines successfully run
DEBUG - 2013-12-04 10:47:26 --> Controller Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:47:26 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:47:26 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:47:26 --> Model Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Model Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:47:26 --> Upload Class Initialized
DEBUG - 2013-12-04 10:47:26 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:47:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:47:27 --> Model Class Initialized
DEBUG - 2013-12-04 10:47:27 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:47:27 --> Final output sent to browser
DEBUG - 2013-12-04 10:47:27 --> Total execution time: 0.2860
DEBUG - 2013-12-04 10:47:27 --> Config Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:47:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:47:27 --> URI Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Router Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Output Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Security Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Input Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:47:27 --> Language Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Loader Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Session Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:47:27 --> Session routines successfully run
DEBUG - 2013-12-04 10:47:27 --> Controller Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:47:27 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:47:27 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:47:27 --> Model Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Model Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:47:27 --> Upload Class Initialized
DEBUG - 2013-12-04 10:47:27 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:47:27 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:47:27 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:48:56 --> Config Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:48:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:48:56 --> URI Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Router Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Output Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Security Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Input Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:48:56 --> Language Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Loader Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Session Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:48:56 --> Session routines successfully run
DEBUG - 2013-12-04 10:48:56 --> Controller Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:48:56 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:48:56 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:48:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:48:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:48:56 --> Upload Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:48:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:48:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:48:56 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:48:56 --> Final output sent to browser
DEBUG - 2013-12-04 10:48:56 --> Total execution time: 0.2340
DEBUG - 2013-12-04 10:48:56 --> Config Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:48:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:48:56 --> URI Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Router Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Output Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Security Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Input Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:48:56 --> Language Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Loader Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Session Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:48:56 --> Session routines successfully run
DEBUG - 2013-12-04 10:48:56 --> Controller Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:48:56 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:48:56 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:48:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:48:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Model Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:48:56 --> Upload Class Initialized
DEBUG - 2013-12-04 10:48:56 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:48:56 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:48:56 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 10:50:00 --> Config Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:50:00 --> URI Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Router Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Output Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Security Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Input Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:50:00 --> Language Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Loader Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Session Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:50:00 --> Session routines successfully run
DEBUG - 2013-12-04 10:50:00 --> Controller Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:50:00 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:50:00 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:50:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:50:00 --> Model Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Model Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:50:00 --> Upload Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:50:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 10:50:00 --> Model Class Initialized
DEBUG - 2013-12-04 10:50:00 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 10:50:00 --> Final output sent to browser
DEBUG - 2013-12-04 10:50:00 --> Total execution time: 0.2390
DEBUG - 2013-12-04 10:50:00 --> Config Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Hooks Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Utf8 Class Initialized
DEBUG - 2013-12-04 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 10:50:00 --> URI Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Router Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Output Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Security Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Input Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 10:50:00 --> Language Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Loader Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Database Driver Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Session Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Helper loaded: string_helper
DEBUG - 2013-12-04 10:50:00 --> Session routines successfully run
DEBUG - 2013-12-04 10:50:00 --> Controller Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Helper loaded: form_helper
DEBUG - 2013-12-04 10:50:00 --> Helper loaded: url_helper
DEBUG - 2013-12-04 10:50:00 --> Form Validation Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 10:50:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:50:00 --> Model Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Model Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Image Lib Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 10:50:00 --> Upload Class Initialized
DEBUG - 2013-12-04 10:50:00 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 10:50:00 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 10:50:00 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 11:02:57 --> Config Class Initialized
DEBUG - 2013-12-04 11:02:57 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:02:57 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:02:57 --> URI Class Initialized
DEBUG - 2013-12-04 11:02:57 --> Router Class Initialized
DEBUG - 2013-12-04 11:02:57 --> Output Class Initialized
DEBUG - 2013-12-04 11:02:57 --> Security Class Initialized
DEBUG - 2013-12-04 11:02:57 --> Input Class Initialized
DEBUG - 2013-12-04 11:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:02:57 --> Language Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Loader Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Session Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:02:58 --> Session routines successfully run
DEBUG - 2013-12-04 11:02:58 --> Controller Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:02:58 --> Form Validation Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:02:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:02:58 --> Model Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Model Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Image Lib Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 11:02:58 --> Upload Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:02:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 11:02:58 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-04 11:02:58 --> Final output sent to browser
DEBUG - 2013-12-04 11:02:58 --> Total execution time: 0.2640
DEBUG - 2013-12-04 11:02:58 --> Config Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:02:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:02:58 --> Config Class Initialized
DEBUG - 2013-12-04 11:02:58 --> URI Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Router Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Output Class Initialized
DEBUG - 2013-12-04 11:02:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:02:58 --> Security Class Initialized
DEBUG - 2013-12-04 11:02:58 --> URI Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Input Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Router Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:02:58 --> Output Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Language Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Security Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Loader Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Input Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:02:58 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Language Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Session Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Loader Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:02:58 --> Session routines successfully run
DEBUG - 2013-12-04 11:02:58 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Controller Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:02:58 --> Session Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:02:58 --> Form Validation Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Session routines successfully run
DEBUG - 2013-12-04 11:02:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:02:58 --> Controller Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:02:58 --> Model Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:02:58 --> Model Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Form Validation Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Image Lib Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 11:02:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:02:58 --> Upload Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Model Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:02:58 --> Model Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 11:02:58 --> Image Lib Class Initialized
ERROR - 2013-12-04 11:02:58 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 11:02:58 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 11:02:58 --> Upload Class Initialized
DEBUG - 2013-12-04 11:02:58 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:02:58 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 11:02:58 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 11:05:44 --> Config Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:05:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:05:44 --> URI Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Router Class Initialized
DEBUG - 2013-12-04 11:05:44 --> No URI present. Default controller set.
DEBUG - 2013-12-04 11:05:44 --> Output Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Security Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Input Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:05:44 --> Language Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Loader Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Session Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:05:44 --> Session routines successfully run
DEBUG - 2013-12-04 11:05:44 --> Controller Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:05:44 --> Form Validation Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:44 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Image Lib Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 11:05:44 --> Upload Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 11:05:44 --> Config Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:05:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:05:44 --> URI Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Router Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Output Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Security Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Input Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:05:44 --> Language Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Loader Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Session Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:05:44 --> Session routines successfully run
DEBUG - 2013-12-04 11:05:44 --> Controller Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:05:44 --> Form Validation Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:44 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Image Lib Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 11:05:44 --> Upload Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 11:05:44 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:44 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-04 11:05:44 --> Final output sent to browser
DEBUG - 2013-12-04 11:05:44 --> Total execution time: 0.2580
DEBUG - 2013-12-04 11:05:44 --> Config Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:05:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:05:44 --> URI Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Router Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Output Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Security Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Input Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:05:44 --> Language Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Loader Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Session Class Initialized
DEBUG - 2013-12-04 11:05:44 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:05:44 --> Session routines successfully run
DEBUG - 2013-12-04 11:05:44 --> Controller Class Initialized
DEBUG - 2013-12-04 11:05:45 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:05:45 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:05:45 --> Form Validation Class Initialized
DEBUG - 2013-12-04 11:05:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:05:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:45 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:45 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:45 --> Image Lib Class Initialized
DEBUG - 2013-12-04 11:05:45 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 11:05:45 --> Upload Class Initialized
DEBUG - 2013-12-04 11:05:45 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:45 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-04 11:05:45 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-04 11:05:48 --> Config Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:05:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:05:49 --> URI Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Router Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Output Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Security Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Input Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:05:49 --> Language Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Loader Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Session Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:05:49 --> Session routines successfully run
DEBUG - 2013-12-04 11:05:49 --> Controller Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:05:49 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:05:49 --> Form Validation Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:49 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Image Lib Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Helper loaded: cookie_helper
DEBUG - 2013-12-04 11:05:49 --> Upload Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 11:05:49 --> XSS Filtering completed
DEBUG - 2013-12-04 11:05:49 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-04 11:05:49 --> XSS Filtering completed
DEBUG - 2013-12-04 11:05:49 --> XSS Filtering completed
DEBUG - 2013-12-04 11:05:49 --> Config Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:05:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:05:49 --> URI Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Router Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Output Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Security Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Input Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:05:49 --> Language Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Loader Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Session Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:05:49 --> Session routines successfully run
DEBUG - 2013-12-04 11:05:49 --> Controller Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:05:49 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:05:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:05:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:05:49 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Image Lib Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Model Class Initialized
DEBUG - 2013-12-04 11:05:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 11:05:50 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-04 11:05:50 --> Final output sent to browser
DEBUG - 2013-12-04 11:05:50 --> Total execution time: 0.5910
DEBUG - 2013-12-04 11:07:20 --> Config Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Hooks Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Utf8 Class Initialized
DEBUG - 2013-12-04 11:07:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-04 11:07:20 --> URI Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Router Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Output Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Security Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Input Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-04 11:07:20 --> Language Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Loader Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Database Driver Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Session Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Helper loaded: string_helper
DEBUG - 2013-12-04 11:07:20 --> Session routines successfully run
DEBUG - 2013-12-04 11:07:20 --> Controller Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Helper loaded: form_helper
DEBUG - 2013-12-04 11:07:20 --> Helper loaded: url_helper
DEBUG - 2013-12-04 11:07:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-04 11:07:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-04 11:07:20 --> Model Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Model Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Image Lib Class Initialized
DEBUG - 2013-12-04 11:07:20 --> Model Class Initialized
DEBUG - 2013-12-04 11:07:21 --> Model Class Initialized
DEBUG - 2013-12-04 11:07:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-04 11:07:21 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-04 11:07:21 --> Final output sent to browser
DEBUG - 2013-12-04 11:07:21 --> Total execution time: 0.4540
