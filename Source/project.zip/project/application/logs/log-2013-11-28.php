<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-11-28 00:02:20 --> Config Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:02:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:02:20 --> URI Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Router Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Output Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Security Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Input Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:02:20 --> Language Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Loader Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Session Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:02:20 --> Session routines successfully run
DEBUG - 2013-11-28 00:02:20 --> Controller Class Initialized
DEBUG - 2013-11-28 00:02:20 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:02:21 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:02:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:02:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:02:21 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:21 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:21 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:02:21 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:02:21 --> DB Transaction Failure
ERROR - 2013-11-28 00:02:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1' at line 4
DEBUG - 2013-11-28 00:02:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 00:02:41 --> Config Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:02:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:02:41 --> URI Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Router Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Output Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Security Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Input Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:02:41 --> Language Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Loader Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Session Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:02:41 --> Session routines successfully run
DEBUG - 2013-11-28 00:02:41 --> Controller Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:02:41 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:02:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:02:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:02:41 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:02:41 --> DB Transaction Failure
ERROR - 2013-11-28 00:02:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1, 10' at line 4
DEBUG - 2013-11-28 00:02:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 00:02:54 --> Config Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:02:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:02:54 --> URI Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Router Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Output Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Security Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Input Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:02:54 --> Language Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Loader Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Session Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:02:54 --> Session routines successfully run
DEBUG - 2013-11-28 00:02:54 --> Controller Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:02:54 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:02:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:02:54 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Model Class Initialized
DEBUG - 2013-11-28 00:02:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:02:54 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:02:54 --> Final output sent to browser
DEBUG - 2013-11-28 00:02:54 --> Total execution time: 0.2790
DEBUG - 2013-11-28 00:03:07 --> Config Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:03:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:03:07 --> URI Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Router Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Output Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Security Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Input Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:03:07 --> Language Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Loader Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Session Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:03:07 --> Session routines successfully run
DEBUG - 2013-11-28 00:03:07 --> Controller Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:03:07 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:03:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:03:07 --> Model Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Model Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Model Class Initialized
DEBUG - 2013-11-28 00:03:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:03:07 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:03:07 --> Final output sent to browser
DEBUG - 2013-11-28 00:03:07 --> Total execution time: 0.2870
DEBUG - 2013-11-28 00:03:19 --> Config Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:03:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:03:19 --> URI Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Router Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Output Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Security Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Input Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:03:19 --> Language Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Loader Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Session Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:03:19 --> Session routines successfully run
DEBUG - 2013-11-28 00:03:19 --> Controller Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:03:19 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:03:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:03:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:03:19 --> Model Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Model Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:03:19 --> Model Class Initialized
DEBUG - 2013-11-28 00:03:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:03:20 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:03:20 --> Final output sent to browser
DEBUG - 2013-11-28 00:03:20 --> Total execution time: 0.3230
DEBUG - 2013-11-28 00:05:12 --> Config Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:05:13 --> URI Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Router Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Output Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Security Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Input Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:05:13 --> Language Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Loader Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Session Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:05:13 --> Session routines successfully run
DEBUG - 2013-11-28 00:05:13 --> Controller Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:05:13 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:05:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:05:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:05:13 --> Model Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Model Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Model Class Initialized
DEBUG - 2013-11-28 00:05:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:05:32 --> Config Class Initialized
DEBUG - 2013-11-28 00:05:32 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:05:32 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:05:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:05:33 --> URI Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Router Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Output Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Security Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Input Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:05:33 --> Language Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Loader Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Session Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:05:33 --> Session routines successfully run
DEBUG - 2013-11-28 00:05:33 --> Controller Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:05:33 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:05:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:05:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:05:33 --> Model Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Model Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Model Class Initialized
DEBUG - 2013-11-28 00:05:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:05:33 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:05:33 --> Final output sent to browser
DEBUG - 2013-11-28 00:05:33 --> Total execution time: 0.4600
DEBUG - 2013-11-28 00:08:15 --> Config Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:08:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:08:15 --> URI Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Router Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Output Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Security Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Input Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:08:15 --> Language Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Loader Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Session Class Initialized
DEBUG - 2013-11-28 00:08:15 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:08:16 --> Session routines successfully run
DEBUG - 2013-11-28 00:08:16 --> Controller Class Initialized
DEBUG - 2013-11-28 00:08:16 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:08:16 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:08:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:08:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:08:16 --> Model Class Initialized
DEBUG - 2013-11-28 00:08:16 --> Model Class Initialized
DEBUG - 2013-11-28 00:08:16 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:08:16 --> Model Class Initialized
DEBUG - 2013-11-28 00:08:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:08:16 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:08:16 --> Final output sent to browser
DEBUG - 2013-11-28 00:08:16 --> Total execution time: 0.3850
DEBUG - 2013-11-28 00:12:39 --> Config Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:12:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:12:39 --> URI Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Router Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Output Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Security Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Input Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:12:39 --> Language Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Loader Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Session Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:12:39 --> Session routines successfully run
DEBUG - 2013-11-28 00:12:39 --> Controller Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:12:39 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:12:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:12:39 --> Model Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Model Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Model Class Initialized
DEBUG - 2013-11-28 00:12:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:12:39 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:12:39 --> Final output sent to browser
DEBUG - 2013-11-28 00:12:39 --> Total execution time: 0.3630
DEBUG - 2013-11-28 00:13:08 --> Config Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:13:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:13:08 --> URI Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Router Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Output Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Security Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Input Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:13:08 --> Language Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Loader Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Session Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:13:08 --> Session routines successfully run
DEBUG - 2013-11-28 00:13:08 --> Controller Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:13:08 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:13:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:13:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:13:08 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:08 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:13:08 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:13:08 --> Final output sent to browser
DEBUG - 2013-11-28 00:13:08 --> Total execution time: 0.3480
DEBUG - 2013-11-28 00:13:11 --> Config Class Initialized
DEBUG - 2013-11-28 00:13:11 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:13:11 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:13:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:13:11 --> URI Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Router Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Output Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Security Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Input Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:13:12 --> Language Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Loader Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Session Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:13:12 --> Session routines successfully run
DEBUG - 2013-11-28 00:13:12 --> Controller Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:13:12 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:13:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:13:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:13:12 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:13:12 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:13:12 --> Final output sent to browser
DEBUG - 2013-11-28 00:13:12 --> Total execution time: 0.3430
DEBUG - 2013-11-28 00:13:31 --> Config Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:13:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:13:31 --> URI Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Router Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Output Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Security Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Input Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:13:31 --> Language Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Loader Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Session Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:13:31 --> Session routines successfully run
DEBUG - 2013-11-28 00:13:31 --> Controller Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:13:31 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:13:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:13:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:13:31 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:13:31 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:13:31 --> Final output sent to browser
DEBUG - 2013-11-28 00:13:31 --> Total execution time: 0.3860
DEBUG - 2013-11-28 00:13:45 --> Config Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:13:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:13:45 --> URI Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Router Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Output Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Security Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Input Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:13:45 --> Language Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Loader Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Session Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:13:45 --> Session routines successfully run
DEBUG - 2013-11-28 00:13:45 --> Controller Class Initialized
DEBUG - 2013-11-28 00:13:45 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:13:46 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:13:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:13:46 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:46 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:46 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:13:46 --> Model Class Initialized
DEBUG - 2013-11-28 00:13:46 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 00:13:46 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 25
ERROR - 2013-11-28 00:13:46 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 25
ERROR - 2013-11-28 00:13:46 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 25
DEBUG - 2013-11-28 00:13:46 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:13:46 --> Final output sent to browser
DEBUG - 2013-11-28 00:13:46 --> Total execution time: 0.4120
DEBUG - 2013-11-28 00:15:58 --> Config Class Initialized
DEBUG - 2013-11-28 00:15:58 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:15:58 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:15:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:15:58 --> URI Class Initialized
DEBUG - 2013-11-28 00:15:58 --> Router Class Initialized
DEBUG - 2013-11-28 00:15:58 --> Output Class Initialized
DEBUG - 2013-11-28 00:15:58 --> Security Class Initialized
DEBUG - 2013-11-28 00:15:58 --> Input Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:15:59 --> Language Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Loader Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Session Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:15:59 --> Session routines successfully run
DEBUG - 2013-11-28 00:15:59 --> Controller Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:15:59 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:15:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:15:59 --> Model Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Model Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Model Class Initialized
DEBUG - 2013-11-28 00:15:59 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:15:59 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:15:59 --> Final output sent to browser
DEBUG - 2013-11-28 00:15:59 --> Total execution time: 0.3760
DEBUG - 2013-11-28 00:16:19 --> Config Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:16:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:16:19 --> URI Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Router Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Output Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Security Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Input Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:16:19 --> Language Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Loader Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Session Class Initialized
DEBUG - 2013-11-28 00:16:19 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:16:22 --> Session garbage collection performed.
DEBUG - 2013-11-28 00:16:22 --> Session routines successfully run
DEBUG - 2013-11-28 00:16:22 --> Controller Class Initialized
DEBUG - 2013-11-28 00:16:22 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:16:22 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:16:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:16:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:16:22 --> Model Class Initialized
DEBUG - 2013-11-28 00:16:22 --> Model Class Initialized
DEBUG - 2013-11-28 00:16:22 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:16:22 --> Model Class Initialized
DEBUG - 2013-11-28 00:16:22 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 00:16:22 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 25
ERROR - 2013-11-28 00:16:22 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 25
ERROR - 2013-11-28 00:16:22 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 25
DEBUG - 2013-11-28 00:16:22 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:16:22 --> Final output sent to browser
DEBUG - 2013-11-28 00:16:22 --> Total execution time: 3.4132
DEBUG - 2013-11-28 00:16:45 --> Config Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:16:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:16:45 --> URI Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Router Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Output Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Security Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Input Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:16:45 --> Language Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Loader Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Session Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:16:45 --> Session routines successfully run
DEBUG - 2013-11-28 00:16:45 --> Controller Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:16:45 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:16:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:16:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:16:45 --> Model Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Model Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Model Class Initialized
DEBUG - 2013-11-28 00:16:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:16:45 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:16:45 --> Final output sent to browser
DEBUG - 2013-11-28 00:16:45 --> Total execution time: 0.4240
DEBUG - 2013-11-28 00:18:30 --> Config Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:18:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:18:30 --> URI Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Router Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Output Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Security Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Input Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:18:30 --> Language Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Loader Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Session Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:18:30 --> Session routines successfully run
DEBUG - 2013-11-28 00:18:30 --> Controller Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:18:30 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:18:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:18:30 --> Model Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Model Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Model Class Initialized
DEBUG - 2013-11-28 00:18:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:18:30 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:18:30 --> Final output sent to browser
DEBUG - 2013-11-28 00:18:30 --> Total execution time: 0.4050
DEBUG - 2013-11-28 00:18:50 --> Config Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:18:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:18:50 --> URI Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Router Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Output Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Security Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Input Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:18:50 --> Language Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Loader Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Session Class Initialized
DEBUG - 2013-11-28 00:18:50 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:18:51 --> Session routines successfully run
DEBUG - 2013-11-28 00:18:51 --> Controller Class Initialized
DEBUG - 2013-11-28 00:18:51 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:18:51 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:18:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:18:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:18:51 --> Model Class Initialized
DEBUG - 2013-11-28 00:18:51 --> Model Class Initialized
DEBUG - 2013-11-28 00:18:51 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:18:51 --> Model Class Initialized
DEBUG - 2013-11-28 00:18:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:18:51 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:18:51 --> Final output sent to browser
DEBUG - 2013-11-28 00:18:51 --> Total execution time: 0.4610
DEBUG - 2013-11-28 00:22:20 --> Config Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:22:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:22:20 --> URI Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Router Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Output Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Security Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Input Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:22:20 --> Language Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Loader Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Session Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:22:20 --> Session routines successfully run
DEBUG - 2013-11-28 00:22:20 --> Controller Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:22:20 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:22:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:22:20 --> Model Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Model Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Model Class Initialized
DEBUG - 2013-11-28 00:22:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:22:36 --> Config Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:22:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:22:36 --> URI Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Router Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Output Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Security Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Input Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:22:36 --> Language Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Loader Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Session Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:22:36 --> Session routines successfully run
DEBUG - 2013-11-28 00:22:36 --> Controller Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:22:36 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:22:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:22:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:22:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:22:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:22:36 --> Final output sent to browser
DEBUG - 2013-11-28 00:22:36 --> Total execution time: 0.4150
DEBUG - 2013-11-28 00:23:08 --> Config Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:23:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:23:08 --> URI Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Router Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Output Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Security Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Input Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:23:08 --> Language Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Loader Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Session Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:23:08 --> Session routines successfully run
DEBUG - 2013-11-28 00:23:08 --> Controller Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:23:08 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:23:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:23:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:23:08 --> Model Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Model Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Model Class Initialized
DEBUG - 2013-11-28 00:23:08 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:23:08 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:23:08 --> Final output sent to browser
DEBUG - 2013-11-28 00:23:08 --> Total execution time: 0.4230
DEBUG - 2013-11-28 00:23:45 --> Config Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:23:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:23:45 --> URI Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Router Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Output Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Security Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Input Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:23:45 --> Language Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Loader Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Session Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:23:45 --> Session routines successfully run
DEBUG - 2013-11-28 00:23:45 --> Controller Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:23:45 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:23:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:23:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:23:45 --> Model Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Model Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Model Class Initialized
DEBUG - 2013-11-28 00:23:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:23:45 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:23:45 --> Final output sent to browser
DEBUG - 2013-11-28 00:23:45 --> Total execution time: 0.4430
DEBUG - 2013-11-28 00:24:57 --> Config Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:24:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:24:57 --> URI Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Router Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Output Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Security Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Input Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:24:57 --> Language Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Loader Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Session Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:24:57 --> Session routines successfully run
DEBUG - 2013-11-28 00:24:57 --> Controller Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:24:57 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:24:57 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:24:57 --> Model Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Model Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Model Class Initialized
DEBUG - 2013-11-28 00:24:57 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:24:57 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:24:57 --> Final output sent to browser
DEBUG - 2013-11-28 00:24:57 --> Total execution time: 0.5570
DEBUG - 2013-11-28 00:25:10 --> Config Class Initialized
DEBUG - 2013-11-28 00:25:10 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:25:10 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:25:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:25:10 --> URI Class Initialized
DEBUG - 2013-11-28 00:25:10 --> Router Class Initialized
DEBUG - 2013-11-28 00:25:10 --> Output Class Initialized
DEBUG - 2013-11-28 00:25:10 --> Security Class Initialized
DEBUG - 2013-11-28 00:25:10 --> Input Class Initialized
DEBUG - 2013-11-28 00:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:25:10 --> Language Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Loader Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Session Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:25:11 --> Session routines successfully run
DEBUG - 2013-11-28 00:25:11 --> Controller Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:25:11 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:25:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:25:11 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:25:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:25:11 --> Final output sent to browser
DEBUG - 2013-11-28 00:25:11 --> Total execution time: 0.4520
DEBUG - 2013-11-28 00:25:24 --> Config Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:25:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:25:24 --> URI Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Router Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Output Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Security Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Input Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:25:24 --> Language Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Loader Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Session Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:25:24 --> Session routines successfully run
DEBUG - 2013-11-28 00:25:24 --> Controller Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:25:24 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:25:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:25:24 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:25:24 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:25:24 --> Final output sent to browser
DEBUG - 2013-11-28 00:25:24 --> Total execution time: 0.4600
DEBUG - 2013-11-28 00:25:35 --> Config Class Initialized
DEBUG - 2013-11-28 00:25:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:25:35 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:25:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:25:36 --> URI Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Router Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Output Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Security Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Input Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:25:36 --> Language Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Loader Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Session Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:25:36 --> Session garbage collection performed.
DEBUG - 2013-11-28 00:25:36 --> Session routines successfully run
DEBUG - 2013-11-28 00:25:36 --> Controller Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:25:36 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:25:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:25:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:25:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:25:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:25:36 --> Final output sent to browser
DEBUG - 2013-11-28 00:25:36 --> Total execution time: 0.4690
DEBUG - 2013-11-28 00:26:25 --> Config Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:26:25 --> URI Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Router Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Output Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Security Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Input Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:26:25 --> Language Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Loader Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Session Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:26:25 --> Session routines successfully run
DEBUG - 2013-11-28 00:26:25 --> Controller Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:26:25 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:26:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:26:25 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:26:25 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:26:25 --> Final output sent to browser
DEBUG - 2013-11-28 00:26:25 --> Total execution time: 0.4790
DEBUG - 2013-11-28 00:26:26 --> Config Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:26:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:26:26 --> URI Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Router Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Output Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Security Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Input Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:26:26 --> Language Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Loader Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Session Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:26:26 --> Session routines successfully run
DEBUG - 2013-11-28 00:26:26 --> Controller Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:26:26 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:26:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:26:26 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:26 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 00:26:26 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-11-28 00:26:42 --> Config Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:26:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:26:42 --> URI Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Router Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Output Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Security Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Input Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:26:42 --> Language Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Loader Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Session Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:26:42 --> Session routines successfully run
DEBUG - 2013-11-28 00:26:42 --> Controller Class Initialized
DEBUG - 2013-11-28 00:26:42 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:26:43 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:26:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:26:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:26:43 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:26:43 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:26:43 --> Final output sent to browser
DEBUG - 2013-11-28 00:26:43 --> Total execution time: 0.4960
DEBUG - 2013-11-28 00:26:43 --> Config Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:26:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:26:43 --> URI Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Router Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Output Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Security Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Input Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:26:43 --> Language Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Loader Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Session Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:26:43 --> Session routines successfully run
DEBUG - 2013-11-28 00:26:43 --> Controller Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:26:43 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:26:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:26:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:26:43 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:43 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:26:44 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:44 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 00:26:44 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-11-28 00:26:54 --> Config Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:26:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:26:54 --> URI Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Router Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Output Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Security Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Input Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:26:54 --> Language Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Loader Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Session Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:26:54 --> Session routines successfully run
DEBUG - 2013-11-28 00:26:54 --> Controller Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:26:54 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:26:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:26:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:26:54 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Model Class Initialized
DEBUG - 2013-11-28 00:26:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:26:54 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:26:54 --> Final output sent to browser
DEBUG - 2013-11-28 00:26:54 --> Total execution time: 0.6080
DEBUG - 2013-11-28 00:27:10 --> Config Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:27:10 --> URI Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Router Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Output Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Security Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Input Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:27:10 --> Language Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Loader Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Session Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:27:10 --> Session routines successfully run
DEBUG - 2013-11-28 00:27:10 --> Controller Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:27:10 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:27:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:27:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:27:10 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:27:10 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:27:11 --> Final output sent to browser
DEBUG - 2013-11-28 00:27:11 --> Total execution time: 0.5370
DEBUG - 2013-11-28 00:27:38 --> Config Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:27:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:27:39 --> URI Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Router Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Output Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Security Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Input Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:27:39 --> Language Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Loader Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Session Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:27:39 --> Session garbage collection performed.
DEBUG - 2013-11-28 00:27:39 --> Session routines successfully run
DEBUG - 2013-11-28 00:27:39 --> Controller Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:27:39 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:27:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:27:39 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:27:39 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:27:39 --> Final output sent to browser
DEBUG - 2013-11-28 00:27:39 --> Total execution time: 0.5370
DEBUG - 2013-11-28 00:27:40 --> Config Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:27:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:27:40 --> URI Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Router Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Output Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Security Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Input Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:27:40 --> Language Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Loader Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Session Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:27:40 --> Session routines successfully run
DEBUG - 2013-11-28 00:27:40 --> Controller Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:27:40 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:27:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:27:40 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Model Class Initialized
DEBUG - 2013-11-28 00:27:40 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 00:27:40 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-11-28 00:28:17 --> Config Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:28:17 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:28:17 --> URI Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Router Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Output Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Security Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Input Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:28:17 --> Language Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Loader Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Session Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:28:17 --> Session routines successfully run
DEBUG - 2013-11-28 00:28:17 --> Controller Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:28:17 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:28:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:28:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:28:17 --> Model Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Model Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Model Class Initialized
DEBUG - 2013-11-28 00:28:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:28:17 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:28:17 --> Final output sent to browser
DEBUG - 2013-11-28 00:28:17 --> Total execution time: 0.5520
DEBUG - 2013-11-28 00:28:18 --> Config Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:28:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:28:18 --> URI Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Router Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Output Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Security Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Input Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:28:18 --> Language Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Loader Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Session Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:28:18 --> Session routines successfully run
DEBUG - 2013-11-28 00:28:18 --> Controller Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:28:18 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:28:18 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:28:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:28:18 --> Model Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Model Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Model Class Initialized
DEBUG - 2013-11-28 00:28:18 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 00:28:19 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-11-28 00:29:12 --> Config Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:29:12 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:29:12 --> URI Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Router Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Output Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Security Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Input Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:29:12 --> Language Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Loader Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Session Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:29:12 --> Session routines successfully run
DEBUG - 2013-11-28 00:29:12 --> Controller Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:29:12 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:29:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:29:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:29:12 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:29:12 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:29:12 --> Final output sent to browser
DEBUG - 2013-11-28 00:29:12 --> Total execution time: 0.5750
DEBUG - 2013-11-28 00:29:13 --> Config Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:29:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:29:13 --> URI Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Router Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Output Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Security Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Input Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:29:13 --> Language Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Loader Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Session Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:29:13 --> Session routines successfully run
DEBUG - 2013-11-28 00:29:13 --> Controller Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:29:13 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:29:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:29:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:29:13 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:13 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 00:29:13 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-11-28 00:29:35 --> Config Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:29:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:29:35 --> URI Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Router Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Output Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Security Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Input Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:29:35 --> Language Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Loader Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Session Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:29:35 --> Session routines successfully run
DEBUG - 2013-11-28 00:29:35 --> Controller Class Initialized
DEBUG - 2013-11-28 00:29:35 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:29:35 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:29:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:29:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:29:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:36 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:29:36 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:29:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:29:36 --> Final output sent to browser
DEBUG - 2013-11-28 00:29:36 --> Total execution time: 0.5900
DEBUG - 2013-11-28 00:29:52 --> Config Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:29:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:29:52 --> URI Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Router Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Output Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Security Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Input Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:29:52 --> Language Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Loader Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Session Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:29:52 --> Session routines successfully run
DEBUG - 2013-11-28 00:29:52 --> Controller Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:29:52 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:29:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:29:52 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Model Class Initialized
DEBUG - 2013-11-28 00:29:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:29:52 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:29:52 --> Final output sent to browser
DEBUG - 2013-11-28 00:29:52 --> Total execution time: 0.5950
DEBUG - 2013-11-28 00:30:23 --> Config Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:30:23 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:30:23 --> URI Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Router Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Output Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Security Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Input Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:30:23 --> Language Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Loader Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Session Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:30:23 --> Session routines successfully run
DEBUG - 2013-11-28 00:30:23 --> Controller Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:30:23 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:30:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:30:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:30:23 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:23 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:30:23 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:30:23 --> Final output sent to browser
DEBUG - 2013-11-28 00:30:23 --> Total execution time: 0.6070
DEBUG - 2013-11-28 00:30:44 --> Config Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:30:44 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:30:44 --> URI Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Router Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Output Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Security Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Input Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:30:44 --> Language Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Loader Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Session Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:30:44 --> Session routines successfully run
DEBUG - 2013-11-28 00:30:44 --> Controller Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:30:44 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:30:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:30:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:30:44 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:30:44 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:30:45 --> Final output sent to browser
DEBUG - 2013-11-28 00:30:45 --> Total execution time: 0.5780
DEBUG - 2013-11-28 00:30:52 --> Config Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:30:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:30:52 --> URI Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Router Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Output Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Security Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Input Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:30:52 --> Language Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Loader Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Session Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:30:52 --> Session routines successfully run
DEBUG - 2013-11-28 00:30:52 --> Controller Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:30:52 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:30:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:30:52 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Model Class Initialized
DEBUG - 2013-11-28 00:30:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:30:52 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:30:52 --> Final output sent to browser
DEBUG - 2013-11-28 00:30:52 --> Total execution time: 0.5830
DEBUG - 2013-11-28 00:31:42 --> Config Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:31:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:31:42 --> URI Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Router Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Output Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Security Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Input Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:31:42 --> Language Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Loader Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Session Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:31:42 --> Session routines successfully run
DEBUG - 2013-11-28 00:31:42 --> Controller Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:31:42 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:31:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:31:42 --> Model Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Model Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Model Class Initialized
DEBUG - 2013-11-28 00:31:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:31:42 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:31:42 --> Final output sent to browser
DEBUG - 2013-11-28 00:31:42 --> Total execution time: 0.6690
DEBUG - 2013-11-28 00:31:50 --> Config Class Initialized
DEBUG - 2013-11-28 00:31:50 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:31:50 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:31:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:31:50 --> URI Class Initialized
DEBUG - 2013-11-28 00:31:50 --> Router Class Initialized
DEBUG - 2013-11-28 00:31:50 --> Output Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Security Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Input Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:31:51 --> Language Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Loader Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Session Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:31:51 --> Session routines successfully run
DEBUG - 2013-11-28 00:31:51 --> Controller Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:31:51 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:31:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:31:51 --> Model Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Model Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Model Class Initialized
DEBUG - 2013-11-28 00:31:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:31:51 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:31:51 --> Final output sent to browser
DEBUG - 2013-11-28 00:31:51 --> Total execution time: 0.5840
DEBUG - 2013-11-28 00:33:34 --> Config Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:33:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:33:34 --> URI Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Router Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Output Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Security Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Input Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:33:34 --> Language Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Loader Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Session Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:33:34 --> Session routines successfully run
DEBUG - 2013-11-28 00:33:34 --> Controller Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:33:34 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:33:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:33:34 --> Model Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Model Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Model Class Initialized
DEBUG - 2013-11-28 00:33:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:33:34 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:33:34 --> Final output sent to browser
DEBUG - 2013-11-28 00:33:34 --> Total execution time: 0.6110
DEBUG - 2013-11-28 00:35:53 --> Config Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:35:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:35:53 --> URI Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Router Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Output Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Security Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Input Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:35:53 --> Language Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Loader Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Session Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:35:53 --> Session routines successfully run
DEBUG - 2013-11-28 00:35:53 --> Controller Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:35:53 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:35:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:35:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:35:53 --> Model Class Initialized
DEBUG - 2013-11-28 00:35:53 --> Model Class Initialized
DEBUG - 2013-11-28 00:35:54 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:35:54 --> Model Class Initialized
DEBUG - 2013-11-28 00:35:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:35:54 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:35:54 --> Final output sent to browser
DEBUG - 2013-11-28 00:35:54 --> Total execution time: 0.6400
DEBUG - 2013-11-28 00:36:00 --> Config Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Hooks Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Utf8 Class Initialized
DEBUG - 2013-11-28 00:36:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 00:36:00 --> URI Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Router Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Output Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Security Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Input Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 00:36:00 --> Language Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Loader Class Initialized
DEBUG - 2013-11-28 00:36:00 --> Database Driver Class Initialized
DEBUG - 2013-11-28 00:36:01 --> Session Class Initialized
DEBUG - 2013-11-28 00:36:01 --> Helper loaded: string_helper
DEBUG - 2013-11-28 00:36:01 --> Session routines successfully run
DEBUG - 2013-11-28 00:36:01 --> Controller Class Initialized
DEBUG - 2013-11-28 00:36:01 --> Helper loaded: form_helper
DEBUG - 2013-11-28 00:36:01 --> Helper loaded: url_helper
DEBUG - 2013-11-28 00:36:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 00:36:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 00:36:01 --> Model Class Initialized
DEBUG - 2013-11-28 00:36:01 --> Model Class Initialized
DEBUG - 2013-11-28 00:36:01 --> Image Lib Class Initialized
DEBUG - 2013-11-28 00:36:01 --> Model Class Initialized
DEBUG - 2013-11-28 00:36:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 00:36:01 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 00:36:01 --> Final output sent to browser
DEBUG - 2013-11-28 00:36:01 --> Total execution time: 0.6390
DEBUG - 2013-11-28 05:02:38 --> Config Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:02:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:02:38 --> URI Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Router Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Output Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Security Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Input Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:02:38 --> Language Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Loader Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Session Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:02:38 --> Session routines successfully run
DEBUG - 2013-11-28 05:02:38 --> Controller Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:02:38 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:02:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:02:38 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Helper loaded: cookie_helper
DEBUG - 2013-11-28 05:02:38 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:02:39 --> Config Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:02:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:02:39 --> URI Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Router Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Output Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Security Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Input Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:02:39 --> Language Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Loader Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Session Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:02:39 --> A session cookie was not found.
DEBUG - 2013-11-28 05:02:39 --> Session routines successfully run
DEBUG - 2013-11-28 05:02:39 --> Controller Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:02:39 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:02:39 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:02:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Helper loaded: cookie_helper
DEBUG - 2013-11-28 05:02:39 --> Upload Class Initialized
DEBUG - 2013-11-28 05:02:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:02:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:02:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:39 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-28 05:02:40 --> Final output sent to browser
DEBUG - 2013-11-28 05:02:40 --> Total execution time: 0.8630
DEBUG - 2013-11-28 05:02:43 --> Config Class Initialized
DEBUG - 2013-11-28 05:02:43 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:02:43 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:02:44 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:02:44 --> URI Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Router Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Output Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Security Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Input Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:02:44 --> Language Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Loader Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Session Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:02:44 --> Session routines successfully run
DEBUG - 2013-11-28 05:02:44 --> Controller Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:02:44 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:02:44 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:02:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Helper loaded: cookie_helper
DEBUG - 2013-11-28 05:02:44 --> Upload Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:02:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:02:44 --> XSS Filtering completed
DEBUG - 2013-11-28 05:02:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:02:44 --> XSS Filtering completed
DEBUG - 2013-11-28 05:02:44 --> XSS Filtering completed
DEBUG - 2013-11-28 05:02:45 --> Config Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:02:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:02:45 --> URI Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Router Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Output Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Security Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Input Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:02:45 --> Language Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Loader Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Session Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:02:45 --> Session routines successfully run
DEBUG - 2013-11-28 05:02:45 --> Controller Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:02:45 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:02:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:02:45 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:02:46 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:02:46 --> Final output sent to browser
DEBUG - 2013-11-28 05:02:46 --> Total execution time: 0.8510
DEBUG - 2013-11-28 05:02:50 --> Config Class Initialized
DEBUG - 2013-11-28 05:02:50 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:02:50 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:02:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:02:50 --> URI Class Initialized
DEBUG - 2013-11-28 05:02:50 --> Router Class Initialized
DEBUG - 2013-11-28 05:02:50 --> Output Class Initialized
DEBUG - 2013-11-28 05:02:50 --> Security Class Initialized
DEBUG - 2013-11-28 05:02:50 --> Input Class Initialized
DEBUG - 2013-11-28 05:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:02:50 --> Language Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Loader Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Session Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:02:51 --> Session routines successfully run
DEBUG - 2013-11-28 05:02:51 --> Controller Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:02:51 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:02:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:02:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:02:51 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Model Class Initialized
DEBUG - 2013-11-28 05:02:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:02:51 --> Final output sent to browser
DEBUG - 2013-11-28 05:02:51 --> Total execution time: 0.6390
DEBUG - 2013-11-28 05:03:29 --> Config Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:03:29 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:03:29 --> URI Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Router Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Output Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Security Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Input Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:03:29 --> Language Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Loader Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Session Class Initialized
DEBUG - 2013-11-28 05:03:29 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:03:29 --> Session routines successfully run
DEBUG - 2013-11-28 05:03:29 --> Controller Class Initialized
DEBUG - 2013-11-28 05:03:30 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:03:30 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:03:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:03:30 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:30 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:30 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:03:30 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:30 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 05:03:30 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 38
ERROR - 2013-11-28 05:03:30 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 38
ERROR - 2013-11-28 05:03:30 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 38
DEBUG - 2013-11-28 05:03:30 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:03:30 --> Final output sent to browser
DEBUG - 2013-11-28 05:03:30 --> Total execution time: 0.7340
DEBUG - 2013-11-28 05:03:43 --> Config Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:03:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:03:43 --> URI Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Router Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Output Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Security Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Input Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:03:43 --> Language Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Loader Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Session Class Initialized
DEBUG - 2013-11-28 05:03:43 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:03:44 --> Session routines successfully run
DEBUG - 2013-11-28 05:03:44 --> Controller Class Initialized
DEBUG - 2013-11-28 05:03:44 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:03:44 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:03:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:03:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:44 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:03:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:03:44 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:03:44 --> Final output sent to browser
DEBUG - 2013-11-28 05:03:44 --> Total execution time: 0.9571
DEBUG - 2013-11-28 05:03:49 --> Config Class Initialized
DEBUG - 2013-11-28 05:03:49 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:03:49 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:03:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:03:50 --> URI Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Router Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Output Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Security Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Input Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:03:50 --> Language Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Loader Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Session Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:03:50 --> Session routines successfully run
DEBUG - 2013-11-28 05:03:50 --> Controller Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:03:50 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:03:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:03:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:03:50 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Model Class Initialized
DEBUG - 2013-11-28 05:03:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:03:50 --> Final output sent to browser
DEBUG - 2013-11-28 05:03:50 --> Total execution time: 0.6680
DEBUG - 2013-11-28 05:04:01 --> Config Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:04:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:04:01 --> URI Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Router Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Output Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Security Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Input Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:04:01 --> Language Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Loader Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Session Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:04:01 --> Session routines successfully run
DEBUG - 2013-11-28 05:04:01 --> Controller Class Initialized
DEBUG - 2013-11-28 05:04:01 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:04:01 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:04:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:04:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:04:02 --> Model Class Initialized
DEBUG - 2013-11-28 05:04:02 --> Model Class Initialized
DEBUG - 2013-11-28 05:04:02 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:04:02 --> Model Class Initialized
DEBUG - 2013-11-28 05:04:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:04:02 --> Final output sent to browser
DEBUG - 2013-11-28 05:04:02 --> Total execution time: 0.6820
DEBUG - 2013-11-28 05:04:39 --> Config Class Initialized
DEBUG - 2013-11-28 05:04:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:04:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:04:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:04:39 --> URI Class Initialized
DEBUG - 2013-11-28 05:04:39 --> Router Class Initialized
DEBUG - 2013-11-28 05:04:39 --> Output Class Initialized
DEBUG - 2013-11-28 05:04:39 --> Security Class Initialized
DEBUG - 2013-11-28 05:04:39 --> Input Class Initialized
DEBUG - 2013-11-28 05:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:04:39 --> Language Class Initialized
DEBUG - 2013-11-28 05:04:52 --> Config Class Initialized
DEBUG - 2013-11-28 05:04:52 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:04:52 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:04:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:04:52 --> URI Class Initialized
DEBUG - 2013-11-28 05:04:52 --> Router Class Initialized
DEBUG - 2013-11-28 05:04:52 --> Output Class Initialized
DEBUG - 2013-11-28 05:04:52 --> Security Class Initialized
DEBUG - 2013-11-28 05:04:52 --> Input Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:04:53 --> Language Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Loader Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Session Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:04:53 --> Session routines successfully run
DEBUG - 2013-11-28 05:04:53 --> Controller Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:04:53 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:04:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:04:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:04:53 --> Model Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Model Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Model Class Initialized
DEBUG - 2013-11-28 05:04:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:04:53 --> Final output sent to browser
DEBUG - 2013-11-28 05:04:53 --> Total execution time: 0.6730
DEBUG - 2013-11-28 05:05:00 --> Config Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:05:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:05:00 --> URI Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Router Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Output Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Security Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Input Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:05:00 --> Language Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Loader Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Session Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:05:00 --> Session routines successfully run
DEBUG - 2013-11-28 05:05:00 --> Controller Class Initialized
DEBUG - 2013-11-28 05:05:00 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:05:00 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:05:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:05:01 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:01 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:01 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:05:01 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:05:01 --> Final output sent to browser
DEBUG - 2013-11-28 05:05:01 --> Total execution time: 0.7010
DEBUG - 2013-11-28 05:05:03 --> Config Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:05:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:05:03 --> URI Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Router Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Output Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Security Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Input Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:05:03 --> Language Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Loader Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Session Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:05:03 --> Session routines successfully run
DEBUG - 2013-11-28 05:05:03 --> Controller Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:05:03 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:05:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:05:03 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:03 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:05:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:05:04 --> Final output sent to browser
DEBUG - 2013-11-28 05:05:04 --> Total execution time: 0.6940
DEBUG - 2013-11-28 05:05:11 --> Config Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:05:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:05:11 --> URI Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Router Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Output Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Security Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Input Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:05:11 --> Language Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Loader Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Session Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:05:11 --> Session routines successfully run
DEBUG - 2013-11-28 05:05:11 --> Controller Class Initialized
DEBUG - 2013-11-28 05:05:11 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:05:12 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:05:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:05:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:05:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:05:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:05:12 --> Final output sent to browser
DEBUG - 2013-11-28 05:05:12 --> Total execution time: 0.6820
DEBUG - 2013-11-28 05:05:17 --> Config Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:05:17 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:05:17 --> URI Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Router Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Output Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Security Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Input Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:05:17 --> Language Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Loader Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Session Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:05:17 --> Session routines successfully run
DEBUG - 2013-11-28 05:05:17 --> Controller Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:05:17 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:05:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:05:17 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:05:17 --> Final output sent to browser
DEBUG - 2013-11-28 05:05:17 --> Total execution time: 0.7020
DEBUG - 2013-11-28 05:05:41 --> Config Class Initialized
DEBUG - 2013-11-28 05:05:41 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:05:41 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:05:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:05:41 --> URI Class Initialized
DEBUG - 2013-11-28 05:05:41 --> Router Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Output Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Security Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Input Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:05:42 --> Language Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Loader Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Session Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:05:42 --> Session routines successfully run
DEBUG - 2013-11-28 05:05:42 --> Controller Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:05:42 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:05:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:05:42 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:05:42 --> Final output sent to browser
DEBUG - 2013-11-28 05:05:42 --> Total execution time: 0.7330
DEBUG - 2013-11-28 05:05:48 --> Config Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:05:48 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:05:48 --> URI Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Router Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Output Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Security Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Input Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:05:48 --> Language Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Loader Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Session Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:05:48 --> Session routines successfully run
DEBUG - 2013-11-28 05:05:48 --> Controller Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:05:48 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:05:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:05:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:05:48 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Model Class Initialized
DEBUG - 2013-11-28 05:05:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:05:49 --> Final output sent to browser
DEBUG - 2013-11-28 05:05:49 --> Total execution time: 0.6920
DEBUG - 2013-11-28 05:06:06 --> Config Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:06:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:06:06 --> URI Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Router Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Output Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Security Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Input Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:06:06 --> Language Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Loader Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Session Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:06:06 --> Session routines successfully run
DEBUG - 2013-11-28 05:06:06 --> Controller Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:06:06 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:06:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:06:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:06:06 --> Model Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Model Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Model Class Initialized
DEBUG - 2013-11-28 05:06:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:06:06 --> Final output sent to browser
DEBUG - 2013-11-28 05:06:06 --> Total execution time: 0.7170
DEBUG - 2013-11-28 05:06:11 --> Config Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:06:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:06:11 --> URI Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Router Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Output Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Security Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Input Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:06:11 --> Language Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Loader Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Session Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:06:11 --> Session routines successfully run
DEBUG - 2013-11-28 05:06:11 --> Controller Class Initialized
DEBUG - 2013-11-28 05:06:11 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:06:11 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:06:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:06:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:06:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:06:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:06:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:06:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:06:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:06:12 --> Final output sent to browser
DEBUG - 2013-11-28 05:06:12 --> Total execution time: 0.7270
DEBUG - 2013-11-28 05:26:39 --> Config Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:26:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:26:39 --> URI Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Router Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Output Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Security Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Input Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:26:39 --> Language Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Loader Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Session Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:26:39 --> Session routines successfully run
DEBUG - 2013-11-28 05:26:39 --> Controller Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:26:39 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:26:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:26:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:26:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:26:40 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:26:40 --> Final output sent to browser
DEBUG - 2013-11-28 05:26:40 --> Total execution time: 0.7950
DEBUG - 2013-11-28 05:26:43 --> Config Class Initialized
DEBUG - 2013-11-28 05:26:43 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:26:43 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:26:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:26:43 --> URI Class Initialized
DEBUG - 2013-11-28 05:26:43 --> Router Class Initialized
DEBUG - 2013-11-28 05:26:43 --> Output Class Initialized
DEBUG - 2013-11-28 05:26:43 --> Security Class Initialized
DEBUG - 2013-11-28 05:26:43 --> Input Class Initialized
DEBUG - 2013-11-28 05:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:26:43 --> Language Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Loader Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Session Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:26:44 --> Session routines successfully run
DEBUG - 2013-11-28 05:26:44 --> Controller Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:26:44 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:26:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:26:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:26:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:26:44 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:26:44 --> XSS Filtering completed
DEBUG - 2013-11-28 05:26:44 --> Config Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:26:44 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:26:44 --> URI Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Router Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Output Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Security Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Input Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:26:44 --> Language Class Initialized
DEBUG - 2013-11-28 05:26:44 --> Loader Class Initialized
DEBUG - 2013-11-28 05:26:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:26:45 --> Session Class Initialized
DEBUG - 2013-11-28 05:26:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:26:45 --> Session routines successfully run
DEBUG - 2013-11-28 05:26:45 --> Controller Class Initialized
DEBUG - 2013-11-28 05:26:45 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:26:45 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:26:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:26:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:26:45 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:45 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:45 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:26:45 --> Model Class Initialized
DEBUG - 2013-11-28 05:26:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:26:45 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:26:45 --> Final output sent to browser
DEBUG - 2013-11-28 05:26:45 --> Total execution time: 1.1571
DEBUG - 2013-11-28 05:29:10 --> Config Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:29:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:29:10 --> URI Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Router Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Output Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Security Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Input Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:29:10 --> Language Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Loader Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Session Class Initialized
DEBUG - 2013-11-28 05:29:10 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:29:10 --> Session routines successfully run
DEBUG - 2013-11-28 05:29:11 --> Controller Class Initialized
DEBUG - 2013-11-28 05:29:11 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:29:11 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:29:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:29:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:29:11 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:11 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:11 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:29:11 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:29:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:29:11 --> Final output sent to browser
DEBUG - 2013-11-28 05:29:11 --> Total execution time: 1.1841
DEBUG - 2013-11-28 05:29:13 --> Config Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:29:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:29:13 --> URI Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Router Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Output Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Security Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Input Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:29:13 --> Language Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Loader Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Session Class Initialized
DEBUG - 2013-11-28 05:29:13 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:29:13 --> Session routines successfully run
DEBUG - 2013-11-28 05:29:13 --> Controller Class Initialized
DEBUG - 2013-11-28 05:29:14 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:29:14 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:29:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:29:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:29:14 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:14 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:14 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:29:14 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:29:14 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:29:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:29:14 --> XSS Filtering completed
DEBUG - 2013-11-28 05:29:14 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:29:14 --> Final output sent to browser
DEBUG - 2013-11-28 05:29:14 --> Total execution time: 1.2231
DEBUG - 2013-11-28 05:29:25 --> Config Class Initialized
DEBUG - 2013-11-28 05:29:25 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:29:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:29:26 --> URI Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Router Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Output Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Security Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Input Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:29:26 --> Language Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Loader Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Session Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:29:26 --> Session routines successfully run
DEBUG - 2013-11-28 05:29:26 --> Controller Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:29:26 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:29:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:29:26 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:29:26 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:29:27 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:29:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:29:27 --> XSS Filtering completed
DEBUG - 2013-11-28 05:29:27 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:29:27 --> Final output sent to browser
DEBUG - 2013-11-28 05:29:27 --> Total execution time: 1.2091
DEBUG - 2013-11-28 05:29:38 --> Config Class Initialized
DEBUG - 2013-11-28 05:29:38 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:29:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:29:39 --> URI Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Router Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Output Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Security Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Input Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:29:39 --> Language Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Loader Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Session Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:29:39 --> Session routines successfully run
DEBUG - 2013-11-28 05:29:39 --> Controller Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:29:39 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:29:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:29:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:29:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:29:40 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:29:40 --> XSS Filtering completed
DEBUG - 2013-11-28 05:29:40 --> Config Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:29:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:29:40 --> URI Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Router Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Output Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Security Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Input Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:29:40 --> Language Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Loader Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Session Class Initialized
DEBUG - 2013-11-28 05:29:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:29:41 --> Session routines successfully run
DEBUG - 2013-11-28 05:29:41 --> Controller Class Initialized
DEBUG - 2013-11-28 05:29:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:29:41 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:29:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:29:41 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:41 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:29:41 --> Model Class Initialized
DEBUG - 2013-11-28 05:29:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:29:41 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:29:41 --> Final output sent to browser
DEBUG - 2013-11-28 05:29:41 --> Total execution time: 1.1641
DEBUG - 2013-11-28 05:30:03 --> Config Class Initialized
DEBUG - 2013-11-28 05:30:03 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:30:03 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:30:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:30:03 --> URI Class Initialized
DEBUG - 2013-11-28 05:30:03 --> Router Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Output Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Security Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Input Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:30:04 --> Language Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Loader Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Session Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:30:04 --> Session routines successfully run
DEBUG - 2013-11-28 05:30:04 --> Controller Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:30:04 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:30:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:30:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:30:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:30:04 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:30:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:30:04 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:30:04 --> Final output sent to browser
DEBUG - 2013-11-28 05:30:04 --> Total execution time: 1.1211
DEBUG - 2013-11-28 05:30:08 --> Config Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:30:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:30:08 --> URI Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Router Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Output Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Security Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Input Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:30:08 --> Language Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Loader Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Session Class Initialized
DEBUG - 2013-11-28 05:30:08 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:30:08 --> Session routines successfully run
DEBUG - 2013-11-28 05:30:08 --> Controller Class Initialized
DEBUG - 2013-11-28 05:30:09 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:30:09 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:30:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:30:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:30:09 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:09 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:09 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:30:09 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:30:09 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:30:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:30:09 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:30:09 --> Final output sent to browser
DEBUG - 2013-11-28 05:30:09 --> Total execution time: 1.3331
DEBUG - 2013-11-28 05:30:13 --> Config Class Initialized
DEBUG - 2013-11-28 05:30:13 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:30:13 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:30:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:30:13 --> URI Class Initialized
DEBUG - 2013-11-28 05:30:13 --> Router Class Initialized
DEBUG - 2013-11-28 05:30:13 --> Output Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Security Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Input Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:30:14 --> Language Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Loader Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Session Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:30:14 --> Session routines successfully run
DEBUG - 2013-11-28 05:30:14 --> Controller Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:30:14 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:30:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:30:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:30:14 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Model Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:30:14 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:30:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:30:14 --> XSS Filtering completed
DEBUG - 2013-11-28 05:30:15 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:30:15 --> Final output sent to browser
DEBUG - 2013-11-28 05:30:15 --> Total execution time: 1.3581
DEBUG - 2013-11-28 05:37:16 --> Config Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:37:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:37:16 --> URI Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Router Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Output Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Security Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Input Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:37:16 --> Language Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Loader Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Session Class Initialized
DEBUG - 2013-11-28 05:37:16 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:37:17 --> Session routines successfully run
DEBUG - 2013-11-28 05:37:17 --> Controller Class Initialized
DEBUG - 2013-11-28 05:37:17 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:37:17 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:37:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:37:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:37:17 --> Model Class Initialized
DEBUG - 2013-11-28 05:37:17 --> Model Class Initialized
DEBUG - 2013-11-28 05:37:17 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:37:17 --> Model Class Initialized
DEBUG - 2013-11-28 05:37:17 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 05:37:17 --> Severity: Notice  --> Undefined variable: like_error C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 13
DEBUG - 2013-11-28 05:37:17 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:37:17 --> Final output sent to browser
DEBUG - 2013-11-28 05:37:17 --> Total execution time: 0.9671
DEBUG - 2013-11-28 05:40:18 --> Config Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:40:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:40:18 --> URI Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Router Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Output Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Security Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Input Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:40:18 --> Language Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Loader Class Initialized
DEBUG - 2013-11-28 05:40:18 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:40:19 --> Session Class Initialized
DEBUG - 2013-11-28 05:40:19 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:40:19 --> Session routines successfully run
DEBUG - 2013-11-28 05:40:19 --> Controller Class Initialized
DEBUG - 2013-11-28 05:40:19 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:40:19 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:40:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:40:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:40:19 --> Model Class Initialized
DEBUG - 2013-11-28 05:40:19 --> Model Class Initialized
DEBUG - 2013-11-28 05:40:19 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:40:19 --> Model Class Initialized
DEBUG - 2013-11-28 05:40:19 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 05:40:19 --> Severity: Notice  --> Undefined variable: like_error C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 15
DEBUG - 2013-11-28 05:40:19 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:40:19 --> Final output sent to browser
DEBUG - 2013-11-28 05:40:19 --> Total execution time: 0.9321
DEBUG - 2013-11-28 05:41:08 --> Config Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:41:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:41:08 --> URI Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Router Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Output Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Security Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Input Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:41:08 --> Language Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Loader Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Session Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:41:08 --> Session routines successfully run
DEBUG - 2013-11-28 05:41:08 --> Controller Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:41:08 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:41:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:41:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:41:08 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:08 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:41:09 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:41:09 --> Final output sent to browser
DEBUG - 2013-11-28 05:41:09 --> Total execution time: 0.8770
DEBUG - 2013-11-28 05:41:11 --> Config Class Initialized
DEBUG - 2013-11-28 05:41:11 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:41:11 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:41:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:41:11 --> URI Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Router Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Output Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Security Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Input Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:41:12 --> Language Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Loader Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Session Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:41:12 --> Session routines successfully run
DEBUG - 2013-11-28 05:41:12 --> Controller Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:41:12 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:41:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:41:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:41:39 --> Config Class Initialized
DEBUG - 2013-11-28 05:41:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:41:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:41:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:41:39 --> URI Class Initialized
DEBUG - 2013-11-28 05:41:39 --> Router Class Initialized
DEBUG - 2013-11-28 05:41:39 --> Output Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Security Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Input Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:41:40 --> Language Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Loader Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Session Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:41:40 --> Session routines successfully run
DEBUG - 2013-11-28 05:41:40 --> Controller Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:41:40 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:41:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:41:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:41:40 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:40 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 05:41:40 --> Severity: Notice  --> Undefined variable: like_error C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 15
DEBUG - 2013-11-28 05:41:40 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:41:40 --> Final output sent to browser
DEBUG - 2013-11-28 05:41:40 --> Total execution time: 1.1061
DEBUG - 2013-11-28 05:41:49 --> Config Class Initialized
DEBUG - 2013-11-28 05:41:49 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:41:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:41:50 --> URI Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Router Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Output Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Security Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Input Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:41:50 --> Language Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Loader Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Session Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:41:50 --> Session routines successfully run
DEBUG - 2013-11-28 05:41:50 --> Controller Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:41:50 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:41:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:41:50 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Model Class Initialized
DEBUG - 2013-11-28 05:41:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:42:18 --> Config Class Initialized
DEBUG - 2013-11-28 05:42:18 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:42:18 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:42:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:42:18 --> URI Class Initialized
DEBUG - 2013-11-28 05:42:18 --> Router Class Initialized
DEBUG - 2013-11-28 05:42:18 --> Output Class Initialized
DEBUG - 2013-11-28 05:42:18 --> Security Class Initialized
DEBUG - 2013-11-28 05:42:18 --> Input Class Initialized
DEBUG - 2013-11-28 05:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:42:18 --> Language Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Loader Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Session Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:42:19 --> Session routines successfully run
DEBUG - 2013-11-28 05:42:19 --> Controller Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:42:19 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:42:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:42:19 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:19 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 05:42:19 --> Severity: Notice  --> Undefined variable: like_error C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 15
DEBUG - 2013-11-28 05:42:19 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:42:19 --> Final output sent to browser
DEBUG - 2013-11-28 05:42:19 --> Total execution time: 1.0131
DEBUG - 2013-11-28 05:42:21 --> Config Class Initialized
DEBUG - 2013-11-28 05:42:21 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:42:21 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:42:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:42:21 --> URI Class Initialized
DEBUG - 2013-11-28 05:42:21 --> Router Class Initialized
DEBUG - 2013-11-28 05:42:21 --> Output Class Initialized
DEBUG - 2013-11-28 05:42:21 --> Security Class Initialized
DEBUG - 2013-11-28 05:42:21 --> Input Class Initialized
DEBUG - 2013-11-28 05:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:42:21 --> Language Class Initialized
DEBUG - 2013-11-28 05:42:21 --> Loader Class Initialized
DEBUG - 2013-11-28 05:42:22 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:42:22 --> Session Class Initialized
DEBUG - 2013-11-28 05:42:22 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:42:22 --> Session garbage collection performed.
DEBUG - 2013-11-28 05:42:22 --> Session routines successfully run
DEBUG - 2013-11-28 05:42:22 --> Controller Class Initialized
DEBUG - 2013-11-28 05:42:22 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:42:22 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:42:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:42:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:42:22 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:22 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:22 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:42:22 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:22 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 05:42:22 --> Severity: Notice  --> Undefined variable: like_error C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 15
DEBUG - 2013-11-28 05:42:22 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:42:22 --> Final output sent to browser
DEBUG - 2013-11-28 05:42:22 --> Total execution time: 1.2911
DEBUG - 2013-11-28 05:42:28 --> Config Class Initialized
DEBUG - 2013-11-28 05:42:28 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:42:28 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:42:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:42:28 --> URI Class Initialized
DEBUG - 2013-11-28 05:42:28 --> Router Class Initialized
DEBUG - 2013-11-28 05:42:28 --> Output Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Security Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Input Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:42:29 --> Language Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Loader Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Session Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:42:29 --> Session garbage collection performed.
DEBUG - 2013-11-28 05:42:29 --> Session routines successfully run
DEBUG - 2013-11-28 05:42:29 --> Controller Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:42:29 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:42:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:42:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:42:29 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:42:29 --> Final output sent to browser
DEBUG - 2013-11-28 05:42:29 --> Total execution time: 0.9591
DEBUG - 2013-11-28 05:42:31 --> Config Class Initialized
DEBUG - 2013-11-28 05:42:31 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:42:31 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:42:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:42:32 --> URI Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Router Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Output Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Security Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Input Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:42:32 --> Language Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Loader Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Session Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:42:32 --> Session routines successfully run
DEBUG - 2013-11-28 05:42:32 --> Controller Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:42:32 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:42:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:42:32 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:42:37 --> Config Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:42:37 --> URI Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Router Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Output Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Security Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Input Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:42:37 --> Language Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Loader Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Session Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:42:37 --> Session routines successfully run
DEBUG - 2013-11-28 05:42:37 --> Controller Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:42:37 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:42:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:42:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:42:37 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Model Class Initialized
DEBUG - 2013-11-28 05:42:37 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 05:42:38 --> Severity: Notice  --> Undefined variable: like_error C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 15
DEBUG - 2013-11-28 05:42:38 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:42:38 --> Final output sent to browser
DEBUG - 2013-11-28 05:42:38 --> Total execution time: 0.9821
DEBUG - 2013-11-28 05:43:02 --> Config Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:43:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:43:02 --> URI Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Router Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Output Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Security Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Input Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:43:02 --> Language Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Loader Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Session Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:43:02 --> Session routines successfully run
DEBUG - 2013-11-28 05:43:02 --> Controller Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:43:02 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:43:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:43:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:43:02 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:02 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 05:43:03 --> Severity: Notice  --> Undefined variable: like_error C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 15
DEBUG - 2013-11-28 05:43:03 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:43:03 --> Final output sent to browser
DEBUG - 2013-11-28 05:43:03 --> Total execution time: 1.0881
DEBUG - 2013-11-28 05:43:38 --> Config Class Initialized
DEBUG - 2013-11-28 05:43:38 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:43:38 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:43:38 --> URI Class Initialized
DEBUG - 2013-11-28 05:43:38 --> Router Class Initialized
DEBUG - 2013-11-28 05:43:38 --> Output Class Initialized
DEBUG - 2013-11-28 05:43:38 --> Security Class Initialized
DEBUG - 2013-11-28 05:43:38 --> Input Class Initialized
DEBUG - 2013-11-28 05:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:43:39 --> Language Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Loader Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Session Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:43:39 --> Session routines successfully run
DEBUG - 2013-11-28 05:43:39 --> Controller Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:43:39 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:43:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:43:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:43:39 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:43:39 --> Final output sent to browser
DEBUG - 2013-11-28 05:43:39 --> Total execution time: 1.0921
DEBUG - 2013-11-28 05:43:57 --> Config Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:43:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:43:57 --> URI Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Router Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Output Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Security Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Input Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:43:57 --> Language Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Loader Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Session Class Initialized
DEBUG - 2013-11-28 05:43:57 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:43:59 --> Session routines successfully run
DEBUG - 2013-11-28 05:43:59 --> Controller Class Initialized
DEBUG - 2013-11-28 05:43:59 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:43:59 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:43:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:43:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:43:59 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:59 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:59 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:43:59 --> Model Class Initialized
DEBUG - 2013-11-28 05:43:59 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:43:59 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:43:59 --> Final output sent to browser
DEBUG - 2013-11-28 05:43:59 --> Total execution time: 2.4361
DEBUG - 2013-11-28 05:44:04 --> Config Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:44:04 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:44:04 --> URI Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Router Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Output Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Security Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Input Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:44:04 --> Language Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Loader Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Session Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:44:04 --> Session routines successfully run
DEBUG - 2013-11-28 05:44:04 --> Controller Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:44:04 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:44:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:44:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:44:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:44:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:44:05 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:44:05 --> Final output sent to browser
DEBUG - 2013-11-28 05:44:05 --> Total execution time: 1.8741
DEBUG - 2013-11-28 05:44:24 --> Config Class Initialized
DEBUG - 2013-11-28 05:44:24 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:44:24 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:44:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:44:25 --> URI Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Router Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Output Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Security Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Input Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:44:25 --> Language Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Loader Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Session Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:44:25 --> Session routines successfully run
DEBUG - 2013-11-28 05:44:25 --> Controller Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:44:25 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:44:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:44:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:44:25 --> Model Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Model Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Model Class Initialized
DEBUG - 2013-11-28 05:44:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:44:25 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:44:25 --> Final output sent to browser
DEBUG - 2013-11-28 05:44:25 --> Total execution time: 1.0601
DEBUG - 2013-11-28 05:45:03 --> Config Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:45:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:45:03 --> URI Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Router Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Output Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Security Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Input Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:45:03 --> Language Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Loader Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Session Class Initialized
DEBUG - 2013-11-28 05:45:03 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:45:03 --> Session routines successfully run
DEBUG - 2013-11-28 05:45:03 --> Controller Class Initialized
DEBUG - 2013-11-28 05:45:04 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:45:04 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:45:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:45:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:45:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:45:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:45:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:45:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:45:04 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:45:04 --> Final output sent to browser
DEBUG - 2013-11-28 05:45:04 --> Total execution time: 1.0501
DEBUG - 2013-11-28 05:45:36 --> Config Class Initialized
DEBUG - 2013-11-28 05:45:36 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:45:36 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:45:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:45:37 --> URI Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Router Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Output Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Security Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Input Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:45:37 --> Language Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Loader Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Session Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:45:37 --> Session routines successfully run
DEBUG - 2013-11-28 05:45:37 --> Controller Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:45:37 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:45:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:45:37 --> Model Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Model Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Model Class Initialized
DEBUG - 2013-11-28 05:45:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:45:37 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:45:37 --> Final output sent to browser
DEBUG - 2013-11-28 05:45:37 --> Total execution time: 0.9911
DEBUG - 2013-11-28 05:47:03 --> Config Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:47:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:47:03 --> URI Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Router Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Output Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Security Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Input Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:47:03 --> Language Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Loader Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Session Class Initialized
DEBUG - 2013-11-28 05:47:03 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:47:03 --> Session routines successfully run
DEBUG - 2013-11-28 05:47:03 --> Controller Class Initialized
DEBUG - 2013-11-28 05:47:04 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:47:04 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:47:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:47:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:47:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:47:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:47:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:47:04 --> Model Class Initialized
DEBUG - 2013-11-28 05:47:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:47:04 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:47:04 --> Final output sent to browser
DEBUG - 2013-11-28 05:47:04 --> Total execution time: 1.0321
DEBUG - 2013-11-28 05:47:59 --> Config Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:47:59 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:47:59 --> URI Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Router Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Output Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Security Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Input Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:47:59 --> Language Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Loader Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Session Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:47:59 --> Session routines successfully run
DEBUG - 2013-11-28 05:47:59 --> Controller Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:47:59 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:47:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:47:59 --> Model Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Model Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Model Class Initialized
DEBUG - 2013-11-28 05:47:59 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:48:00 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:48:00 --> Final output sent to browser
DEBUG - 2013-11-28 05:48:00 --> Total execution time: 1.1971
DEBUG - 2013-11-28 05:48:24 --> Config Class Initialized
DEBUG - 2013-11-28 05:48:24 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:48:24 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:48:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:48:24 --> URI Class Initialized
DEBUG - 2013-11-28 05:48:24 --> Router Class Initialized
DEBUG - 2013-11-28 05:48:24 --> Output Class Initialized
DEBUG - 2013-11-28 05:48:24 --> Security Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Input Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:48:25 --> Language Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Loader Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Session Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:48:25 --> Session routines successfully run
DEBUG - 2013-11-28 05:48:25 --> Controller Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:48:25 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:48:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:48:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:48:25 --> Model Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Model Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Model Class Initialized
DEBUG - 2013-11-28 05:48:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:48:25 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:48:25 --> Final output sent to browser
DEBUG - 2013-11-28 05:48:25 --> Total execution time: 1.0631
DEBUG - 2013-11-28 05:49:40 --> Config Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:49:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:49:40 --> URI Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Router Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Output Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Security Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Input Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:49:40 --> Language Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Loader Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Session Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:49:40 --> Session routines successfully run
DEBUG - 2013-11-28 05:49:40 --> Controller Class Initialized
DEBUG - 2013-11-28 05:49:40 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:49:40 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:49:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:49:41 --> Model Class Initialized
DEBUG - 2013-11-28 05:49:41 --> Model Class Initialized
DEBUG - 2013-11-28 05:49:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:49:41 --> Model Class Initialized
DEBUG - 2013-11-28 05:49:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:49:41 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:49:41 --> Final output sent to browser
DEBUG - 2013-11-28 05:49:41 --> Total execution time: 1.1601
DEBUG - 2013-11-28 05:57:14 --> Config Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:57:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:57:14 --> URI Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Router Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Output Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Security Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Input Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:57:14 --> Language Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Loader Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Session Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:57:14 --> Session routines successfully run
DEBUG - 2013-11-28 05:57:14 --> Controller Class Initialized
DEBUG - 2013-11-28 05:57:14 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:57:15 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:57:15 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:57:15 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:15 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:15 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:57:15 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:15 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:57:15 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:57:15 --> Final output sent to browser
DEBUG - 2013-11-28 05:57:15 --> Total execution time: 1.2421
DEBUG - 2013-11-28 05:57:33 --> Config Class Initialized
DEBUG - 2013-11-28 05:57:33 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:57:33 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:57:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:57:33 --> URI Class Initialized
DEBUG - 2013-11-28 05:57:33 --> Router Class Initialized
DEBUG - 2013-11-28 05:57:33 --> Output Class Initialized
DEBUG - 2013-11-28 05:57:33 --> Security Class Initialized
DEBUG - 2013-11-28 05:57:33 --> Input Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:57:34 --> Language Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Loader Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Session Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:57:34 --> Session routines successfully run
DEBUG - 2013-11-28 05:57:34 --> Controller Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:57:34 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:57:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:57:34 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:57:34 --> Config Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:57:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:57:34 --> URI Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Router Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Output Class Initialized
DEBUG - 2013-11-28 05:57:34 --> Security Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Input Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:57:35 --> Language Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Loader Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Session Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:57:35 --> Session routines successfully run
DEBUG - 2013-11-28 05:57:35 --> Controller Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:57:35 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:57:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:57:35 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:57:35 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:57:35 --> Final output sent to browser
DEBUG - 2013-11-28 05:57:35 --> Total execution time: 1.1801
DEBUG - 2013-11-28 05:57:43 --> Config Class Initialized
DEBUG - 2013-11-28 05:57:43 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:57:43 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:57:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:57:43 --> URI Class Initialized
DEBUG - 2013-11-28 05:57:43 --> Router Class Initialized
DEBUG - 2013-11-28 05:57:43 --> Output Class Initialized
DEBUG - 2013-11-28 05:57:43 --> Security Class Initialized
DEBUG - 2013-11-28 05:57:43 --> Input Class Initialized
DEBUG - 2013-11-28 05:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:57:43 --> Language Class Initialized
DEBUG - 2013-11-28 05:57:43 --> Loader Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Session Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:57:44 --> Session routines successfully run
DEBUG - 2013-11-28 05:57:44 --> Controller Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:57:44 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:57:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:57:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:57:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:57:44 --> Config Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:57:44 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:57:44 --> URI Class Initialized
DEBUG - 2013-11-28 05:57:44 --> Router Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Output Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Security Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Input Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:57:45 --> Language Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Loader Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Session Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:57:45 --> Session routines successfully run
DEBUG - 2013-11-28 05:57:45 --> Controller Class Initialized
DEBUG - 2013-11-28 05:57:45 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:57:45 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:57:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:57:45 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:46 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:46 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:57:46 --> Model Class Initialized
DEBUG - 2013-11-28 05:57:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:57:46 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:57:46 --> Final output sent to browser
DEBUG - 2013-11-28 05:57:46 --> Total execution time: 1.5041
DEBUG - 2013-11-28 05:58:34 --> Config Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:58:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:58:34 --> URI Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Router Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Output Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Security Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Input Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:58:34 --> Language Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Loader Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Session Class Initialized
DEBUG - 2013-11-28 05:58:34 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:58:35 --> Session routines successfully run
DEBUG - 2013-11-28 05:58:35 --> Controller Class Initialized
DEBUG - 2013-11-28 05:58:35 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:58:35 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:58:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:58:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:58:35 --> Model Class Initialized
DEBUG - 2013-11-28 05:58:35 --> Model Class Initialized
DEBUG - 2013-11-28 05:58:35 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:58:35 --> Model Class Initialized
DEBUG - 2013-11-28 05:58:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:58:35 --> Form Validation Class Initialized
DEBUG - 2013-11-28 05:58:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 05:58:35 --> XSS Filtering completed
DEBUG - 2013-11-28 05:58:35 --> Config Class Initialized
DEBUG - 2013-11-28 05:58:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 05:58:35 --> Utf8 Class Initialized
DEBUG - 2013-11-28 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 05:58:36 --> URI Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Router Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Output Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Security Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Input Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 05:58:36 --> Language Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Loader Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Session Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Helper loaded: string_helper
DEBUG - 2013-11-28 05:58:36 --> Session routines successfully run
DEBUG - 2013-11-28 05:58:36 --> Controller Class Initialized
DEBUG - 2013-11-28 05:58:36 --> Helper loaded: form_helper
DEBUG - 2013-11-28 05:58:36 --> Helper loaded: url_helper
DEBUG - 2013-11-28 05:58:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 05:58:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 05:58:36 --> Model Class Initialized
DEBUG - 2013-11-28 05:58:37 --> Model Class Initialized
DEBUG - 2013-11-28 05:58:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 05:58:37 --> Model Class Initialized
DEBUG - 2013-11-28 05:58:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 05:58:37 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 05:58:37 --> Final output sent to browser
DEBUG - 2013-11-28 05:58:37 --> Total execution time: 1.4841
DEBUG - 2013-11-28 06:20:31 --> Config Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:20:31 --> URI Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Router Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Output Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Security Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Input Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:20:31 --> Language Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Loader Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Session Class Initialized
DEBUG - 2013-11-28 06:20:31 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:20:32 --> Session routines successfully run
DEBUG - 2013-11-28 06:20:32 --> Controller Class Initialized
DEBUG - 2013-11-28 06:20:32 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:20:32 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:20:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:20:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:20:32 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:32 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:32 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:20:32 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:20:32 --> Final output sent to browser
DEBUG - 2013-11-28 06:20:32 --> Total execution time: 1.0411
DEBUG - 2013-11-28 06:20:34 --> Config Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:20:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:20:34 --> URI Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Router Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Output Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Security Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Input Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:20:34 --> Language Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Loader Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Session Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:20:34 --> Session routines successfully run
DEBUG - 2013-11-28 06:20:34 --> Controller Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:20:34 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:20:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:20:34 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:34 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:35 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:20:35 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:20:35 --> Final output sent to browser
DEBUG - 2013-11-28 06:20:35 --> Total execution time: 1.0221
DEBUG - 2013-11-28 06:20:44 --> Config Class Initialized
DEBUG - 2013-11-28 06:20:44 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:20:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:20:45 --> URI Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Router Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Output Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Security Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Input Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:20:45 --> Language Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Loader Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Session Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:20:45 --> Session routines successfully run
DEBUG - 2013-11-28 06:20:45 --> Controller Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:20:45 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:20:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:20:45 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:20:45 --> Final output sent to browser
DEBUG - 2013-11-28 06:20:46 --> Total execution time: 1.0511
DEBUG - 2013-11-28 06:20:53 --> Config Class Initialized
DEBUG - 2013-11-28 06:20:53 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:20:53 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:20:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:20:54 --> URI Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Router Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Output Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Security Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Input Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:20:54 --> Language Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Loader Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Session Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:20:54 --> Session routines successfully run
DEBUG - 2013-11-28 06:20:54 --> Controller Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:20:54 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:20:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:20:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:20:54 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Model Class Initialized
DEBUG - 2013-11-28 06:20:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:20:54 --> Final output sent to browser
DEBUG - 2013-11-28 06:20:55 --> Total execution time: 1.0821
DEBUG - 2013-11-28 06:39:27 --> Config Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:39:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:39:27 --> URI Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Router Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Output Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Security Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Input Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:39:27 --> Language Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Loader Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Session Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:39:27 --> Session routines successfully run
DEBUG - 2013-11-28 06:39:27 --> Controller Class Initialized
DEBUG - 2013-11-28 06:39:27 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:39:27 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:39:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:39:28 --> Model Class Initialized
DEBUG - 2013-11-28 06:39:28 --> Model Class Initialized
DEBUG - 2013-11-28 06:39:28 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:39:28 --> Model Class Initialized
DEBUG - 2013-11-28 06:39:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:39:28 --> DB Transaction Failure
ERROR - 2013-11-28 06:39:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked
FROM (`Posts`)
JOIN `users` ON `Posts`.`user_id` = `users`.`id`
J' at line 1
DEBUG - 2013-11-28 06:39:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:41:47 --> Config Class Initialized
DEBUG - 2013-11-28 06:41:47 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:41:47 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:41:47 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:41:47 --> URI Class Initialized
DEBUG - 2013-11-28 06:41:47 --> Router Class Initialized
DEBUG - 2013-11-28 06:41:47 --> Output Class Initialized
DEBUG - 2013-11-28 06:41:47 --> Security Class Initialized
DEBUG - 2013-11-28 06:41:47 --> Input Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:41:48 --> Language Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Loader Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Session Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:41:48 --> Session routines successfully run
DEBUG - 2013-11-28 06:41:48 --> Controller Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:41:48 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:41:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:41:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:41:48 --> Model Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Model Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Model Class Initialized
DEBUG - 2013-11-28 06:41:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:41:48 --> DB Transaction Failure
ERROR - 2013-11-28 06:41:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked
FROM (`Posts`)
JOIN `users` ON `Posts`.`user_id` = `users`.`id`
J' at line 1
DEBUG - 2013-11-28 06:41:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:45:00 --> Config Class Initialized
DEBUG - 2013-11-28 06:45:00 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:45:00 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:45:00 --> URI Class Initialized
DEBUG - 2013-11-28 06:45:00 --> Router Class Initialized
DEBUG - 2013-11-28 06:45:00 --> Output Class Initialized
DEBUG - 2013-11-28 06:45:00 --> Security Class Initialized
DEBUG - 2013-11-28 06:45:00 --> Input Class Initialized
DEBUG - 2013-11-28 06:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:45:00 --> Language Class Initialized
DEBUG - 2013-11-28 06:45:00 --> Loader Class Initialized
DEBUG - 2013-11-28 06:45:01 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:45:01 --> Session Class Initialized
DEBUG - 2013-11-28 06:45:01 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:45:01 --> Session routines successfully run
DEBUG - 2013-11-28 06:45:01 --> Controller Class Initialized
DEBUG - 2013-11-28 06:45:01 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:45:01 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:45:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:45:01 --> Model Class Initialized
DEBUG - 2013-11-28 06:45:01 --> Model Class Initialized
DEBUG - 2013-11-28 06:45:01 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:45:01 --> Model Class Initialized
DEBUG - 2013-11-28 06:45:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:45:01 --> DB Transaction Failure
ERROR - 2013-11-28 06:45:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked
FROM (`Posts`)
JOIN `users` ON `Posts`.`user_id` = `users`.`id`
J' at line 1
DEBUG - 2013-11-28 06:45:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:47:58 --> Config Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:47:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:47:58 --> URI Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Router Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Output Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Security Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Input Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:47:58 --> Language Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Loader Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Session Class Initialized
DEBUG - 2013-11-28 06:47:58 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:47:59 --> Session routines successfully run
DEBUG - 2013-11-28 06:47:59 --> Controller Class Initialized
DEBUG - 2013-11-28 06:47:59 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:47:59 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:47:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:47:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:47:59 --> Model Class Initialized
DEBUG - 2013-11-28 06:47:59 --> Model Class Initialized
DEBUG - 2013-11-28 06:47:59 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:47:59 --> Model Class Initialized
DEBUG - 2013-11-28 06:47:59 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:47:59 --> DB Transaction Failure
ERROR - 2013-11-28 06:47:59 --> Query error: Not unique table/alias: 'user_profiles'
DEBUG - 2013-11-28 06:47:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:48:00 --> Config Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:48:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:48:00 --> URI Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Router Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Output Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Security Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Input Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:48:00 --> Language Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Loader Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Session Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:48:00 --> Session routines successfully run
DEBUG - 2013-11-28 06:48:00 --> Controller Class Initialized
DEBUG - 2013-11-28 06:48:00 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:48:01 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:48:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:48:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:48:01 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:01 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:01 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:48:01 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:48:01 --> DB Transaction Failure
ERROR - 2013-11-28 06:48:01 --> Query error: Not unique table/alias: 'user_profiles'
DEBUG - 2013-11-28 06:48:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:48:20 --> Config Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:48:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:48:20 --> URI Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Router Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Output Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Security Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Input Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:48:20 --> Language Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Loader Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Session Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:48:20 --> Session routines successfully run
DEBUG - 2013-11-28 06:48:20 --> Controller Class Initialized
DEBUG - 2013-11-28 06:48:20 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:48:20 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:48:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:48:21 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:21 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:21 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:48:21 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:48:21 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 06:48:21 --> Final output sent to browser
DEBUG - 2013-11-28 06:48:21 --> Total execution time: 1.5421
DEBUG - 2013-11-28 06:48:34 --> Config Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:48:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:48:34 --> URI Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Router Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Output Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Security Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Input Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:48:34 --> Language Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Loader Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Session Class Initialized
DEBUG - 2013-11-28 06:48:34 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:48:35 --> Session routines successfully run
DEBUG - 2013-11-28 06:48:35 --> Controller Class Initialized
DEBUG - 2013-11-28 06:48:35 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:48:35 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:48:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:48:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:48:35 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:35 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:35 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:48:35 --> Model Class Initialized
DEBUG - 2013-11-28 06:48:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:48:35 --> DB Transaction Failure
ERROR - 2013-11-28 06:48:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked
FROM (`Posts`)
JOIN `users` ON `Posts`.`user_id` = `users`.`id`
J' at line 1
DEBUG - 2013-11-28 06:48:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:49:38 --> Config Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:49:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:49:38 --> URI Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Router Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Output Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Security Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Input Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:49:38 --> Language Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Loader Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Session Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:49:38 --> Session routines successfully run
DEBUG - 2013-11-28 06:49:38 --> Controller Class Initialized
DEBUG - 2013-11-28 06:49:38 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:49:38 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:49:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:49:39 --> Model Class Initialized
DEBUG - 2013-11-28 06:49:39 --> Model Class Initialized
DEBUG - 2013-11-28 06:49:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:49:39 --> Model Class Initialized
DEBUG - 2013-11-28 06:49:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:49:39 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 06:49:39 --> Final output sent to browser
DEBUG - 2013-11-28 06:49:39 --> Total execution time: 1.1851
DEBUG - 2013-11-28 06:49:54 --> Config Class Initialized
DEBUG - 2013-11-28 06:49:54 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:49:54 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:49:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:49:54 --> URI Class Initialized
DEBUG - 2013-11-28 06:49:54 --> Router Class Initialized
DEBUG - 2013-11-28 06:49:54 --> Output Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Security Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Input Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:49:55 --> Language Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Loader Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Session Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:49:55 --> Session routines successfully run
DEBUG - 2013-11-28 06:49:55 --> Controller Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:49:55 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:49:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:49:55 --> Model Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Model Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Model Class Initialized
DEBUG - 2013-11-28 06:49:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:49:55 --> DB Transaction Failure
ERROR - 2013-11-28 06:49:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked
FROM (`Posts`)
JOIN `users` ON `Posts`.`user_id` = `users`.`id`
J' at line 1
DEBUG - 2013-11-28 06:49:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:50:05 --> Config Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:50:06 --> URI Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Router Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Output Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Security Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Input Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:50:06 --> Language Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Loader Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Session Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:50:06 --> Session routines successfully run
DEBUG - 2013-11-28 06:50:06 --> Controller Class Initialized
DEBUG - 2013-11-28 06:50:06 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:50:06 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:50:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:50:06 --> Model Class Initialized
DEBUG - 2013-11-28 06:50:07 --> Model Class Initialized
DEBUG - 2013-11-28 06:50:07 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:50:07 --> Model Class Initialized
DEBUG - 2013-11-28 06:50:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:50:07 --> DB Transaction Failure
ERROR - 2013-11-28 06:50:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked
FROM (`Posts`)
JOIN `users` ON `Posts`.`user_id` = `users`.`id`
J' at line 1
DEBUG - 2013-11-28 06:50:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:52:18 --> Config Class Initialized
DEBUG - 2013-11-28 06:52:18 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:52:18 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:52:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:52:18 --> URI Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Router Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Output Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Security Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Input Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:52:19 --> Language Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Loader Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Session Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:52:19 --> Session routines successfully run
DEBUG - 2013-11-28 06:52:19 --> Controller Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:52:19 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:52:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:52:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:52:19 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:52:19 --> DB Transaction Failure
ERROR - 2013-11-28 06:52:20 --> Query error: Unknown column 'PostLikes.*' in 'field list'
DEBUG - 2013-11-28 06:52:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:52:45 --> Config Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:52:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:52:45 --> URI Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Router Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Output Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Security Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Input Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:52:45 --> Language Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Loader Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Session Class Initialized
DEBUG - 2013-11-28 06:52:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:52:46 --> Session routines successfully run
DEBUG - 2013-11-28 06:52:46 --> Controller Class Initialized
DEBUG - 2013-11-28 06:52:46 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:52:46 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:52:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:52:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:52:46 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:46 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:46 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:52:46 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:52:46 --> DB Transaction Failure
ERROR - 2013-11-28 06:52:46 --> Query error: Unknown column 'COUNT(PostLikes.*)' in 'field list'
DEBUG - 2013-11-28 06:52:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:52:57 --> Config Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:52:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:52:57 --> URI Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Router Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Output Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Security Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Input Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:52:57 --> Language Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Loader Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Session Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:52:57 --> Session routines successfully run
DEBUG - 2013-11-28 06:52:57 --> Controller Class Initialized
DEBUG - 2013-11-28 06:52:57 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:52:57 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:52:57 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:52:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:52:58 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:58 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:58 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:52:58 --> Model Class Initialized
DEBUG - 2013-11-28 06:52:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:52:58 --> DB Transaction Failure
ERROR - 2013-11-28 06:52:58 --> Query error: Unknown column 'COUNT(PostLikes.*)' in 'field list'
DEBUG - 2013-11-28 06:52:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:53:32 --> Config Class Initialized
DEBUG - 2013-11-28 06:53:32 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:53:32 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:53:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:53:32 --> URI Class Initialized
DEBUG - 2013-11-28 06:53:32 --> Router Class Initialized
DEBUG - 2013-11-28 06:53:32 --> Output Class Initialized
DEBUG - 2013-11-28 06:53:32 --> Security Class Initialized
DEBUG - 2013-11-28 06:53:32 --> Input Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:53:33 --> Language Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Loader Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Session Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:53:33 --> Session routines successfully run
DEBUG - 2013-11-28 06:53:33 --> Controller Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:53:33 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:53:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-28 06:53:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:53:33 --> DB Transaction Failure
ERROR - 2013-11-28 06:53:33 --> Query error: Unknown column 'PostLikes.*' in 'field list'
DEBUG - 2013-11-28 06:53:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:53:53 --> Config Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:53:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:53:53 --> URI Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Router Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Output Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Security Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Input Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:53:53 --> Language Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Loader Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Session Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:53:53 --> Session routines successfully run
DEBUG - 2013-11-28 06:53:53 --> Controller Class Initialized
DEBUG - 2013-11-28 06:53:53 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:53:53 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:53:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:53:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:53:53 --> Model Class Initialized
DEBUG - 2013-11-28 06:53:54 --> Model Class Initialized
DEBUG - 2013-11-28 06:53:54 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:53:54 --> Model Class Initialized
DEBUG - 2013-11-28 06:53:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:53:54 --> DB Transaction Failure
ERROR - 2013-11-28 06:53:54 --> Query error: Unknown column 'PostLikes.*' in 'field list'
DEBUG - 2013-11-28 06:53:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:54:08 --> Config Class Initialized
DEBUG - 2013-11-28 06:54:08 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:54:08 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:54:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:54:08 --> URI Class Initialized
DEBUG - 2013-11-28 06:54:08 --> Router Class Initialized
DEBUG - 2013-11-28 06:54:08 --> Output Class Initialized
DEBUG - 2013-11-28 06:54:08 --> Security Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Input Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:54:09 --> Language Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Loader Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Session Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:54:09 --> Session routines successfully run
DEBUG - 2013-11-28 06:54:09 --> Controller Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:54:09 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:54:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:54:09 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:54:09 --> DB Transaction Failure
ERROR - 2013-11-28 06:54:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked
FROM (`Posts`)
JOIN `users` ON `Posts`.`user_id` = `users`.`id`
J' at line 1
DEBUG - 2013-11-28 06:54:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:54:22 --> Config Class Initialized
DEBUG - 2013-11-28 06:54:22 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:54:22 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:54:22 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:54:22 --> URI Class Initialized
DEBUG - 2013-11-28 06:54:22 --> Router Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Output Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Security Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Input Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:54:23 --> Language Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Loader Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Session Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:54:23 --> Session routines successfully run
DEBUG - 2013-11-28 06:54:23 --> Controller Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:54:23 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:54:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:54:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:54:23 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:23 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:54:25 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:54:25 --> DB Transaction Failure
ERROR - 2013-11-28 06:54:25 --> Query error: Unknown column 'PostLikes.*' in 'field list'
DEBUG - 2013-11-28 06:54:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:54:40 --> Config Class Initialized
DEBUG - 2013-11-28 06:54:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:54:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:54:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:54:40 --> URI Class Initialized
DEBUG - 2013-11-28 06:54:40 --> Router Class Initialized
DEBUG - 2013-11-28 06:54:40 --> Output Class Initialized
DEBUG - 2013-11-28 06:54:40 --> Security Class Initialized
DEBUG - 2013-11-28 06:54:40 --> Input Class Initialized
DEBUG - 2013-11-28 06:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:54:40 --> Language Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Loader Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Session Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:54:41 --> Session routines successfully run
DEBUG - 2013-11-28 06:54:41 --> Controller Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:54:41 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:54:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:54:41 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:54:41 --> DB Transaction Failure
ERROR - 2013-11-28 06:54:41 --> Query error: Unknown column 'COUNT(PostLikes.*)' in 'field list'
DEBUG - 2013-11-28 06:54:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:54:52 --> Config Class Initialized
DEBUG - 2013-11-28 06:54:52 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:54:52 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:54:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:54:52 --> URI Class Initialized
DEBUG - 2013-11-28 06:54:52 --> Router Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Output Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Security Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Input Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:54:53 --> Language Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Loader Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Session Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:54:53 --> Session routines successfully run
DEBUG - 2013-11-28 06:54:53 --> Controller Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:54:53 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:54:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:54:53 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Model Class Initialized
DEBUG - 2013-11-28 06:54:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:54:53 --> DB Transaction Failure
ERROR - 2013-11-28 06:54:53 --> Query error: Unknown column 'PostLikes.*' in 'field list'
DEBUG - 2013-11-28 06:54:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:55:06 --> Config Class Initialized
DEBUG - 2013-11-28 06:55:06 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:55:06 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:55:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:55:06 --> URI Class Initialized
DEBUG - 2013-11-28 06:55:06 --> Router Class Initialized
DEBUG - 2013-11-28 06:55:06 --> Output Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Security Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Input Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:55:07 --> Language Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Loader Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Session Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:55:07 --> Session routines successfully run
DEBUG - 2013-11-28 06:55:07 --> Controller Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:55:07 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:55:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:55:07 --> Model Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Model Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:55:07 --> Model Class Initialized
DEBUG - 2013-11-28 06:55:08 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:55:08 --> DB Transaction Failure
ERROR - 2013-11-28 06:55:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked
FROM (`Posts`)
JOIN `users` ON `Posts`.`user_id` = `users`.`id`
J' at line 1
DEBUG - 2013-11-28 06:55:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:57:36 --> Config Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:57:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:57:36 --> URI Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Router Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Output Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Security Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Input Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:57:36 --> Language Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Loader Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:57:36 --> Session Class Initialized
DEBUG - 2013-11-28 06:57:37 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:57:37 --> Session garbage collection performed.
DEBUG - 2013-11-28 06:57:37 --> Session routines successfully run
DEBUG - 2013-11-28 06:57:37 --> Controller Class Initialized
DEBUG - 2013-11-28 06:57:37 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:57:37 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:57:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:57:37 --> Model Class Initialized
DEBUG - 2013-11-28 06:57:37 --> Model Class Initialized
DEBUG - 2013-11-28 06:57:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:57:37 --> Model Class Initialized
DEBUG - 2013-11-28 06:57:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:57:37 --> DB Transaction Failure
ERROR - 2013-11-28 06:57:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked, Posts.*, users.username, user_profiles.profile_image
FROM (`Post' at line 1
DEBUG - 2013-11-28 06:57:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 06:57:59 --> Config Class Initialized
DEBUG - 2013-11-28 06:57:59 --> Hooks Class Initialized
DEBUG - 2013-11-28 06:57:59 --> Utf8 Class Initialized
DEBUG - 2013-11-28 06:57:59 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 06:57:59 --> URI Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Router Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Output Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Security Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Input Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 06:58:00 --> Language Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Loader Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Database Driver Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Session Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Helper loaded: string_helper
DEBUG - 2013-11-28 06:58:00 --> Session routines successfully run
DEBUG - 2013-11-28 06:58:00 --> Controller Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Helper loaded: form_helper
DEBUG - 2013-11-28 06:58:00 --> Helper loaded: url_helper
DEBUG - 2013-11-28 06:58:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 06:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 06:58:00 --> Model Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Model Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Image Lib Class Initialized
DEBUG - 2013-11-28 06:58:00 --> Model Class Initialized
DEBUG - 2013-11-28 06:58:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 06:58:01 --> DB Transaction Failure
ERROR - 2013-11-28 06:58:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked, Posts.*, users.username, user_profiles.profile_image
FROM (`Post' at line 1
DEBUG - 2013-11-28 06:58:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 07:01:07 --> Config Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:01:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:01:07 --> URI Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Router Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Output Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Security Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Input Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:01:07 --> Language Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Loader Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Session Class Initialized
DEBUG - 2013-11-28 07:01:07 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:01:07 --> Session routines successfully run
DEBUG - 2013-11-28 07:01:07 --> Controller Class Initialized
DEBUG - 2013-11-28 07:01:08 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:01:08 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:01:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:01:08 --> Model Class Initialized
DEBUG - 2013-11-28 07:01:08 --> Model Class Initialized
DEBUG - 2013-11-28 07:01:08 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:01:08 --> Model Class Initialized
DEBUG - 2013-11-28 07:01:08 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:01:08 --> DB Transaction Failure
ERROR - 2013-11-28 07:01:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked, Posts.*, users.username, user_profiles.profile_image
          ' at line 1
DEBUG - 2013-11-28 07:01:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 07:01:25 --> Config Class Initialized
DEBUG - 2013-11-28 07:01:25 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:01:26 --> URI Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Router Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Output Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Security Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Input Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:01:26 --> Language Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Loader Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Session Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:01:26 --> Session routines successfully run
DEBUG - 2013-11-28 07:01:26 --> Controller Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:01:26 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:01:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:01:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:01:26 --> Model Class Initialized
DEBUG - 2013-11-28 07:01:26 --> Model Class Initialized
DEBUG - 2013-11-28 07:01:27 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:01:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:01:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:01:27 --> DB Transaction Failure
ERROR - 2013-11-28 07:01:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) AS is_liked, Posts.*, users.username, user_profiles.profile_image
          ' at line 1
DEBUG - 2013-11-28 07:01:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 07:02:38 --> Config Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:02:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:02:38 --> URI Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Router Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Output Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Security Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Input Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:02:38 --> Language Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Loader Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:02:38 --> Session Class Initialized
DEBUG - 2013-11-28 07:02:39 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:02:39 --> Session routines successfully run
DEBUG - 2013-11-28 07:02:39 --> Controller Class Initialized
DEBUG - 2013-11-28 07:02:39 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:02:39 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:02:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:02:39 --> Model Class Initialized
DEBUG - 2013-11-28 07:02:39 --> Model Class Initialized
DEBUG - 2013-11-28 07:02:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:02:39 --> Model Class Initialized
DEBUG - 2013-11-28 07:02:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:02:39 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:02:39 --> Final output sent to browser
DEBUG - 2013-11-28 07:02:39 --> Total execution time: 1.2721
DEBUG - 2013-11-28 07:03:08 --> Config Class Initialized
DEBUG - 2013-11-28 07:03:08 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:03:08 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:03:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:03:08 --> URI Class Initialized
DEBUG - 2013-11-28 07:03:08 --> Router Class Initialized
DEBUG - 2013-11-28 07:03:08 --> Output Class Initialized
DEBUG - 2013-11-28 07:03:08 --> Security Class Initialized
DEBUG - 2013-11-28 07:03:08 --> Input Class Initialized
DEBUG - 2013-11-28 07:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:03:08 --> Language Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Loader Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Session Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:03:09 --> Session routines successfully run
DEBUG - 2013-11-28 07:03:09 --> Controller Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:03:09 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:03:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:03:09 --> Model Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Model Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Model Class Initialized
DEBUG - 2013-11-28 07:03:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:03:09 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:03:09 --> Final output sent to browser
DEBUG - 2013-11-28 07:03:09 --> Total execution time: 1.2671
DEBUG - 2013-11-28 07:15:39 --> Config Class Initialized
DEBUG - 2013-11-28 07:15:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:15:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:15:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:15:39 --> URI Class Initialized
DEBUG - 2013-11-28 07:15:39 --> Router Class Initialized
DEBUG - 2013-11-28 07:15:39 --> Output Class Initialized
DEBUG - 2013-11-28 07:15:40 --> Security Class Initialized
DEBUG - 2013-11-28 07:15:40 --> Input Class Initialized
DEBUG - 2013-11-28 07:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:15:40 --> Language Class Initialized
DEBUG - 2013-11-28 07:15:40 --> Loader Class Initialized
DEBUG - 2013-11-28 07:15:40 --> Database Driver Class Initialized
ERROR - 2013-11-28 07:15:40 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-11-28 07:15:40 --> Session Class Initialized
DEBUG - 2013-11-28 07:15:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:15:40 --> Session routines successfully run
DEBUG - 2013-11-28 07:15:40 --> Controller Class Initialized
DEBUG - 2013-11-28 07:15:40 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:15:40 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:15:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:15:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:15:40 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:40 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:15:41 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:15:41 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:15:41 --> Final output sent to browser
DEBUG - 2013-11-28 07:15:41 --> Total execution time: 1.6431
DEBUG - 2013-11-28 07:15:50 --> Config Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:15:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:15:50 --> URI Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Router Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Output Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Security Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Input Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:15:50 --> Language Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Loader Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Session Class Initialized
DEBUG - 2013-11-28 07:15:50 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:15:50 --> Session routines successfully run
DEBUG - 2013-11-28 07:15:51 --> Controller Class Initialized
DEBUG - 2013-11-28 07:15:51 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:15:51 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:15:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:15:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:15:51 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:51 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:51 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:15:51 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:15:51 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:15:51 --> Final output sent to browser
DEBUG - 2013-11-28 07:15:51 --> Total execution time: 1.3441
DEBUG - 2013-11-28 07:15:54 --> Config Class Initialized
DEBUG - 2013-11-28 07:15:54 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:15:54 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:15:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:15:55 --> URI Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Router Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Output Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Security Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Input Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:15:55 --> Language Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Loader Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Session Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:15:55 --> Session routines successfully run
DEBUG - 2013-11-28 07:15:55 --> Controller Class Initialized
DEBUG - 2013-11-28 07:15:55 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:15:55 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:15:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:15:55 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:56 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:56 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:15:56 --> Model Class Initialized
DEBUG - 2013-11-28 07:15:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:16:19 --> Config Class Initialized
DEBUG - 2013-11-28 07:16:19 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:16:19 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:16:19 --> URI Class Initialized
DEBUG - 2013-11-28 07:16:19 --> Router Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Output Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Security Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Input Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:16:20 --> Language Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Loader Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Session Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:16:20 --> Session routines successfully run
DEBUG - 2013-11-28 07:16:20 --> Controller Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:16:20 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:16:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:16:20 --> Model Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Model Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Model Class Initialized
DEBUG - 2013-11-28 07:16:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:16:21 --> XSS Filtering completed
DEBUG - 2013-11-28 07:16:21 --> Config Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:16:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:16:21 --> URI Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Router Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Output Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Security Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Input Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:16:21 --> Language Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Loader Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Session Class Initialized
DEBUG - 2013-11-28 07:16:21 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:16:22 --> Session routines successfully run
DEBUG - 2013-11-28 07:16:22 --> Controller Class Initialized
DEBUG - 2013-11-28 07:16:22 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:16:22 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:16:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:16:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:16:22 --> Model Class Initialized
DEBUG - 2013-11-28 07:16:22 --> Model Class Initialized
DEBUG - 2013-11-28 07:16:22 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:16:22 --> Model Class Initialized
DEBUG - 2013-11-28 07:16:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:16:22 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:16:22 --> Final output sent to browser
DEBUG - 2013-11-28 07:16:22 --> Total execution time: 1.6661
DEBUG - 2013-11-28 07:17:01 --> Config Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:17:01 --> URI Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Router Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Output Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Security Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Input Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:17:01 --> Language Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Loader Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Session Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:17:01 --> Session routines successfully run
DEBUG - 2013-11-28 07:17:01 --> Controller Class Initialized
DEBUG - 2013-11-28 07:17:01 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:17:02 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:17:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:17:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:17:02 --> XSS Filtering completed
DEBUG - 2013-11-28 07:17:02 --> Config Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:17:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:17:02 --> URI Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Router Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Output Class Initialized
DEBUG - 2013-11-28 07:17:02 --> Security Class Initialized
DEBUG - 2013-11-28 07:17:03 --> Input Class Initialized
DEBUG - 2013-11-28 07:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:17:03 --> Language Class Initialized
DEBUG - 2013-11-28 07:17:03 --> Loader Class Initialized
DEBUG - 2013-11-28 07:17:03 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:17:03 --> Session Class Initialized
DEBUG - 2013-11-28 07:17:03 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:17:03 --> Session routines successfully run
DEBUG - 2013-11-28 07:17:03 --> Controller Class Initialized
DEBUG - 2013-11-28 07:17:03 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:17:03 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:17:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:17:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:17:03 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:03 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:17:04 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:17:04 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:17:04 --> Final output sent to browser
DEBUG - 2013-11-28 07:17:04 --> Total execution time: 1.7081
DEBUG - 2013-11-28 07:17:06 --> Config Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:17:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:17:06 --> URI Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Router Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Output Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Security Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Input Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:17:06 --> Language Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Loader Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Session Class Initialized
DEBUG - 2013-11-28 07:17:06 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:17:06 --> Session routines successfully run
DEBUG - 2013-11-28 07:17:06 --> Controller Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:17:07 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:17:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:17:07 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:17:07 --> XSS Filtering completed
DEBUG - 2013-11-28 07:17:07 --> Config Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:17:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:17:07 --> URI Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Router Class Initialized
DEBUG - 2013-11-28 07:17:07 --> Output Class Initialized
DEBUG - 2013-11-28 07:17:08 --> Security Class Initialized
DEBUG - 2013-11-28 07:17:08 --> Input Class Initialized
DEBUG - 2013-11-28 07:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:17:08 --> Language Class Initialized
DEBUG - 2013-11-28 07:17:08 --> Loader Class Initialized
DEBUG - 2013-11-28 07:17:08 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:17:08 --> Session Class Initialized
DEBUG - 2013-11-28 07:17:08 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:17:08 --> Session routines successfully run
DEBUG - 2013-11-28 07:17:08 --> Controller Class Initialized
DEBUG - 2013-11-28 07:17:08 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:17:09 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:17:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:17:09 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:09 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:09 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:17:09 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:17:09 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:17:09 --> Final output sent to browser
DEBUG - 2013-11-28 07:17:09 --> Total execution time: 2.0241
DEBUG - 2013-11-28 07:17:11 --> Config Class Initialized
DEBUG - 2013-11-28 07:17:11 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:17:11 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:17:11 --> URI Class Initialized
DEBUG - 2013-11-28 07:17:11 --> Router Class Initialized
DEBUG - 2013-11-28 07:17:11 --> Output Class Initialized
DEBUG - 2013-11-28 07:17:11 --> Security Class Initialized
DEBUG - 2013-11-28 07:17:11 --> Input Class Initialized
DEBUG - 2013-11-28 07:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:17:11 --> Language Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Loader Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Session Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:17:12 --> Session routines successfully run
DEBUG - 2013-11-28 07:17:12 --> Controller Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:17:12 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:17:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:17:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:17:12 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:17:12 --> XSS Filtering completed
DEBUG - 2013-11-28 07:17:13 --> Config Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:17:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:17:13 --> URI Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Router Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Output Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Security Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Input Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:17:13 --> Language Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Loader Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Session Class Initialized
DEBUG - 2013-11-28 07:17:13 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:17:14 --> Session routines successfully run
DEBUG - 2013-11-28 07:17:14 --> Controller Class Initialized
DEBUG - 2013-11-28 07:17:14 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:17:14 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:17:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:17:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:14 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:17:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:17:14 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:17:14 --> Final output sent to browser
DEBUG - 2013-11-28 07:17:14 --> Total execution time: 1.6351
DEBUG - 2013-11-28 07:18:45 --> Config Class Initialized
DEBUG - 2013-11-28 07:18:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:18:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:18:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:18:45 --> URI Class Initialized
DEBUG - 2013-11-28 07:18:45 --> Router Class Initialized
DEBUG - 2013-11-28 07:18:45 --> Output Class Initialized
DEBUG - 2013-11-28 07:18:45 --> Security Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Input Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:18:46 --> Language Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Loader Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Session Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:18:46 --> Session routines successfully run
DEBUG - 2013-11-28 07:18:46 --> Controller Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:18:46 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:18:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:18:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:18:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:18:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:18:47 --> XSS Filtering completed
DEBUG - 2013-11-28 07:19:12 --> Config Class Initialized
DEBUG - 2013-11-28 07:19:12 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:19:12 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:19:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:19:13 --> URI Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Router Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Output Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Security Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Input Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:19:13 --> Language Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Loader Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Session Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:19:13 --> Session garbage collection performed.
DEBUG - 2013-11-28 07:19:13 --> Session routines successfully run
DEBUG - 2013-11-28 07:19:13 --> Controller Class Initialized
DEBUG - 2013-11-28 07:19:13 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:19:13 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:19:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:19:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:14 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:19:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:19:14 --> XSS Filtering completed
DEBUG - 2013-11-28 07:19:34 --> Config Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:19:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:19:34 --> URI Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Router Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Output Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Security Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Input Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:19:34 --> Language Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Loader Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Session Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:19:34 --> Session routines successfully run
DEBUG - 2013-11-28 07:19:34 --> Controller Class Initialized
DEBUG - 2013-11-28 07:19:34 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:19:34 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:19:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:19:35 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:35 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:35 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:19:35 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:19:35 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:19:35 --> Final output sent to browser
DEBUG - 2013-11-28 07:19:35 --> Total execution time: 1.6361
DEBUG - 2013-11-28 07:19:37 --> Config Class Initialized
DEBUG - 2013-11-28 07:19:37 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:19:37 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:19:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:19:37 --> URI Class Initialized
DEBUG - 2013-11-28 07:19:37 --> Router Class Initialized
DEBUG - 2013-11-28 07:19:37 --> Output Class Initialized
DEBUG - 2013-11-28 07:19:37 --> Security Class Initialized
DEBUG - 2013-11-28 07:19:37 --> Input Class Initialized
DEBUG - 2013-11-28 07:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:19:38 --> Language Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Loader Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Session Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:19:38 --> Session routines successfully run
DEBUG - 2013-11-28 07:19:38 --> Controller Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:19:38 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:19:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:19:38 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:19:38 --> XSS Filtering completed
DEBUG - 2013-11-28 07:19:55 --> Config Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:19:55 --> URI Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Router Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Output Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Security Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Input Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:19:55 --> Language Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Loader Class Initialized
DEBUG - 2013-11-28 07:19:55 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Session Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:19:56 --> Session routines successfully run
DEBUG - 2013-11-28 07:19:56 --> Controller Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:19:56 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:19:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:19:56 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:19:56 --> XSS Filtering completed
DEBUG - 2013-11-28 07:19:56 --> Config Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:19:56 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:19:57 --> URI Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Router Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Output Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Security Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Input Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:19:57 --> Language Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Loader Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Session Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:19:57 --> Session routines successfully run
DEBUG - 2013-11-28 07:19:57 --> Controller Class Initialized
DEBUG - 2013-11-28 07:19:57 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:19:57 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:19:57 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:19:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:58 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:19:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:19:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:19:58 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:19:58 --> Final output sent to browser
DEBUG - 2013-11-28 07:19:58 --> Total execution time: 1.7051
DEBUG - 2013-11-28 07:20:12 --> Config Class Initialized
DEBUG - 2013-11-28 07:20:12 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:20:12 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:20:12 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:20:12 --> URI Class Initialized
DEBUG - 2013-11-28 07:20:12 --> Router Class Initialized
DEBUG - 2013-11-28 07:20:12 --> Output Class Initialized
DEBUG - 2013-11-28 07:20:12 --> Security Class Initialized
DEBUG - 2013-11-28 07:20:12 --> Input Class Initialized
DEBUG - 2013-11-28 07:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:20:13 --> Language Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Loader Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Session Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:20:13 --> Session routines successfully run
DEBUG - 2013-11-28 07:20:13 --> Controller Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:20:13 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:20:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:20:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:20:13 --> XSS Filtering completed
DEBUG - 2013-11-28 07:20:29 --> Config Class Initialized
DEBUG - 2013-11-28 07:20:29 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:20:29 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:20:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:20:30 --> URI Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Router Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Output Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Security Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Input Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:20:30 --> Language Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Loader Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Session Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:20:30 --> Session routines successfully run
DEBUG - 2013-11-28 07:20:30 --> Controller Class Initialized
DEBUG - 2013-11-28 07:20:30 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:20:30 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:20:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:20:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:20:31 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:31 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:31 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:20:31 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:20:31 --> XSS Filtering completed
DEBUG - 2013-11-28 07:20:36 --> Config Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:20:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:20:36 --> URI Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Router Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Output Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Security Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Input Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:20:36 --> Language Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Loader Class Initialized
DEBUG - 2013-11-28 07:20:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:20:37 --> Session Class Initialized
DEBUG - 2013-11-28 07:20:37 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:20:37 --> Session garbage collection performed.
DEBUG - 2013-11-28 07:20:37 --> Session routines successfully run
DEBUG - 2013-11-28 07:20:37 --> Controller Class Initialized
DEBUG - 2013-11-28 07:20:37 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:20:37 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:20:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:20:37 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:37 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:20:37 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:20:37 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:20:37 --> Final output sent to browser
DEBUG - 2013-11-28 07:20:37 --> Total execution time: 1.4701
DEBUG - 2013-11-28 07:20:39 --> Config Class Initialized
DEBUG - 2013-11-28 07:20:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:20:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:20:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:20:39 --> URI Class Initialized
DEBUG - 2013-11-28 07:20:39 --> Router Class Initialized
DEBUG - 2013-11-28 07:20:39 --> Output Class Initialized
DEBUG - 2013-11-28 07:20:39 --> Security Class Initialized
DEBUG - 2013-11-28 07:20:39 --> Input Class Initialized
DEBUG - 2013-11-28 07:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:20:40 --> Language Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Loader Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Session Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:20:40 --> Session routines successfully run
DEBUG - 2013-11-28 07:20:40 --> Controller Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:20:40 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:20:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:20:40 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:40 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:20:40 --> XSS Filtering completed
DEBUG - 2013-11-28 07:20:45 --> Config Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:20:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:20:45 --> URI Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Router Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Output Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Security Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Input Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:20:45 --> Language Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Loader Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:20:45 --> Session Class Initialized
DEBUG - 2013-11-28 07:20:46 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:20:46 --> Session routines successfully run
DEBUG - 2013-11-28 07:20:46 --> Controller Class Initialized
DEBUG - 2013-11-28 07:20:46 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:20:46 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:20:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:20:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:20:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:46 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:20:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:20:46 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:20:46 --> Final output sent to browser
DEBUG - 2013-11-28 07:20:46 --> Total execution time: 1.5481
DEBUG - 2013-11-28 07:20:55 --> Config Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:20:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:20:55 --> URI Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Router Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Output Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Security Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Input Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:20:55 --> Language Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Loader Class Initialized
DEBUG - 2013-11-28 07:20:55 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:20:56 --> Session Class Initialized
DEBUG - 2013-11-28 07:20:56 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:20:56 --> Session routines successfully run
DEBUG - 2013-11-28 07:20:56 --> Controller Class Initialized
DEBUG - 2013-11-28 07:20:56 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:20:56 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:20:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:20:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:20:56 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:56 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:56 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:20:56 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:20:56 --> XSS Filtering completed
DEBUG - 2013-11-28 07:20:56 --> Config Class Initialized
DEBUG - 2013-11-28 07:20:56 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:20:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:20:57 --> URI Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Router Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Output Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Security Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Input Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:20:57 --> Language Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Loader Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Session Class Initialized
DEBUG - 2013-11-28 07:20:57 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:20:57 --> Session routines successfully run
DEBUG - 2013-11-28 07:20:57 --> Controller Class Initialized
DEBUG - 2013-11-28 07:20:58 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:20:58 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:20:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:20:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:20:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:58 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:20:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:20:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:20:58 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:20:58 --> Final output sent to browser
DEBUG - 2013-11-28 07:20:58 --> Total execution time: 1.9081
DEBUG - 2013-11-28 07:21:26 --> Config Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:21:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:21:26 --> URI Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Router Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Output Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Security Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Input Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:21:26 --> Language Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Loader Class Initialized
DEBUG - 2013-11-28 07:21:26 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:21:27 --> Session Class Initialized
DEBUG - 2013-11-28 07:21:27 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:21:27 --> Session routines successfully run
DEBUG - 2013-11-28 07:21:27 --> Controller Class Initialized
DEBUG - 2013-11-28 07:21:27 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:21:27 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:21:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:21:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:21:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:21:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:21:27 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:21:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:21:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:21:27 --> XSS Filtering completed
DEBUG - 2013-11-28 07:22:27 --> Config Class Initialized
DEBUG - 2013-11-28 07:22:27 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:22:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:22:28 --> URI Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Router Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Output Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Security Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Input Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:22:28 --> Language Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Loader Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Session Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:22:28 --> Session routines successfully run
DEBUG - 2013-11-28 07:22:28 --> Controller Class Initialized
DEBUG - 2013-11-28 07:22:28 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:22:29 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:22:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:22:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:29 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:22:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:22:29 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:22:29 --> Final output sent to browser
DEBUG - 2013-11-28 07:22:29 --> Total execution time: 1.6581
DEBUG - 2013-11-28 07:22:30 --> Config Class Initialized
DEBUG - 2013-11-28 07:22:30 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:22:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:22:31 --> URI Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Router Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Output Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Security Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Input Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:22:31 --> Language Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Loader Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Session Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:22:31 --> Session routines successfully run
DEBUG - 2013-11-28 07:22:31 --> Controller Class Initialized
DEBUG - 2013-11-28 07:22:31 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:22:31 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:22:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:22:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:22:32 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:32 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:32 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:22:32 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:22:32 --> XSS Filtering completed
DEBUG - 2013-11-28 07:22:50 --> Config Class Initialized
DEBUG - 2013-11-28 07:22:50 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:22:50 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:22:50 --> URI Class Initialized
DEBUG - 2013-11-28 07:22:50 --> Router Class Initialized
DEBUG - 2013-11-28 07:22:50 --> Output Class Initialized
DEBUG - 2013-11-28 07:22:50 --> Security Class Initialized
DEBUG - 2013-11-28 07:22:50 --> Input Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:22:51 --> Language Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Loader Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Session Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:22:51 --> Session routines successfully run
DEBUG - 2013-11-28 07:22:51 --> Controller Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:22:51 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:22:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:22:51 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:22:51 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:22:52 --> Final output sent to browser
DEBUG - 2013-11-28 07:22:52 --> Total execution time: 1.4721
DEBUG - 2013-11-28 07:22:53 --> Config Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:22:53 --> URI Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Router Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Output Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Security Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Input Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:22:53 --> Language Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Loader Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Session Class Initialized
DEBUG - 2013-11-28 07:22:53 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:22:53 --> Session routines successfully run
DEBUG - 2013-11-28 07:22:53 --> Controller Class Initialized
DEBUG - 2013-11-28 07:22:54 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:22:54 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:22:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:22:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:22:54 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:54 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:54 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:22:54 --> Model Class Initialized
DEBUG - 2013-11-28 07:22:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:22:54 --> XSS Filtering completed
DEBUG - 2013-11-28 07:24:00 --> Config Class Initialized
DEBUG - 2013-11-28 07:24:00 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:24:00 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:24:00 --> URI Class Initialized
DEBUG - 2013-11-28 07:24:00 --> Router Class Initialized
DEBUG - 2013-11-28 07:24:00 --> Output Class Initialized
DEBUG - 2013-11-28 07:24:00 --> Security Class Initialized
DEBUG - 2013-11-28 07:24:00 --> Input Class Initialized
DEBUG - 2013-11-28 07:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:24:00 --> Language Class Initialized
DEBUG - 2013-11-28 07:24:00 --> Loader Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Session Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:24:01 --> Session routines successfully run
DEBUG - 2013-11-28 07:24:01 --> Controller Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:24:01 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:24:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:24:01 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:24:01 --> XSS Filtering completed
DEBUG - 2013-11-28 07:24:01 --> Config Class Initialized
DEBUG - 2013-11-28 07:24:01 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:24:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:24:02 --> URI Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Router Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Output Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Security Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Input Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:24:02 --> Language Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Loader Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Session Class Initialized
DEBUG - 2013-11-28 07:24:02 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:24:03 --> Session routines successfully run
DEBUG - 2013-11-28 07:24:03 --> Controller Class Initialized
DEBUG - 2013-11-28 07:24:03 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:24:03 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:24:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:24:03 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:03 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:03 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:24:03 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:24:03 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:24:03 --> Final output sent to browser
DEBUG - 2013-11-28 07:24:03 --> Total execution time: 1.9261
DEBUG - 2013-11-28 07:24:07 --> Config Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:24:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:24:07 --> URI Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Router Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Output Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Security Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Input Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:24:07 --> Language Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Loader Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Session Class Initialized
DEBUG - 2013-11-28 07:24:07 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:24:08 --> Session routines successfully run
DEBUG - 2013-11-28 07:24:08 --> Controller Class Initialized
DEBUG - 2013-11-28 07:24:08 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:24:08 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:24:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:24:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:24:08 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:08 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:08 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:24:08 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:08 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:24:08 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:24:08 --> Final output sent to browser
DEBUG - 2013-11-28 07:24:08 --> Total execution time: 1.8031
DEBUG - 2013-11-28 07:24:10 --> Config Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:24:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:24:10 --> URI Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Router Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Output Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Security Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Input Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:24:10 --> Language Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Loader Class Initialized
DEBUG - 2013-11-28 07:24:10 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:24:11 --> Session Class Initialized
DEBUG - 2013-11-28 07:24:11 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:24:11 --> Session routines successfully run
DEBUG - 2013-11-28 07:24:11 --> Controller Class Initialized
DEBUG - 2013-11-28 07:24:11 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:24:11 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:24:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:24:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:24:11 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:11 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:11 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:24:11 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:24:11 --> XSS Filtering completed
ERROR - 2013-11-28 07:24:11 --> Severity: Warning  --> Missing argument 1 for Posts::is_liked(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 92 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 107
ERROR - 2013-11-28 07:24:11 --> Severity: Warning  --> Missing argument 2 for Posts::is_liked(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 92 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 107
ERROR - 2013-11-28 07:24:11 --> Severity: Notice  --> Undefined variable: user_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 108
ERROR - 2013-11-28 07:24:12 --> Severity: Notice  --> Undefined variable: user_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 109
ERROR - 2013-11-28 07:24:12 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 95 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 74
ERROR - 2013-11-28 07:24:12 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 82
DEBUG - 2013-11-28 07:24:12 --> Config Class Initialized
DEBUG - 2013-11-28 07:24:12 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:24:12 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:24:12 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:24:12 --> URI Class Initialized
DEBUG - 2013-11-28 07:24:12 --> Router Class Initialized
DEBUG - 2013-11-28 07:24:12 --> Output Class Initialized
DEBUG - 2013-11-28 07:24:12 --> Security Class Initialized
DEBUG - 2013-11-28 07:24:12 --> Input Class Initialized
DEBUG - 2013-11-28 07:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:24:13 --> Language Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Loader Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Session Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:24:13 --> Session routines successfully run
DEBUG - 2013-11-28 07:24:13 --> Controller Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:24:13 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:24:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:24:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:24:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:24:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:24:14 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:24:14 --> Final output sent to browser
DEBUG - 2013-11-28 07:24:14 --> Total execution time: 1.7461
DEBUG - 2013-11-28 07:33:35 --> Config Class Initialized
DEBUG - 2013-11-28 07:33:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:33:35 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:33:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:33:35 --> URI Class Initialized
DEBUG - 2013-11-28 07:33:35 --> Router Class Initialized
DEBUG - 2013-11-28 07:33:35 --> Output Class Initialized
DEBUG - 2013-11-28 07:33:35 --> Security Class Initialized
DEBUG - 2013-11-28 07:33:35 --> Input Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:33:36 --> Language Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Loader Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Session Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:33:36 --> Session routines successfully run
DEBUG - 2013-11-28 07:33:36 --> Controller Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:33:36 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:33:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:33:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:33:36 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:33:36 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:33:37 --> Config Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:33:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:33:37 --> URI Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Router Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Output Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Security Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Input Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:33:37 --> Language Class Initialized
DEBUG - 2013-11-28 07:33:37 --> Loader Class Initialized
DEBUG - 2013-11-28 07:33:38 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:33:38 --> Session Class Initialized
DEBUG - 2013-11-28 07:33:38 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:33:38 --> Session routines successfully run
DEBUG - 2013-11-28 07:33:38 --> Controller Class Initialized
DEBUG - 2013-11-28 07:33:38 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:33:38 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:33:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:33:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:33:38 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:38 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:38 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:33:38 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:33:39 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:33:39 --> Final output sent to browser
DEBUG - 2013-11-28 07:33:39 --> Total execution time: 2.0831
DEBUG - 2013-11-28 07:33:43 --> Config Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:33:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:33:43 --> URI Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Router Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Output Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Security Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Input Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:33:43 --> Language Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Loader Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Session Class Initialized
DEBUG - 2013-11-28 07:33:43 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:33:44 --> Session routines successfully run
DEBUG - 2013-11-28 07:33:44 --> Controller Class Initialized
DEBUG - 2013-11-28 07:33:44 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:33:44 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:33:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:33:44 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:44 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:44 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:33:44 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:33:44 --> Config Class Initialized
DEBUG - 2013-11-28 07:33:44 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:33:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:33:45 --> URI Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Router Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Output Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Security Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Input Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:33:45 --> Language Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Loader Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Session Class Initialized
DEBUG - 2013-11-28 07:33:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:33:45 --> Session routines successfully run
DEBUG - 2013-11-28 07:33:45 --> Controller Class Initialized
DEBUG - 2013-11-28 07:33:46 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:33:46 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:33:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:33:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:46 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:33:46 --> Model Class Initialized
DEBUG - 2013-11-28 07:33:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:33:46 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:33:46 --> Final output sent to browser
DEBUG - 2013-11-28 07:33:46 --> Total execution time: 1.9161
DEBUG - 2013-11-28 07:35:26 --> Config Class Initialized
DEBUG - 2013-11-28 07:35:26 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:35:26 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:35:26 --> URI Class Initialized
DEBUG - 2013-11-28 07:35:26 --> Router Class Initialized
DEBUG - 2013-11-28 07:35:26 --> Output Class Initialized
DEBUG - 2013-11-28 07:35:26 --> Security Class Initialized
DEBUG - 2013-11-28 07:35:26 --> Input Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:35:27 --> Language Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Loader Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Session Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:35:27 --> Session garbage collection performed.
DEBUG - 2013-11-28 07:35:27 --> Session routines successfully run
DEBUG - 2013-11-28 07:35:27 --> Controller Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:35:27 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:35:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:35:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:35:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:28 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 07:35:28 --> Severity: Notice  --> Undefined variable: user_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 118
DEBUG - 2013-11-28 07:35:53 --> Config Class Initialized
DEBUG - 2013-11-28 07:35:53 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:35:53 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:35:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:35:54 --> URI Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Router Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Output Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Security Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Input Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:35:54 --> Language Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Loader Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Session Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:35:54 --> Session routines successfully run
DEBUG - 2013-11-28 07:35:54 --> Controller Class Initialized
DEBUG - 2013-11-28 07:35:54 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:35:54 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:35:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:35:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:35:55 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:55 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:55 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:35:55 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:35:55 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:35:55 --> Final output sent to browser
DEBUG - 2013-11-28 07:35:55 --> Total execution time: 1.8271
DEBUG - 2013-11-28 07:35:57 --> Config Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:35:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:35:57 --> URI Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Router Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Output Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Security Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Input Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:35:57 --> Language Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Loader Class Initialized
DEBUG - 2013-11-28 07:35:57 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:35:58 --> Session Class Initialized
DEBUG - 2013-11-28 07:35:58 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:35:58 --> Session routines successfully run
DEBUG - 2013-11-28 07:35:58 --> Controller Class Initialized
DEBUG - 2013-11-28 07:35:58 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:35:58 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:35:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:35:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:58 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:35:58 --> Model Class Initialized
DEBUG - 2013-11-28 07:35:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:36:49 --> Config Class Initialized
DEBUG - 2013-11-28 07:36:49 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:36:49 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:36:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:36:49 --> URI Class Initialized
DEBUG - 2013-11-28 07:36:49 --> Router Class Initialized
DEBUG - 2013-11-28 07:36:49 --> Output Class Initialized
DEBUG - 2013-11-28 07:36:49 --> Security Class Initialized
DEBUG - 2013-11-28 07:36:49 --> Input Class Initialized
DEBUG - 2013-11-28 07:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:36:49 --> Language Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Loader Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Session Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:36:50 --> Session routines successfully run
DEBUG - 2013-11-28 07:36:50 --> Controller Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:36:50 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:36:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:36:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:36:50 --> Model Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Model Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Model Class Initialized
DEBUG - 2013-11-28 07:36:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:36:50 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:36:50 --> Final output sent to browser
DEBUG - 2013-11-28 07:36:51 --> Total execution time: 1.6011
DEBUG - 2013-11-28 07:40:09 --> Config Class Initialized
DEBUG - 2013-11-28 07:40:09 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:40:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:40:10 --> URI Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Router Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Output Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Security Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Input Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:40:10 --> Language Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Loader Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Session Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:40:10 --> Session routines successfully run
DEBUG - 2013-11-28 07:40:10 --> Controller Class Initialized
DEBUG - 2013-11-28 07:40:10 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:40:11 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:40:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:40:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:40:11 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:11 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:11 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:40:11 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:40:11 --> Config Class Initialized
DEBUG - 2013-11-28 07:40:11 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:40:11 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:40:11 --> URI Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Router Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Output Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Security Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Input Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:40:12 --> Language Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Loader Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Session Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:40:12 --> Session routines successfully run
DEBUG - 2013-11-28 07:40:12 --> Controller Class Initialized
DEBUG - 2013-11-28 07:40:12 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:40:13 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:40:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:40:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:13 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:40:13 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:40:13 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:40:13 --> Final output sent to browser
DEBUG - 2013-11-28 07:40:13 --> Total execution time: 2.0751
DEBUG - 2013-11-28 07:40:20 --> Config Class Initialized
DEBUG - 2013-11-28 07:40:20 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:40:20 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:40:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:40:20 --> URI Class Initialized
DEBUG - 2013-11-28 07:40:20 --> Router Class Initialized
DEBUG - 2013-11-28 07:40:20 --> Output Class Initialized
DEBUG - 2013-11-28 07:40:20 --> Security Class Initialized
DEBUG - 2013-11-28 07:40:20 --> Input Class Initialized
DEBUG - 2013-11-28 07:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:40:20 --> Language Class Initialized
DEBUG - 2013-11-28 07:40:20 --> Loader Class Initialized
DEBUG - 2013-11-28 07:40:21 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:40:21 --> Session Class Initialized
DEBUG - 2013-11-28 07:40:21 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:40:21 --> Session garbage collection performed.
DEBUG - 2013-11-28 07:40:21 --> Session routines successfully run
DEBUG - 2013-11-28 07:40:21 --> Controller Class Initialized
DEBUG - 2013-11-28 07:40:21 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:40:21 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:40:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:40:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:40:21 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:21 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:21 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:40:21 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:40:21 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:40:22 --> Final output sent to browser
DEBUG - 2013-11-28 07:40:22 --> Total execution time: 1.6861
DEBUG - 2013-11-28 07:40:27 --> Config Class Initialized
DEBUG - 2013-11-28 07:40:27 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:40:27 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:40:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:40:27 --> URI Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Router Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Output Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Security Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Input Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:40:28 --> Language Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Loader Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Session Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:40:28 --> Session routines successfully run
DEBUG - 2013-11-28 07:40:28 --> Controller Class Initialized
DEBUG - 2013-11-28 07:40:28 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:40:28 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:40:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:40:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:40:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:29 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:40:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:40:29 --> Config Class Initialized
DEBUG - 2013-11-28 07:40:29 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:40:29 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:40:29 --> URI Class Initialized
DEBUG - 2013-11-28 07:40:29 --> Router Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Output Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Security Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Input Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:40:30 --> Language Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Loader Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Session Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:40:30 --> Session routines successfully run
DEBUG - 2013-11-28 07:40:30 --> Controller Class Initialized
DEBUG - 2013-11-28 07:40:30 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:40:31 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:40:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:40:31 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:31 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:31 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:40:31 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:40:31 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:40:32 --> Final output sent to browser
DEBUG - 2013-11-28 07:40:32 --> Total execution time: 2.4281
DEBUG - 2013-11-28 07:40:40 --> Config Class Initialized
DEBUG - 2013-11-28 07:40:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:40:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:40:41 --> URI Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Router Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Output Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Security Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Input Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:40:41 --> Language Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Loader Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Session Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:40:41 --> Session routines successfully run
DEBUG - 2013-11-28 07:40:41 --> Controller Class Initialized
DEBUG - 2013-11-28 07:40:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:40:42 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:40:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:40:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:40:42 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:42 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:42 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:40:42 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:40:42 --> Config Class Initialized
DEBUG - 2013-11-28 07:40:42 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:40:42 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:40:42 --> URI Class Initialized
DEBUG - 2013-11-28 07:40:42 --> Router Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Output Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Security Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Input Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:40:43 --> Language Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Loader Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Session Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:40:43 --> Session routines successfully run
DEBUG - 2013-11-28 07:40:43 --> Controller Class Initialized
DEBUG - 2013-11-28 07:40:43 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:40:43 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:40:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:40:44 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:44 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:44 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:40:44 --> Model Class Initialized
DEBUG - 2013-11-28 07:40:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:40:44 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:40:44 --> Final output sent to browser
DEBUG - 2013-11-28 07:40:44 --> Total execution time: 1.9361
DEBUG - 2013-11-28 07:41:35 --> Config Class Initialized
DEBUG - 2013-11-28 07:41:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:41:35 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:41:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:41:35 --> URI Class Initialized
DEBUG - 2013-11-28 07:41:35 --> Router Class Initialized
DEBUG - 2013-11-28 07:41:35 --> Output Class Initialized
DEBUG - 2013-11-28 07:41:35 --> Security Class Initialized
DEBUG - 2013-11-28 07:41:35 --> Input Class Initialized
DEBUG - 2013-11-28 07:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:41:35 --> Language Class Initialized
DEBUG - 2013-11-28 07:41:35 --> Loader Class Initialized
DEBUG - 2013-11-28 07:41:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:41:36 --> Session Class Initialized
DEBUG - 2013-11-28 07:41:36 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:41:37 --> Session routines successfully run
DEBUG - 2013-11-28 07:41:37 --> Controller Class Initialized
DEBUG - 2013-11-28 07:41:37 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:41:37 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:41:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:41:37 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:37 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:41:37 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:41:38 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:41:38 --> Final output sent to browser
DEBUG - 2013-11-28 07:41:38 --> Total execution time: 2.8872
DEBUG - 2013-11-28 07:41:40 --> Config Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:41:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:41:40 --> URI Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Router Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Output Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Security Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Input Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:41:40 --> Language Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Loader Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Session Class Initialized
DEBUG - 2013-11-28 07:41:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:41:41 --> Session routines successfully run
DEBUG - 2013-11-28 07:41:41 --> Controller Class Initialized
DEBUG - 2013-11-28 07:41:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:41:41 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:41:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:41:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:41:41 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:41 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:41:41 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:41:48 --> Config Class Initialized
DEBUG - 2013-11-28 07:41:48 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:41:48 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:41:48 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:41:48 --> URI Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Router Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Output Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Security Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Input Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:41:49 --> Language Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Loader Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Session Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:41:49 --> Session routines successfully run
DEBUG - 2013-11-28 07:41:49 --> Controller Class Initialized
DEBUG - 2013-11-28 07:41:49 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:41:49 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:41:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:41:50 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:50 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:50 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:41:50 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:41:50 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:41:50 --> Final output sent to browser
DEBUG - 2013-11-28 07:41:50 --> Total execution time: 1.9801
DEBUG - 2013-11-28 07:41:57 --> Config Class Initialized
DEBUG - 2013-11-28 07:41:57 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:41:57 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:41:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:41:58 --> URI Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Router Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Output Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Security Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Input Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:41:58 --> Language Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Loader Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Session Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:41:58 --> Session routines successfully run
DEBUG - 2013-11-28 07:41:58 --> Controller Class Initialized
DEBUG - 2013-11-28 07:41:58 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:41:59 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:41:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:41:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:41:59 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:59 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:59 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:41:59 --> Model Class Initialized
DEBUG - 2013-11-28 07:41:59 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:41:59 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:41:59 --> Final output sent to browser
DEBUG - 2013-11-28 07:41:59 --> Total execution time: 1.9281
DEBUG - 2013-11-28 07:42:01 --> Config Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:42:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:42:01 --> URI Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Router Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Output Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Security Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Input Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:42:01 --> Language Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Loader Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:42:01 --> Session Class Initialized
DEBUG - 2013-11-28 07:42:02 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:42:02 --> Session routines successfully run
DEBUG - 2013-11-28 07:42:02 --> Controller Class Initialized
DEBUG - 2013-11-28 07:42:02 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:42:02 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:42:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:42:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:42:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:42:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:42:02 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:42:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:42:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:42:02 --> Config Class Initialized
DEBUG - 2013-11-28 07:42:02 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:42:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:42:03 --> URI Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Router Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Output Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Security Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Input Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:42:03 --> Language Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Loader Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Session Class Initialized
DEBUG - 2013-11-28 07:42:03 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:42:04 --> Session routines successfully run
DEBUG - 2013-11-28 07:42:04 --> Controller Class Initialized
DEBUG - 2013-11-28 07:42:04 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:42:04 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:42:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:42:04 --> Model Class Initialized
DEBUG - 2013-11-28 07:42:04 --> Model Class Initialized
DEBUG - 2013-11-28 07:42:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:42:04 --> Model Class Initialized
DEBUG - 2013-11-28 07:42:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:42:04 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:42:05 --> Final output sent to browser
DEBUG - 2013-11-28 07:42:05 --> Total execution time: 2.1111
DEBUG - 2013-11-28 07:47:40 --> Config Class Initialized
DEBUG - 2013-11-28 07:47:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:47:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:47:41 --> URI Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Router Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Output Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Security Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Input Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:47:41 --> Language Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Loader Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Session Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:47:41 --> Session routines successfully run
DEBUG - 2013-11-28 07:47:41 --> Controller Class Initialized
DEBUG - 2013-11-28 07:47:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:47:42 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:47:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:47:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:47:42 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:42 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:42 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:47:42 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:47:42 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:47:42 --> Final output sent to browser
DEBUG - 2013-11-28 07:47:42 --> Total execution time: 1.9531
DEBUG - 2013-11-28 07:47:44 --> Config Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:47:44 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:47:44 --> URI Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Router Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Output Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Security Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Input Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:47:44 --> Language Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Loader Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:47:44 --> Session Class Initialized
DEBUG - 2013-11-28 07:47:45 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:47:45 --> Session routines successfully run
DEBUG - 2013-11-28 07:47:45 --> Controller Class Initialized
DEBUG - 2013-11-28 07:47:45 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:47:45 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:47:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:47:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:47:45 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:45 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:45 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:47:45 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:47:45 --> Config Class Initialized
DEBUG - 2013-11-28 07:47:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:47:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:47:46 --> URI Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Router Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Output Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Security Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Input Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:47:46 --> Language Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Loader Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Session Class Initialized
DEBUG - 2013-11-28 07:47:46 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:47:47 --> Session routines successfully run
DEBUG - 2013-11-28 07:47:47 --> Controller Class Initialized
DEBUG - 2013-11-28 07:47:47 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:47:47 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:47:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:47:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:47:47 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:47 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:47 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:47:47 --> Model Class Initialized
DEBUG - 2013-11-28 07:47:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:47:47 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:47:47 --> Final output sent to browser
DEBUG - 2013-11-28 07:47:48 --> Total execution time: 2.1321
DEBUG - 2013-11-28 07:48:22 --> Config Class Initialized
DEBUG - 2013-11-28 07:48:22 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:48:22 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:48:22 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:48:22 --> URI Class Initialized
DEBUG - 2013-11-28 07:48:22 --> Router Class Initialized
DEBUG - 2013-11-28 07:48:22 --> Output Class Initialized
DEBUG - 2013-11-28 07:48:22 --> Security Class Initialized
DEBUG - 2013-11-28 07:48:23 --> Input Class Initialized
DEBUG - 2013-11-28 07:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:48:23 --> Language Class Initialized
DEBUG - 2013-11-28 07:48:23 --> Loader Class Initialized
DEBUG - 2013-11-28 07:48:23 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:48:23 --> Session Class Initialized
DEBUG - 2013-11-28 07:48:23 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:48:23 --> Session routines successfully run
DEBUG - 2013-11-28 07:48:23 --> Controller Class Initialized
DEBUG - 2013-11-28 07:48:23 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:48:23 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:48:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:48:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:48:23 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:24 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:24 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:48:24 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:48:24 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:48:24 --> Final output sent to browser
DEBUG - 2013-11-28 07:48:24 --> Total execution time: 2.1281
DEBUG - 2013-11-28 07:48:25 --> Config Class Initialized
DEBUG - 2013-11-28 07:48:25 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:48:25 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:48:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:48:25 --> URI Class Initialized
DEBUG - 2013-11-28 07:48:25 --> Router Class Initialized
DEBUG - 2013-11-28 07:48:25 --> Output Class Initialized
DEBUG - 2013-11-28 07:48:25 --> Security Class Initialized
DEBUG - 2013-11-28 07:48:26 --> Input Class Initialized
DEBUG - 2013-11-28 07:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:48:26 --> Language Class Initialized
DEBUG - 2013-11-28 07:48:26 --> Loader Class Initialized
DEBUG - 2013-11-28 07:48:26 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:48:26 --> Session Class Initialized
DEBUG - 2013-11-28 07:48:26 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:48:26 --> Session routines successfully run
DEBUG - 2013-11-28 07:48:26 --> Controller Class Initialized
DEBUG - 2013-11-28 07:48:26 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:48:26 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:48:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:48:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:48:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:27 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:48:27 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:27 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 07:48:27 --> Severity: Warning  --> Missing argument 1 for Posts::is_liked(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 92 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 107
ERROR - 2013-11-28 07:48:27 --> Severity: Warning  --> Missing argument 2 for Posts::is_liked(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 92 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 107
ERROR - 2013-11-28 07:48:27 --> Severity: Notice  --> Undefined variable: user_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 108
ERROR - 2013-11-28 07:48:27 --> Severity: Notice  --> Undefined variable: user_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 109
ERROR - 2013-11-28 07:48:27 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 95 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 74
ERROR - 2013-11-28 07:48:27 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 82
DEBUG - 2013-11-28 07:48:28 --> Config Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:48:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:48:28 --> URI Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Router Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Output Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Security Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Input Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:48:28 --> Language Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Loader Class Initialized
DEBUG - 2013-11-28 07:48:28 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:48:29 --> Session Class Initialized
DEBUG - 2013-11-28 07:48:29 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:48:29 --> Session routines successfully run
DEBUG - 2013-11-28 07:48:29 --> Controller Class Initialized
DEBUG - 2013-11-28 07:48:29 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:48:29 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:48:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:48:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:29 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:48:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:48:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:48:30 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:48:30 --> Final output sent to browser
DEBUG - 2013-11-28 07:48:30 --> Total execution time: 2.1351
DEBUG - 2013-11-28 07:50:21 --> Config Class Initialized
DEBUG - 2013-11-28 07:50:21 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:50:21 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:50:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:50:21 --> URI Class Initialized
DEBUG - 2013-11-28 07:50:21 --> Router Class Initialized
DEBUG - 2013-11-28 07:50:21 --> Output Class Initialized
DEBUG - 2013-11-28 07:50:21 --> Security Class Initialized
DEBUG - 2013-11-28 07:50:21 --> Input Class Initialized
DEBUG - 2013-11-28 07:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:50:21 --> Language Class Initialized
DEBUG - 2013-11-28 07:50:22 --> Loader Class Initialized
DEBUG - 2013-11-28 07:50:22 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:50:22 --> Session Class Initialized
DEBUG - 2013-11-28 07:50:22 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:50:24 --> Session routines successfully run
DEBUG - 2013-11-28 07:50:24 --> Controller Class Initialized
DEBUG - 2013-11-28 07:50:24 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:50:24 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:50:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:50:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:50:24 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:24 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:24 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:50:24 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:24 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 07:50:24 --> Severity: Warning  --> Missing argument 1 for Posts::is_liked(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 92 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 107
ERROR - 2013-11-28 07:50:25 --> Severity: Warning  --> Missing argument 2 for Posts::is_liked(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 92 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 107
ERROR - 2013-11-28 07:50:25 --> Severity: Notice  --> Undefined variable: user_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 108
ERROR - 2013-11-28 07:50:25 --> Severity: Notice  --> Undefined variable: post_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 109
ERROR - 2013-11-28 07:50:25 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 95 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 74
ERROR - 2013-11-28 07:50:25 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 82
DEBUG - 2013-11-28 07:50:25 --> Config Class Initialized
DEBUG - 2013-11-28 07:50:25 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:50:25 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:50:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:50:25 --> URI Class Initialized
DEBUG - 2013-11-28 07:50:25 --> Router Class Initialized
DEBUG - 2013-11-28 07:50:25 --> Output Class Initialized
DEBUG - 2013-11-28 07:50:25 --> Security Class Initialized
DEBUG - 2013-11-28 07:50:25 --> Input Class Initialized
DEBUG - 2013-11-28 07:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:50:25 --> Language Class Initialized
DEBUG - 2013-11-28 07:50:26 --> Loader Class Initialized
DEBUG - 2013-11-28 07:50:26 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:50:26 --> Session Class Initialized
DEBUG - 2013-11-28 07:50:26 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:50:29 --> Session routines successfully run
DEBUG - 2013-11-28 07:50:29 --> Controller Class Initialized
DEBUG - 2013-11-28 07:50:29 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:50:29 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:50:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:50:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:50:29 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:30 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:30 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:50:30 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:50:30 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:50:30 --> Final output sent to browser
DEBUG - 2013-11-28 07:50:30 --> Total execution time: 5.0073
DEBUG - 2013-11-28 07:50:37 --> Config Class Initialized
DEBUG - 2013-11-28 07:50:37 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:50:37 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:50:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:50:37 --> URI Class Initialized
DEBUG - 2013-11-28 07:50:37 --> Router Class Initialized
DEBUG - 2013-11-28 07:50:37 --> Output Class Initialized
DEBUG - 2013-11-28 07:50:37 --> Security Class Initialized
DEBUG - 2013-11-28 07:50:37 --> Input Class Initialized
DEBUG - 2013-11-28 07:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:50:38 --> Language Class Initialized
DEBUG - 2013-11-28 07:50:38 --> Loader Class Initialized
DEBUG - 2013-11-28 07:50:38 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:50:38 --> Session Class Initialized
DEBUG - 2013-11-28 07:50:38 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:50:38 --> Session routines successfully run
DEBUG - 2013-11-28 07:50:38 --> Controller Class Initialized
DEBUG - 2013-11-28 07:50:38 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:50:38 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:50:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:50:38 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:38 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:50:39 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:39 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 07:50:39 --> Severity: Warning  --> Missing argument 1 for Posts::is_liked(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 92 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 107
ERROR - 2013-11-28 07:50:39 --> Severity: Warning  --> Missing argument 2 for Posts::is_liked(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 92 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 107
ERROR - 2013-11-28 07:50:39 --> Severity: Notice  --> Undefined variable: user_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 108
ERROR - 2013-11-28 07:50:39 --> Severity: Notice  --> Undefined variable: post_id C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 109
ERROR - 2013-11-28 07:50:39 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 95 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 74
ERROR - 2013-11-28 07:50:39 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 82
DEBUG - 2013-11-28 07:50:39 --> Config Class Initialized
DEBUG - 2013-11-28 07:50:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:50:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:50:40 --> URI Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Router Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Output Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Security Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Input Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:50:40 --> Language Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Loader Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Session Class Initialized
DEBUG - 2013-11-28 07:50:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:50:41 --> Session routines successfully run
DEBUG - 2013-11-28 07:50:41 --> Controller Class Initialized
DEBUG - 2013-11-28 07:50:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:50:41 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:50:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:50:41 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:41 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:50:41 --> Model Class Initialized
DEBUG - 2013-11-28 07:50:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:50:41 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:50:41 --> Final output sent to browser
DEBUG - 2013-11-28 07:50:42 --> Total execution time: 2.1161
DEBUG - 2013-11-28 07:52:00 --> Config Class Initialized
DEBUG - 2013-11-28 07:52:00 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:52:01 --> URI Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Router Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Output Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Security Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Input Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:52:01 --> Language Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Loader Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Session Class Initialized
DEBUG - 2013-11-28 07:52:01 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:52:01 --> Session routines successfully run
DEBUG - 2013-11-28 07:52:01 --> Controller Class Initialized
DEBUG - 2013-11-28 07:52:02 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:52:02 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:52:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:52:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:52:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:02 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:52:02 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:02 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 07:52:02 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 95 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 74
ERROR - 2013-11-28 07:52:02 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 82
DEBUG - 2013-11-28 07:52:02 --> Config Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:52:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:52:03 --> URI Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Router Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Output Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Security Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Input Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:52:03 --> Language Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Loader Class Initialized
DEBUG - 2013-11-28 07:52:03 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:52:04 --> Session Class Initialized
DEBUG - 2013-11-28 07:52:04 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:52:04 --> Session routines successfully run
DEBUG - 2013-11-28 07:52:04 --> Controller Class Initialized
DEBUG - 2013-11-28 07:52:04 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:52:04 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:52:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:52:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:52:04 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:04 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:52:04 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:52:05 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:52:05 --> Final output sent to browser
DEBUG - 2013-11-28 07:52:05 --> Total execution time: 2.1261
DEBUG - 2013-11-28 07:52:13 --> Config Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:52:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:52:13 --> URI Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Router Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Output Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Security Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Input Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:52:13 --> Language Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Loader Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:52:13 --> Session Class Initialized
DEBUG - 2013-11-28 07:52:14 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:52:14 --> Session routines successfully run
DEBUG - 2013-11-28 07:52:14 --> Controller Class Initialized
DEBUG - 2013-11-28 07:52:14 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:52:14 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:52:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:52:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:52:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:14 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:52:14 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:15 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 07:52:15 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 98
DEBUG - 2013-11-28 07:52:15 --> Config Class Initialized
DEBUG - 2013-11-28 07:52:15 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:52:15 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:52:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:52:15 --> URI Class Initialized
DEBUG - 2013-11-28 07:52:15 --> Router Class Initialized
DEBUG - 2013-11-28 07:52:15 --> Output Class Initialized
DEBUG - 2013-11-28 07:52:15 --> Security Class Initialized
DEBUG - 2013-11-28 07:52:15 --> Input Class Initialized
DEBUG - 2013-11-28 07:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:52:15 --> Language Class Initialized
DEBUG - 2013-11-28 07:52:16 --> Loader Class Initialized
DEBUG - 2013-11-28 07:52:16 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:52:16 --> Session Class Initialized
DEBUG - 2013-11-28 07:52:16 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:52:16 --> Session routines successfully run
DEBUG - 2013-11-28 07:52:16 --> Controller Class Initialized
DEBUG - 2013-11-28 07:52:16 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:52:16 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:52:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:52:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:52:16 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:16 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:17 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:52:17 --> Model Class Initialized
DEBUG - 2013-11-28 07:52:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:52:17 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:52:17 --> Final output sent to browser
DEBUG - 2013-11-28 07:52:17 --> Total execution time: 2.1061
DEBUG - 2013-11-28 07:59:18 --> Config Class Initialized
DEBUG - 2013-11-28 07:59:18 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:59:18 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:59:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:59:18 --> URI Class Initialized
DEBUG - 2013-11-28 07:59:18 --> Router Class Initialized
DEBUG - 2013-11-28 07:59:18 --> Output Class Initialized
DEBUG - 2013-11-28 07:59:18 --> Security Class Initialized
DEBUG - 2013-11-28 07:59:18 --> Input Class Initialized
DEBUG - 2013-11-28 07:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:59:18 --> Language Class Initialized
DEBUG - 2013-11-28 07:59:19 --> Loader Class Initialized
DEBUG - 2013-11-28 07:59:19 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:59:19 --> Session Class Initialized
DEBUG - 2013-11-28 07:59:19 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:59:19 --> Session routines successfully run
DEBUG - 2013-11-28 07:59:19 --> Controller Class Initialized
DEBUG - 2013-11-28 07:59:19 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:59:19 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:59:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:59:20 --> Model Class Initialized
DEBUG - 2013-11-28 07:59:20 --> Model Class Initialized
DEBUG - 2013-11-28 07:59:20 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:59:20 --> Model Class Initialized
DEBUG - 2013-11-28 07:59:20 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 07:59:20 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 95 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 74
ERROR - 2013-11-28 07:59:20 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 82
DEBUG - 2013-11-28 07:59:21 --> Config Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Hooks Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Utf8 Class Initialized
DEBUG - 2013-11-28 07:59:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 07:59:21 --> URI Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Router Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Output Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Security Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Input Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 07:59:21 --> Language Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Loader Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Database Driver Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Session Class Initialized
DEBUG - 2013-11-28 07:59:21 --> Helper loaded: string_helper
DEBUG - 2013-11-28 07:59:22 --> Session routines successfully run
DEBUG - 2013-11-28 07:59:22 --> Controller Class Initialized
DEBUG - 2013-11-28 07:59:22 --> Helper loaded: form_helper
DEBUG - 2013-11-28 07:59:22 --> Helper loaded: url_helper
DEBUG - 2013-11-28 07:59:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 07:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 07:59:22 --> Model Class Initialized
DEBUG - 2013-11-28 07:59:22 --> Model Class Initialized
DEBUG - 2013-11-28 07:59:22 --> Image Lib Class Initialized
DEBUG - 2013-11-28 07:59:22 --> Model Class Initialized
DEBUG - 2013-11-28 07:59:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 07:59:23 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 07:59:23 --> Final output sent to browser
DEBUG - 2013-11-28 07:59:23 --> Total execution time: 2.0961
DEBUG - 2013-11-28 08:02:04 --> Config Class Initialized
DEBUG - 2013-11-28 08:02:04 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:02:04 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:02:04 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:02:04 --> URI Class Initialized
DEBUG - 2013-11-28 08:02:04 --> Router Class Initialized
DEBUG - 2013-11-28 08:02:04 --> Output Class Initialized
DEBUG - 2013-11-28 08:02:05 --> Security Class Initialized
DEBUG - 2013-11-28 08:02:05 --> Input Class Initialized
DEBUG - 2013-11-28 08:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:02:05 --> Language Class Initialized
DEBUG - 2013-11-28 08:02:05 --> Loader Class Initialized
DEBUG - 2013-11-28 08:02:05 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:02:05 --> Session Class Initialized
DEBUG - 2013-11-28 08:02:05 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:02:05 --> Session routines successfully run
DEBUG - 2013-11-28 08:02:05 --> Controller Class Initialized
DEBUG - 2013-11-28 08:02:05 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:02:05 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:02:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:02:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:02:05 --> Model Class Initialized
DEBUG - 2013-11-28 08:02:06 --> Model Class Initialized
DEBUG - 2013-11-28 08:02:06 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:02:06 --> Model Class Initialized
DEBUG - 2013-11-28 08:02:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:02:21 --> Config Class Initialized
DEBUG - 2013-11-28 08:02:21 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:02:21 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:02:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:02:21 --> URI Class Initialized
DEBUG - 2013-11-28 08:02:21 --> Router Class Initialized
DEBUG - 2013-11-28 08:02:21 --> Output Class Initialized
DEBUG - 2013-11-28 08:02:21 --> Security Class Initialized
DEBUG - 2013-11-28 08:02:21 --> Input Class Initialized
DEBUG - 2013-11-28 08:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:02:22 --> Language Class Initialized
DEBUG - 2013-11-28 08:02:22 --> Loader Class Initialized
DEBUG - 2013-11-28 08:02:22 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:02:22 --> Session Class Initialized
DEBUG - 2013-11-28 08:02:22 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:02:22 --> Session routines successfully run
DEBUG - 2013-11-28 08:02:22 --> Controller Class Initialized
DEBUG - 2013-11-28 08:02:22 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:02:22 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:02:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:02:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:02:22 --> Model Class Initialized
DEBUG - 2013-11-28 08:02:22 --> Model Class Initialized
DEBUG - 2013-11-28 08:02:23 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:02:23 --> Model Class Initialized
DEBUG - 2013-11-28 08:02:23 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 08:02:23 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:02:23 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:02:23 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:02:23 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:02:23 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:02:23 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
DEBUG - 2013-11-28 08:02:24 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:02:24 --> Final output sent to browser
DEBUG - 2013-11-28 08:02:24 --> Total execution time: 2.6642
DEBUG - 2013-11-28 08:04:02 --> Config Class Initialized
DEBUG - 2013-11-28 08:04:02 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:04:02 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:04:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:04:03 --> URI Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Router Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Output Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Security Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Input Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:04:03 --> Language Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Loader Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Session Class Initialized
DEBUG - 2013-11-28 08:04:03 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:04:03 --> Session routines successfully run
DEBUG - 2013-11-28 08:04:03 --> Controller Class Initialized
DEBUG - 2013-11-28 08:04:04 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:04:04 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:04:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:04:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:04:04 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:04 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:04 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:04:04 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:04:04 --> DB Transaction Failure
ERROR - 2013-11-28 08:04:04 --> Query error: Unknown column 'Posts.user_id' in 'where clause'
DEBUG - 2013-11-28 08:04:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 08:04:28 --> Config Class Initialized
DEBUG - 2013-11-28 08:04:28 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:04:28 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:04:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:04:28 --> URI Class Initialized
DEBUG - 2013-11-28 08:04:28 --> Router Class Initialized
DEBUG - 2013-11-28 08:04:28 --> No URI present. Default controller set.
DEBUG - 2013-11-28 08:04:28 --> Output Class Initialized
DEBUG - 2013-11-28 08:04:28 --> Security Class Initialized
DEBUG - 2013-11-28 08:04:28 --> Input Class Initialized
DEBUG - 2013-11-28 08:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:04:28 --> Language Class Initialized
DEBUG - 2013-11-28 08:04:28 --> Loader Class Initialized
DEBUG - 2013-11-28 08:04:29 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:04:29 --> Session Class Initialized
DEBUG - 2013-11-28 08:04:29 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:04:29 --> Session routines successfully run
DEBUG - 2013-11-28 08:04:29 --> Controller Class Initialized
DEBUG - 2013-11-28 08:04:29 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:04:29 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:04:29 --> Form Validation Class Initialized
DEBUG - 2013-11-28 08:04:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:04:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:04:29 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:29 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Upload Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:04:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:04:30 --> Config Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:04:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:04:30 --> URI Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Router Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Output Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Security Class Initialized
DEBUG - 2013-11-28 08:04:30 --> Input Class Initialized
DEBUG - 2013-11-28 08:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:04:31 --> Language Class Initialized
DEBUG - 2013-11-28 08:04:31 --> Loader Class Initialized
DEBUG - 2013-11-28 08:04:31 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:04:31 --> Session Class Initialized
DEBUG - 2013-11-28 08:04:31 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:04:31 --> Session routines successfully run
DEBUG - 2013-11-28 08:04:31 --> Controller Class Initialized
DEBUG - 2013-11-28 08:04:31 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:04:31 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:04:31 --> Form Validation Class Initialized
DEBUG - 2013-11-28 08:04:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:04:31 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:32 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:32 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:04:32 --> Upload Class Initialized
DEBUG - 2013-11-28 08:04:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:04:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:04:32 --> Config Class Initialized
DEBUG - 2013-11-28 08:04:32 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:04:32 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:04:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:04:32 --> URI Class Initialized
DEBUG - 2013-11-28 08:04:32 --> Router Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Output Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Security Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Input Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:04:33 --> Language Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Loader Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Session Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:04:33 --> Session routines successfully run
DEBUG - 2013-11-28 08:04:33 --> Controller Class Initialized
DEBUG - 2013-11-28 08:04:33 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:04:33 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:04:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:04:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:04:34 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:34 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:34 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:04:34 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:04:34 --> DB Transaction Failure
ERROR - 2013-11-28 08:04:34 --> Query error: Unknown column 'Posts.user_id' in 'where clause'
DEBUG - 2013-11-28 08:04:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 08:04:57 --> Config Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:04:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:04:57 --> URI Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Router Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Output Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Security Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Input Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:04:57 --> Language Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Loader Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Session Class Initialized
DEBUG - 2013-11-28 08:04:57 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:04:58 --> Session routines successfully run
DEBUG - 2013-11-28 08:04:58 --> Controller Class Initialized
DEBUG - 2013-11-28 08:04:58 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:04:58 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:04:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:04:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:04:58 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:58 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:58 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:04:58 --> Model Class Initialized
DEBUG - 2013-11-28 08:04:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:04:59 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:04:59 --> Final output sent to browser
DEBUG - 2013-11-28 08:04:59 --> Total execution time: 2.0761
DEBUG - 2013-11-28 08:05:38 --> Config Class Initialized
DEBUG - 2013-11-28 08:05:38 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:05:38 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:05:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:05:38 --> URI Class Initialized
DEBUG - 2013-11-28 08:05:38 --> Router Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Output Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Security Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Input Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:05:39 --> Language Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Loader Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Session Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:05:39 --> Session routines successfully run
DEBUG - 2013-11-28 08:05:39 --> Controller Class Initialized
DEBUG - 2013-11-28 08:05:39 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:05:39 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:05:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:05:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:05:40 --> Model Class Initialized
DEBUG - 2013-11-28 08:05:40 --> Model Class Initialized
DEBUG - 2013-11-28 08:05:40 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:05:40 --> Model Class Initialized
DEBUG - 2013-11-28 08:05:40 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:05:40 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:05:40 --> Final output sent to browser
DEBUG - 2013-11-28 08:05:40 --> Total execution time: 2.0901
DEBUG - 2013-11-28 08:05:58 --> Config Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:05:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:05:58 --> URI Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Router Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Output Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Security Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Input Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:05:58 --> Language Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Loader Class Initialized
DEBUG - 2013-11-28 08:05:58 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:05:59 --> Session Class Initialized
DEBUG - 2013-11-28 08:05:59 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:05:59 --> Session routines successfully run
DEBUG - 2013-11-28 08:05:59 --> Controller Class Initialized
DEBUG - 2013-11-28 08:05:59 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:05:59 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:05:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:05:59 --> Model Class Initialized
DEBUG - 2013-11-28 08:05:59 --> Model Class Initialized
DEBUG - 2013-11-28 08:05:59 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:05:59 --> Model Class Initialized
DEBUG - 2013-11-28 08:06:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:06:00 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:06:00 --> Final output sent to browser
DEBUG - 2013-11-28 08:06:00 --> Total execution time: 2.0491
DEBUG - 2013-11-28 08:06:31 --> Config Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:06:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:06:32 --> URI Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Router Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Output Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Security Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Input Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:06:32 --> Language Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Loader Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Session Class Initialized
DEBUG - 2013-11-28 08:06:32 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:06:33 --> Session routines successfully run
DEBUG - 2013-11-28 08:06:33 --> Controller Class Initialized
DEBUG - 2013-11-28 08:06:33 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:06:33 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:06:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:06:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:06:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:06:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:06:33 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:06:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:06:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:06:33 --> DB Transaction Failure
ERROR - 2013-11-28 08:06:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM Posts
                            JOIN users ON Posts.user_id = users.id
' at line 3
DEBUG - 2013-11-28 08:06:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 08:06:46 --> Config Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:06:47 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:06:47 --> URI Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Router Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Output Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Security Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Input Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:06:47 --> Language Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Loader Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Session Class Initialized
DEBUG - 2013-11-28 08:06:47 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:06:48 --> Session routines successfully run
DEBUG - 2013-11-28 08:06:48 --> Controller Class Initialized
DEBUG - 2013-11-28 08:06:48 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:06:48 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:06:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:06:48 --> Model Class Initialized
DEBUG - 2013-11-28 08:06:48 --> Model Class Initialized
DEBUG - 2013-11-28 08:06:48 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:06:48 --> Model Class Initialized
DEBUG - 2013-11-28 08:06:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:06:48 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:06:49 --> Final output sent to browser
DEBUG - 2013-11-28 08:06:49 --> Total execution time: 2.0671
DEBUG - 2013-11-28 08:10:16 --> Config Class Initialized
DEBUG - 2013-11-28 08:10:16 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:10:16 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:10:17 --> URI Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Router Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Output Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Security Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Input Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:10:17 --> Language Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Loader Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Session Class Initialized
DEBUG - 2013-11-28 08:10:17 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:10:18 --> Session garbage collection performed.
DEBUG - 2013-11-28 08:10:18 --> Session routines successfully run
DEBUG - 2013-11-28 08:10:18 --> Controller Class Initialized
DEBUG - 2013-11-28 08:10:18 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:10:18 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:10:18 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:10:18 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:18 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:18 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:10:19 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:19 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 08:10:19 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:10:19 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:10:19 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:10:19 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:10:19 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
ERROR - 2013-11-28 08:10:19 --> Severity: Notice  --> Undefined index: is_liked C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 46
DEBUG - 2013-11-28 08:10:19 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:10:19 --> Final output sent to browser
DEBUG - 2013-11-28 08:10:19 --> Total execution time: 2.9052
DEBUG - 2013-11-28 08:10:31 --> Config Class Initialized
DEBUG - 2013-11-28 08:10:31 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:10:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:10:32 --> URI Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Router Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Output Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Security Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Input Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:10:32 --> Language Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Loader Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Session Class Initialized
DEBUG - 2013-11-28 08:10:32 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:10:33 --> Session routines successfully run
DEBUG - 2013-11-28 08:10:33 --> Controller Class Initialized
DEBUG - 2013-11-28 08:10:33 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:10:33 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:10:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:10:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:33 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:10:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:10:34 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:10:34 --> Final output sent to browser
DEBUG - 2013-11-28 08:10:34 --> Total execution time: 2.2861
DEBUG - 2013-11-28 08:10:54 --> Config Class Initialized
DEBUG - 2013-11-28 08:10:54 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:10:54 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:10:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:10:54 --> URI Class Initialized
DEBUG - 2013-11-28 08:10:54 --> Router Class Initialized
DEBUG - 2013-11-28 08:10:54 --> Output Class Initialized
DEBUG - 2013-11-28 08:10:54 --> Security Class Initialized
DEBUG - 2013-11-28 08:10:54 --> Input Class Initialized
DEBUG - 2013-11-28 08:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:10:55 --> Language Class Initialized
DEBUG - 2013-11-28 08:10:55 --> Loader Class Initialized
DEBUG - 2013-11-28 08:10:55 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:10:55 --> Session Class Initialized
DEBUG - 2013-11-28 08:10:55 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:10:55 --> Session routines successfully run
DEBUG - 2013-11-28 08:10:55 --> Controller Class Initialized
DEBUG - 2013-11-28 08:10:55 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:10:55 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:10:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:10:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:10:55 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:56 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:56 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:10:56 --> Model Class Initialized
DEBUG - 2013-11-28 08:10:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:10:56 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:10:56 --> Final output sent to browser
DEBUG - 2013-11-28 08:10:56 --> Total execution time: 2.4021
DEBUG - 2013-11-28 08:11:10 --> Config Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:11:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:11:11 --> URI Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Router Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Output Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Security Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Input Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:11:11 --> Language Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Loader Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Session Class Initialized
DEBUG - 2013-11-28 08:11:11 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:11:12 --> Session routines successfully run
DEBUG - 2013-11-28 08:11:12 --> Controller Class Initialized
DEBUG - 2013-11-28 08:11:12 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:11:12 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:11:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:11:12 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:12 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:11:12 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:11:12 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:11:13 --> Final output sent to browser
DEBUG - 2013-11-28 08:11:13 --> Total execution time: 2.0731
DEBUG - 2013-11-28 08:11:31 --> Config Class Initialized
DEBUG - 2013-11-28 08:11:31 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:11:31 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:11:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:11:31 --> URI Class Initialized
DEBUG - 2013-11-28 08:11:31 --> Router Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Output Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Security Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Input Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:11:32 --> Language Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Loader Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Session Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:11:32 --> Session routines successfully run
DEBUG - 2013-11-28 08:11:32 --> Controller Class Initialized
DEBUG - 2013-11-28 08:11:32 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:11:32 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:11:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:11:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:11:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:33 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:11:33 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:33 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 08:11:33 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 95 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 74
ERROR - 2013-11-28 08:11:33 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 82
DEBUG - 2013-11-28 08:11:33 --> Config Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Hooks Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Utf8 Class Initialized
DEBUG - 2013-11-28 08:11:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 08:11:34 --> URI Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Router Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Output Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Security Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Input Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 08:11:34 --> Language Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Loader Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Database Driver Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Session Class Initialized
DEBUG - 2013-11-28 08:11:34 --> Helper loaded: string_helper
DEBUG - 2013-11-28 08:11:35 --> Session routines successfully run
DEBUG - 2013-11-28 08:11:35 --> Controller Class Initialized
DEBUG - 2013-11-28 08:11:35 --> Helper loaded: form_helper
DEBUG - 2013-11-28 08:11:35 --> Helper loaded: url_helper
DEBUG - 2013-11-28 08:11:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 08:11:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 08:11:35 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:35 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:35 --> Image Lib Class Initialized
DEBUG - 2013-11-28 08:11:35 --> Model Class Initialized
DEBUG - 2013-11-28 08:11:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 08:11:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 08:11:36 --> Final output sent to browser
DEBUG - 2013-11-28 08:11:36 --> Total execution time: 2.3031
DEBUG - 2013-11-28 17:52:23 --> Config Class Initialized
DEBUG - 2013-11-28 17:52:23 --> Hooks Class Initialized
DEBUG - 2013-11-28 17:52:23 --> Utf8 Class Initialized
DEBUG - 2013-11-28 17:52:23 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 17:52:23 --> URI Class Initialized
DEBUG - 2013-11-28 17:52:24 --> Router Class Initialized
DEBUG - 2013-11-28 17:52:24 --> Output Class Initialized
DEBUG - 2013-11-28 17:52:24 --> Security Class Initialized
DEBUG - 2013-11-28 17:52:24 --> Input Class Initialized
DEBUG - 2013-11-28 17:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 17:52:24 --> Language Class Initialized
DEBUG - 2013-11-28 17:52:24 --> Loader Class Initialized
DEBUG - 2013-11-28 17:52:25 --> Database Driver Class Initialized
ERROR - 2013-11-28 17:52:25 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-11-28 17:52:26 --> Session Class Initialized
DEBUG - 2013-11-28 17:52:26 --> Helper loaded: string_helper
DEBUG - 2013-11-28 17:52:27 --> Session routines successfully run
DEBUG - 2013-11-28 17:52:27 --> Controller Class Initialized
DEBUG - 2013-11-28 17:52:27 --> Helper loaded: form_helper
DEBUG - 2013-11-28 17:52:27 --> Helper loaded: url_helper
DEBUG - 2013-11-28 17:52:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 17:52:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 17:52:27 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:27 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:27 --> Image Lib Class Initialized
DEBUG - 2013-11-28 17:52:28 --> Helper loaded: cookie_helper
DEBUG - 2013-11-28 17:52:28 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 17:52:28 --> Config Class Initialized
DEBUG - 2013-11-28 17:52:28 --> Hooks Class Initialized
DEBUG - 2013-11-28 17:52:28 --> Utf8 Class Initialized
DEBUG - 2013-11-28 17:52:29 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 17:52:29 --> URI Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Router Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Output Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Security Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Input Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 17:52:29 --> Language Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Loader Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Database Driver Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Session Class Initialized
DEBUG - 2013-11-28 17:52:29 --> Helper loaded: string_helper
DEBUG - 2013-11-28 17:52:30 --> A session cookie was not found.
DEBUG - 2013-11-28 17:52:30 --> Session routines successfully run
DEBUG - 2013-11-28 17:52:30 --> Controller Class Initialized
DEBUG - 2013-11-28 17:52:30 --> Helper loaded: form_helper
DEBUG - 2013-11-28 17:52:30 --> Helper loaded: url_helper
DEBUG - 2013-11-28 17:52:30 --> Form Validation Class Initialized
DEBUG - 2013-11-28 17:52:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 17:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 17:52:30 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:30 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:30 --> Image Lib Class Initialized
DEBUG - 2013-11-28 17:52:31 --> Helper loaded: cookie_helper
DEBUG - 2013-11-28 17:52:31 --> Upload Class Initialized
DEBUG - 2013-11-28 17:52:31 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 17:52:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 17:52:31 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:31 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-28 17:52:31 --> Final output sent to browser
DEBUG - 2013-11-28 17:52:31 --> Total execution time: 2.9812
DEBUG - 2013-11-28 17:52:37 --> Config Class Initialized
DEBUG - 2013-11-28 17:52:37 --> Hooks Class Initialized
DEBUG - 2013-11-28 17:52:37 --> Utf8 Class Initialized
DEBUG - 2013-11-28 17:52:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 17:52:37 --> URI Class Initialized
DEBUG - 2013-11-28 17:52:37 --> Router Class Initialized
DEBUG - 2013-11-28 17:52:37 --> Output Class Initialized
DEBUG - 2013-11-28 17:52:38 --> Security Class Initialized
DEBUG - 2013-11-28 17:52:38 --> Input Class Initialized
DEBUG - 2013-11-28 17:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 17:52:38 --> Language Class Initialized
DEBUG - 2013-11-28 17:52:38 --> Loader Class Initialized
DEBUG - 2013-11-28 17:52:38 --> Database Driver Class Initialized
DEBUG - 2013-11-28 17:52:38 --> Session Class Initialized
DEBUG - 2013-11-28 17:52:38 --> Helper loaded: string_helper
DEBUG - 2013-11-28 17:52:38 --> Session routines successfully run
DEBUG - 2013-11-28 17:52:38 --> Controller Class Initialized
DEBUG - 2013-11-28 17:52:38 --> Helper loaded: form_helper
DEBUG - 2013-11-28 17:52:38 --> Helper loaded: url_helper
DEBUG - 2013-11-28 17:52:39 --> Form Validation Class Initialized
DEBUG - 2013-11-28 17:52:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 17:52:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 17:52:39 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:39 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 17:52:39 --> Helper loaded: cookie_helper
DEBUG - 2013-11-28 17:52:39 --> Upload Class Initialized
DEBUG - 2013-11-28 17:52:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 17:52:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 17:52:39 --> XSS Filtering completed
DEBUG - 2013-11-28 17:52:40 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 17:52:40 --> XSS Filtering completed
DEBUG - 2013-11-28 17:52:40 --> XSS Filtering completed
DEBUG - 2013-11-28 17:52:41 --> Config Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Hooks Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Utf8 Class Initialized
DEBUG - 2013-11-28 17:52:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 17:52:41 --> URI Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Router Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Output Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Security Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Input Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 17:52:41 --> Language Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Loader Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Database Driver Class Initialized
DEBUG - 2013-11-28 17:52:41 --> Session Class Initialized
DEBUG - 2013-11-28 17:52:42 --> Helper loaded: string_helper
DEBUG - 2013-11-28 17:52:42 --> Session routines successfully run
DEBUG - 2013-11-28 17:52:42 --> Controller Class Initialized
DEBUG - 2013-11-28 17:52:42 --> Helper loaded: form_helper
DEBUG - 2013-11-28 17:52:42 --> Helper loaded: url_helper
DEBUG - 2013-11-28 17:52:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 17:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 17:52:42 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:42 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:42 --> Image Lib Class Initialized
DEBUG - 2013-11-28 17:52:42 --> Model Class Initialized
DEBUG - 2013-11-28 17:52:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 17:52:43 --> DB Transaction Failure
ERROR - 2013-11-28 17:52:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY Posts.created DESC' at line 8
DEBUG - 2013-11-28 17:52:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 17:53:40 --> Config Class Initialized
DEBUG - 2013-11-28 17:53:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 17:53:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 17:53:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 17:53:40 --> URI Class Initialized
DEBUG - 2013-11-28 17:53:40 --> Router Class Initialized
DEBUG - 2013-11-28 17:53:40 --> Output Class Initialized
DEBUG - 2013-11-28 17:53:40 --> Security Class Initialized
DEBUG - 2013-11-28 17:53:40 --> Input Class Initialized
DEBUG - 2013-11-28 17:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 17:53:41 --> Language Class Initialized
DEBUG - 2013-11-28 17:53:41 --> Loader Class Initialized
DEBUG - 2013-11-28 17:53:41 --> Database Driver Class Initialized
DEBUG - 2013-11-28 17:53:41 --> Session Class Initialized
DEBUG - 2013-11-28 17:53:41 --> Helper loaded: string_helper
DEBUG - 2013-11-28 17:53:41 --> Session routines successfully run
DEBUG - 2013-11-28 17:53:41 --> Controller Class Initialized
DEBUG - 2013-11-28 17:53:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 17:53:41 --> Helper loaded: url_helper
DEBUG - 2013-11-28 17:53:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 17:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 17:53:41 --> Model Class Initialized
DEBUG - 2013-11-28 17:53:42 --> Model Class Initialized
DEBUG - 2013-11-28 17:53:42 --> Image Lib Class Initialized
DEBUG - 2013-11-28 17:53:42 --> Model Class Initialized
DEBUG - 2013-11-28 17:53:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 17:53:42 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 17:53:42 --> Final output sent to browser
DEBUG - 2013-11-28 17:53:42 --> Total execution time: 2.2911
DEBUG - 2013-11-28 18:19:22 --> Config Class Initialized
DEBUG - 2013-11-28 18:19:22 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:19:22 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:19:22 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:19:22 --> URI Class Initialized
DEBUG - 2013-11-28 18:19:22 --> Router Class Initialized
DEBUG - 2013-11-28 18:19:22 --> Output Class Initialized
DEBUG - 2013-11-28 18:19:22 --> Security Class Initialized
DEBUG - 2013-11-28 18:19:22 --> Input Class Initialized
DEBUG - 2013-11-28 18:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:19:22 --> Language Class Initialized
DEBUG - 2013-11-28 18:19:23 --> Loader Class Initialized
DEBUG - 2013-11-28 18:19:23 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:19:23 --> Session Class Initialized
DEBUG - 2013-11-28 18:19:23 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:19:23 --> Session routines successfully run
DEBUG - 2013-11-28 18:19:23 --> Controller Class Initialized
DEBUG - 2013-11-28 18:19:23 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:19:23 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:19:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:19:24 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:24 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:24 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:19:24 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:19:24 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:19:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 18:19:24 --> XSS Filtering completed
DEBUG - 2013-11-28 18:19:25 --> Config Class Initialized
DEBUG - 2013-11-28 18:19:25 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:19:25 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:19:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:19:25 --> URI Class Initialized
DEBUG - 2013-11-28 18:19:25 --> Router Class Initialized
DEBUG - 2013-11-28 18:19:25 --> Output Class Initialized
DEBUG - 2013-11-28 18:19:25 --> Security Class Initialized
DEBUG - 2013-11-28 18:19:25 --> Input Class Initialized
DEBUG - 2013-11-28 18:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:19:25 --> Language Class Initialized
DEBUG - 2013-11-28 18:19:25 --> Loader Class Initialized
DEBUG - 2013-11-28 18:19:26 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:19:26 --> Session Class Initialized
DEBUG - 2013-11-28 18:19:26 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:19:26 --> Session routines successfully run
DEBUG - 2013-11-28 18:19:26 --> Controller Class Initialized
DEBUG - 2013-11-28 18:19:26 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:19:26 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:19:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:19:26 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:26 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:27 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:19:27 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:19:27 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:19:27 --> Final output sent to browser
DEBUG - 2013-11-28 18:19:27 --> Total execution time: 2.3661
DEBUG - 2013-11-28 18:19:37 --> Config Class Initialized
DEBUG - 2013-11-28 18:19:37 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:19:37 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:19:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:19:37 --> URI Class Initialized
DEBUG - 2013-11-28 18:19:37 --> Router Class Initialized
DEBUG - 2013-11-28 18:19:37 --> Output Class Initialized
DEBUG - 2013-11-28 18:19:37 --> Security Class Initialized
DEBUG - 2013-11-28 18:19:37 --> Input Class Initialized
DEBUG - 2013-11-28 18:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:19:38 --> Language Class Initialized
DEBUG - 2013-11-28 18:19:38 --> Loader Class Initialized
DEBUG - 2013-11-28 18:19:38 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:19:38 --> Session Class Initialized
DEBUG - 2013-11-28 18:19:38 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:19:38 --> Session routines successfully run
DEBUG - 2013-11-28 18:19:38 --> Controller Class Initialized
DEBUG - 2013-11-28 18:19:38 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:19:38 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:19:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:19:39 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:39 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:39 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:19:39 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:19:39 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:19:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 18:19:39 --> XSS Filtering completed
DEBUG - 2013-11-28 18:19:39 --> Config Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:19:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:19:40 --> URI Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Router Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Output Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Security Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Input Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:19:40 --> Language Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Loader Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Session Class Initialized
DEBUG - 2013-11-28 18:19:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:19:41 --> Session routines successfully run
DEBUG - 2013-11-28 18:19:41 --> Controller Class Initialized
DEBUG - 2013-11-28 18:19:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:19:41 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:19:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:19:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:19:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:19:42 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:19:42 --> Final output sent to browser
DEBUG - 2013-11-28 18:19:42 --> Total execution time: 2.2411
DEBUG - 2013-11-28 18:19:52 --> Config Class Initialized
DEBUG - 2013-11-28 18:19:52 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:19:52 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:19:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:19:52 --> URI Class Initialized
DEBUG - 2013-11-28 18:19:52 --> Router Class Initialized
DEBUG - 2013-11-28 18:19:52 --> Output Class Initialized
DEBUG - 2013-11-28 18:19:52 --> Security Class Initialized
DEBUG - 2013-11-28 18:19:52 --> Input Class Initialized
DEBUG - 2013-11-28 18:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:19:53 --> Language Class Initialized
DEBUG - 2013-11-28 18:19:53 --> Loader Class Initialized
DEBUG - 2013-11-28 18:19:53 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:19:53 --> Session Class Initialized
DEBUG - 2013-11-28 18:19:53 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:19:53 --> Session routines successfully run
DEBUG - 2013-11-28 18:19:53 --> Controller Class Initialized
DEBUG - 2013-11-28 18:19:53 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:19:53 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:19:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:19:53 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:54 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:54 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:19:54 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:19:54 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:19:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 18:19:54 --> XSS Filtering completed
DEBUG - 2013-11-28 18:19:55 --> Config Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:19:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:19:55 --> URI Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Router Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Output Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Security Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Input Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:19:55 --> Language Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Loader Class Initialized
DEBUG - 2013-11-28 18:19:55 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:19:56 --> Session Class Initialized
DEBUG - 2013-11-28 18:19:56 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:19:56 --> Session routines successfully run
DEBUG - 2013-11-28 18:19:56 --> Controller Class Initialized
DEBUG - 2013-11-28 18:19:56 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:19:56 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:19:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:19:56 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:56 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:56 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:19:57 --> Model Class Initialized
DEBUG - 2013-11-28 18:19:57 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:19:57 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:19:57 --> Final output sent to browser
DEBUG - 2013-11-28 18:19:57 --> Total execution time: 2.2881
DEBUG - 2013-11-28 18:20:07 --> Config Class Initialized
DEBUG - 2013-11-28 18:20:07 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:20:07 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:20:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:20:07 --> URI Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Router Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Output Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Security Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Input Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:20:08 --> Language Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Loader Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Session Class Initialized
DEBUG - 2013-11-28 18:20:08 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:20:08 --> Session routines successfully run
DEBUG - 2013-11-28 18:20:08 --> Controller Class Initialized
DEBUG - 2013-11-28 18:20:09 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:20:09 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:20:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:20:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:20:09 --> Model Class Initialized
DEBUG - 2013-11-28 18:20:09 --> Model Class Initialized
DEBUG - 2013-11-28 18:20:09 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:20:09 --> Model Class Initialized
DEBUG - 2013-11-28 18:20:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:20:09 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:20:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 18:20:10 --> XSS Filtering completed
DEBUG - 2013-11-28 18:20:10 --> Config Class Initialized
DEBUG - 2013-11-28 18:20:10 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:20:10 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:20:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:20:10 --> URI Class Initialized
DEBUG - 2013-11-28 18:20:10 --> Router Class Initialized
DEBUG - 2013-11-28 18:20:10 --> Output Class Initialized
DEBUG - 2013-11-28 18:20:10 --> Security Class Initialized
DEBUG - 2013-11-28 18:20:10 --> Input Class Initialized
DEBUG - 2013-11-28 18:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:20:11 --> Language Class Initialized
DEBUG - 2013-11-28 18:20:11 --> Loader Class Initialized
DEBUG - 2013-11-28 18:20:11 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:20:11 --> Session Class Initialized
DEBUG - 2013-11-28 18:20:11 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:20:11 --> Session garbage collection performed.
DEBUG - 2013-11-28 18:20:11 --> Session routines successfully run
DEBUG - 2013-11-28 18:20:11 --> Controller Class Initialized
DEBUG - 2013-11-28 18:20:11 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:20:11 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:20:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:20:12 --> Model Class Initialized
DEBUG - 2013-11-28 18:20:12 --> Model Class Initialized
DEBUG - 2013-11-28 18:20:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:20:12 --> Model Class Initialized
DEBUG - 2013-11-28 18:20:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:20:12 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:20:13 --> Final output sent to browser
DEBUG - 2013-11-28 18:20:13 --> Total execution time: 2.6722
DEBUG - 2013-11-28 18:22:41 --> Config Class Initialized
DEBUG - 2013-11-28 18:22:41 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:22:41 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:22:41 --> URI Class Initialized
DEBUG - 2013-11-28 18:22:41 --> Router Class Initialized
DEBUG - 2013-11-28 18:22:41 --> Output Class Initialized
DEBUG - 2013-11-28 18:22:41 --> Security Class Initialized
DEBUG - 2013-11-28 18:22:41 --> Input Class Initialized
DEBUG - 2013-11-28 18:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:22:42 --> Language Class Initialized
DEBUG - 2013-11-28 18:22:42 --> Loader Class Initialized
DEBUG - 2013-11-28 18:22:42 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:22:42 --> Session Class Initialized
DEBUG - 2013-11-28 18:22:42 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:22:42 --> Session routines successfully run
DEBUG - 2013-11-28 18:22:42 --> Controller Class Initialized
DEBUG - 2013-11-28 18:22:42 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:22:42 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:22:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:22:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:22:43 --> Model Class Initialized
DEBUG - 2013-11-28 18:22:43 --> Model Class Initialized
DEBUG - 2013-11-28 18:22:43 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:22:43 --> Model Class Initialized
DEBUG - 2013-11-28 18:22:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:22:43 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:22:43 --> Final output sent to browser
DEBUG - 2013-11-28 18:22:43 --> Total execution time: 2.5321
DEBUG - 2013-11-28 18:22:53 --> Config Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:22:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:22:54 --> URI Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Router Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Output Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Security Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Input Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:22:54 --> Language Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Loader Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:22:54 --> Session Class Initialized
DEBUG - 2013-11-28 18:22:55 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:22:55 --> Session routines successfully run
DEBUG - 2013-11-28 18:22:55 --> Controller Class Initialized
DEBUG - 2013-11-28 18:22:55 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:22:55 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:22:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:22:55 --> Model Class Initialized
DEBUG - 2013-11-28 18:22:55 --> Model Class Initialized
DEBUG - 2013-11-28 18:22:55 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:22:56 --> Model Class Initialized
DEBUG - 2013-11-28 18:22:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:22:56 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:22:56 --> Final output sent to browser
DEBUG - 2013-11-28 18:22:56 --> Total execution time: 2.4451
DEBUG - 2013-11-28 18:23:13 --> Config Class Initialized
DEBUG - 2013-11-28 18:23:13 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:23:13 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:23:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:23:14 --> URI Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Router Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Output Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Security Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Input Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:23:14 --> Language Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Loader Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Session Class Initialized
DEBUG - 2013-11-28 18:23:14 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:23:15 --> Session routines successfully run
DEBUG - 2013-11-28 18:23:15 --> Controller Class Initialized
DEBUG - 2013-11-28 18:23:15 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:23:15 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:23:15 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:23:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:23:15 --> Model Class Initialized
DEBUG - 2013-11-28 18:23:15 --> Model Class Initialized
DEBUG - 2013-11-28 18:23:15 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:23:16 --> Model Class Initialized
DEBUG - 2013-11-28 18:23:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:23:16 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:23:16 --> Final output sent to browser
DEBUG - 2013-11-28 18:23:16 --> Total execution time: 2.5621
DEBUG - 2013-11-28 18:25:24 --> Config Class Initialized
DEBUG - 2013-11-28 18:25:24 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:25:24 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:25:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:25:24 --> URI Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Router Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Output Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Security Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Input Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:25:25 --> Language Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Loader Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Session Class Initialized
DEBUG - 2013-11-28 18:25:25 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:25:26 --> Session routines successfully run
DEBUG - 2013-11-28 18:25:26 --> Controller Class Initialized
DEBUG - 2013-11-28 18:25:26 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:25:26 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:25:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:25:26 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:26 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:27 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:25:27 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:25:27 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:25:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 18:25:27 --> XSS Filtering completed
DEBUG - 2013-11-28 18:25:27 --> Config Class Initialized
DEBUG - 2013-11-28 18:25:27 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:25:27 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:25:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:25:27 --> URI Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Router Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Output Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Security Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Input Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:25:28 --> Language Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Loader Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Session Class Initialized
DEBUG - 2013-11-28 18:25:28 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:25:29 --> Session routines successfully run
DEBUG - 2013-11-28 18:25:29 --> Controller Class Initialized
DEBUG - 2013-11-28 18:25:29 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:25:29 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:25:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:25:29 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:29 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:29 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:25:29 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:25:30 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:25:30 --> Final output sent to browser
DEBUG - 2013-11-28 18:25:30 --> Total execution time: 2.6572
DEBUG - 2013-11-28 18:25:35 --> Config Class Initialized
DEBUG - 2013-11-28 18:25:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:25:35 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:25:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:25:35 --> URI Class Initialized
DEBUG - 2013-11-28 18:25:35 --> Router Class Initialized
DEBUG - 2013-11-28 18:25:35 --> Output Class Initialized
DEBUG - 2013-11-28 18:25:35 --> Security Class Initialized
DEBUG - 2013-11-28 18:25:35 --> Input Class Initialized
DEBUG - 2013-11-28 18:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:25:35 --> Language Class Initialized
DEBUG - 2013-11-28 18:25:36 --> Loader Class Initialized
DEBUG - 2013-11-28 18:25:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:25:36 --> Session Class Initialized
DEBUG - 2013-11-28 18:25:36 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:25:36 --> Session routines successfully run
DEBUG - 2013-11-28 18:25:36 --> Controller Class Initialized
DEBUG - 2013-11-28 18:25:36 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:25:36 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:25:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:25:36 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:37 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:25:37 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:25:37 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:25:37 --> Final output sent to browser
DEBUG - 2013-11-28 18:25:37 --> Total execution time: 2.3381
DEBUG - 2013-11-28 18:25:43 --> Config Class Initialized
DEBUG - 2013-11-28 18:25:43 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:25:43 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:25:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:25:43 --> URI Class Initialized
DEBUG - 2013-11-28 18:25:43 --> Router Class Initialized
DEBUG - 2013-11-28 18:25:43 --> Output Class Initialized
DEBUG - 2013-11-28 18:25:43 --> Security Class Initialized
DEBUG - 2013-11-28 18:25:44 --> Input Class Initialized
DEBUG - 2013-11-28 18:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:25:44 --> Language Class Initialized
DEBUG - 2013-11-28 18:25:44 --> Loader Class Initialized
DEBUG - 2013-11-28 18:25:44 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:25:44 --> Session Class Initialized
DEBUG - 2013-11-28 18:25:44 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:25:44 --> Session routines successfully run
DEBUG - 2013-11-28 18:25:44 --> Controller Class Initialized
DEBUG - 2013-11-28 18:25:44 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:25:44 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:25:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:25:45 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:45 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:45 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:25:45 --> Model Class Initialized
DEBUG - 2013-11-28 18:25:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:25:45 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:25:45 --> Final output sent to browser
DEBUG - 2013-11-28 18:25:46 --> Total execution time: 2.4411
DEBUG - 2013-11-28 18:28:09 --> Config Class Initialized
DEBUG - 2013-11-28 18:28:09 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:28:09 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:28:09 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:28:10 --> URI Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Router Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Output Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Security Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Input Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:28:10 --> Language Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Loader Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Session Class Initialized
DEBUG - 2013-11-28 18:28:10 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:28:11 --> Session routines successfully run
DEBUG - 2013-11-28 18:28:11 --> Controller Class Initialized
DEBUG - 2013-11-28 18:28:11 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:28:11 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:28:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:28:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:28:11 --> Model Class Initialized
DEBUG - 2013-11-28 18:28:11 --> Model Class Initialized
DEBUG - 2013-11-28 18:28:11 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:28:11 --> Model Class Initialized
DEBUG - 2013-11-28 18:28:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:28:12 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:28:12 --> Final output sent to browser
DEBUG - 2013-11-28 18:28:12 --> Total execution time: 2.5991
DEBUG - 2013-11-28 18:28:39 --> Config Class Initialized
DEBUG - 2013-11-28 18:28:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:28:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:28:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:28:39 --> URI Class Initialized
DEBUG - 2013-11-28 18:28:39 --> Router Class Initialized
DEBUG - 2013-11-28 18:28:39 --> Output Class Initialized
DEBUG - 2013-11-28 18:28:39 --> Security Class Initialized
DEBUG - 2013-11-28 18:28:39 --> Input Class Initialized
DEBUG - 2013-11-28 18:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:28:39 --> Language Class Initialized
DEBUG - 2013-11-28 18:28:39 --> Loader Class Initialized
DEBUG - 2013-11-28 18:28:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:28:40 --> Session Class Initialized
DEBUG - 2013-11-28 18:28:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:28:40 --> Session routines successfully run
DEBUG - 2013-11-28 18:28:40 --> Controller Class Initialized
DEBUG - 2013-11-28 18:28:40 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:28:40 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:28:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:28:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:28:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:28:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:28:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:28:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:28:41 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:28:41 --> Final output sent to browser
DEBUG - 2013-11-28 18:28:42 --> Total execution time: 2.7702
DEBUG - 2013-11-28 18:29:22 --> Config Class Initialized
DEBUG - 2013-11-28 18:29:22 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:29:22 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:29:22 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:29:22 --> URI Class Initialized
DEBUG - 2013-11-28 18:29:22 --> Router Class Initialized
DEBUG - 2013-11-28 18:29:22 --> Output Class Initialized
DEBUG - 2013-11-28 18:29:22 --> Security Class Initialized
DEBUG - 2013-11-28 18:29:23 --> Input Class Initialized
DEBUG - 2013-11-28 18:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:29:23 --> Language Class Initialized
DEBUG - 2013-11-28 18:29:23 --> Loader Class Initialized
DEBUG - 2013-11-28 18:29:23 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:29:23 --> Session Class Initialized
DEBUG - 2013-11-28 18:29:23 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:29:23 --> Session routines successfully run
DEBUG - 2013-11-28 18:29:23 --> Controller Class Initialized
DEBUG - 2013-11-28 18:29:23 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:29:23 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:29:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:29:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:29:24 --> Model Class Initialized
DEBUG - 2013-11-28 18:29:24 --> Model Class Initialized
DEBUG - 2013-11-28 18:29:24 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:29:24 --> Model Class Initialized
DEBUG - 2013-11-28 18:29:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:29:24 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:29:24 --> Final output sent to browser
DEBUG - 2013-11-28 18:29:24 --> Total execution time: 2.3761
DEBUG - 2013-11-28 18:31:13 --> Config Class Initialized
DEBUG - 2013-11-28 18:31:13 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:31:13 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:31:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:31:13 --> URI Class Initialized
DEBUG - 2013-11-28 18:31:13 --> Router Class Initialized
DEBUG - 2013-11-28 18:31:13 --> Output Class Initialized
DEBUG - 2013-11-28 18:31:13 --> Security Class Initialized
DEBUG - 2013-11-28 18:31:14 --> Input Class Initialized
DEBUG - 2013-11-28 18:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:31:14 --> Language Class Initialized
DEBUG - 2013-11-28 18:31:14 --> Loader Class Initialized
DEBUG - 2013-11-28 18:31:14 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:31:14 --> Session Class Initialized
DEBUG - 2013-11-28 18:31:14 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:31:14 --> Session routines successfully run
DEBUG - 2013-11-28 18:31:14 --> Controller Class Initialized
DEBUG - 2013-11-28 18:31:14 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:31:14 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:31:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:31:15 --> Model Class Initialized
DEBUG - 2013-11-28 18:31:15 --> Model Class Initialized
DEBUG - 2013-11-28 18:31:15 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:31:15 --> Model Class Initialized
DEBUG - 2013-11-28 18:31:15 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:31:35 --> Config Class Initialized
DEBUG - 2013-11-28 18:31:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:31:35 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:31:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:31:35 --> URI Class Initialized
DEBUG - 2013-11-28 18:31:35 --> Router Class Initialized
DEBUG - 2013-11-28 18:31:35 --> Output Class Initialized
DEBUG - 2013-11-28 18:31:35 --> Security Class Initialized
DEBUG - 2013-11-28 18:31:35 --> Input Class Initialized
DEBUG - 2013-11-28 18:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:31:36 --> Language Class Initialized
DEBUG - 2013-11-28 18:31:36 --> Loader Class Initialized
DEBUG - 2013-11-28 18:31:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:31:36 --> Session Class Initialized
DEBUG - 2013-11-28 18:31:36 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:31:36 --> Session routines successfully run
DEBUG - 2013-11-28 18:31:36 --> Controller Class Initialized
DEBUG - 2013-11-28 18:31:36 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:31:36 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:31:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:31:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:31:37 --> Model Class Initialized
DEBUG - 2013-11-28 18:31:37 --> Model Class Initialized
DEBUG - 2013-11-28 18:31:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:31:37 --> Model Class Initialized
DEBUG - 2013-11-28 18:31:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:31:37 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:31:38 --> Final output sent to browser
DEBUG - 2013-11-28 18:31:38 --> Total execution time: 2.6822
DEBUG - 2013-11-28 18:32:17 --> Config Class Initialized
DEBUG - 2013-11-28 18:32:17 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:32:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:32:18 --> URI Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Router Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Output Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Security Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Input Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:32:18 --> Language Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Loader Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:32:18 --> Session Class Initialized
DEBUG - 2013-11-28 18:32:19 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:32:19 --> Session routines successfully run
DEBUG - 2013-11-28 18:32:19 --> Controller Class Initialized
DEBUG - 2013-11-28 18:32:19 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:32:19 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:32:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:32:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:32:19 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:19 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:19 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:32:19 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:32:20 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:32:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 18:32:20 --> XSS Filtering completed
DEBUG - 2013-11-28 18:32:20 --> Config Class Initialized
DEBUG - 2013-11-28 18:32:20 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:32:20 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:32:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:32:20 --> URI Class Initialized
DEBUG - 2013-11-28 18:32:20 --> Router Class Initialized
DEBUG - 2013-11-28 18:32:20 --> Output Class Initialized
DEBUG - 2013-11-28 18:32:21 --> Security Class Initialized
DEBUG - 2013-11-28 18:32:21 --> Input Class Initialized
DEBUG - 2013-11-28 18:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:32:21 --> Language Class Initialized
DEBUG - 2013-11-28 18:32:21 --> Loader Class Initialized
DEBUG - 2013-11-28 18:32:21 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:32:21 --> Session Class Initialized
DEBUG - 2013-11-28 18:32:21 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:32:21 --> Session routines successfully run
DEBUG - 2013-11-28 18:32:21 --> Controller Class Initialized
DEBUG - 2013-11-28 18:32:22 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:32:22 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:32:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:32:22 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:22 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:22 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:32:22 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:32:23 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:32:23 --> Final output sent to browser
DEBUG - 2013-11-28 18:32:23 --> Total execution time: 2.7512
DEBUG - 2013-11-28 18:32:32 --> Config Class Initialized
DEBUG - 2013-11-28 18:32:32 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:32:32 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:32:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:32:32 --> URI Class Initialized
DEBUG - 2013-11-28 18:32:32 --> Router Class Initialized
DEBUG - 2013-11-28 18:32:32 --> Output Class Initialized
DEBUG - 2013-11-28 18:32:33 --> Security Class Initialized
DEBUG - 2013-11-28 18:32:33 --> Input Class Initialized
DEBUG - 2013-11-28 18:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:32:33 --> Language Class Initialized
DEBUG - 2013-11-28 18:32:33 --> Loader Class Initialized
DEBUG - 2013-11-28 18:32:33 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:32:33 --> Session Class Initialized
DEBUG - 2013-11-28 18:32:33 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:32:33 --> Session routines successfully run
DEBUG - 2013-11-28 18:32:33 --> Controller Class Initialized
DEBUG - 2013-11-28 18:32:33 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:32:34 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:32:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:32:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:32:34 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:34 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:34 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:32:34 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:32:34 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:32:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 18:32:35 --> XSS Filtering completed
DEBUG - 2013-11-28 18:32:35 --> Config Class Initialized
DEBUG - 2013-11-28 18:32:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:32:35 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:32:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:32:35 --> URI Class Initialized
DEBUG - 2013-11-28 18:32:35 --> Router Class Initialized
DEBUG - 2013-11-28 18:32:35 --> Output Class Initialized
DEBUG - 2013-11-28 18:32:35 --> Security Class Initialized
DEBUG - 2013-11-28 18:32:35 --> Input Class Initialized
DEBUG - 2013-11-28 18:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:32:36 --> Language Class Initialized
DEBUG - 2013-11-28 18:32:36 --> Loader Class Initialized
DEBUG - 2013-11-28 18:32:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:32:36 --> Session Class Initialized
DEBUG - 2013-11-28 18:32:36 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:32:36 --> Session routines successfully run
DEBUG - 2013-11-28 18:32:36 --> Controller Class Initialized
DEBUG - 2013-11-28 18:32:36 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:32:36 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:32:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:32:37 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:37 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:37 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:32:37 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:32:37 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:32:37 --> Final output sent to browser
DEBUG - 2013-11-28 18:32:37 --> Total execution time: 2.5221
DEBUG - 2013-11-28 18:32:45 --> Config Class Initialized
DEBUG - 2013-11-28 18:32:45 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:32:45 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:32:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:32:45 --> URI Class Initialized
DEBUG - 2013-11-28 18:32:45 --> Router Class Initialized
DEBUG - 2013-11-28 18:32:45 --> Output Class Initialized
DEBUG - 2013-11-28 18:32:45 --> Security Class Initialized
DEBUG - 2013-11-28 18:32:45 --> Input Class Initialized
DEBUG - 2013-11-28 18:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:32:46 --> Language Class Initialized
DEBUG - 2013-11-28 18:32:46 --> Loader Class Initialized
DEBUG - 2013-11-28 18:32:46 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:32:46 --> Session Class Initialized
DEBUG - 2013-11-28 18:32:46 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:32:46 --> Session routines successfully run
DEBUG - 2013-11-28 18:32:46 --> Controller Class Initialized
DEBUG - 2013-11-28 18:32:46 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:32:46 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:32:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:32:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:32:47 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:47 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:47 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:32:47 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:32:47 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:32:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 18:32:47 --> XSS Filtering completed
DEBUG - 2013-11-28 18:32:47 --> Config Class Initialized
DEBUG - 2013-11-28 18:32:47 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:32:48 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:32:48 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:32:48 --> URI Class Initialized
DEBUG - 2013-11-28 18:32:48 --> Router Class Initialized
DEBUG - 2013-11-28 18:32:48 --> Output Class Initialized
DEBUG - 2013-11-28 18:32:48 --> Security Class Initialized
DEBUG - 2013-11-28 18:32:48 --> Input Class Initialized
DEBUG - 2013-11-28 18:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:32:48 --> Language Class Initialized
DEBUG - 2013-11-28 18:32:49 --> Loader Class Initialized
DEBUG - 2013-11-28 18:32:49 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:32:49 --> Session Class Initialized
DEBUG - 2013-11-28 18:32:49 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:32:49 --> Session routines successfully run
DEBUG - 2013-11-28 18:32:49 --> Controller Class Initialized
DEBUG - 2013-11-28 18:32:49 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:32:49 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:32:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:32:50 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:50 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:50 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:32:50 --> Model Class Initialized
DEBUG - 2013-11-28 18:32:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:32:50 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:32:50 --> Final output sent to browser
DEBUG - 2013-11-28 18:32:50 --> Total execution time: 2.7192
DEBUG - 2013-11-28 18:38:24 --> Config Class Initialized
DEBUG - 2013-11-28 18:38:24 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:38:24 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:38:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:38:24 --> URI Class Initialized
DEBUG - 2013-11-28 18:38:24 --> Router Class Initialized
DEBUG - 2013-11-28 18:38:24 --> Output Class Initialized
DEBUG - 2013-11-28 18:38:24 --> Security Class Initialized
DEBUG - 2013-11-28 18:38:24 --> Input Class Initialized
DEBUG - 2013-11-28 18:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:38:24 --> Language Class Initialized
DEBUG - 2013-11-28 18:38:25 --> Loader Class Initialized
DEBUG - 2013-11-28 18:38:25 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:38:25 --> Session Class Initialized
DEBUG - 2013-11-28 18:38:25 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:38:25 --> Session routines successfully run
DEBUG - 2013-11-28 18:38:25 --> Controller Class Initialized
DEBUG - 2013-11-28 18:38:25 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:38:25 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:38:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:38:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:38:26 --> Model Class Initialized
DEBUG - 2013-11-28 18:38:26 --> Model Class Initialized
DEBUG - 2013-11-28 18:38:26 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:38:26 --> Model Class Initialized
DEBUG - 2013-11-28 18:38:26 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 18:38:26 --> Severity: Notice  --> Undefined variable: num_pages C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 13
DEBUG - 2013-11-28 18:38:26 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:38:26 --> Final output sent to browser
DEBUG - 2013-11-28 18:38:26 --> Total execution time: 2.6422
DEBUG - 2013-11-28 18:38:58 --> Config Class Initialized
DEBUG - 2013-11-28 18:38:58 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:38:58 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:38:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:38:59 --> URI Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Router Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Output Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Security Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Input Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:38:59 --> Language Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Loader Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Session Class Initialized
DEBUG - 2013-11-28 18:38:59 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:38:59 --> Session routines successfully run
DEBUG - 2013-11-28 18:39:00 --> Controller Class Initialized
DEBUG - 2013-11-28 18:39:00 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:39:00 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:39:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:39:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:39:00 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:00 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:00 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:39:00 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:39:01 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:39:01 --> Final output sent to browser
DEBUG - 2013-11-28 18:39:01 --> Total execution time: 2.4771
DEBUG - 2013-11-28 18:39:28 --> Config Class Initialized
DEBUG - 2013-11-28 18:39:28 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:39:28 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:39:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:39:28 --> URI Class Initialized
DEBUG - 2013-11-28 18:39:28 --> Router Class Initialized
DEBUG - 2013-11-28 18:39:28 --> Output Class Initialized
DEBUG - 2013-11-28 18:39:28 --> Security Class Initialized
DEBUG - 2013-11-28 18:39:29 --> Input Class Initialized
DEBUG - 2013-11-28 18:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:39:29 --> Language Class Initialized
DEBUG - 2013-11-28 18:39:29 --> Loader Class Initialized
DEBUG - 2013-11-28 18:39:29 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:39:29 --> Session Class Initialized
DEBUG - 2013-11-28 18:39:29 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:39:29 --> Session routines successfully run
DEBUG - 2013-11-28 18:39:29 --> Controller Class Initialized
DEBUG - 2013-11-28 18:39:29 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:39:30 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:39:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:39:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:39:30 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:30 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:30 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:39:30 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:39:30 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:39:31 --> Final output sent to browser
DEBUG - 2013-11-28 18:39:31 --> Total execution time: 2.6832
DEBUG - 2013-11-28 18:39:35 --> Config Class Initialized
DEBUG - 2013-11-28 18:39:35 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:39:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:39:36 --> URI Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Router Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Output Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Security Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Input Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:39:36 --> Language Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Loader Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:39:36 --> Session Class Initialized
DEBUG - 2013-11-28 18:39:37 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:39:37 --> Session routines successfully run
DEBUG - 2013-11-28 18:39:37 --> Controller Class Initialized
DEBUG - 2013-11-28 18:39:37 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:39:37 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:39:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:39:38 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:38 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:38 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:39:38 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:39:38 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:39:38 --> Final output sent to browser
DEBUG - 2013-11-28 18:39:38 --> Total execution time: 2.6722
DEBUG - 2013-11-28 18:39:41 --> Config Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:39:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:39:42 --> URI Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Router Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Output Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Security Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Input Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:39:42 --> Language Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Loader Class Initialized
DEBUG - 2013-11-28 18:39:42 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:39:43 --> Session Class Initialized
DEBUG - 2013-11-28 18:39:43 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:39:43 --> Session routines successfully run
DEBUG - 2013-11-28 18:39:43 --> Controller Class Initialized
DEBUG - 2013-11-28 18:39:43 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:39:43 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:39:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:39:43 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:44 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:44 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:39:44 --> Model Class Initialized
DEBUG - 2013-11-28 18:39:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:39:44 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:39:44 --> Final output sent to browser
DEBUG - 2013-11-28 18:39:44 --> Total execution time: 2.6712
DEBUG - 2013-11-28 18:40:20 --> Config Class Initialized
DEBUG - 2013-11-28 18:40:20 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:40:20 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:40:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:40:21 --> URI Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Router Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Output Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Security Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Input Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:40:21 --> Language Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Loader Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Session Class Initialized
DEBUG - 2013-11-28 18:40:21 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:40:22 --> Session routines successfully run
DEBUG - 2013-11-28 18:40:22 --> Controller Class Initialized
DEBUG - 2013-11-28 18:40:22 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:40:22 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:40:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:40:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:40:22 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:22 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:23 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:40:23 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:23 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:40:23 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:40:23 --> Final output sent to browser
DEBUG - 2013-11-28 18:40:23 --> Total execution time: 2.5591
DEBUG - 2013-11-28 18:40:39 --> Config Class Initialized
DEBUG - 2013-11-28 18:40:39 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:40:39 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:40:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:40:39 --> URI Class Initialized
DEBUG - 2013-11-28 18:40:39 --> Router Class Initialized
DEBUG - 2013-11-28 18:40:40 --> Output Class Initialized
DEBUG - 2013-11-28 18:40:40 --> Security Class Initialized
DEBUG - 2013-11-28 18:40:40 --> Input Class Initialized
DEBUG - 2013-11-28 18:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:40:40 --> Language Class Initialized
DEBUG - 2013-11-28 18:40:40 --> Loader Class Initialized
DEBUG - 2013-11-28 18:40:40 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:40:40 --> Session Class Initialized
DEBUG - 2013-11-28 18:40:40 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:40:40 --> Session routines successfully run
DEBUG - 2013-11-28 18:40:41 --> Controller Class Initialized
DEBUG - 2013-11-28 18:40:41 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:40:41 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:40:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:40:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:40:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:41 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:40:41 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:40:42 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:40:42 --> Final output sent to browser
DEBUG - 2013-11-28 18:40:42 --> Total execution time: 2.6082
DEBUG - 2013-11-28 18:40:49 --> Config Class Initialized
DEBUG - 2013-11-28 18:40:49 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:40:49 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:40:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:40:49 --> URI Class Initialized
DEBUG - 2013-11-28 18:40:49 --> Router Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Output Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Security Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Input Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:40:50 --> Language Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Loader Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Session Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:40:50 --> Session routines successfully run
DEBUG - 2013-11-28 18:40:50 --> Controller Class Initialized
DEBUG - 2013-11-28 18:40:50 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:40:51 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:40:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:40:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:40:51 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:51 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:51 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:40:51 --> Model Class Initialized
DEBUG - 2013-11-28 18:40:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:40:52 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:40:52 --> Final output sent to browser
DEBUG - 2013-11-28 18:40:52 --> Total execution time: 2.7592
DEBUG - 2013-11-28 18:43:54 --> Config Class Initialized
DEBUG - 2013-11-28 18:43:54 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:43:54 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:43:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:43:54 --> URI Class Initialized
DEBUG - 2013-11-28 18:43:54 --> Router Class Initialized
DEBUG - 2013-11-28 18:43:54 --> Output Class Initialized
DEBUG - 2013-11-28 18:43:54 --> Security Class Initialized
DEBUG - 2013-11-28 18:43:54 --> Input Class Initialized
DEBUG - 2013-11-28 18:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:43:55 --> Language Class Initialized
DEBUG - 2013-11-28 18:43:55 --> Loader Class Initialized
DEBUG - 2013-11-28 18:43:55 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:43:55 --> Session Class Initialized
DEBUG - 2013-11-28 18:43:55 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:43:55 --> Session routines successfully run
DEBUG - 2013-11-28 18:43:55 --> Controller Class Initialized
DEBUG - 2013-11-28 18:43:55 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:43:55 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:43:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:43:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:43:56 --> Model Class Initialized
DEBUG - 2013-11-28 18:43:56 --> Model Class Initialized
DEBUG - 2013-11-28 18:43:56 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:43:56 --> Model Class Initialized
DEBUG - 2013-11-28 18:43:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:43:56 --> DB Transaction Failure
ERROR - 2013-11-28 18:43:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE Posts.user_id=1' at line 1
DEBUG - 2013-11-28 18:43:56 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-28 18:44:15 --> Config Class Initialized
DEBUG - 2013-11-28 18:44:15 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:44:15 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:44:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:44:16 --> URI Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Router Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Output Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Security Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Input Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:44:16 --> Language Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Loader Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Session Class Initialized
DEBUG - 2013-11-28 18:44:16 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:44:17 --> Session routines successfully run
DEBUG - 2013-11-28 18:44:17 --> Controller Class Initialized
DEBUG - 2013-11-28 18:44:17 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:44:17 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:44:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:44:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:44:17 --> Model Class Initialized
DEBUG - 2013-11-28 18:44:17 --> Model Class Initialized
DEBUG - 2013-11-28 18:44:17 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:44:17 --> Model Class Initialized
DEBUG - 2013-11-28 18:44:18 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:44:41 --> Config Class Initialized
DEBUG - 2013-11-28 18:44:41 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:44:41 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:44:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:44:41 --> URI Class Initialized
DEBUG - 2013-11-28 18:44:41 --> Router Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Output Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Security Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Input Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:44:42 --> Language Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Loader Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Session Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:44:42 --> Session routines successfully run
DEBUG - 2013-11-28 18:44:42 --> Controller Class Initialized
DEBUG - 2013-11-28 18:44:42 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:44:42 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:44:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:44:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:44:43 --> Model Class Initialized
DEBUG - 2013-11-28 18:44:43 --> Model Class Initialized
DEBUG - 2013-11-28 18:44:43 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:44:43 --> Model Class Initialized
DEBUG - 2013-11-28 18:44:43 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 18:44:43 --> Severity: Notice  --> Undefined index: num_posts C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 53
DEBUG - 2013-11-28 18:44:44 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:44:44 --> Final output sent to browser
DEBUG - 2013-11-28 18:44:44 --> Total execution time: 2.6051
DEBUG - 2013-11-28 18:44:56 --> Config Class Initialized
DEBUG - 2013-11-28 18:44:56 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:44:56 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:44:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:44:56 --> URI Class Initialized
DEBUG - 2013-11-28 18:44:56 --> Router Class Initialized
DEBUG - 2013-11-28 18:44:57 --> Output Class Initialized
DEBUG - 2013-11-28 18:44:57 --> Security Class Initialized
DEBUG - 2013-11-28 18:44:57 --> Input Class Initialized
DEBUG - 2013-11-28 18:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:44:57 --> Language Class Initialized
DEBUG - 2013-11-28 18:44:57 --> Loader Class Initialized
DEBUG - 2013-11-28 18:44:57 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:44:57 --> Session Class Initialized
DEBUG - 2013-11-28 18:44:57 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:45:01 --> Session routines successfully run
DEBUG - 2013-11-28 18:45:01 --> Controller Class Initialized
DEBUG - 2013-11-28 18:45:01 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:45:01 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:45:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:45:02 --> Model Class Initialized
DEBUG - 2013-11-28 18:45:02 --> Model Class Initialized
DEBUG - 2013-11-28 18:45:02 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:45:02 --> Model Class Initialized
DEBUG - 2013-11-28 18:45:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:45:02 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:45:02 --> Final output sent to browser
DEBUG - 2013-11-28 18:45:02 --> Total execution time: 6.1804
DEBUG - 2013-11-28 18:46:16 --> Config Class Initialized
DEBUG - 2013-11-28 18:46:16 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:46:16 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:46:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:46:17 --> URI Class Initialized
DEBUG - 2013-11-28 18:46:17 --> Router Class Initialized
DEBUG - 2013-11-28 18:46:17 --> Output Class Initialized
DEBUG - 2013-11-28 18:46:17 --> Security Class Initialized
DEBUG - 2013-11-28 18:46:17 --> Input Class Initialized
DEBUG - 2013-11-28 18:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:46:17 --> Language Class Initialized
DEBUG - 2013-11-28 18:46:17 --> Loader Class Initialized
DEBUG - 2013-11-28 18:46:17 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:46:18 --> Session Class Initialized
DEBUG - 2013-11-28 18:46:18 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:46:18 --> Session routines successfully run
DEBUG - 2013-11-28 18:46:18 --> Controller Class Initialized
DEBUG - 2013-11-28 18:46:18 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:46:18 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:46:18 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:46:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:46:19 --> Model Class Initialized
DEBUG - 2013-11-28 18:46:19 --> Model Class Initialized
DEBUG - 2013-11-28 18:46:19 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:46:26 --> Config Class Initialized
DEBUG - 2013-11-28 18:46:26 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:46:26 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:46:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:46:26 --> URI Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Router Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Output Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Security Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Input Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:46:27 --> Language Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Loader Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Session Class Initialized
DEBUG - 2013-11-28 18:46:27 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:46:28 --> Session routines successfully run
DEBUG - 2013-11-28 18:46:28 --> Controller Class Initialized
DEBUG - 2013-11-28 18:46:28 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:46:28 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:46:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:46:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:46:28 --> Model Class Initialized
DEBUG - 2013-11-28 18:46:28 --> Model Class Initialized
DEBUG - 2013-11-28 18:46:28 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:46:29 --> Model Class Initialized
DEBUG - 2013-11-28 18:46:29 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-11-28 18:46:29 --> Severity: Notice  --> Undefined index: num_posts C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 54
ERROR - 2013-11-28 18:46:29 --> Severity: Notice  --> Undefined index: num_posts C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 54
DEBUG - 2013-11-28 18:46:29 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:46:29 --> Final output sent to browser
DEBUG - 2013-11-28 18:46:29 --> Total execution time: 2.8592
DEBUG - 2013-11-28 18:47:44 --> Config Class Initialized
DEBUG - 2013-11-28 18:47:44 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:47:44 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:47:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:47:45 --> URI Class Initialized
DEBUG - 2013-11-28 18:47:45 --> Router Class Initialized
DEBUG - 2013-11-28 18:47:45 --> Output Class Initialized
DEBUG - 2013-11-28 18:47:45 --> Security Class Initialized
DEBUG - 2013-11-28 18:47:45 --> Input Class Initialized
DEBUG - 2013-11-28 18:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:47:45 --> Language Class Initialized
DEBUG - 2013-11-28 18:47:45 --> Loader Class Initialized
DEBUG - 2013-11-28 18:47:45 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:47:45 --> Session Class Initialized
DEBUG - 2013-11-28 18:47:46 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:47:46 --> Session routines successfully run
DEBUG - 2013-11-28 18:47:46 --> Controller Class Initialized
DEBUG - 2013-11-28 18:47:46 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:47:46 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:47:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:47:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:47:46 --> Model Class Initialized
DEBUG - 2013-11-28 18:47:46 --> Model Class Initialized
DEBUG - 2013-11-28 18:47:46 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:47:47 --> Model Class Initialized
DEBUG - 2013-11-28 18:47:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:47:47 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:47:47 --> Final output sent to browser
DEBUG - 2013-11-28 18:47:47 --> Total execution time: 2.6722
DEBUG - 2013-11-28 18:49:46 --> Config Class Initialized
DEBUG - 2013-11-28 18:49:46 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:49:46 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:49:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:49:46 --> URI Class Initialized
DEBUG - 2013-11-28 18:49:46 --> Router Class Initialized
DEBUG - 2013-11-28 18:49:46 --> Output Class Initialized
DEBUG - 2013-11-28 18:49:46 --> Security Class Initialized
DEBUG - 2013-11-28 18:49:46 --> Input Class Initialized
DEBUG - 2013-11-28 18:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:49:47 --> Language Class Initialized
DEBUG - 2013-11-28 18:49:47 --> Loader Class Initialized
DEBUG - 2013-11-28 18:49:47 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:49:47 --> Session Class Initialized
DEBUG - 2013-11-28 18:49:47 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:49:47 --> Session routines successfully run
DEBUG - 2013-11-28 18:49:47 --> Controller Class Initialized
DEBUG - 2013-11-28 18:49:47 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:49:47 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:49:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:49:48 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:48 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:48 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:49:48 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:49:48 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:49:48 --> Final output sent to browser
DEBUG - 2013-11-28 18:49:48 --> Total execution time: 2.5341
DEBUG - 2013-11-28 18:49:50 --> Config Class Initialized
DEBUG - 2013-11-28 18:49:50 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:49:50 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:49:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:49:51 --> URI Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Router Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Output Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Security Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Input Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:49:51 --> Language Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Loader Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Session Class Initialized
DEBUG - 2013-11-28 18:49:51 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:49:51 --> Session routines successfully run
DEBUG - 2013-11-28 18:49:52 --> Controller Class Initialized
DEBUG - 2013-11-28 18:49:52 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:49:52 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:49:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:49:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:49:52 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:52 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:52 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:49:52 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:49:53 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:49:53 --> Final output sent to browser
DEBUG - 2013-11-28 18:49:53 --> Total execution time: 2.5411
DEBUG - 2013-11-28 18:49:55 --> Config Class Initialized
DEBUG - 2013-11-28 18:49:55 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:49:55 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:49:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:49:56 --> URI Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Router Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Output Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Security Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Input Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:49:56 --> Language Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Loader Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Session Class Initialized
DEBUG - 2013-11-28 18:49:56 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:49:57 --> Session routines successfully run
DEBUG - 2013-11-28 18:49:57 --> Controller Class Initialized
DEBUG - 2013-11-28 18:49:57 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:49:57 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:49:57 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:49:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:49:57 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:57 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:58 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:49:58 --> Model Class Initialized
DEBUG - 2013-11-28 18:49:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:49:58 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:49:58 --> Final output sent to browser
DEBUG - 2013-11-28 18:49:58 --> Total execution time: 2.7522
DEBUG - 2013-11-28 18:57:18 --> Config Class Initialized
DEBUG - 2013-11-28 18:57:18 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:57:18 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:57:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:57:18 --> URI Class Initialized
DEBUG - 2013-11-28 18:57:18 --> Router Class Initialized
DEBUG - 2013-11-28 18:57:19 --> Output Class Initialized
DEBUG - 2013-11-28 18:57:19 --> Security Class Initialized
DEBUG - 2013-11-28 18:57:19 --> Input Class Initialized
DEBUG - 2013-11-28 18:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:57:19 --> Language Class Initialized
DEBUG - 2013-11-28 18:57:19 --> Loader Class Initialized
DEBUG - 2013-11-28 18:57:19 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:57:19 --> Session Class Initialized
DEBUG - 2013-11-28 18:57:19 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:57:19 --> A session cookie was not found.
DEBUG - 2013-11-28 18:57:20 --> Session routines successfully run
DEBUG - 2013-11-28 18:57:20 --> Controller Class Initialized
DEBUG - 2013-11-28 18:57:20 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:57:20 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:57:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:57:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:57:20 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:20 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:21 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:57:21 --> Helper loaded: cookie_helper
DEBUG - 2013-11-28 18:57:21 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:21 --> Config Class Initialized
DEBUG - 2013-11-28 18:57:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:57:21 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:57:21 --> Config Class Initialized
DEBUG - 2013-11-28 18:57:21 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:57:21 --> Hooks Class Initialized
DEBUG - 2013-11-28 18:57:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:57:21 --> Utf8 Class Initialized
DEBUG - 2013-11-28 18:57:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 18:57:22 --> URI Class Initialized
DEBUG - 2013-11-28 18:57:22 --> URI Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Router Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Router Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Output Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Output Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Security Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Security Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Input Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Input Class Initialized
DEBUG - 2013-11-28 18:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 18:57:23 --> Language Class Initialized
DEBUG - 2013-11-28 18:57:23 --> Language Class Initialized
DEBUG - 2013-11-28 18:57:23 --> Loader Class Initialized
DEBUG - 2013-11-28 18:57:23 --> Loader Class Initialized
DEBUG - 2013-11-28 18:57:23 --> Database Driver Class Initialized
DEBUG - 2013-11-28 18:57:23 --> Database Driver Class Initialized
ERROR - 2013-11-28 18:57:23 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-11-28 18:57:23 --> Session Class Initialized
DEBUG - 2013-11-28 18:57:23 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:57:24 --> Session Class Initialized
DEBUG - 2013-11-28 18:57:24 --> A session cookie was not found.
DEBUG - 2013-11-28 18:57:24 --> Helper loaded: string_helper
DEBUG - 2013-11-28 18:57:24 --> Session routines successfully run
DEBUG - 2013-11-28 18:57:24 --> Controller Class Initialized
DEBUG - 2013-11-28 18:57:24 --> Session routines successfully run
DEBUG - 2013-11-28 18:57:24 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:57:24 --> Controller Class Initialized
DEBUG - 2013-11-28 18:57:24 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:57:24 --> Helper loaded: form_helper
DEBUG - 2013-11-28 18:57:24 --> Form Validation Class Initialized
DEBUG - 2013-11-28 18:57:24 --> Helper loaded: url_helper
DEBUG - 2013-11-28 18:57:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:57:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 18:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:57:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:57:25 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:25 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:25 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:25 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:25 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:57:25 --> Image Lib Class Initialized
DEBUG - 2013-11-28 18:57:25 --> Helper loaded: cookie_helper
DEBUG - 2013-11-28 18:57:25 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:26 --> Upload Class Initialized
DEBUG - 2013-11-28 18:57:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:57:26 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 18:57:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 18:57:26 --> Model Class Initialized
DEBUG - 2013-11-28 18:57:26 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-11-28 18:57:26 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-11-28 18:57:26 --> Final output sent to browser
DEBUG - 2013-11-28 18:57:26 --> Final output sent to browser
DEBUG - 2013-11-28 18:57:26 --> Total execution time: 5.3053
DEBUG - 2013-11-28 18:57:26 --> Total execution time: 4.9603
DEBUG - 2013-11-28 20:20:04 --> Config Class Initialized
DEBUG - 2013-11-28 20:20:04 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:20:04 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:20:04 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:20:04 --> URI Class Initialized
DEBUG - 2013-11-28 20:20:04 --> Router Class Initialized
DEBUG - 2013-11-28 20:20:04 --> Output Class Initialized
DEBUG - 2013-11-28 20:20:04 --> Security Class Initialized
DEBUG - 2013-11-28 20:20:04 --> Input Class Initialized
DEBUG - 2013-11-28 20:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:20:04 --> Language Class Initialized
DEBUG - 2013-11-28 20:20:04 --> Loader Class Initialized
DEBUG - 2013-11-28 20:20:05 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:20:05 --> Session Class Initialized
DEBUG - 2013-11-28 20:20:05 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:20:05 --> Session routines successfully run
DEBUG - 2013-11-28 20:20:05 --> Controller Class Initialized
DEBUG - 2013-11-28 20:20:05 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:20:05 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:20:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:20:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:20:06 --> Model Class Initialized
DEBUG - 2013-11-28 20:20:06 --> Model Class Initialized
DEBUG - 2013-11-28 20:20:06 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:20:06 --> Model Class Initialized
DEBUG - 2013-11-28 20:20:33 --> Config Class Initialized
DEBUG - 2013-11-28 20:20:33 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:20:33 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:20:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:20:34 --> URI Class Initialized
DEBUG - 2013-11-28 20:20:34 --> Router Class Initialized
DEBUG - 2013-11-28 20:20:34 --> Output Class Initialized
DEBUG - 2013-11-28 20:20:34 --> Security Class Initialized
DEBUG - 2013-11-28 20:20:34 --> Input Class Initialized
DEBUG - 2013-11-28 20:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:20:34 --> Language Class Initialized
DEBUG - 2013-11-28 20:20:34 --> Loader Class Initialized
DEBUG - 2013-11-28 20:20:34 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:20:34 --> Session Class Initialized
DEBUG - 2013-11-28 20:20:35 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:20:35 --> Session routines successfully run
DEBUG - 2013-11-28 20:20:35 --> Controller Class Initialized
DEBUG - 2013-11-28 20:20:35 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:20:35 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:20:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:20:35 --> Model Class Initialized
DEBUG - 2013-11-28 20:20:35 --> Model Class Initialized
DEBUG - 2013-11-28 20:20:36 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:20:36 --> Model Class Initialized
DEBUG - 2013-11-28 20:20:36 --> Model Class Initialized
ERROR - 2013-11-28 20:20:36 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:20:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:20:36 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:20:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:20:36 --> XSS Filtering completed
DEBUG - 2013-11-28 20:21:48 --> Config Class Initialized
DEBUG - 2013-11-28 20:21:48 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:21:48 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:21:48 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:21:48 --> URI Class Initialized
DEBUG - 2013-11-28 20:21:48 --> Router Class Initialized
DEBUG - 2013-11-28 20:21:48 --> Output Class Initialized
DEBUG - 2013-11-28 20:21:48 --> Security Class Initialized
DEBUG - 2013-11-28 20:21:48 --> Input Class Initialized
DEBUG - 2013-11-28 20:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:21:48 --> Language Class Initialized
DEBUG - 2013-11-28 20:21:48 --> Loader Class Initialized
DEBUG - 2013-11-28 20:21:49 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:21:49 --> Session Class Initialized
DEBUG - 2013-11-28 20:21:49 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:21:49 --> Session routines successfully run
DEBUG - 2013-11-28 20:21:49 --> Controller Class Initialized
DEBUG - 2013-11-28 20:21:49 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:21:49 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:21:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:21:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:21:50 --> Model Class Initialized
DEBUG - 2013-11-28 20:21:50 --> Model Class Initialized
DEBUG - 2013-11-28 20:21:50 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:21:50 --> Model Class Initialized
DEBUG - 2013-11-28 20:21:50 --> Model Class Initialized
ERROR - 2013-11-28 20:21:50 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:21:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:21:50 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:21:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:21:50 --> XSS Filtering completed
DEBUG - 2013-11-28 20:22:51 --> Config Class Initialized
DEBUG - 2013-11-28 20:22:51 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:22:51 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:22:52 --> URI Class Initialized
DEBUG - 2013-11-28 20:22:52 --> Router Class Initialized
DEBUG - 2013-11-28 20:22:52 --> Output Class Initialized
DEBUG - 2013-11-28 20:22:52 --> Security Class Initialized
DEBUG - 2013-11-28 20:22:52 --> Input Class Initialized
DEBUG - 2013-11-28 20:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:22:52 --> Language Class Initialized
DEBUG - 2013-11-28 20:22:52 --> Loader Class Initialized
DEBUG - 2013-11-28 20:22:52 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:22:52 --> Session Class Initialized
DEBUG - 2013-11-28 20:22:53 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:22:53 --> Session routines successfully run
DEBUG - 2013-11-28 20:22:53 --> Controller Class Initialized
DEBUG - 2013-11-28 20:22:53 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:22:53 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:22:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:22:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:22:53 --> Model Class Initialized
DEBUG - 2013-11-28 20:22:53 --> Model Class Initialized
DEBUG - 2013-11-28 20:22:54 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:22:54 --> Model Class Initialized
DEBUG - 2013-11-28 20:22:54 --> Model Class Initialized
ERROR - 2013-11-28 20:22:54 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:22:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:22:54 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:22:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:22:54 --> XSS Filtering completed
DEBUG - 2013-11-28 20:23:15 --> Config Class Initialized
DEBUG - 2013-11-28 20:23:15 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:23:15 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:23:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:23:15 --> URI Class Initialized
DEBUG - 2013-11-28 20:23:15 --> Router Class Initialized
DEBUG - 2013-11-28 20:23:15 --> Output Class Initialized
DEBUG - 2013-11-28 20:23:15 --> Security Class Initialized
DEBUG - 2013-11-28 20:23:15 --> Input Class Initialized
DEBUG - 2013-11-28 20:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:23:15 --> Language Class Initialized
DEBUG - 2013-11-28 20:23:15 --> Loader Class Initialized
DEBUG - 2013-11-28 20:23:16 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:23:16 --> Session Class Initialized
DEBUG - 2013-11-28 20:23:16 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:23:16 --> Session routines successfully run
DEBUG - 2013-11-28 20:23:16 --> Controller Class Initialized
DEBUG - 2013-11-28 20:23:16 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:23:16 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:23:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:23:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:23:17 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:17 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:17 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:23:17 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:17 --> Model Class Initialized
ERROR - 2013-11-28 20:23:17 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:23:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:23:17 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:23:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:23:18 --> XSS Filtering completed
DEBUG - 2013-11-28 20:23:28 --> Config Class Initialized
DEBUG - 2013-11-28 20:23:28 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:23:28 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:23:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:23:28 --> URI Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Router Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Output Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Security Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Input Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:23:29 --> Language Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Loader Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Session Class Initialized
DEBUG - 2013-11-28 20:23:29 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:23:29 --> Session routines successfully run
DEBUG - 2013-11-28 20:23:30 --> Controller Class Initialized
DEBUG - 2013-11-28 20:23:30 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:23:30 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:23:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:23:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:23:30 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:30 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:30 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:23:30 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:31 --> Model Class Initialized
ERROR - 2013-11-28 20:23:31 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:23:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:23:31 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:23:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:23:31 --> XSS Filtering completed
DEBUG - 2013-11-28 20:23:43 --> Config Class Initialized
DEBUG - 2013-11-28 20:23:43 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:23:43 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:23:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:23:43 --> URI Class Initialized
DEBUG - 2013-11-28 20:23:43 --> Router Class Initialized
DEBUG - 2013-11-28 20:23:43 --> Output Class Initialized
DEBUG - 2013-11-28 20:23:43 --> Security Class Initialized
DEBUG - 2013-11-28 20:23:43 --> Input Class Initialized
DEBUG - 2013-11-28 20:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:23:44 --> Language Class Initialized
DEBUG - 2013-11-28 20:23:44 --> Loader Class Initialized
DEBUG - 2013-11-28 20:23:44 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:23:44 --> Session Class Initialized
DEBUG - 2013-11-28 20:23:44 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:23:44 --> Session routines successfully run
DEBUG - 2013-11-28 20:23:44 --> Controller Class Initialized
DEBUG - 2013-11-28 20:23:44 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:23:44 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:23:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:23:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:23:45 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:45 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:45 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:23:45 --> Model Class Initialized
DEBUG - 2013-11-28 20:23:45 --> Model Class Initialized
ERROR - 2013-11-28 20:23:45 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:23:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:23:46 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:23:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:23:46 --> XSS Filtering completed
DEBUG - 2013-11-28 20:24:09 --> Config Class Initialized
DEBUG - 2013-11-28 20:24:09 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:24:09 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:24:09 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:24:09 --> URI Class Initialized
DEBUG - 2013-11-28 20:24:09 --> Router Class Initialized
DEBUG - 2013-11-28 20:24:09 --> Output Class Initialized
DEBUG - 2013-11-28 20:24:09 --> Security Class Initialized
DEBUG - 2013-11-28 20:24:09 --> Input Class Initialized
DEBUG - 2013-11-28 20:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:24:09 --> Language Class Initialized
DEBUG - 2013-11-28 20:24:10 --> Loader Class Initialized
DEBUG - 2013-11-28 20:24:10 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:24:10 --> Session Class Initialized
DEBUG - 2013-11-28 20:24:10 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:24:10 --> Session routines successfully run
DEBUG - 2013-11-28 20:24:10 --> Controller Class Initialized
DEBUG - 2013-11-28 20:24:10 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:24:10 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:24:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:24:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:24:11 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:11 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:11 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:24:11 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:11 --> Model Class Initialized
ERROR - 2013-11-28 20:24:11 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:24:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:24:11 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:24:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:24:11 --> XSS Filtering completed
DEBUG - 2013-11-28 20:24:26 --> Config Class Initialized
DEBUG - 2013-11-28 20:24:26 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:24:26 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:24:26 --> URI Class Initialized
DEBUG - 2013-11-28 20:24:26 --> Router Class Initialized
DEBUG - 2013-11-28 20:24:26 --> Output Class Initialized
DEBUG - 2013-11-28 20:24:26 --> Security Class Initialized
DEBUG - 2013-11-28 20:24:26 --> Input Class Initialized
DEBUG - 2013-11-28 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:24:26 --> Language Class Initialized
DEBUG - 2013-11-28 20:24:26 --> Loader Class Initialized
DEBUG - 2013-11-28 20:24:27 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:24:27 --> Session Class Initialized
DEBUG - 2013-11-28 20:24:27 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:24:27 --> Session routines successfully run
DEBUG - 2013-11-28 20:24:27 --> Controller Class Initialized
DEBUG - 2013-11-28 20:24:27 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:24:27 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:24:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:24:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:24:28 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:28 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:28 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:24:28 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:28 --> Model Class Initialized
ERROR - 2013-11-28 20:24:28 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:24:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:24:28 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:24:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:24:29 --> XSS Filtering completed
DEBUG - 2013-11-28 20:24:36 --> Config Class Initialized
DEBUG - 2013-11-28 20:24:36 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:24:36 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:24:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:24:36 --> URI Class Initialized
DEBUG - 2013-11-28 20:24:36 --> Router Class Initialized
DEBUG - 2013-11-28 20:24:36 --> Output Class Initialized
DEBUG - 2013-11-28 20:24:36 --> Security Class Initialized
DEBUG - 2013-11-28 20:24:36 --> Input Class Initialized
DEBUG - 2013-11-28 20:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:24:37 --> Language Class Initialized
DEBUG - 2013-11-28 20:24:37 --> Loader Class Initialized
DEBUG - 2013-11-28 20:24:37 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:24:37 --> Session Class Initialized
DEBUG - 2013-11-28 20:24:37 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:24:37 --> Session routines successfully run
DEBUG - 2013-11-28 20:24:37 --> Controller Class Initialized
DEBUG - 2013-11-28 20:24:37 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:24:37 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:24:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:24:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:24:38 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:38 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:38 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:24:38 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:38 --> Model Class Initialized
ERROR - 2013-11-28 20:24:38 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:24:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:24:39 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:24:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:24:39 --> XSS Filtering completed
DEBUG - 2013-11-28 20:24:54 --> Config Class Initialized
DEBUG - 2013-11-28 20:24:55 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:24:55 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:24:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:24:55 --> URI Class Initialized
DEBUG - 2013-11-28 20:24:55 --> Router Class Initialized
DEBUG - 2013-11-28 20:24:55 --> Output Class Initialized
DEBUG - 2013-11-28 20:24:55 --> Security Class Initialized
DEBUG - 2013-11-28 20:24:55 --> Input Class Initialized
DEBUG - 2013-11-28 20:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:24:55 --> Language Class Initialized
DEBUG - 2013-11-28 20:24:55 --> Loader Class Initialized
DEBUG - 2013-11-28 20:24:56 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:24:56 --> Session Class Initialized
DEBUG - 2013-11-28 20:24:56 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:24:56 --> Session garbage collection performed.
DEBUG - 2013-11-28 20:24:56 --> Session routines successfully run
DEBUG - 2013-11-28 20:24:56 --> Controller Class Initialized
DEBUG - 2013-11-28 20:24:56 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:24:56 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:24:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:24:57 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:57 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:57 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:24:57 --> Model Class Initialized
DEBUG - 2013-11-28 20:24:57 --> Model Class Initialized
ERROR - 2013-11-28 20:24:57 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:24:57 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:24:57 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:24:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:24:58 --> XSS Filtering completed
DEBUG - 2013-11-28 20:25:09 --> Config Class Initialized
DEBUG - 2013-11-28 20:25:09 --> Hooks Class Initialized
DEBUG - 2013-11-28 20:25:09 --> Utf8 Class Initialized
DEBUG - 2013-11-28 20:25:09 --> UTF-8 Support Enabled
DEBUG - 2013-11-28 20:25:10 --> URI Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Router Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Output Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Security Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Input Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-28 20:25:10 --> Language Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Loader Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Database Driver Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Session Class Initialized
DEBUG - 2013-11-28 20:25:10 --> Helper loaded: string_helper
DEBUG - 2013-11-28 20:25:11 --> Session routines successfully run
DEBUG - 2013-11-28 20:25:11 --> Controller Class Initialized
DEBUG - 2013-11-28 20:25:11 --> Helper loaded: form_helper
DEBUG - 2013-11-28 20:25:11 --> Helper loaded: url_helper
DEBUG - 2013-11-28 20:25:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-11-28 20:25:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-11-28 20:25:11 --> Model Class Initialized
DEBUG - 2013-11-28 20:25:11 --> Model Class Initialized
DEBUG - 2013-11-28 20:25:12 --> Image Lib Class Initialized
DEBUG - 2013-11-28 20:25:12 --> Model Class Initialized
DEBUG - 2013-11-28 20:25:12 --> Model Class Initialized
ERROR - 2013-11-28 20:25:12 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-11-28 20:25:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-11-28 20:25:12 --> Form Validation Class Initialized
DEBUG - 2013-11-28 20:25:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-28 20:25:12 --> XSS Filtering completed
