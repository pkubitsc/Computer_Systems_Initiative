<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-12-06 13:11:07 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:07 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:07 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:07 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:08 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:08 --> No URI present. Default controller set.
DEBUG - 2013-12-06 13:11:08 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:08 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:08 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:08 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:08 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:08 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:09 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:09 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:09 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:09 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:09 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:09 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:10 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:11:10 --> Upload Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:10 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:10 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:10 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:10 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:10 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:11 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:11 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:11:11 --> Upload Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:11 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-06 13:11:11 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:11 --> Total execution time: 0.4690
DEBUG - 2013-12-06 13:11:11 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:11 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:11 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:11 --> Session garbage collection performed.
DEBUG - 2013-12-06 13:11:11 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:11 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:11 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:11:11 --> Upload Class Initialized
DEBUG - 2013-12-06 13:11:11 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:11 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:11:11 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:11:20 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:20 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:20 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:21 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:21 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:21 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:21 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:21 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:21 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:11:21 --> Upload Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:21 --> XSS Filtering completed
DEBUG - 2013-12-06 13:11:21 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 13:11:21 --> XSS Filtering completed
DEBUG - 2013-12-06 13:11:21 --> XSS Filtering completed
DEBUG - 2013-12-06 13:11:21 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:21 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:21 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:21 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:21 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:21 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:21 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:22 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:11:22 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:22 --> Total execution time: 0.6660
DEBUG - 2013-12-06 13:11:29 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:29 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:29 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:29 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:30 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:30 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:30 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:30 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:30 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:11:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:30 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:30 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:30 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:30 --> Upload Class Initialized
DEBUG - 2013-12-06 13:11:30 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:30 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-06 13:11:30 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:30 --> Total execution time: 0.9501
DEBUG - 2013-12-06 13:11:34 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:34 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:34 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:34 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:34 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:34 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:34 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:11:34 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:34 --> Total execution time: 0.8610
DEBUG - 2013-12-06 13:11:38 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:38 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:38 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:38 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:38 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:38 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:38 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:38 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:11:38 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:38 --> Total execution time: 0.2380
DEBUG - 2013-12-06 13:11:41 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:41 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:41 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:41 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:41 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:41 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:41 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:41 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:11:41 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:41 --> Total execution time: 0.1510
DEBUG - 2013-12-06 13:11:43 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:43 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:43 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:43 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:43 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:43 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:43 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:43 --> Helper loaded: security_helper
DEBUG - 2013-12-06 13:11:43 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:11:43 --> File loaded: application/views/home/search_view.php
DEBUG - 2013-12-06 13:11:43 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:43 --> Total execution time: 0.1790
DEBUG - 2013-12-06 13:11:49 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:49 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:49 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:49 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:49 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:49 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:49 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:49 --> Helper loaded: security_helper
DEBUG - 2013-12-06 13:11:49 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:11:49 --> XSS Filtering completed
DEBUG - 2013-12-06 13:11:49 --> File loaded: application/views/home/search_view.php
DEBUG - 2013-12-06 13:11:49 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:49 --> Total execution time: 0.2110
DEBUG - 2013-12-06 13:11:52 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:52 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:52 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:52 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:52 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:52 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:52 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:53 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:53 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:53 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:53 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:53 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:11:53 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:11:53 --> Final output sent to browser
DEBUG - 2013-12-06 13:11:53 --> Total execution time: 0.2740
DEBUG - 2013-12-06 13:11:59 --> Config Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:11:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:11:59 --> URI Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Router Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Output Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Security Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Input Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:11:59 --> Language Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Loader Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Session Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:11:59 --> Session routines successfully run
DEBUG - 2013-12-06 13:11:59 --> Controller Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:11:59 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:11:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:11:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:11:59 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Model Class Initialized
DEBUG - 2013-12-06 13:11:59 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:12:53 --> Config Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:12:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:12:53 --> URI Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Router Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Output Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Security Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Input Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:12:53 --> Language Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Loader Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Session Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:12:53 --> Session routines successfully run
DEBUG - 2013-12-06 13:12:53 --> Controller Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:12:53 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:12:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:12:53 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:12:53 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:12:53 --> Final output sent to browser
DEBUG - 2013-12-06 13:12:53 --> Total execution time: 0.2480
DEBUG - 2013-12-06 13:12:57 --> Config Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:12:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:12:57 --> URI Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Router Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Output Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Security Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Input Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:12:57 --> Language Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Loader Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Session Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:12:57 --> Session routines successfully run
DEBUG - 2013-12-06 13:12:57 --> Controller Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:12:57 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:12:57 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:12:57 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:57 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:12:57 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 206 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 224
ERROR - 2013-12-06 13:12:58 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 232
DEBUG - 2013-12-06 13:12:58 --> Config Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:12:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:12:58 --> URI Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Router Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Output Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Security Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Input Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:12:58 --> Language Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Loader Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Session Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:12:58 --> Session routines successfully run
DEBUG - 2013-12-06 13:12:58 --> Controller Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:12:58 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:12:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:12:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:12:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:12:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:12:58 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:12:58 --> Final output sent to browser
DEBUG - 2013-12-06 13:12:58 --> Total execution time: 0.2280
DEBUG - 2013-12-06 13:13:02 --> Config Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:13:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:13:02 --> URI Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Router Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Output Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Security Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Input Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:13:02 --> Language Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Loader Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Session Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:13:02 --> Session routines successfully run
DEBUG - 2013-12-06 13:13:02 --> Controller Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:13:02 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:13:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:13:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:13:02 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:13:02 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 248
DEBUG - 2013-12-06 13:13:02 --> Config Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:13:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:13:02 --> URI Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Router Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Output Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Security Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Input Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:13:02 --> Language Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Loader Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Session Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:13:02 --> Session routines successfully run
DEBUG - 2013-12-06 13:13:02 --> Controller Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:13:02 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:13:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:13:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:13:02 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:13:03 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:13:03 --> Final output sent to browser
DEBUG - 2013-12-06 13:13:03 --> Total execution time: 0.1790
DEBUG - 2013-12-06 13:13:07 --> Config Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:13:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:13:07 --> URI Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Router Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Output Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Security Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Input Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:13:07 --> Language Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Loader Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Session Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:13:07 --> Session routines successfully run
DEBUG - 2013-12-06 13:13:07 --> Controller Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:13:07 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:13:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:13:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:13:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:13:07 --> Severity: Warning  --> Missing argument 3 for Posts::like_post(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php on line 206 and defined C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 224
ERROR - 2013-12-06 13:13:07 --> Severity: Notice  --> Undefined variable: num_likes C:\Program Files (x86)\Ampps\www\project\application\models\home\posts.php 232
DEBUG - 2013-12-06 13:13:07 --> Config Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:13:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:13:07 --> URI Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Router Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Output Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Security Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Input Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:13:07 --> Language Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Loader Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Session Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:13:07 --> Session routines successfully run
DEBUG - 2013-12-06 13:13:07 --> Controller Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:13:07 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:13:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:13:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:13:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:13:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:13:07 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:13:07 --> Final output sent to browser
DEBUG - 2013-12-06 13:13:07 --> Total execution time: 0.1890
DEBUG - 2013-12-06 13:15:38 --> Config Class Initialized
DEBUG - 2013-12-06 13:15:38 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:15:38 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:15:38 --> URI Class Initialized
DEBUG - 2013-12-06 13:15:38 --> Router Class Initialized
DEBUG - 2013-12-06 13:15:38 --> No URI present. Default controller set.
DEBUG - 2013-12-06 13:15:38 --> Output Class Initialized
DEBUG - 2013-12-06 13:15:38 --> Security Class Initialized
DEBUG - 2013-12-06 13:15:38 --> Input Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:15:39 --> Language Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Loader Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Session Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:15:39 --> A session cookie was not found.
DEBUG - 2013-12-06 13:15:39 --> Session routines successfully run
DEBUG - 2013-12-06 13:15:39 --> Controller Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:15:39 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:15:39 --> Upload Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:15:39 --> Config Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:15:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:15:39 --> URI Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Router Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Output Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Security Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Input Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:15:39 --> Language Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Loader Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Session Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:15:39 --> Session routines successfully run
DEBUG - 2013-12-06 13:15:39 --> Controller Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:15:39 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:15:39 --> Upload Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:15:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:39 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-06 13:15:39 --> Final output sent to browser
DEBUG - 2013-12-06 13:15:39 --> Total execution time: 0.1860
DEBUG - 2013-12-06 13:15:39 --> Config Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:15:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:15:39 --> URI Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Router Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Output Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Security Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Input Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:15:39 --> Language Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Loader Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Session Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:15:39 --> Session routines successfully run
DEBUG - 2013-12-06 13:15:39 --> Controller Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:15:39 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:15:39 --> Upload Class Initialized
DEBUG - 2013-12-06 13:15:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:39 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:15:39 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:15:45 --> Config Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:15:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:15:45 --> URI Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Router Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Output Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Security Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Input Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:15:45 --> Language Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Loader Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Session Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:15:45 --> Session routines successfully run
DEBUG - 2013-12-06 13:15:45 --> Controller Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:15:45 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:15:45 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:15:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:45 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:45 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:15:46 --> Upload Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:15:46 --> XSS Filtering completed
DEBUG - 2013-12-06 13:15:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 13:15:46 --> XSS Filtering completed
DEBUG - 2013-12-06 13:15:46 --> XSS Filtering completed
DEBUG - 2013-12-06 13:15:46 --> Config Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:15:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:15:46 --> URI Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Router Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Output Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Security Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Input Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:15:46 --> Language Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Loader Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Session Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:15:46 --> Session routines successfully run
DEBUG - 2013-12-06 13:15:46 --> Controller Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:15:46 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:15:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:15:46 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:15:46 --> Final output sent to browser
DEBUG - 2013-12-06 13:15:46 --> Total execution time: 0.2010
DEBUG - 2013-12-06 13:15:55 --> Config Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:15:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:15:55 --> URI Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Router Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Output Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Security Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Input Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:15:55 --> Language Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Loader Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Session Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:15:55 --> Session routines successfully run
DEBUG - 2013-12-06 13:15:55 --> Controller Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:15:55 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:15:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:15:55 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Model Class Initialized
DEBUG - 2013-12-06 13:15:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:18:19 --> Config Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:18:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:18:19 --> URI Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Router Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Output Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Security Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Input Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:18:19 --> Language Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Loader Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Session Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:18:19 --> Session routines successfully run
DEBUG - 2013-12-06 13:18:19 --> Controller Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:18:19 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:18:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:18:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:18:19 --> Model Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Model Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Model Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Model Class Initialized
DEBUG - 2013-12-06 13:18:19 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:18:19 --> Severity: Notice  --> Undefined index: num_likes C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 202
DEBUG - 2013-12-06 13:19:00 --> Config Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:19:01 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:19:01 --> URI Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Router Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Output Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Security Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Input Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:19:01 --> Language Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Loader Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Session Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:19:01 --> Session routines successfully run
DEBUG - 2013-12-06 13:19:01 --> Controller Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:19:01 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:19:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:19:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:19:01 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:19:25 --> Config Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:19:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:19:25 --> URI Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Router Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Output Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Security Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Input Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:19:25 --> Language Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Loader Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Session Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:19:25 --> Session routines successfully run
DEBUG - 2013-12-06 13:19:25 --> Controller Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:19:25 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:19:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:19:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:19:25 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:19:25 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:19:25 --> Final output sent to browser
DEBUG - 2013-12-06 13:19:25 --> Total execution time: 0.2590
DEBUG - 2013-12-06 13:19:31 --> Config Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:19:31 --> URI Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Router Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Output Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Security Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Input Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:19:31 --> Language Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Loader Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Session Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:19:31 --> Session routines successfully run
DEBUG - 2013-12-06 13:19:31 --> Controller Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:19:31 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:19:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:19:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:19:31 --> Config Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:19:31 --> URI Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Router Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Output Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Security Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Input Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:19:31 --> Language Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Loader Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Session Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:19:31 --> Session routines successfully run
DEBUG - 2013-12-06 13:19:31 --> Controller Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:19:31 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:19:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:19:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:19:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:19:31 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:19:31 --> Final output sent to browser
DEBUG - 2013-12-06 13:19:31 --> Total execution time: 0.2470
DEBUG - 2013-12-06 13:20:55 --> Config Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:20:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:20:55 --> URI Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Router Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Output Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Security Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Input Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:20:55 --> Language Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Loader Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Session Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:20:55 --> Session routines successfully run
DEBUG - 2013-12-06 13:20:55 --> Controller Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:20:55 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:20:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:20:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:20:55 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:20:55 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:20:55 --> Final output sent to browser
DEBUG - 2013-12-06 13:20:55 --> Total execution time: 0.3160
DEBUG - 2013-12-06 13:20:58 --> Config Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:20:58 --> URI Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Router Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Output Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Security Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Input Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:20:58 --> Language Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Loader Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Session Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:20:58 --> Session routines successfully run
DEBUG - 2013-12-06 13:20:58 --> Controller Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:20:58 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:20:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:20:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:20:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:20:58 --> Config Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:20:58 --> URI Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Router Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Output Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Security Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Input Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:20:58 --> Language Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Loader Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Session Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:20:58 --> Session routines successfully run
DEBUG - 2013-12-06 13:20:58 --> Controller Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:20:58 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:20:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:20:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:20:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:20:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:20:58 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:20:58 --> Final output sent to browser
DEBUG - 2013-12-06 13:20:58 --> Total execution time: 0.2710
DEBUG - 2013-12-06 13:21:11 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:11 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:11 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:11 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:11 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:11 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:11 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:21:11 --> Final output sent to browser
DEBUG - 2013-12-06 13:21:11 --> Total execution time: 0.5760
DEBUG - 2013-12-06 13:21:11 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:11 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:11 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:11 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:11 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:11 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:11 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:11 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:11 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:11 --> A session cookie was not found.
DEBUG - 2013-12-06 13:21:11 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:11 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:12 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:12 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:12 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:21:12 --> Upload Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:12 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:12 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-06 13:21:12 --> Final output sent to browser
DEBUG - 2013-12-06 13:21:12 --> Total execution time: 0.2450
DEBUG - 2013-12-06 13:21:12 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:12 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:12 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:12 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:12 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:12 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:12 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:12 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:21:12 --> Upload Class Initialized
DEBUG - 2013-12-06 13:21:12 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:12 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:21:12 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:21:16 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:16 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:16 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:16 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:16 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:16 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:16 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:21:16 --> Upload Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:21:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 13:21:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:21:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:21:17 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:17 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:17 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:17 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:17 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:17 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:17 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:17 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:21:17 --> Final output sent to browser
DEBUG - 2013-12-06 13:21:17 --> Total execution time: 0.2420
DEBUG - 2013-12-06 13:21:22 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:22 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:22 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:22 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:22 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:22 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:22 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:22 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:22 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:22 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:22 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:22 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:22 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:22 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:22 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:21:22 --> Final output sent to browser
DEBUG - 2013-12-06 13:21:22 --> Total execution time: 0.2820
DEBUG - 2013-12-06 13:21:25 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:25 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:25 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:25 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:25 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:25 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:26 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:26 --> Config Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:21:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:21:26 --> URI Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Router Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Output Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Security Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Input Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:21:26 --> Language Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Loader Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Session Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:21:26 --> Session routines successfully run
DEBUG - 2013-12-06 13:21:26 --> Controller Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:21:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:21:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:21:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:21:26 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Model Class Initialized
DEBUG - 2013-12-06 13:21:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:21:26 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:21:26 --> Final output sent to browser
DEBUG - 2013-12-06 13:21:26 --> Total execution time: 0.2460
DEBUG - 2013-12-06 13:22:56 --> Config Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:22:56 --> URI Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Router Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Output Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Security Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Input Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:22:56 --> Language Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Loader Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Session Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:22:56 --> Session routines successfully run
DEBUG - 2013-12-06 13:22:56 --> Controller Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:22:56 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:22:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:22:56 --> Model Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Model Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Model Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Model Class Initialized
DEBUG - 2013-12-06 13:22:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:22:56 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-06 13:22:56 --> Final output sent to browser
DEBUG - 2013-12-06 13:22:56 --> Total execution time: 0.3120
DEBUG - 2013-12-06 13:23:33 --> Config Class Initialized
DEBUG - 2013-12-06 13:23:33 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:23:33 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:23:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:23:33 --> URI Class Initialized
DEBUG - 2013-12-06 13:23:33 --> Router Class Initialized
DEBUG - 2013-12-06 13:23:33 --> Output Class Initialized
DEBUG - 2013-12-06 13:23:33 --> Security Class Initialized
DEBUG - 2013-12-06 13:23:33 --> Input Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:23:34 --> Language Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Loader Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Session Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:23:34 --> Session routines successfully run
DEBUG - 2013-12-06 13:23:34 --> Controller Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:23:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:23:34 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:23:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:23:34 --> Model Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Model Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Upload Class Initialized
DEBUG - 2013-12-06 13:23:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:23:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:23:34 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-06 13:23:34 --> Final output sent to browser
DEBUG - 2013-12-06 13:23:34 --> Total execution time: 0.3290
DEBUG - 2013-12-06 13:23:37 --> Config Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:23:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:23:37 --> URI Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Router Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Output Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Security Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Input Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:23:37 --> Language Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Loader Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Session Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:23:37 --> Session routines successfully run
DEBUG - 2013-12-06 13:23:37 --> Controller Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:23:37 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:23:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:23:37 --> Model Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Model Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Model Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Model Class Initialized
DEBUG - 2013-12-06 13:23:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:23:37 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:23:37 --> Final output sent to browser
DEBUG - 2013-12-06 13:23:37 --> Total execution time: 0.3090
DEBUG - 2013-12-06 13:25:05 --> Config Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:25:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:25:05 --> URI Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Router Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Output Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Security Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Input Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:25:05 --> Language Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Loader Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Session Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:25:05 --> Session routines successfully run
DEBUG - 2013-12-06 13:25:05 --> Controller Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:25:05 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:25:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:25:05 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:25:05 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:25:05 --> Final output sent to browser
DEBUG - 2013-12-06 13:25:05 --> Total execution time: 0.3440
DEBUG - 2013-12-06 13:25:39 --> Config Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:25:39 --> URI Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Router Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Output Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Security Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Input Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:25:39 --> Language Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Loader Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Session Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:25:39 --> Session routines successfully run
DEBUG - 2013-12-06 13:25:39 --> Controller Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:25:39 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:25:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:25:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:25:39 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:25:39 --> Final output sent to browser
DEBUG - 2013-12-06 13:25:39 --> Total execution time: 0.2840
DEBUG - 2013-12-06 13:25:51 --> Config Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:25:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:25:51 --> URI Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Router Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Output Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Security Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Input Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:25:51 --> Language Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Loader Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Session Class Initialized
DEBUG - 2013-12-06 13:25:51 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:25:52 --> Session routines successfully run
DEBUG - 2013-12-06 13:25:52 --> Controller Class Initialized
DEBUG - 2013-12-06 13:25:52 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:25:52 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:25:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:25:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:25:52 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:52 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:52 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:25:52 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:52 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:25:52 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:25:52 --> Final output sent to browser
DEBUG - 2013-12-06 13:25:52 --> Total execution time: 0.6380
DEBUG - 2013-12-06 13:25:54 --> Config Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:25:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:25:54 --> URI Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Router Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Output Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Security Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Input Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:25:54 --> Language Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Loader Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Session Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:25:54 --> Session routines successfully run
DEBUG - 2013-12-06 13:25:54 --> Controller Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:25:54 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:25:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:25:54 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Model Class Initialized
DEBUG - 2013-12-06 13:25:54 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:25:54 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:26:06 --> Config Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:26:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:26:06 --> URI Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Router Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Output Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Security Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Input Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:26:06 --> Language Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Loader Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Session Class Initialized
DEBUG - 2013-12-06 13:26:06 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:26:07 --> Session routines successfully run
DEBUG - 2013-12-06 13:26:07 --> Controller Class Initialized
DEBUG - 2013-12-06 13:26:07 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:26:07 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:26:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:26:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:07 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:26:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:07 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:26:07 --> Helper loaded: security_helper
DEBUG - 2013-12-06 13:26:07 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:26:07 --> File loaded: application/views/home/search_view.php
DEBUG - 2013-12-06 13:26:07 --> Final output sent to browser
DEBUG - 2013-12-06 13:26:07 --> Total execution time: 0.7790
DEBUG - 2013-12-06 13:26:10 --> Config Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:26:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:26:10 --> URI Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Router Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Output Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Security Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Input Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:26:10 --> Language Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Loader Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Session Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:26:10 --> Session routines successfully run
DEBUG - 2013-12-06 13:26:10 --> Controller Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:26:10 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:26:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:26:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:26:10 --> Helper loaded: security_helper
DEBUG - 2013-12-06 13:26:10 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:26:10 --> XSS Filtering completed
DEBUG - 2013-12-06 13:26:10 --> File loaded: application/views/home/search_view.php
DEBUG - 2013-12-06 13:26:10 --> Final output sent to browser
DEBUG - 2013-12-06 13:26:10 --> Total execution time: 0.3400
DEBUG - 2013-12-06 13:26:24 --> Config Class Initialized
DEBUG - 2013-12-06 13:26:24 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:26:24 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:26:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:26:24 --> URI Class Initialized
DEBUG - 2013-12-06 13:26:24 --> Router Class Initialized
DEBUG - 2013-12-06 13:26:24 --> Output Class Initialized
DEBUG - 2013-12-06 13:26:24 --> Security Class Initialized
DEBUG - 2013-12-06 13:26:24 --> Input Class Initialized
DEBUG - 2013-12-06 13:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:26:25 --> Language Class Initialized
DEBUG - 2013-12-06 13:26:25 --> Loader Class Initialized
DEBUG - 2013-12-06 13:26:25 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:26:25 --> Session Class Initialized
DEBUG - 2013-12-06 13:26:25 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:26:27 --> Session routines successfully run
DEBUG - 2013-12-06 13:26:27 --> Controller Class Initialized
DEBUG - 2013-12-06 13:26:27 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:26:27 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:26:27 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:26:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:26:27 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:27 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:27 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:26:27 --> Upload Class Initialized
DEBUG - 2013-12-06 13:26:27 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:26:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:26:27 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-06 13:26:27 --> Final output sent to browser
DEBUG - 2013-12-06 13:26:27 --> Total execution time: 2.5851
DEBUG - 2013-12-06 13:26:28 --> Config Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:26:28 --> URI Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Router Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Output Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Security Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Input Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:26:28 --> Language Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Loader Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Session Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:26:28 --> Session routines successfully run
DEBUG - 2013-12-06 13:26:28 --> Controller Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:26:28 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:26:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:26:28 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:26:28 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:26:28 --> Final output sent to browser
DEBUG - 2013-12-06 13:26:28 --> Total execution time: 0.2970
DEBUG - 2013-12-06 13:26:31 --> Config Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:26:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:26:31 --> URI Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Router Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Output Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Security Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Input Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:26:31 --> Language Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Loader Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Session Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:26:31 --> Session routines successfully run
DEBUG - 2013-12-06 13:26:31 --> Controller Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:26:31 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:26:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:26:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:26:31 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:32 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:26:32 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:26:32 --> Final output sent to browser
DEBUG - 2013-12-06 13:26:32 --> Total execution time: 0.3610
DEBUG - 2013-12-06 13:26:38 --> Config Class Initialized
DEBUG - 2013-12-06 13:26:38 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:26:38 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:26:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:26:38 --> URI Class Initialized
DEBUG - 2013-12-06 13:26:38 --> Router Class Initialized
DEBUG - 2013-12-06 13:26:38 --> Output Class Initialized
DEBUG - 2013-12-06 13:26:38 --> Security Class Initialized
DEBUG - 2013-12-06 13:26:38 --> Input Class Initialized
DEBUG - 2013-12-06 13:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:26:38 --> Language Class Initialized
DEBUG - 2013-12-06 13:26:38 --> Loader Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Session Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:26:39 --> Session routines successfully run
DEBUG - 2013-12-06 13:26:39 --> Controller Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:26:39 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:26:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:26:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:26:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:26:39 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:26:39 --> Final output sent to browser
DEBUG - 2013-12-06 13:26:39 --> Total execution time: 0.2820
DEBUG - 2013-12-06 13:26:42 --> Config Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:26:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:26:42 --> URI Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Router Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Output Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Security Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Input Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:26:42 --> Language Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Loader Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:26:42 --> Session Class Initialized
DEBUG - 2013-12-06 13:26:43 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:26:43 --> Session routines successfully run
DEBUG - 2013-12-06 13:26:43 --> Controller Class Initialized
DEBUG - 2013-12-06 13:26:43 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:26:43 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:26:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:26:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:26:43 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:43 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:43 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:26:43 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:43 --> Model Class Initialized
DEBUG - 2013-12-06 13:26:43 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:26:43 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:27:05 --> Config Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:27:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:27:05 --> URI Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Router Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Output Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Security Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Input Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:27:05 --> Language Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Loader Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Session Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:27:05 --> Session routines successfully run
DEBUG - 2013-12-06 13:27:05 --> Controller Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:27:05 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:27:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:27:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:27:05 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:27:05 --> Helper loaded: security_helper
DEBUG - 2013-12-06 13:27:05 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:27:05 --> File loaded: application/views/home/search_view.php
DEBUG - 2013-12-06 13:27:05 --> Final output sent to browser
DEBUG - 2013-12-06 13:27:05 --> Total execution time: 0.3500
DEBUG - 2013-12-06 13:27:10 --> Config Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:27:10 --> URI Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Router Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Output Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Security Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Input Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:27:10 --> Language Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Loader Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Session Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:27:10 --> Session routines successfully run
DEBUG - 2013-12-06 13:27:10 --> Controller Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:27:10 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:27:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:27:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:27:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:27:10 --> Helper loaded: security_helper
DEBUG - 2013-12-06 13:27:10 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:27:10 --> XSS Filtering completed
DEBUG - 2013-12-06 13:27:10 --> File loaded: application/views/home/search_view.php
DEBUG - 2013-12-06 13:27:10 --> Final output sent to browser
DEBUG - 2013-12-06 13:27:10 --> Total execution time: 0.3450
DEBUG - 2013-12-06 13:27:33 --> Config Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:27:33 --> URI Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Router Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Output Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Security Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Input Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:27:33 --> Language Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Loader Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Session Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:27:33 --> Session routines successfully run
DEBUG - 2013-12-06 13:27:33 --> Controller Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:27:33 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:27:33 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:27:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:27:33 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Upload Class Initialized
DEBUG - 2013-12-06 13:27:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:27:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:27:33 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-06 13:27:33 --> Final output sent to browser
DEBUG - 2013-12-06 13:27:33 --> Total execution time: 0.3530
DEBUG - 2013-12-06 13:27:34 --> Config Class Initialized
DEBUG - 2013-12-06 13:27:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:27:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:27:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:27:35 --> URI Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Router Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Output Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Security Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Input Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:27:35 --> Language Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Loader Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Session Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:27:35 --> Session routines successfully run
DEBUG - 2013-12-06 13:27:35 --> Controller Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:27:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:27:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:27:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:27:35 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:27:35 --> File loaded: application/views/home/followed_list_view.php
DEBUG - 2013-12-06 13:27:35 --> Final output sent to browser
DEBUG - 2013-12-06 13:27:35 --> Total execution time: 0.2960
DEBUG - 2013-12-06 13:27:38 --> Config Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:27:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:27:38 --> URI Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Router Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Output Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Security Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Input Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:27:38 --> Language Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Loader Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Session Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:27:38 --> Session routines successfully run
DEBUG - 2013-12-06 13:27:38 --> Controller Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:27:38 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:27:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:27:38 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Model Class Initialized
DEBUG - 2013-12-06 13:27:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:27:38 --> File loaded: application/views/home/other_profile_view.php
DEBUG - 2013-12-06 13:27:38 --> Final output sent to browser
DEBUG - 2013-12-06 13:27:38 --> Total execution time: 0.3480
DEBUG - 2013-12-06 13:57:44 --> Config Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:57:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:57:44 --> URI Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Router Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Output Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Security Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Input Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:57:44 --> Language Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Loader Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Session Class Initialized
DEBUG - 2013-12-06 13:57:44 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:57:45 --> Session routines successfully run
DEBUG - 2013-12-06 13:57:45 --> Controller Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:57:45 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:57:45 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:45 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Upload Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:57:45 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:57:45 --> Config Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:57:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:57:45 --> URI Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Router Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Output Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Security Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Input Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:57:45 --> Language Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Loader Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Session Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:57:45 --> A session cookie was not found.
DEBUG - 2013-12-06 13:57:45 --> Session routines successfully run
DEBUG - 2013-12-06 13:57:45 --> Controller Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:57:45 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:57:45 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:57:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:57:46 --> Upload Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:57:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:46 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-06 13:57:46 --> Final output sent to browser
DEBUG - 2013-12-06 13:57:46 --> Total execution time: 0.4640
DEBUG - 2013-12-06 13:57:46 --> Config Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:57:46 --> URI Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Router Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Output Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Security Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Input Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:57:46 --> Language Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Loader Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Session Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:57:46 --> Session routines successfully run
DEBUG - 2013-12-06 13:57:46 --> Controller Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:57:46 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:57:46 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:57:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:57:46 --> Upload Class Initialized
DEBUG - 2013-12-06 13:57:46 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:46 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:57:46 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:57:48 --> Config Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:57:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:57:48 --> URI Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Router Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Output Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Security Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Input Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:57:48 --> Language Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Loader Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Session Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:57:48 --> Session routines successfully run
DEBUG - 2013-12-06 13:57:48 --> Controller Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:57:48 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:57:48 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:57:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:48 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:57:48 --> Upload Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:57:48 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 13:57:48 --> Final output sent to browser
DEBUG - 2013-12-06 13:57:48 --> Total execution time: 0.3400
DEBUG - 2013-12-06 13:57:48 --> Config Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Config Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:57:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:57:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:57:48 --> URI Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Router Class Initialized
DEBUG - 2013-12-06 13:57:48 --> URI Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Output Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Router Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Security Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Output Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Input Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Security Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:57:48 --> Input Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Language Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:57:48 --> Loader Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Language Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Loader Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Session Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:57:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:57:48 --> Session routines successfully run
DEBUG - 2013-12-06 13:57:48 --> Session Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Controller Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:57:49 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:57:49 --> Session routines successfully run
DEBUG - 2013-12-06 13:57:49 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:57:49 --> Controller Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:57:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:57:49 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:49 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:57:49 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:49 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:57:49 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Upload Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:57:49 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:49 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:57:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:57:49 --> Upload Class Initialized
ERROR - 2013-12-06 13:57:49 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:57:49 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:49 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:57:49 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:57:58 --> Config Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:57:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:57:58 --> URI Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Router Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Output Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Security Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Input Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:57:58 --> Language Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Loader Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Session Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:57:58 --> Session routines successfully run
DEBUG - 2013-12-06 13:57:58 --> Controller Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:57:58 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:57:58 --> Helper loaded: security_helper
DEBUG - 2013-12-06 13:57:58 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:57:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Model Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:57:58 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:57:58 --> XSS Filtering completed
DEBUG - 2013-12-06 13:57:58 --> Final output sent to browser
DEBUG - 2013-12-06 13:57:58 --> Total execution time: 0.3560
DEBUG - 2013-12-06 13:58:04 --> Config Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:58:04 --> URI Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Router Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Output Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Security Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Input Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:58:04 --> Language Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Loader Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Session Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:58:04 --> Session routines successfully run
DEBUG - 2013-12-06 13:58:04 --> Controller Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:58:04 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:58:04 --> Helper loaded: security_helper
DEBUG - 2013-12-06 13:58:04 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:04 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:58:04 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:58:04 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:04 --> Final output sent to browser
DEBUG - 2013-12-06 13:58:04 --> Total execution time: 0.3590
DEBUG - 2013-12-06 13:58:15 --> Config Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:58:15 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:58:15 --> URI Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Router Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Output Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Security Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Input Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:58:15 --> Language Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Loader Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Session Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:58:15 --> Session routines successfully run
DEBUG - 2013-12-06 13:58:15 --> Controller Class Initialized
DEBUG - 2013-12-06 13:58:15 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:58:16 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:58:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:58:16 --> Upload Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:58:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 13:58:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:16 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:16 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 13:58:16 --> Final output sent to browser
DEBUG - 2013-12-06 13:58:16 --> Total execution time: 0.4210
DEBUG - 2013-12-06 13:58:16 --> Config Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Config Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:58:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:58:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:58:16 --> URI Class Initialized
DEBUG - 2013-12-06 13:58:16 --> URI Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Router Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Router Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Output Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Output Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Security Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Security Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Input Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Input Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:58:16 --> Language Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Language Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Loader Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Loader Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Session Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Session Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:58:16 --> Session routines successfully run
DEBUG - 2013-12-06 13:58:16 --> Session routines successfully run
DEBUG - 2013-12-06 13:58:16 --> Controller Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Controller Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:58:16 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:58:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:58:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:58:16 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:58:16 --> Upload Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Upload Class Initialized
DEBUG - 2013-12-06 13:58:16 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:16 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:58:16 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:58:17 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 13:58:17 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 13:58:23 --> Config Class Initialized
DEBUG - 2013-12-06 13:58:23 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:58:23 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:58:23 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:58:23 --> URI Class Initialized
DEBUG - 2013-12-06 13:58:23 --> Router Class Initialized
DEBUG - 2013-12-06 13:58:23 --> Output Class Initialized
DEBUG - 2013-12-06 13:58:23 --> Security Class Initialized
DEBUG - 2013-12-06 13:58:23 --> Input Class Initialized
DEBUG - 2013-12-06 13:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:58:23 --> Language Class Initialized
DEBUG - 2013-12-06 13:58:23 --> Loader Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Session Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:58:24 --> Session routines successfully run
DEBUG - 2013-12-06 13:58:24 --> Controller Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:58:24 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:24 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:58:24 --> Upload Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:58:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 13:58:24 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:24 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:24 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:24 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:24 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:24 --> XSS Filtering completed
DEBUG - 2013-12-06 13:58:24 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 13:58:24 --> Final output sent to browser
DEBUG - 2013-12-06 13:58:24 --> Total execution time: 0.4370
DEBUG - 2013-12-06 13:58:24 --> Config Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Config Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Hooks Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Utf8 Class Initialized
DEBUG - 2013-12-06 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 13:58:24 --> URI Class Initialized
DEBUG - 2013-12-06 13:58:24 --> URI Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Router Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Router Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Output Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Output Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Security Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Security Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Input Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Input Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 13:58:24 --> Language Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Language Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Loader Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Loader Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Database Driver Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Session Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Session Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: string_helper
DEBUG - 2013-12-06 13:58:24 --> Session routines successfully run
DEBUG - 2013-12-06 13:58:24 --> Session routines successfully run
DEBUG - 2013-12-06 13:58:24 --> Controller Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Controller Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: form_helper
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: url_helper
DEBUG - 2013-12-06 13:58:24 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Form Validation Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:58:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 13:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:24 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Model Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Image Lib Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:58:24 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 13:58:24 --> Upload Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Upload Class Initialized
DEBUG - 2013-12-06 13:58:24 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:24 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 13:58:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 13:58:24 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 13:58:24 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 13:58:24 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:00:16 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:16 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:16 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:16 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:16 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:16 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:16 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:00:16 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:16 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:16 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:16 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:16 --> Final output sent to browser
DEBUG - 2013-12-06 14:00:16 --> Total execution time: 0.3810
DEBUG - 2013-12-06 14:00:19 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:19 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:19 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:19 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:19 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:19 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:19 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:19 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:19 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:00:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:00:19 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:19 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:19 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:19 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:19 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:19 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:19 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:00:19 --> Final output sent to browser
DEBUG - 2013-12-06 14:00:19 --> Total execution time: 0.4510
DEBUG - 2013-12-06 14:00:19 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:19 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:19 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:19 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:19 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:19 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:20 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:20 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:20 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:20 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:20 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:20 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:20 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:20 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:20 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:20 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:00:20 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:00:20 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:00:20 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:00:31 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:31 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:31 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:31 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:31 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:31 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:31 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:31 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:31 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:00:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:00:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:31 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:00:31 --> Final output sent to browser
DEBUG - 2013-12-06 14:00:31 --> Total execution time: 0.4730
DEBUG - 2013-12-06 14:00:31 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:31 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:31 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:31 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:31 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:31 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:32 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:32 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:32 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:32 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:32 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:32 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:32 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:32 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:32 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:32 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:32 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:32 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:32 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:32 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:00:32 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2013-12-06 14:00:32 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:00:32 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:00:32 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:00:43 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:43 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:43 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:43 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:43 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:43 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:43 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:00:43 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:43 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:43 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:43 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:43 --> Final output sent to browser
DEBUG - 2013-12-06 14:00:43 --> Total execution time: 0.3720
DEBUG - 2013-12-06 14:00:45 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:45 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:45 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:45 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:45 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:45 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:45 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:45 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:45 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:46 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:00:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:00:46 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:46 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:46 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:46 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:46 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:46 --> XSS Filtering completed
DEBUG - 2013-12-06 14:00:46 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:00:46 --> Final output sent to browser
DEBUG - 2013-12-06 14:00:46 --> Total execution time: 0.4780
DEBUG - 2013-12-06 14:00:46 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Config Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:00:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:46 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:00:46 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:00:46 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:46 --> URI Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Router Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Output Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Security Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:46 --> Input Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:00:46 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Language Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Loader Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:46 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:46 --> Session Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:46 --> Session routines successfully run
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:46 --> Controller Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:00:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:00:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:46 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:00:46 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:46 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:46 --> Model Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:00:46 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:00:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:00:46 --> Upload Class Initialized
DEBUG - 2013-12-06 14:00:46 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2013-12-06 14:00:46 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:00:46 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:00:46 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:05:21 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:21 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:21 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:21 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:21 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:21 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:21 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:21 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:21 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:21 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:05:21 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:05:22 --> Final output sent to browser
DEBUG - 2013-12-06 14:05:22 --> Total execution time: 0.4130
DEBUG - 2013-12-06 14:05:22 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:22 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:22 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:22 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:22 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:22 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:22 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:22 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:22 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:22 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:22 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:22 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:22 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:22 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:22 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:05:22 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:05:22 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:05:22 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:05:26 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:26 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:26 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:26 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:26 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:26 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:05:26 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:26 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:26 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:26 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:26 --> Final output sent to browser
DEBUG - 2013-12-06 14:05:26 --> Total execution time: 0.3970
DEBUG - 2013-12-06 14:05:29 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:29 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:29 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:29 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:29 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:29 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:29 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:05:29 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:29 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:29 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:29 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:29 --> Final output sent to browser
DEBUG - 2013-12-06 14:05:29 --> Total execution time: 0.4390
DEBUG - 2013-12-06 14:05:37 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:37 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:37 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:37 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:37 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:37 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:37 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:37 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:37 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:05:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:05:37 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:37 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:37 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:37 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:37 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:37 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:37 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:05:37 --> Final output sent to browser
DEBUG - 2013-12-06 14:05:38 --> Total execution time: 0.5110
DEBUG - 2013-12-06 14:05:38 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:38 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:38 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:38 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:38 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:38 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:38 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:38 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:38 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:38 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:38 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:38 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:38 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:38 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:38 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:38 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:38 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:05:38 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:05:38 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:05:38 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:05:47 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:47 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:47 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:47 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:47 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:47 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:47 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:05:47 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:47 --> Final output sent to browser
DEBUG - 2013-12-06 14:05:47 --> Total execution time: 0.4150
DEBUG - 2013-12-06 14:05:50 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:50 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:50 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:50 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:50 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:50 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:50 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:50 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:51 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:51 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:51 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:51 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:51 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:51 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:05:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:05:51 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:51 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:51 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:51 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:51 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:51 --> XSS Filtering completed
DEBUG - 2013-12-06 14:05:51 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:05:51 --> Final output sent to browser
DEBUG - 2013-12-06 14:05:51 --> Total execution time: 0.5240
DEBUG - 2013-12-06 14:05:51 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Config Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:05:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:05:51 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:51 --> URI Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Router Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Output Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Security Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Input Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:05:51 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Language Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Loader Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Session Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:05:51 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:51 --> Session routines successfully run
DEBUG - 2013-12-06 14:05:51 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Controller Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:51 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:05:51 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:05:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:52 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:52 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:52 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:52 --> Model Class Initialized
DEBUG - 2013-12-06 14:05:52 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:52 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:05:52 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:52 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:05:52 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:52 --> Upload Class Initialized
DEBUG - 2013-12-06 14:05:52 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:52 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:05:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:05:52 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:05:52 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:05:52 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:13:28 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:28 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:28 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:28 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:28 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:28 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:28 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:28 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:28 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:13:28 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:13:28 --> Final output sent to browser
DEBUG - 2013-12-06 14:13:28 --> Total execution time: 0.4880
DEBUG - 2013-12-06 14:13:28 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:28 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:28 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:28 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:28 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:29 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:29 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:29 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:29 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:29 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:29 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:29 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:29 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:29 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:29 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:29 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:29 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:29 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:13:29 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:13:29 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:13:29 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:13:42 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:42 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:42 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:42 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:42 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:42 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:42 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:42 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:43 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:43 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:43 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:43 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:43 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:43 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:13:43 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:13:43 --> Final output sent to browser
DEBUG - 2013-12-06 14:13:43 --> Total execution time: 0.4720
DEBUG - 2013-12-06 14:13:43 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:43 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:43 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:43 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:43 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:43 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:43 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:43 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:43 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:43 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:43 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:44 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:44 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:44 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:44 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:44 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:44 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:44 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:44 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:13:44 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:13:44 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:13:44 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:13:45 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:45 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:45 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:46 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:46 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:46 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:46 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:46 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:46 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:46 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:46 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:13:46 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:13:46 --> Final output sent to browser
DEBUG - 2013-12-06 14:13:46 --> Total execution time: 0.4630
DEBUG - 2013-12-06 14:13:46 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Config Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:13:46 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:46 --> URI Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Router Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Output Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Security Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Input Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:13:46 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Language Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Loader Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:46 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:47 --> Session Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:47 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:13:47 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Session routines successfully run
DEBUG - 2013-12-06 14:13:47 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:47 --> Controller Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:47 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:13:47 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:13:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:47 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:13:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:47 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:13:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:13:47 --> Upload Class Initialized
DEBUG - 2013-12-06 14:13:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:13:47 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2013-12-06 14:13:47 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:13:47 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:13:47 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:16:24 --> Config Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:16:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:16:24 --> URI Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Router Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Output Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Security Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Input Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:16:24 --> Language Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Loader Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Session Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:16:24 --> Session routines successfully run
DEBUG - 2013-12-06 14:16:24 --> Controller Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:16:24 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:16:24 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:16:24 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:16:24 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:16:24 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:16:24 --> XSS Filtering completed
DEBUG - 2013-12-06 14:16:24 --> Final output sent to browser
DEBUG - 2013-12-06 14:16:24 --> Total execution time: 0.4650
DEBUG - 2013-12-06 14:16:27 --> Config Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:16:27 --> URI Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Router Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Output Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Security Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Input Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:16:27 --> Language Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Loader Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Session Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:16:27 --> Session garbage collection performed.
DEBUG - 2013-12-06 14:16:27 --> Session routines successfully run
DEBUG - 2013-12-06 14:16:27 --> Controller Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:16:27 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:16:27 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:16:27 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:16:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:16:27 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:16:27 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:16:27 --> XSS Filtering completed
DEBUG - 2013-12-06 14:16:27 --> Final output sent to browser
DEBUG - 2013-12-06 14:16:27 --> Total execution time: 0.4890
DEBUG - 2013-12-06 14:16:33 --> Config Class Initialized
DEBUG - 2013-12-06 14:16:33 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:16:34 --> URI Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Router Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Output Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Security Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Input Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:16:34 --> Language Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Loader Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Session Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:16:34 --> Session garbage collection performed.
DEBUG - 2013-12-06 14:16:34 --> Session routines successfully run
DEBUG - 2013-12-06 14:16:34 --> Controller Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:16:34 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:16:34 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:16:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:16:34 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:16:34 --> Upload Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:16:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:16:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:16:34 --> XSS Filtering completed
DEBUG - 2013-12-06 14:16:34 --> XSS Filtering completed
DEBUG - 2013-12-06 14:16:34 --> XSS Filtering completed
DEBUG - 2013-12-06 14:16:34 --> XSS Filtering completed
DEBUG - 2013-12-06 14:16:34 --> XSS Filtering completed
DEBUG - 2013-12-06 14:16:34 --> XSS Filtering completed
DEBUG - 2013-12-06 14:16:34 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:16:34 --> Final output sent to browser
DEBUG - 2013-12-06 14:16:34 --> Total execution time: 0.5880
DEBUG - 2013-12-06 14:16:34 --> Config Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Config Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:16:34 --> URI Class Initialized
DEBUG - 2013-12-06 14:16:34 --> URI Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Router Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Router Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Output Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Output Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Security Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Security Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Input Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Input Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:16:34 --> Language Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Language Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Loader Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Loader Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:16:34 --> Session Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Session Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:16:35 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:16:35 --> Session routines successfully run
DEBUG - 2013-12-06 14:16:35 --> Session routines successfully run
DEBUG - 2013-12-06 14:16:35 --> Controller Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Controller Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:16:35 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:16:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:16:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:16:35 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:16:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:16:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:16:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:16:35 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Model Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:16:35 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:16:35 --> Upload Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Upload Class Initialized
DEBUG - 2013-12-06 14:16:35 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:16:35 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:16:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:16:35 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:16:35 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:16:35 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:22:47 --> Config Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:22:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:22:47 --> URI Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Router Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Output Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Security Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Input Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:22:47 --> Language Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Loader Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Session Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:22:47 --> Session routines successfully run
DEBUG - 2013-12-06 14:22:47 --> Controller Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:22:47 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:22:47 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:22:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:22:47 --> Upload Class Initialized
DEBUG - 2013-12-06 14:22:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:22:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:22:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:22:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:22:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:22:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:22:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:22:48 --> XSS Filtering completed
DEBUG - 2013-12-06 14:22:48 --> XSS Filtering completed
ERROR - 2013-12-06 14:22:48 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-06 14:22:48 --> Email Class Initialized
DEBUG - 2013-12-06 14:22:48 --> File loaded: application/views/email/activate-html.php
DEBUG - 2013-12-06 14:22:48 --> File loaded: application/views/email/activate-txt.php
DEBUG - 2013-12-06 14:22:48 --> Language file loaded: language/english/email_lang.php
DEBUG - 2013-12-06 14:22:51 --> Config Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:22:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:22:51 --> URI Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Router Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Output Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Security Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Input Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:22:51 --> Language Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Loader Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Session Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:22:51 --> Session routines successfully run
DEBUG - 2013-12-06 14:22:51 --> Controller Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:22:51 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:22:51 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:22:51 --> Model Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Model Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:22:51 --> Upload Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:22:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:22:51 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-06 14:22:51 --> Final output sent to browser
DEBUG - 2013-12-06 14:22:51 --> Total execution time: 0.5060
DEBUG - 2013-12-06 14:22:51 --> Config Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:22:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:22:51 --> URI Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Router Class Initialized
DEBUG - 2013-12-06 14:22:51 --> Output Class Initialized
DEBUG - 2013-12-06 14:22:52 --> Security Class Initialized
DEBUG - 2013-12-06 14:22:52 --> Input Class Initialized
DEBUG - 2013-12-06 14:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:22:52 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:02 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:02 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:02 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:02 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:02 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:02 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:02 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:02 --> Upload Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:23:02 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:02 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-06 14:23:02 --> Final output sent to browser
DEBUG - 2013-12-06 14:23:02 --> Total execution time: 0.6030
DEBUG - 2013-12-06 14:23:02 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:02 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:02 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:02 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:03 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:03 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:03 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:03 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:03 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:03 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:03 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:03 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:03 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:03 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:03 --> Upload Class Initialized
DEBUG - 2013-12-06 14:23:03 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:23:03 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:03 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-06 14:23:03 --> Final output sent to browser
DEBUG - 2013-12-06 14:23:03 --> Total execution time: 0.5450
DEBUG - 2013-12-06 14:23:21 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:21 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:21 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:21 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:21 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:21 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:21 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:21 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:21 --> Upload Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:23:21 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:23:21 --> Final output sent to browser
DEBUG - 2013-12-06 14:23:21 --> Total execution time: 0.5350
DEBUG - 2013-12-06 14:23:21 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:21 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:21 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:21 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:22 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:22 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:22 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:22 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:22 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:22 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:22 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:22 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:22 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:22 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:22 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:22 --> Upload Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Upload Class Initialized
DEBUG - 2013-12-06 14:23:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:23:22 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:23:22 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:23:22 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:23:25 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:25 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:25 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:25 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:25 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:26 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:26 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:26 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:26 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:26 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:23:26 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:26 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:26 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:26 --> XSS Filtering completed
DEBUG - 2013-12-06 14:23:26 --> Final output sent to browser
DEBUG - 2013-12-06 14:23:26 --> Total execution time: 0.4860
DEBUG - 2013-12-06 14:23:30 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:30 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:30 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:30 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:30 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:31 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:31 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:31 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:31 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:23:31 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:31 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:31 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:31 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:31 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:23:31 --> Final output sent to browser
DEBUG - 2013-12-06 14:23:31 --> Total execution time: 0.5250
DEBUG - 2013-12-06 14:23:34 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:34 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:35 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:35 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:35 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:35 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:35 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:35 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:35 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:35 --> Upload Class Initialized
DEBUG - 2013-12-06 14:23:35 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:23:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:23:35 --> XSS Filtering completed
DEBUG - 2013-12-06 14:23:35 --> XSS Filtering completed
DEBUG - 2013-12-06 14:23:35 --> XSS Filtering completed
DEBUG - 2013-12-06 14:23:35 --> XSS Filtering completed
DEBUG - 2013-12-06 14:23:35 --> XSS Filtering completed
DEBUG - 2013-12-06 14:23:35 --> XSS Filtering completed
DEBUG - 2013-12-06 14:23:37 --> Config Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:23:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:23:37 --> URI Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Router Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Output Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Security Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Input Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:23:37 --> Language Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Loader Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Session Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:23:37 --> Session routines successfully run
DEBUG - 2013-12-06 14:23:37 --> Controller Class Initialized
DEBUG - 2013-12-06 14:23:37 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:23:37 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:23:37 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:23:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:23:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:38 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:38 --> Model Class Initialized
DEBUG - 2013-12-06 14:23:38 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:23:38 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:23:38 --> Upload Class Initialized
DEBUG - 2013-12-06 14:23:38 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:23:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:23:38 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:23:38 --> Final output sent to browser
DEBUG - 2013-12-06 14:23:38 --> Total execution time: 0.5420
DEBUG - 2013-12-06 14:28:19 --> Config Class Initialized
DEBUG - 2013-12-06 14:28:19 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:28:19 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:28:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:28:19 --> URI Class Initialized
DEBUG - 2013-12-06 14:28:19 --> Router Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Output Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Security Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Input Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:28:20 --> Language Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Loader Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Session Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:28:20 --> Session routines successfully run
DEBUG - 2013-12-06 14:28:20 --> Controller Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:28:20 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:28:20 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:20 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:28:20 --> Upload Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:28:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:28:20 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:20 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:20 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:20 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:20 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:20 --> XSS Filtering completed
ERROR - 2013-12-06 14:28:20 --> Could not find the language line "auth_confirm_password_err"
DEBUG - 2013-12-06 14:28:20 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:28:20 --> Final output sent to browser
DEBUG - 2013-12-06 14:28:20 --> Total execution time: 0.6790
DEBUG - 2013-12-06 14:28:20 --> Config Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Config Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:28:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:28:20 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:28:20 --> URI Class Initialized
DEBUG - 2013-12-06 14:28:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:28:20 --> Router Class Initialized
DEBUG - 2013-12-06 14:28:20 --> URI Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Output Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Router Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Security Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Output Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Input Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Security Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:28:20 --> Input Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Language Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:28:20 --> Loader Class Initialized
DEBUG - 2013-12-06 14:28:20 --> Language Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Loader Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Session Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:28:21 --> Session Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Session routines successfully run
DEBUG - 2013-12-06 14:28:21 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:28:21 --> Controller Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Session routines successfully run
DEBUG - 2013-12-06 14:28:21 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:28:21 --> Controller Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:28:21 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:28:21 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:28:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:28:21 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:28:21 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:21 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:28:21 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Upload Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:28:21 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:21 --> Upload Class Initialized
DEBUG - 2013-12-06 14:28:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:28:21 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2013-12-06 14:28:21 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:28:21 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:28:21 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:28:47 --> Config Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:28:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:28:47 --> URI Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Router Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Output Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Security Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Input Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:28:47 --> Language Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Loader Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Session Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:28:47 --> Session routines successfully run
DEBUG - 2013-12-06 14:28:47 --> Controller Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:28:47 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:28:47 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:28:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:28:47 --> Upload Class Initialized
DEBUG - 2013-12-06 14:28:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:28:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:28:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:47 --> XSS Filtering completed
DEBUG - 2013-12-06 14:28:47 --> XSS Filtering completed
ERROR - 2013-12-06 14:28:47 --> Could not find the language line "I think you are wrong"
DEBUG - 2013-12-06 14:28:47 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:28:47 --> Final output sent to browser
DEBUG - 2013-12-06 14:28:47 --> Total execution time: 0.6780
DEBUG - 2013-12-06 14:28:48 --> Config Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Config Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:28:48 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:28:48 --> URI Class Initialized
DEBUG - 2013-12-06 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:28:48 --> Router Class Initialized
DEBUG - 2013-12-06 14:28:48 --> URI Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Output Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Router Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Security Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Output Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Input Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Security Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:28:48 --> Input Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Language Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:28:48 --> Loader Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Language Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Loader Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Session Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:28:48 --> Session Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Session routines successfully run
DEBUG - 2013-12-06 14:28:48 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:28:48 --> Controller Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Session routines successfully run
DEBUG - 2013-12-06 14:28:48 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:28:48 --> Controller Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:28:48 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:28:48 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:28:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:28:48 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:28:48 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:48 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Model Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:28:48 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Upload Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:28:48 --> Upload Class Initialized
DEBUG - 2013-12-06 14:28:48 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:48 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:28:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:28:48 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:28:48 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:28:48 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:31:31 --> Config Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:31:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:31:31 --> URI Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Router Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Output Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Security Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Input Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:31:31 --> Language Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Loader Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Session Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:31:31 --> Session routines successfully run
DEBUG - 2013-12-06 14:31:31 --> Controller Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:31:31 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:31:31 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:31:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:31 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:31:31 --> Upload Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:31:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:31:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:31 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:31 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:31:31 --> Final output sent to browser
DEBUG - 2013-12-06 14:31:31 --> Total execution time: 0.6950
DEBUG - 2013-12-06 14:31:31 --> Config Class Initialized
DEBUG - 2013-12-06 14:31:31 --> Config Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:31:32 --> URI Class Initialized
DEBUG - 2013-12-06 14:31:32 --> URI Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Router Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Router Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Output Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Output Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Security Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Security Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Input Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Input Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:31:32 --> Language Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Language Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Loader Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Loader Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Session Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Session Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:31:32 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:31:32 --> Session routines successfully run
DEBUG - 2013-12-06 14:31:32 --> Session routines successfully run
DEBUG - 2013-12-06 14:31:32 --> Controller Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Controller Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:31:32 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:31:32 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:31:32 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:31:32 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:31:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:31:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:32 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:31:32 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:31:32 --> Upload Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Upload Class Initialized
DEBUG - 2013-12-06 14:31:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:31:32 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:31:32 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:31:32 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:31:44 --> Config Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:31:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:31:44 --> URI Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Router Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Output Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Security Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Input Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:31:44 --> Language Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Loader Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Session Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:31:44 --> Session routines successfully run
DEBUG - 2013-12-06 14:31:44 --> Controller Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:31:44 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:31:44 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:31:44 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:44 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:31:44 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:31:44 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:44 --> Final output sent to browser
DEBUG - 2013-12-06 14:31:44 --> Total execution time: 0.5730
DEBUG - 2013-12-06 14:31:47 --> Config Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:31:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:31:47 --> URI Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Router Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Output Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Security Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Input Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:31:47 --> Language Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Loader Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Session Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:31:47 --> Session routines successfully run
DEBUG - 2013-12-06 14:31:47 --> Controller Class Initialized
DEBUG - 2013-12-06 14:31:47 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:31:47 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:31:47 --> Helper loaded: security_helper
DEBUG - 2013-12-06 14:31:47 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:31:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:48 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:48 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:48 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:31:48 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:31:48 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:48 --> Final output sent to browser
DEBUG - 2013-12-06 14:31:48 --> Total execution time: 0.5660
DEBUG - 2013-12-06 14:31:50 --> Config Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:31:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:31:50 --> URI Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Router Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Output Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Security Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Input Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:31:50 --> Language Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Loader Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Session Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:31:50 --> Session routines successfully run
DEBUG - 2013-12-06 14:31:50 --> Controller Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:31:50 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:31:50 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:50 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:31:50 --> Upload Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:31:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:31:50 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:50 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:50 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:50 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:50 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:50 --> XSS Filtering completed
DEBUG - 2013-12-06 14:31:50 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:31:50 --> Final output sent to browser
DEBUG - 2013-12-06 14:31:50 --> Total execution time: 0.7030
DEBUG - 2013-12-06 14:31:50 --> Config Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Config Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:31:50 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:31:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:31:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:31:51 --> URI Class Initialized
DEBUG - 2013-12-06 14:31:51 --> URI Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Router Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Router Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Output Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Output Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Security Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Security Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Input Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Input Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:31:51 --> Language Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Language Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Loader Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Loader Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Session Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Session Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:31:51 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:31:51 --> Session routines successfully run
DEBUG - 2013-12-06 14:31:51 --> Session routines successfully run
DEBUG - 2013-12-06 14:31:51 --> Controller Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Controller Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:31:51 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:31:51 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:31:51 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:31:51 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:31:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:51 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Model Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:31:51 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:31:51 --> Upload Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Upload Class Initialized
DEBUG - 2013-12-06 14:31:51 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:51 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:31:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:31:51 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:31:51 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:31:52 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:32:09 --> Config Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:32:09 --> URI Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Router Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Output Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Security Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Input Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:32:09 --> Language Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Loader Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Session Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:32:09 --> Session routines successfully run
DEBUG - 2013-12-06 14:32:09 --> Controller Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:32:09 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:32:09 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:32:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:32:09 --> Model Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Model Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:32:09 --> Upload Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:32:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:32:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:32:09 --> XSS Filtering completed
DEBUG - 2013-12-06 14:32:09 --> XSS Filtering completed
DEBUG - 2013-12-06 14:32:09 --> XSS Filtering completed
DEBUG - 2013-12-06 14:32:09 --> XSS Filtering completed
DEBUG - 2013-12-06 14:32:09 --> XSS Filtering completed
DEBUG - 2013-12-06 14:32:09 --> XSS Filtering completed
DEBUG - 2013-12-06 14:32:09 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:32:09 --> Final output sent to browser
DEBUG - 2013-12-06 14:32:09 --> Total execution time: 0.6870
DEBUG - 2013-12-06 14:32:09 --> Config Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:32:09 --> URI Class Initialized
DEBUG - 2013-12-06 14:32:09 --> Router Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Output Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Config Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Security Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Input Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:32:10 --> Language Class Initialized
DEBUG - 2013-12-06 14:32:10 --> URI Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Loader Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Router Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Output Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Session Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Security Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:32:10 --> Input Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Session routines successfully run
DEBUG - 2013-12-06 14:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:32:10 --> Controller Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Language Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:32:10 --> Loader Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:32:10 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Session Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:32:10 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:32:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:32:10 --> Session routines successfully run
DEBUG - 2013-12-06 14:32:10 --> Model Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Controller Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Model Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:32:10 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:32:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:32:10 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Upload Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:32:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:32:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:32:10 --> Model Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:32:10 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:32:10 --> Model Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:32:10 --> Upload Class Initialized
DEBUG - 2013-12-06 14:32:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:32:10 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:32:10 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:35:39 --> Config Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:35:39 --> URI Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Router Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Output Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Security Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Input Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:35:39 --> Language Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Loader Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Session Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:35:39 --> Session garbage collection performed.
DEBUG - 2013-12-06 14:35:39 --> Session routines successfully run
DEBUG - 2013-12-06 14:35:39 --> Controller Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:35:39 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:35:39 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:35:39 --> Model Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Model Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:35:39 --> Upload Class Initialized
DEBUG - 2013-12-06 14:35:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:35:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:35:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:35:39 --> XSS Filtering completed
DEBUG - 2013-12-06 14:35:39 --> XSS Filtering completed
DEBUG - 2013-12-06 14:35:39 --> XSS Filtering completed
DEBUG - 2013-12-06 14:35:39 --> XSS Filtering completed
DEBUG - 2013-12-06 14:35:39 --> XSS Filtering completed
DEBUG - 2013-12-06 14:35:40 --> XSS Filtering completed
DEBUG - 2013-12-06 14:35:40 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:35:40 --> Final output sent to browser
DEBUG - 2013-12-06 14:35:40 --> Total execution time: 0.7330
DEBUG - 2013-12-06 14:35:40 --> Config Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Config Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:35:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:35:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:35:40 --> URI Class Initialized
DEBUG - 2013-12-06 14:35:40 --> URI Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Router Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Router Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Output Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Output Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Security Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Security Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Input Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Input Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:35:40 --> Language Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Language Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Loader Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Loader Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Session Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Session Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:35:40 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:35:40 --> Session routines successfully run
DEBUG - 2013-12-06 14:35:40 --> Session routines successfully run
DEBUG - 2013-12-06 14:35:40 --> Controller Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Controller Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:35:40 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:35:40 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:35:40 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:35:40 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:35:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:35:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:35:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:35:40 --> Model Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Model Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Model Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Model Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:35:40 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:35:41 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:35:41 --> Upload Class Initialized
DEBUG - 2013-12-06 14:35:41 --> Upload Class Initialized
DEBUG - 2013-12-06 14:35:41 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:35:41 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:35:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:35:41 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:35:41 --> 404 Page Not Found --> errors/page_missing
ERROR - 2013-12-06 14:35:41 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:37:03 --> Config Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:37:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:37:03 --> URI Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Router Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Output Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Security Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Input Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:37:03 --> Language Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Loader Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Session Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:37:03 --> Session routines successfully run
DEBUG - 2013-12-06 14:37:03 --> Controller Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:37:03 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:37:03 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:37:03 --> Model Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Model Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:37:03 --> Upload Class Initialized
DEBUG - 2013-12-06 14:37:03 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:37:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:37:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-06 14:37:04 --> XSS Filtering completed
DEBUG - 2013-12-06 14:37:04 --> XSS Filtering completed
DEBUG - 2013-12-06 14:37:04 --> XSS Filtering completed
DEBUG - 2013-12-06 14:37:04 --> XSS Filtering completed
DEBUG - 2013-12-06 14:37:04 --> XSS Filtering completed
DEBUG - 2013-12-06 14:37:04 --> XSS Filtering completed
DEBUG - 2013-12-06 14:37:04 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-06 14:37:04 --> Final output sent to browser
DEBUG - 2013-12-06 14:37:04 --> Total execution time: 0.7370
DEBUG - 2013-12-06 14:37:04 --> Config Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Config Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Hooks Class Initialized
DEBUG - 2013-12-06 14:37:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:37:04 --> Utf8 Class Initialized
DEBUG - 2013-12-06 14:37:04 --> URI Class Initialized
DEBUG - 2013-12-06 14:37:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-06 14:37:04 --> Router Class Initialized
DEBUG - 2013-12-06 14:37:04 --> URI Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Output Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Router Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Security Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Output Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Input Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Security Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:37:04 --> Input Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Language Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-06 14:37:04 --> Loader Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Language Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Loader Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Session Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Database Driver Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:37:04 --> Session Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Session routines successfully run
DEBUG - 2013-12-06 14:37:04 --> Helper loaded: string_helper
DEBUG - 2013-12-06 14:37:04 --> Controller Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:37:04 --> Session routines successfully run
DEBUG - 2013-12-06 14:37:04 --> Controller Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:37:04 --> Helper loaded: form_helper
DEBUG - 2013-12-06 14:37:04 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Helper loaded: url_helper
DEBUG - 2013-12-06 14:37:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:37:04 --> Form Validation Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:37:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-06 14:37:04 --> Model Class Initialized
DEBUG - 2013-12-06 14:37:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:37:05 --> Model Class Initialized
DEBUG - 2013-12-06 14:37:05 --> Model Class Initialized
DEBUG - 2013-12-06 14:37:05 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:37:05 --> Model Class Initialized
DEBUG - 2013-12-06 14:37:05 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:37:05 --> Image Lib Class Initialized
DEBUG - 2013-12-06 14:37:05 --> Upload Class Initialized
DEBUG - 2013-12-06 14:37:05 --> Helper loaded: cookie_helper
DEBUG - 2013-12-06 14:37:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-06 14:37:05 --> Upload Class Initialized
DEBUG - 2013-12-06 14:37:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-06 14:37:05 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2013-12-06 14:37:05 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-06 14:37:05 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-06 14:37:05 --> 404 Page Not Found --> errors/page_missing
