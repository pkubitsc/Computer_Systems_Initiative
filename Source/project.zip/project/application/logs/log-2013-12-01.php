<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-12-01 01:18:12 --> Config Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Hooks Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Utf8 Class Initialized
DEBUG - 2013-12-01 01:18:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 01:18:12 --> URI Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Router Class Initialized
DEBUG - 2013-12-01 01:18:12 --> No URI present. Default controller set.
DEBUG - 2013-12-01 01:18:12 --> Output Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Security Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Input Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 01:18:12 --> Language Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Loader Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Database Driver Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Session Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Helper loaded: string_helper
DEBUG - 2013-12-01 01:18:12 --> A session cookie was not found.
DEBUG - 2013-12-01 01:18:12 --> Session routines successfully run
DEBUG - 2013-12-01 01:18:12 --> Controller Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Helper loaded: form_helper
DEBUG - 2013-12-01 01:18:12 --> Helper loaded: url_helper
DEBUG - 2013-12-01 01:18:12 --> Form Validation Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 01:18:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 01:18:12 --> Model Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Model Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Image Lib Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 01:18:12 --> Upload Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 01:18:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 01:18:12 --> Config Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Hooks Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Utf8 Class Initialized
DEBUG - 2013-12-01 01:18:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 01:18:12 --> URI Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Router Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Output Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Security Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Input Class Initialized
DEBUG - 2013-12-01 01:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 01:18:12 --> Language Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Loader Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Database Driver Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Session Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Helper loaded: string_helper
DEBUG - 2013-12-01 01:18:13 --> Session routines successfully run
DEBUG - 2013-12-01 01:18:13 --> Controller Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Helper loaded: form_helper
DEBUG - 2013-12-01 01:18:13 --> Helper loaded: url_helper
DEBUG - 2013-12-01 01:18:13 --> Form Validation Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 01:18:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 01:18:13 --> Model Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Model Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Image Lib Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 01:18:13 --> Upload Class Initialized
DEBUG - 2013-12-01 01:18:13 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 01:18:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 01:18:13 --> Model Class Initialized
DEBUG - 2013-12-01 01:18:13 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 01:18:13 --> Final output sent to browser
DEBUG - 2013-12-01 01:18:13 --> Total execution time: 0.8160
DEBUG - 2013-12-01 01:20:48 --> Config Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Hooks Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Utf8 Class Initialized
DEBUG - 2013-12-01 01:20:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 01:20:48 --> URI Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Router Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Output Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Security Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Input Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 01:20:48 --> Language Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Loader Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Database Driver Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Session Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Helper loaded: string_helper
DEBUG - 2013-12-01 01:20:48 --> Session routines successfully run
DEBUG - 2013-12-01 01:20:48 --> Controller Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Helper loaded: form_helper
DEBUG - 2013-12-01 01:20:48 --> Helper loaded: url_helper
DEBUG - 2013-12-01 01:20:48 --> Form Validation Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 01:20:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 01:20:48 --> Model Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Model Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Image Lib Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 01:20:48 --> Upload Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 01:20:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 01:20:48 --> XSS Filtering completed
DEBUG - 2013-12-01 01:20:48 --> Model Class Initialized
DEBUG - 2013-12-01 01:20:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 01:20:48 --> XSS Filtering completed
DEBUG - 2013-12-01 01:20:48 --> XSS Filtering completed
DEBUG - 2013-12-01 01:20:49 --> Config Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Hooks Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Utf8 Class Initialized
DEBUG - 2013-12-01 01:20:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 01:20:49 --> URI Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Router Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Output Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Security Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Input Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 01:20:49 --> Language Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Loader Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Session Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Helper loaded: string_helper
DEBUG - 2013-12-01 01:20:49 --> Session routines successfully run
DEBUG - 2013-12-01 01:20:49 --> Controller Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Helper loaded: form_helper
DEBUG - 2013-12-01 01:20:49 --> Helper loaded: url_helper
DEBUG - 2013-12-01 01:20:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 01:20:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 01:20:49 --> Model Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Model Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Image Lib Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Model Class Initialized
DEBUG - 2013-12-01 01:20:49 --> Model Class Initialized
ERROR - 2013-12-01 01:20:49 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 01:20:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 01:20:49 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 01:20:49 --> Final output sent to browser
DEBUG - 2013-12-01 01:20:49 --> Total execution time: 0.4710
DEBUG - 2013-12-01 02:21:21 --> Config Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:21:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:21:21 --> URI Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Router Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Output Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Security Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Input Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:21:21 --> Language Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Loader Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Session Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:21:21 --> Session routines successfully run
DEBUG - 2013-12-01 02:21:21 --> Controller Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:21:21 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:21:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:21:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:21:21 --> Model Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Model Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Model Class Initialized
DEBUG - 2013-12-01 02:21:21 --> Model Class Initialized
ERROR - 2013-12-01 02:21:21 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:21:21 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 02:21:21 --> Severity: Notice  --> Undefined variable: BASE_URL C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 48
DEBUG - 2013-12-01 02:21:21 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 02:21:21 --> Final output sent to browser
DEBUG - 2013-12-01 02:21:21 --> Total execution time: 0.3420
DEBUG - 2013-12-01 02:22:04 --> Config Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Config Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:22:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:22:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:22:04 --> URI Class Initialized
DEBUG - 2013-12-01 02:22:04 --> URI Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Router Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Router Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Output Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Output Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Security Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Security Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Input Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:22:04 --> Input Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Language Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:22:04 --> Loader Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Language Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Loader Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Session Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:22:04 --> Session Class Initialized
DEBUG - 2013-12-01 02:22:04 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:22:05 --> Session routines successfully run
DEBUG - 2013-12-01 02:22:05 --> Controller Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:22:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:22:05 --> Session routines successfully run
DEBUG - 2013-12-01 02:22:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:22:05 --> Controller Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:22:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:22:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:22:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:22:05 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:22:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Model Class Initialized
ERROR - 2013-12-01 02:22:05 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:22:05 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 02:22:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:22:05 --> Model Class Initialized
ERROR - 2013-12-01 02:22:05 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:22:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 02:22:05 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 02:22:05 --> Final output sent to browser
DEBUG - 2013-12-01 02:22:05 --> Total execution time: 0.7810
DEBUG - 2013-12-01 02:22:05 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 02:22:05 --> Final output sent to browser
DEBUG - 2013-12-01 02:22:05 --> Total execution time: 0.8010
DEBUG - 2013-12-01 02:25:18 --> Config Class Initialized
DEBUG - 2013-12-01 02:25:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:25:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:25:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:25:18 --> URI Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Router Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Output Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Security Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Input Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:25:19 --> Language Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Loader Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Session Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:25:19 --> Session routines successfully run
DEBUG - 2013-12-01 02:25:19 --> Controller Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:25:19 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:25:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:25:19 --> Model Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Model Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Model Class Initialized
DEBUG - 2013-12-01 02:25:19 --> Model Class Initialized
ERROR - 2013-12-01 02:25:19 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:25:19 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 02:25:19 --> Severity: Notice  --> Undefined variable: config C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 48
DEBUG - 2013-12-01 02:25:19 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 02:25:19 --> Final output sent to browser
DEBUG - 2013-12-01 02:25:19 --> Total execution time: 0.3960
DEBUG - 2013-12-01 02:25:32 --> Config Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:25:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:25:32 --> URI Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Router Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Output Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Security Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Input Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:25:32 --> Language Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Loader Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Session Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:25:32 --> Session routines successfully run
DEBUG - 2013-12-01 02:25:32 --> Controller Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:25:32 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:25:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:25:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:25:32 --> Model Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Model Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Model Class Initialized
DEBUG - 2013-12-01 02:25:32 --> Model Class Initialized
ERROR - 2013-12-01 02:25:32 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:25:32 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 02:25:32 --> Severity: Notice  --> Undefined variable: base_url C:\Program Files (x86)\Ampps\www\project\application\views\home\postsview.php 48
DEBUG - 2013-12-01 02:25:32 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 02:25:32 --> Final output sent to browser
DEBUG - 2013-12-01 02:25:32 --> Total execution time: 0.3900
DEBUG - 2013-12-01 02:37:26 --> Config Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:37:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:37:26 --> URI Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Router Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Output Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Security Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Input Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:37:26 --> Language Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Loader Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Session Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:37:26 --> Session routines successfully run
DEBUG - 2013-12-01 02:37:26 --> Controller Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:37:26 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:37:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:37:26 --> Model Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Model Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Model Class Initialized
DEBUG - 2013-12-01 02:37:26 --> Model Class Initialized
ERROR - 2013-12-01 02:37:26 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:37:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 02:37:49 --> Config Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:37:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:37:49 --> URI Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Router Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Output Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Security Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Input Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:37:49 --> Language Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Loader Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Session Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:37:49 --> Session routines successfully run
DEBUG - 2013-12-01 02:37:49 --> Controller Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:37:49 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:37:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:37:49 --> Model Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Model Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Model Class Initialized
DEBUG - 2013-12-01 02:37:49 --> Model Class Initialized
ERROR - 2013-12-01 02:37:49 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:37:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 02:37:49 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 02:37:49 --> Final output sent to browser
DEBUG - 2013-12-01 02:37:49 --> Total execution time: 0.4070
DEBUG - 2013-12-01 02:38:05 --> Config Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:38:05 --> URI Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Router Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Output Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Security Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Input Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:38:05 --> Language Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Loader Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Session Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:38:05 --> Session routines successfully run
DEBUG - 2013-12-01 02:38:05 --> Controller Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:38:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:38:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:38:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:38:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Model Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Model Class Initialized
ERROR - 2013-12-01 02:38:05 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:38:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 02:38:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 02:38:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 02:38:05 --> XSS Filtering completed
DEBUG - 2013-12-01 02:38:05 --> Config Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Hooks Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Utf8 Class Initialized
DEBUG - 2013-12-01 02:38:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 02:38:06 --> URI Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Router Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Output Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Security Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Input Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 02:38:06 --> Language Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Loader Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Database Driver Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Session Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Helper loaded: string_helper
DEBUG - 2013-12-01 02:38:06 --> Session routines successfully run
DEBUG - 2013-12-01 02:38:06 --> Controller Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Helper loaded: form_helper
DEBUG - 2013-12-01 02:38:06 --> Helper loaded: url_helper
DEBUG - 2013-12-01 02:38:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 02:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 02:38:06 --> Model Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Model Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Image Lib Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Model Class Initialized
DEBUG - 2013-12-01 02:38:06 --> Model Class Initialized
ERROR - 2013-12-01 02:38:06 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 02:38:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 02:38:06 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 02:38:06 --> Final output sent to browser
DEBUG - 2013-12-01 02:38:06 --> Total execution time: 0.4030
DEBUG - 2013-12-01 03:06:20 --> Config Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:06:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:06:20 --> URI Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Router Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Output Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Security Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Input Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:06:20 --> Language Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Loader Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Session Class Initialized
DEBUG - 2013-12-01 03:06:20 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:06:21 --> Session routines successfully run
DEBUG - 2013-12-01 03:06:21 --> Controller Class Initialized
DEBUG - 2013-12-01 03:06:21 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:06:21 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:06:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:06:21 --> Model Class Initialized
DEBUG - 2013-12-01 03:06:21 --> Model Class Initialized
DEBUG - 2013-12-01 03:06:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:06:21 --> Model Class Initialized
DEBUG - 2013-12-01 03:06:21 --> Model Class Initialized
ERROR - 2013-12-01 03:06:21 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 03:06:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:06:21 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 03:06:21 --> Final output sent to browser
DEBUG - 2013-12-01 03:06:21 --> Total execution time: 0.9691
DEBUG - 2013-12-01 03:06:29 --> Config Class Initialized
DEBUG - 2013-12-01 03:06:29 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:06:29 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:06:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:06:29 --> URI Class Initialized
DEBUG - 2013-12-01 03:06:29 --> Router Class Initialized
DEBUG - 2013-12-01 03:06:29 --> Output Class Initialized
DEBUG - 2013-12-01 03:06:29 --> Security Class Initialized
DEBUG - 2013-12-01 03:06:29 --> Input Class Initialized
DEBUG - 2013-12-01 03:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:06:29 --> Language Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Loader Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Session Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:06:30 --> Session routines successfully run
DEBUG - 2013-12-01 03:06:30 --> Controller Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:06:30 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:06:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:06:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:06:30 --> Model Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Model Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Model Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Model Class Initialized
ERROR - 2013-12-01 03:06:30 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 03:06:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:06:30 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:06:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 03:06:30 --> XSS Filtering completed
ERROR - 2013-12-01 03:06:30 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\application\models\home\hashtags.php 70
DEBUG - 2013-12-01 03:06:30 --> DB Transaction Failure
ERROR - 2013-12-01 03:06:30 --> Query error: Unknown column 'Array' in 'where clause'
DEBUG - 2013-12-01 03:06:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 03:08:30 --> Config Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:08:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:08:30 --> URI Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Router Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Output Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Security Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Input Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:08:30 --> Language Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Loader Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Session Class Initialized
DEBUG - 2013-12-01 03:08:30 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:08:33 --> Session routines successfully run
DEBUG - 2013-12-01 03:08:33 --> Controller Class Initialized
DEBUG - 2013-12-01 03:08:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:08:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:08:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:08:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:08:33 --> Model Class Initialized
DEBUG - 2013-12-01 03:08:33 --> Model Class Initialized
DEBUG - 2013-12-01 03:08:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:08:33 --> Model Class Initialized
DEBUG - 2013-12-01 03:08:33 --> Model Class Initialized
ERROR - 2013-12-01 03:08:33 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 03:08:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:08:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:08:33 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 03:08:33 --> Final output sent to browser
DEBUG - 2013-12-01 03:08:33 --> Total execution time: 3.0082
DEBUG - 2013-12-01 03:08:34 --> Config Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:08:34 --> URI Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Router Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Output Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Security Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Input Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:08:34 --> Language Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Loader Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Session Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:08:34 --> Session routines successfully run
DEBUG - 2013-12-01 03:08:34 --> Controller Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:08:34 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:08:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:08:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:08:34 --> Model Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Model Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Model Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Model Class Initialized
ERROR - 2013-12-01 03:08:34 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 03:08:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:08:34 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:08:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 03:08:34 --> XSS Filtering completed
ERROR - 2013-12-01 03:08:34 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\application\models\home\hashtags.php 70
DEBUG - 2013-12-01 03:18:16 --> Config Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:18:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:18:16 --> URI Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Router Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Output Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Security Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Input Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:18:16 --> Language Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Loader Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Session Class Initialized
DEBUG - 2013-12-01 03:18:16 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:18:17 --> Session routines successfully run
DEBUG - 2013-12-01 03:18:17 --> Controller Class Initialized
DEBUG - 2013-12-01 03:18:17 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:18:17 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:18:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:18:17 --> Model Class Initialized
DEBUG - 2013-12-01 03:18:17 --> Model Class Initialized
DEBUG - 2013-12-01 03:18:17 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:18:17 --> Model Class Initialized
DEBUG - 2013-12-01 03:18:17 --> Model Class Initialized
ERROR - 2013-12-01 03:18:17 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 03:18:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:18:17 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:18:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 03:18:17 --> XSS Filtering completed
ERROR - 2013-12-01 03:18:17 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\application\models\home\hashtags.php 70
DEBUG - 2013-12-01 03:30:04 --> Config Class Initialized
DEBUG - 2013-12-01 03:30:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:30:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:30:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:30:04 --> URI Class Initialized
DEBUG - 2013-12-01 03:30:04 --> Router Class Initialized
DEBUG - 2013-12-01 03:30:04 --> No URI present. Default controller set.
DEBUG - 2013-12-01 03:30:04 --> Output Class Initialized
DEBUG - 2013-12-01 03:30:04 --> Security Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Input Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:30:05 --> Language Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Loader Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Session Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:30:05 --> Session routines successfully run
DEBUG - 2013-12-01 03:30:05 --> Controller Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:30:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:30:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:30:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:30:05 --> Model Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Model Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Upload Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:30:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:30:05 --> Config Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:30:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:30:05 --> URI Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Router Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Output Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Security Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Input Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:30:05 --> Language Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Loader Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Session Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:30:05 --> Session routines successfully run
DEBUG - 2013-12-01 03:30:05 --> Controller Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:30:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:30:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:30:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:30:05 --> Model Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Model Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Upload Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:30:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:30:05 --> Config Class Initialized
DEBUG - 2013-12-01 03:30:05 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:30:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:30:06 --> URI Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Router Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Output Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Security Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Input Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:30:06 --> Language Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Loader Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Session Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:30:06 --> Session routines successfully run
DEBUG - 2013-12-01 03:30:06 --> Controller Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:30:06 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:30:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:30:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:30:06 --> Model Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Model Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Model Class Initialized
DEBUG - 2013-12-01 03:30:06 --> Model Class Initialized
ERROR - 2013-12-01 03:30:06 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 03:30:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:30:06 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 03:30:06 --> Final output sent to browser
DEBUG - 2013-12-01 03:30:06 --> Total execution time: 0.4930
DEBUG - 2013-12-01 03:43:17 --> Config Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:43:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:43:17 --> URI Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Router Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Output Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Security Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Input Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:43:17 --> Language Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Loader Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Session Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:43:17 --> Session routines successfully run
DEBUG - 2013-12-01 03:43:17 --> Controller Class Initialized
DEBUG - 2013-12-01 03:43:17 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:43:18 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:43:18 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:43:18 --> Model Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Model Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Upload Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:43:18 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:43:18 --> Helper loaded: cookie_helper
ERROR - 2013-12-01 03:43:18 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 03:43:18 --> Severity: Notice  --> Undefined index: ip_address C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 03:43:18 --> Severity: Notice  --> Undefined index: user_agent C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 03:43:18 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 03:43:18 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 288
ERROR - 2013-12-01 03:43:18 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 289
DEBUG - 2013-12-01 03:43:18 --> Config Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:43:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:43:18 --> URI Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Router Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Output Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Security Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Input Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:43:18 --> Language Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Loader Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Session Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:43:18 --> Session routines successfully run
DEBUG - 2013-12-01 03:43:18 --> Controller Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:43:18 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:43:18 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:43:18 --> Model Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Model Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 03:43:18 --> Upload Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:43:18 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:43:18 --> Config Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:43:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:43:18 --> URI Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Router Class Initialized
DEBUG - 2013-12-01 03:43:18 --> Output Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Security Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Input Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:43:19 --> Language Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Loader Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Session Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:43:19 --> Session routines successfully run
DEBUG - 2013-12-01 03:43:19 --> Controller Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:43:19 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:43:19 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:43:19 --> Model Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Model Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 03:43:19 --> Upload Class Initialized
DEBUG - 2013-12-01 03:43:19 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:43:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:43:19 --> Model Class Initialized
DEBUG - 2013-12-01 03:43:19 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 03:43:19 --> Final output sent to browser
DEBUG - 2013-12-01 03:43:19 --> Total execution time: 0.5980
DEBUG - 2013-12-01 03:46:34 --> Config Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Utf8 Class Initialized
DEBUG - 2013-12-01 03:46:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 03:46:34 --> URI Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Router Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Output Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Security Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Input Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 03:46:34 --> Language Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Loader Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Database Driver Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Session Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Helper loaded: string_helper
DEBUG - 2013-12-01 03:46:34 --> Session routines successfully run
DEBUG - 2013-12-01 03:46:34 --> Controller Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Helper loaded: form_helper
DEBUG - 2013-12-01 03:46:34 --> Helper loaded: url_helper
DEBUG - 2013-12-01 03:46:34 --> Form Validation Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 03:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:46:34 --> Model Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Model Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Image Lib Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 03:46:34 --> Upload Class Initialized
DEBUG - 2013-12-01 03:46:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 03:46:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 03:46:34 --> File loaded: application/views/auth/forgot_password_form.php
DEBUG - 2013-12-01 03:46:35 --> Final output sent to browser
DEBUG - 2013-12-01 03:46:35 --> Total execution time: 0.5750
DEBUG - 2013-12-01 04:37:39 --> Config Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:37:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:37:39 --> URI Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Router Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Output Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Security Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Input Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:37:39 --> Language Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Loader Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Session Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:37:39 --> Session routines successfully run
DEBUG - 2013-12-01 04:37:39 --> Controller Class Initialized
DEBUG - 2013-12-01 04:37:39 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:37:39 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:37:39 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:37:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:37:40 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 04:37:40 --> Upload Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:37:40 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:37:40 --> XSS Filtering completed
DEBUG - 2013-12-01 04:37:40 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:37:40 --> XSS Filtering completed
DEBUG - 2013-12-01 04:37:40 --> XSS Filtering completed
DEBUG - 2013-12-01 04:37:40 --> Config Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:37:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:37:40 --> URI Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Router Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Output Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Security Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Input Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:37:40 --> Language Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Loader Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Session Class Initialized
DEBUG - 2013-12-01 04:37:40 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:37:41 --> Session routines successfully run
DEBUG - 2013-12-01 04:37:41 --> Controller Class Initialized
DEBUG - 2013-12-01 04:37:41 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:37:41 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:37:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:37:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:37:41 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:41 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:41 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:37:41 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:41 --> Model Class Initialized
ERROR - 2013-12-01 04:37:41 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:37:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:37:41 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 04:37:41 --> Final output sent to browser
DEBUG - 2013-12-01 04:37:41 --> Total execution time: 0.6620
DEBUG - 2013-12-01 04:37:51 --> Config Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:37:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:37:51 --> URI Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Router Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Output Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Security Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Input Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:37:51 --> Language Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Loader Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Session Class Initialized
DEBUG - 2013-12-01 04:37:51 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:37:53 --> Session routines successfully run
DEBUG - 2013-12-01 04:37:53 --> Controller Class Initialized
DEBUG - 2013-12-01 04:37:53 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:37:53 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:37:53 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:37:53 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:53 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:53 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:37:53 --> Model Class Initialized
DEBUG - 2013-12-01 04:37:53 --> Model Class Initialized
ERROR - 2013-12-01 04:37:53 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:37:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:37:53 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:37:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:37:53 --> XSS Filtering completed
ERROR - 2013-12-01 04:37:53 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\application\models\home\hashtags.php 70
DEBUG - 2013-12-01 04:40:22 --> Config Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:40:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:40:22 --> URI Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Router Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Output Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Security Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Input Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:40:22 --> Language Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Loader Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Session Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:40:22 --> Session routines successfully run
DEBUG - 2013-12-01 04:40:22 --> Controller Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:40:22 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:40:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:40:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:40:22 --> Model Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Model Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Model Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Model Class Initialized
ERROR - 2013-12-01 04:40:22 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:40:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:40:22 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:40:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:40:22 --> XSS Filtering completed
ERROR - 2013-12-01 04:40:22 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\application\models\home\hashtags.php 70
DEBUG - 2013-12-01 04:40:51 --> Config Class Initialized
DEBUG - 2013-12-01 04:40:51 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:40:51 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:40:52 --> URI Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Router Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Output Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Security Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Input Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:40:52 --> Language Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Loader Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Session Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:40:52 --> Session routines successfully run
DEBUG - 2013-12-01 04:40:52 --> Controller Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:40:52 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:40:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:40:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:40:52 --> Model Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Model Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Model Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Model Class Initialized
ERROR - 2013-12-01 04:40:52 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:40:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:40:52 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:40:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:40:52 --> XSS Filtering completed
DEBUG - 2013-12-01 04:41:56 --> Config Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:41:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:41:56 --> URI Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Router Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Output Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Security Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Input Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:41:56 --> Language Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Loader Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Session Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:41:56 --> Session routines successfully run
DEBUG - 2013-12-01 04:41:56 --> Controller Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:41:56 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:41:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:41:56 --> Model Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Model Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Model Class Initialized
DEBUG - 2013-12-01 04:41:56 --> Model Class Initialized
ERROR - 2013-12-01 04:41:57 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:41:57 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:41:57 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:41:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:41:57 --> XSS Filtering completed
DEBUG - 2013-12-01 04:42:14 --> Config Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:42:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:42:14 --> URI Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Router Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Output Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Security Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Input Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:42:14 --> Language Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Loader Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Session Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:42:14 --> Session routines successfully run
DEBUG - 2013-12-01 04:42:14 --> Controller Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:42:14 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:42:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:42:14 --> Model Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Model Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Model Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Model Class Initialized
ERROR - 2013-12-01 04:42:14 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:42:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:42:14 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:42:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:42:14 --> XSS Filtering completed
DEBUG - 2013-12-01 04:43:04 --> Config Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:43:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:43:04 --> URI Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Router Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Output Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Security Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Input Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:43:04 --> Language Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Loader Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Session Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:43:04 --> Session routines successfully run
DEBUG - 2013-12-01 04:43:04 --> Controller Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:43:04 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:43:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:43:04 --> Model Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Model Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Model Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Model Class Initialized
ERROR - 2013-12-01 04:43:04 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:43:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:43:04 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:43:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:43:04 --> XSS Filtering completed
DEBUG - 2013-12-01 04:45:21 --> Config Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:45:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:45:21 --> URI Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Router Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Output Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Security Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Input Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:45:21 --> Language Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Loader Class Initialized
DEBUG - 2013-12-01 04:45:21 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:45:22 --> Session Class Initialized
DEBUG - 2013-12-01 04:45:22 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:45:22 --> Session routines successfully run
DEBUG - 2013-12-01 04:45:22 --> Controller Class Initialized
DEBUG - 2013-12-01 04:45:22 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:45:22 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:45:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:45:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:45:22 --> Model Class Initialized
DEBUG - 2013-12-01 04:45:22 --> Model Class Initialized
DEBUG - 2013-12-01 04:45:22 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:45:22 --> Model Class Initialized
DEBUG - 2013-12-01 04:45:22 --> Model Class Initialized
ERROR - 2013-12-01 04:45:22 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:45:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:45:22 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:45:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:45:22 --> XSS Filtering completed
DEBUG - 2013-12-01 04:45:37 --> Config Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:45:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:45:37 --> URI Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Router Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Output Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Security Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Input Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:45:37 --> Language Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Loader Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Session Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:45:37 --> Session routines successfully run
DEBUG - 2013-12-01 04:45:37 --> Controller Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:45:37 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:45:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:45:37 --> Model Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Model Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Model Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Model Class Initialized
ERROR - 2013-12-01 04:45:37 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:45:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:45:37 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:45:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:45:37 --> XSS Filtering completed
DEBUG - 2013-12-01 04:46:26 --> Config Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 04:46:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 04:46:26 --> URI Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Router Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Output Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Security Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Input Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 04:46:26 --> Language Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Loader Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Database Driver Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Session Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Helper loaded: string_helper
DEBUG - 2013-12-01 04:46:26 --> Session routines successfully run
DEBUG - 2013-12-01 04:46:26 --> Controller Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Helper loaded: form_helper
DEBUG - 2013-12-01 04:46:26 --> Helper loaded: url_helper
DEBUG - 2013-12-01 04:46:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 04:46:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 04:46:26 --> Model Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Model Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Image Lib Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Model Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Model Class Initialized
ERROR - 2013-12-01 04:46:26 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 04:46:26 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 04:46:26 --> Form Validation Class Initialized
DEBUG - 2013-12-01 04:46:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 04:46:26 --> XSS Filtering completed
DEBUG - 2013-12-01 05:10:33 --> Config Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:10:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:10:33 --> URI Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Router Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Output Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Security Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Input Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:10:33 --> Language Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Loader Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Session Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:10:33 --> Session routines successfully run
DEBUG - 2013-12-01 05:10:33 --> Controller Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:10:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:10:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:10:33 --> Model Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Model Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Model Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Model Class Initialized
ERROR - 2013-12-01 05:10:33 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 05:10:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:10:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:10:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:10:33 --> XSS Filtering completed
DEBUG - 2013-12-01 05:14:26 --> Config Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:14:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:14:26 --> URI Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Router Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Output Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Security Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Input Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:14:26 --> Language Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Loader Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Session Class Initialized
DEBUG - 2013-12-01 05:14:26 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:14:26 --> Session garbage collection performed.
DEBUG - 2013-12-01 05:14:26 --> Session routines successfully run
DEBUG - 2013-12-01 05:14:27 --> Controller Class Initialized
DEBUG - 2013-12-01 05:14:27 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:14:27 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:14:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:14:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:14:27 --> Model Class Initialized
DEBUG - 2013-12-01 05:14:27 --> Model Class Initialized
DEBUG - 2013-12-01 05:14:27 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:14:27 --> Model Class Initialized
DEBUG - 2013-12-01 05:14:27 --> Model Class Initialized
ERROR - 2013-12-01 05:14:27 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 05:14:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:14:27 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:14:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:14:27 --> XSS Filtering completed
DEBUG - 2013-12-01 05:14:27 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:14:27 --> Final output sent to browser
DEBUG - 2013-12-01 05:14:27 --> Total execution time: 0.8040
DEBUG - 2013-12-01 05:16:17 --> Config Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:16:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:16:17 --> URI Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Router Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Output Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Security Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Input Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:16:17 --> Language Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Loader Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Session Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:16:17 --> Session routines successfully run
DEBUG - 2013-12-01 05:16:17 --> Controller Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:16:17 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:16:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:16:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:16:17 --> Model Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Model Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Model Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Model Class Initialized
ERROR - 2013-12-01 05:16:17 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 05:16:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:16:17 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:16:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:16:17 --> XSS Filtering completed
DEBUG - 2013-12-01 05:16:17 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:16:17 --> Final output sent to browser
DEBUG - 2013-12-01 05:16:18 --> Total execution time: 0.7730
DEBUG - 2013-12-01 05:17:34 --> Config Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:17:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:17:34 --> URI Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Router Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Output Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Security Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Input Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:17:34 --> Language Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Loader Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Session Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:17:34 --> Session routines successfully run
DEBUG - 2013-12-01 05:17:34 --> Controller Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:17:34 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:17:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:17:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:17:34 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Model Class Initialized
ERROR - 2013-12-01 05:17:34 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 05:17:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:17:34 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:17:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:17:34 --> XSS Filtering completed
DEBUG - 2013-12-01 05:17:34 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:17:34 --> Final output sent to browser
DEBUG - 2013-12-01 05:17:34 --> Total execution time: 0.8921
DEBUG - 2013-12-01 05:17:36 --> Config Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:17:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:17:36 --> URI Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Router Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Output Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Security Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Input Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:17:36 --> Language Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Loader Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Session Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:17:36 --> Session routines successfully run
DEBUG - 2013-12-01 05:17:36 --> Controller Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:17:36 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:17:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:17:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:37 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:17:37 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:37 --> Model Class Initialized
ERROR - 2013-12-01 05:17:37 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 05:17:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:17:37 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:17:37 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:17:37 --> Final output sent to browser
DEBUG - 2013-12-01 05:17:37 --> Total execution time: 0.8120
DEBUG - 2013-12-01 05:17:46 --> Config Class Initialized
DEBUG - 2013-12-01 05:17:46 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:17:46 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:17:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:17:46 --> URI Class Initialized
DEBUG - 2013-12-01 05:17:46 --> Router Class Initialized
DEBUG - 2013-12-01 05:17:46 --> Output Class Initialized
DEBUG - 2013-12-01 05:17:46 --> Security Class Initialized
DEBUG - 2013-12-01 05:17:46 --> Input Class Initialized
DEBUG - 2013-12-01 05:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:17:46 --> Language Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Loader Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Session Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:17:47 --> Session routines successfully run
DEBUG - 2013-12-01 05:17:47 --> Controller Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:17:47 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:17:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:17:47 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Model Class Initialized
DEBUG - 2013-12-01 05:17:47 --> Model Class Initialized
ERROR - 2013-12-01 05:17:47 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 05:17:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:17:47 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:17:47 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:17:47 --> Final output sent to browser
DEBUG - 2013-12-01 05:17:47 --> Total execution time: 0.9701
DEBUG - 2013-12-01 05:18:10 --> Config Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:18:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:18:10 --> URI Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Router Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Output Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Security Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Input Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:18:10 --> Language Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Loader Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Session Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:18:10 --> Session routines successfully run
DEBUG - 2013-12-01 05:18:10 --> Controller Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:18:10 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:18:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:18:10 --> Model Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Model Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Model Class Initialized
DEBUG - 2013-12-01 05:18:10 --> Model Class Initialized
ERROR - 2013-12-01 05:18:11 --> Severity: Notice  --> Undefined property: Home::$profile_table_name C:\Program Files (x86)\Ampps\www\project\system\core\Model.php 51
DEBUG - 2013-12-01 05:18:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:18:11 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:18:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:18:11 --> Final output sent to browser
DEBUG - 2013-12-01 05:18:11 --> Total execution time: 0.9371
DEBUG - 2013-12-01 05:19:11 --> Config Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:19:11 --> URI Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Router Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Output Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Security Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Input Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:19:11 --> Language Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Loader Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Session Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:19:11 --> Session routines successfully run
DEBUG - 2013-12-01 05:19:11 --> Controller Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:19:11 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:19:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:19:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:19:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:19:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:19:11 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:19:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:19:11 --> Final output sent to browser
DEBUG - 2013-12-01 05:19:11 --> Total execution time: 0.8080
DEBUG - 2013-12-01 05:19:20 --> Config Class Initialized
DEBUG - 2013-12-01 05:19:20 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:19:20 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:19:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:19:20 --> URI Class Initialized
DEBUG - 2013-12-01 05:19:20 --> Router Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Output Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Security Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Input Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:19:21 --> Language Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Loader Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Session Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:19:21 --> Session routines successfully run
DEBUG - 2013-12-01 05:19:21 --> Controller Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:19:21 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:19:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:19:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:19:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:19:21 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:19:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:19:21 --> XSS Filtering completed
DEBUG - 2013-12-01 05:19:21 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:19:21 --> Final output sent to browser
DEBUG - 2013-12-01 05:19:21 --> Total execution time: 0.8060
DEBUG - 2013-12-01 05:20:37 --> Config Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:20:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:20:37 --> URI Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Router Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Output Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Security Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Input Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:20:37 --> Language Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Loader Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Session Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:20:37 --> Session routines successfully run
DEBUG - 2013-12-01 05:20:37 --> Controller Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:20:37 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:20:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:20:37 --> Model Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Model Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Model Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Model Class Initialized
DEBUG - 2013-12-01 05:20:37 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:20:38 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:20:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:20:38 --> XSS Filtering completed
DEBUG - 2013-12-01 05:20:38 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:20:38 --> Final output sent to browser
DEBUG - 2013-12-01 05:20:38 --> Total execution time: 0.8370
DEBUG - 2013-12-01 05:21:31 --> Config Class Initialized
DEBUG - 2013-12-01 05:21:31 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:21:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:21:32 --> URI Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Router Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Output Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Security Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Input Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:21:32 --> Language Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Loader Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Session Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:21:32 --> Session routines successfully run
DEBUG - 2013-12-01 05:21:32 --> Controller Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:21:32 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:21:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:21:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:21:32 --> Model Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Model Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Model Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Model Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:21:32 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:21:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:21:32 --> XSS Filtering completed
DEBUG - 2013-12-01 05:21:32 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:21:32 --> Final output sent to browser
DEBUG - 2013-12-01 05:21:32 --> Total execution time: 0.7770
DEBUG - 2013-12-01 05:21:57 --> Config Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:21:57 --> URI Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Router Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Output Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Security Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Input Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:21:57 --> Language Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Loader Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Session Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:21:57 --> Session routines successfully run
DEBUG - 2013-12-01 05:21:57 --> Controller Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:21:57 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:21:57 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:21:57 --> Model Class Initialized
DEBUG - 2013-12-01 05:21:57 --> Model Class Initialized
DEBUG - 2013-12-01 05:21:58 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:21:58 --> Model Class Initialized
DEBUG - 2013-12-01 05:21:58 --> Model Class Initialized
DEBUG - 2013-12-01 05:21:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:21:58 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:21:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:21:58 --> XSS Filtering completed
ERROR - 2013-12-01 05:21:58 --> Severity: Notice  --> Undefined variable: hashtags_removed C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 111
ERROR - 2013-12-01 05:21:58 --> Severity: Warning  --> implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed C:\Program Files (x86)\Ampps\www\project\application\models\home\hashtags.php 69
DEBUG - 2013-12-01 05:22:20 --> Config Class Initialized
DEBUG - 2013-12-01 05:22:20 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:22:20 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:22:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:22:20 --> URI Class Initialized
DEBUG - 2013-12-01 05:22:20 --> Router Class Initialized
DEBUG - 2013-12-01 05:22:20 --> Output Class Initialized
DEBUG - 2013-12-01 05:22:20 --> Security Class Initialized
DEBUG - 2013-12-01 05:22:20 --> Input Class Initialized
DEBUG - 2013-12-01 05:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:22:20 --> Language Class Initialized
DEBUG - 2013-12-01 05:22:20 --> Loader Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Session Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:22:21 --> Session routines successfully run
DEBUG - 2013-12-01 05:22:21 --> Controller Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:22:21 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:22:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:22:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:22:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:22:21 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:22:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:22:21 --> XSS Filtering completed
DEBUG - 2013-12-01 05:23:04 --> Config Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:23:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:23:04 --> URI Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Router Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Output Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Security Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Input Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:23:04 --> Language Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Loader Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Session Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:23:04 --> Session routines successfully run
DEBUG - 2013-12-01 05:23:04 --> Controller Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:23:04 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:23:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:23:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:23:04 --> Model Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Model Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Model Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Model Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:23:04 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:23:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:23:04 --> XSS Filtering completed
DEBUG - 2013-12-01 05:23:04 --> DB Transaction Failure
ERROR - 2013-12-01 05:23:04 --> Query error: Unknown column 'we' in 'where clause'
DEBUG - 2013-12-01 05:23:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:23:20 --> Config Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:23:20 --> URI Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Router Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Output Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Security Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Input Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:23:20 --> Language Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Loader Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Session Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:23:20 --> Session routines successfully run
DEBUG - 2013-12-01 05:23:20 --> Controller Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:23:20 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:23:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:23:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:23:20 --> Model Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Model Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:23:20 --> Model Class Initialized
DEBUG - 2013-12-01 05:23:21 --> Model Class Initialized
DEBUG - 2013-12-01 05:23:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:23:21 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:23:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:23:21 --> XSS Filtering completed
DEBUG - 2013-12-01 05:23:21 --> DB Transaction Failure
ERROR - 2013-12-01 05:23:21 --> Query error: Unknown column 'we' in 'where clause'
DEBUG - 2013-12-01 05:23:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:25:40 --> Config Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:25:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:25:40 --> URI Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Router Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Output Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Security Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Input Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:25:40 --> Language Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Loader Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:25:40 --> Session Class Initialized
DEBUG - 2013-12-01 05:25:41 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:25:41 --> Session routines successfully run
DEBUG - 2013-12-01 05:25:41 --> Controller Class Initialized
DEBUG - 2013-12-01 05:25:41 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:25:41 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:25:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:25:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:25:41 --> Model Class Initialized
DEBUG - 2013-12-01 05:25:41 --> Model Class Initialized
DEBUG - 2013-12-01 05:25:41 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:25:41 --> Model Class Initialized
DEBUG - 2013-12-01 05:25:41 --> Model Class Initialized
DEBUG - 2013-12-01 05:25:41 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:25:41 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:25:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:25:41 --> XSS Filtering completed
DEBUG - 2013-12-01 05:25:41 --> DB Transaction Failure
ERROR - 2013-12-01 05:25:41 --> Query error: Unknown column 'we' in 'where clause'
DEBUG - 2013-12-01 05:25:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:25:48 --> Config Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:25:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:25:49 --> URI Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Router Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Output Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Security Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Input Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:25:49 --> Language Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Loader Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Session Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:25:49 --> Session routines successfully run
DEBUG - 2013-12-01 05:25:49 --> Controller Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:25:49 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:25:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:25:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:25:49 --> Model Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Model Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Model Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Model Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:25:49 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:25:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:25:49 --> XSS Filtering completed
DEBUG - 2013-12-01 05:25:49 --> DB Transaction Failure
ERROR - 2013-12-01 05:25:49 --> Query error: Unknown column 'we' in 'where clause'
DEBUG - 2013-12-01 05:25:49 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:27:58 --> Config Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:27:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:27:58 --> URI Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Router Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Output Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Security Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Input Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:27:58 --> Language Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Loader Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Session Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:27:58 --> Session routines successfully run
DEBUG - 2013-12-01 05:27:58 --> Controller Class Initialized
DEBUG - 2013-12-01 05:27:58 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:27:59 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:27:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:27:59 --> Model Class Initialized
DEBUG - 2013-12-01 05:27:59 --> Model Class Initialized
DEBUG - 2013-12-01 05:27:59 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:27:59 --> Model Class Initialized
DEBUG - 2013-12-01 05:27:59 --> Model Class Initialized
DEBUG - 2013-12-01 05:27:59 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:27:59 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:27:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:27:59 --> XSS Filtering completed
DEBUG - 2013-12-01 05:27:59 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:27:59 --> Final output sent to browser
DEBUG - 2013-12-01 05:27:59 --> Total execution time: 1.1971
DEBUG - 2013-12-01 05:28:16 --> Config Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:28:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:28:16 --> URI Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Router Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Output Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Security Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Input Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:28:16 --> Language Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Loader Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Session Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:28:16 --> Session routines successfully run
DEBUG - 2013-12-01 05:28:16 --> Controller Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:28:16 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:28:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:28:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:28:16 --> Model Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Model Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Model Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Model Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:28:16 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:28:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:28:16 --> XSS Filtering completed
DEBUG - 2013-12-01 05:28:16 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:28:17 --> Final output sent to browser
DEBUG - 2013-12-01 05:28:17 --> Total execution time: 0.9091
DEBUG - 2013-12-01 05:30:10 --> Config Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:30:10 --> URI Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Router Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Output Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Security Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Input Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:30:10 --> Language Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Loader Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Session Class Initialized
DEBUG - 2013-12-01 05:30:10 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:30:10 --> Session routines successfully run
DEBUG - 2013-12-01 05:30:11 --> Controller Class Initialized
DEBUG - 2013-12-01 05:30:11 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:30:11 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:30:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:30:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:30:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:30:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:30:11 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:30:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:30:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:30:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:30:11 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:30:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:30:11 --> XSS Filtering completed
DEBUG - 2013-12-01 05:30:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 05:30:11 --> Final output sent to browser
DEBUG - 2013-12-01 05:30:11 --> Total execution time: 1.1111
DEBUG - 2013-12-01 05:31:02 --> Config Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:31:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:31:02 --> URI Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Router Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Output Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Security Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Input Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:31:02 --> Language Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Loader Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Session Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:31:02 --> Session routines successfully run
DEBUG - 2013-12-01 05:31:02 --> Controller Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:31:02 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:31:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:31:02 --> Model Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Model Class Initialized
DEBUG - 2013-12-01 05:31:02 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:31:03 --> Model Class Initialized
DEBUG - 2013-12-01 05:31:03 --> Model Class Initialized
DEBUG - 2013-12-01 05:31:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:31:03 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:31:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:31:03 --> XSS Filtering completed
ERROR - 2013-12-01 05:31:03 --> Severity: Notice  --> Use of undefined constant str - assumed 'str' C:\Program Files (x86)\Ampps\www\project\application\models\home\hashtags.php 71
ERROR - 2013-12-01 05:31:03 --> Invalid query: 
DEBUG - 2013-12-01 05:31:03 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:31:12 --> Config Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:31:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:31:12 --> URI Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Router Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Output Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Security Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Input Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:31:12 --> Language Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Loader Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Session Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:31:12 --> Session routines successfully run
DEBUG - 2013-12-01 05:31:12 --> Controller Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:31:12 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:31:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:31:12 --> Model Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Model Class Initialized
DEBUG - 2013-12-01 05:31:12 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:31:13 --> Model Class Initialized
DEBUG - 2013-12-01 05:31:13 --> Model Class Initialized
DEBUG - 2013-12-01 05:31:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:31:13 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:31:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:31:13 --> XSS Filtering completed
DEBUG - 2013-12-01 05:31:13 --> DB Transaction Failure
ERROR - 2013-12-01 05:31:13 --> Query error: Duplicate entry 'we' for key 'hashtag'
DEBUG - 2013-12-01 05:31:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:32:34 --> Config Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:32:34 --> URI Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Router Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Output Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Security Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Input Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:32:34 --> Language Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Loader Class Initialized
DEBUG - 2013-12-01 05:32:34 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Session Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:32:35 --> Session garbage collection performed.
DEBUG - 2013-12-01 05:32:35 --> Session routines successfully run
DEBUG - 2013-12-01 05:32:35 --> Controller Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:32:35 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:32:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:32:35 --> Model Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Model Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Model Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Model Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:32:35 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:32:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:32:35 --> XSS Filtering completed
DEBUG - 2013-12-01 05:32:35 --> DB Transaction Failure
ERROR - 2013-12-01 05:32:35 --> Query error: Duplicate entry 'we' for key 'hashtag'
DEBUG - 2013-12-01 05:32:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:35:19 --> Config Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:35:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:35:19 --> URI Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Router Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Output Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Security Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Input Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:35:19 --> Language Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Loader Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Session Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:35:19 --> Session routines successfully run
DEBUG - 2013-12-01 05:35:19 --> Controller Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:35:19 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:35:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:35:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:35:19 --> Model Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Model Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Model Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Model Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:35:19 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:35:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:35:19 --> XSS Filtering completed
DEBUG - 2013-12-01 05:35:20 --> DB Transaction Failure
ERROR - 2013-12-01 05:35:20 --> Query error: Duplicate entry 'we' for key 'hashtag'
DEBUG - 2013-12-01 05:35:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:35:36 --> Config Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:35:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:35:36 --> URI Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Router Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Output Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Security Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Input Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:35:36 --> Language Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Loader Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Session Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:35:36 --> Session routines successfully run
DEBUG - 2013-12-01 05:35:36 --> Controller Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:35:36 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:35:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:35:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:35:36 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:35:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:35:36 --> XSS Filtering completed
DEBUG - 2013-12-01 05:36:11 --> Config Class Initialized
DEBUG - 2013-12-01 05:36:11 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:36:11 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:36:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:36:12 --> URI Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Router Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Output Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Security Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Input Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:36:12 --> Language Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Loader Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Session Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:36:12 --> Session routines successfully run
DEBUG - 2013-12-01 05:36:12 --> Controller Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:36:12 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:36:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:36:12 --> Model Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Model Class Initialized
DEBUG - 2013-12-01 05:36:12 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:36:14 --> Model Class Initialized
DEBUG - 2013-12-01 05:36:14 --> Model Class Initialized
DEBUG - 2013-12-01 05:36:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:36:14 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:36:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:36:14 --> XSS Filtering completed
DEBUG - 2013-12-01 05:39:33 --> Config Class Initialized
DEBUG - 2013-12-01 05:39:33 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:39:33 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:39:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:39:33 --> URI Class Initialized
DEBUG - 2013-12-01 05:39:33 --> Router Class Initialized
DEBUG - 2013-12-01 05:39:33 --> Output Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Security Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Input Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:39:34 --> Language Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Loader Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Session Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:39:34 --> Session routines successfully run
DEBUG - 2013-12-01 05:39:34 --> Controller Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:39:34 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:39:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:39:34 --> Model Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Model Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Model Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Model Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:39:34 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:39:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:39:34 --> XSS Filtering completed
DEBUG - 2013-12-01 05:39:34 --> DB Transaction Failure
ERROR - 2013-12-01 05:39:34 --> Query error: Duplicate entry 'we' for key 'hashtag'
DEBUG - 2013-12-01 05:39:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:39:58 --> Config Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:39:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:39:58 --> URI Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Router Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Output Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Security Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Input Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:39:58 --> Language Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Loader Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Session Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:39:58 --> Session routines successfully run
DEBUG - 2013-12-01 05:39:58 --> Controller Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:39:58 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:39:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:39:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:39:58 --> Model Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Model Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Model Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Model Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:39:58 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:39:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:39:59 --> XSS Filtering completed
DEBUG - 2013-12-01 05:39:59 --> DB Transaction Failure
ERROR - 2013-12-01 05:39:59 --> Query error: Duplicate entry 'we' for key 'hashtag'
DEBUG - 2013-12-01 05:39:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:40:30 --> Config Class Initialized
DEBUG - 2013-12-01 05:40:30 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:40:30 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:40:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:40:30 --> URI Class Initialized
DEBUG - 2013-12-01 05:40:30 --> Router Class Initialized
DEBUG - 2013-12-01 05:40:30 --> Output Class Initialized
DEBUG - 2013-12-01 05:40:30 --> Security Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Input Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:40:31 --> Language Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Loader Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Session Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:40:31 --> Session routines successfully run
DEBUG - 2013-12-01 05:40:31 --> Controller Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:40:31 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:40:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:40:31 --> Model Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Model Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Model Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Model Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:40:31 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:40:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:40:31 --> XSS Filtering completed
DEBUG - 2013-12-01 05:40:51 --> Config Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:40:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:40:51 --> URI Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Router Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Output Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Security Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Input Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:40:51 --> Language Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Loader Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Session Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:40:51 --> Session routines successfully run
DEBUG - 2013-12-01 05:40:51 --> Controller Class Initialized
DEBUG - 2013-12-01 05:40:51 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:40:52 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:40:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:40:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:40:52 --> Model Class Initialized
DEBUG - 2013-12-01 05:40:52 --> Model Class Initialized
DEBUG - 2013-12-01 05:40:52 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:40:52 --> Model Class Initialized
DEBUG - 2013-12-01 05:40:52 --> Model Class Initialized
DEBUG - 2013-12-01 05:40:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:40:52 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:40:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:40:52 --> XSS Filtering completed
DEBUG - 2013-12-01 05:41:53 --> Config Class Initialized
DEBUG - 2013-12-01 05:41:53 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:41:53 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:41:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:41:54 --> URI Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Router Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Output Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Security Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Input Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:41:54 --> Language Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Loader Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Session Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:41:54 --> Session routines successfully run
DEBUG - 2013-12-01 05:41:54 --> Controller Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:41:54 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:41:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:41:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:41:54 --> Model Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Model Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Model Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Model Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:41:54 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:41:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:41:54 --> XSS Filtering completed
DEBUG - 2013-12-01 05:42:04 --> Config Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:42:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:42:04 --> URI Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Router Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Output Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Security Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Input Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:42:04 --> Language Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Loader Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Session Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:42:04 --> Session routines successfully run
DEBUG - 2013-12-01 05:42:04 --> Controller Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:42:04 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:42:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:42:04 --> Model Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Model Class Initialized
DEBUG - 2013-12-01 05:42:04 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:42:05 --> Model Class Initialized
DEBUG - 2013-12-01 05:42:05 --> Model Class Initialized
DEBUG - 2013-12-01 05:42:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:42:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:42:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:42:05 --> XSS Filtering completed
DEBUG - 2013-12-01 05:43:12 --> Config Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:43:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:43:12 --> URI Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Router Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Output Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Security Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Input Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:43:12 --> Language Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Loader Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Session Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:43:12 --> Session routines successfully run
DEBUG - 2013-12-01 05:43:12 --> Controller Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:43:12 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:43:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:43:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:43:12 --> Model Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Model Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Model Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Model Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:43:12 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:43:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:43:13 --> XSS Filtering completed
DEBUG - 2013-12-01 05:45:22 --> Config Class Initialized
DEBUG - 2013-12-01 05:45:22 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:45:22 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:45:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:45:22 --> URI Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Router Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Output Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Security Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Input Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:45:23 --> Language Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Loader Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Session Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:45:23 --> Session routines successfully run
DEBUG - 2013-12-01 05:45:23 --> Controller Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:45:23 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:45:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:45:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:45:23 --> Model Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Model Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Model Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Model Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:45:23 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:45:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:45:23 --> XSS Filtering completed
DEBUG - 2013-12-01 05:51:24 --> Config Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:51:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:51:24 --> URI Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Router Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Output Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Security Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Input Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:51:24 --> Language Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Loader Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Session Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:51:24 --> Session routines successfully run
DEBUG - 2013-12-01 05:51:24 --> Controller Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:51:24 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:51:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:51:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:51:24 --> Model Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Model Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Model Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Model Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:51:24 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:51:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:51:25 --> XSS Filtering completed
DEBUG - 2013-12-01 05:51:25 --> DB Transaction Failure
ERROR - 2013-12-01 05:51:25 --> Query error: Duplicate entry 'we' for key 'hashtag'
DEBUG - 2013-12-01 05:51:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 05:53:35 --> Config Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:53:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:53:35 --> URI Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Router Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Output Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Security Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Input Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:53:35 --> Language Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Loader Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Session Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:53:35 --> Session routines successfully run
DEBUG - 2013-12-01 05:53:35 --> Controller Class Initialized
DEBUG - 2013-12-01 05:53:35 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:53:35 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:53:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:53:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:53:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:53:36 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:53:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:53:36 --> Model Class Initialized
DEBUG - 2013-12-01 05:53:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:53:36 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:53:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:53:36 --> XSS Filtering completed
DEBUG - 2013-12-01 05:54:10 --> Config Class Initialized
DEBUG - 2013-12-01 05:54:10 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:54:10 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:54:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:54:11 --> URI Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Router Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Output Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Security Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Input Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:54:11 --> Language Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Loader Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Session Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:54:11 --> Session garbage collection performed.
DEBUG - 2013-12-01 05:54:11 --> Session routines successfully run
DEBUG - 2013-12-01 05:54:11 --> Controller Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:54:11 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:54:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:54:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:54:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Model Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:54:11 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:54:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:54:11 --> XSS Filtering completed
DEBUG - 2013-12-01 05:57:06 --> Config Class Initialized
DEBUG - 2013-12-01 05:57:06 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:57:06 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:57:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:57:07 --> URI Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Router Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Output Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Security Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Input Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:57:07 --> Language Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Loader Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Session Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:57:07 --> Session routines successfully run
DEBUG - 2013-12-01 05:57:07 --> Controller Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:57:07 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:57:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:57:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:57:07 --> Model Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Model Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Model Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Model Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:57:07 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:57:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:57:07 --> XSS Filtering completed
DEBUG - 2013-12-01 05:59:05 --> Config Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Hooks Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Utf8 Class Initialized
DEBUG - 2013-12-01 05:59:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 05:59:05 --> URI Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Router Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Output Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Security Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Input Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 05:59:05 --> Language Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Loader Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Session Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 05:59:05 --> Session routines successfully run
DEBUG - 2013-12-01 05:59:05 --> Controller Class Initialized
DEBUG - 2013-12-01 05:59:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 05:59:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 05:59:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 05:59:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 05:59:06 --> Model Class Initialized
DEBUG - 2013-12-01 05:59:06 --> Model Class Initialized
DEBUG - 2013-12-01 05:59:06 --> Image Lib Class Initialized
DEBUG - 2013-12-01 05:59:06 --> Model Class Initialized
DEBUG - 2013-12-01 05:59:06 --> Model Class Initialized
DEBUG - 2013-12-01 05:59:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 05:59:06 --> Form Validation Class Initialized
DEBUG - 2013-12-01 05:59:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 05:59:06 --> XSS Filtering completed
ERROR - 2013-12-01 05:59:06 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
ERROR - 2013-12-01 05:59:06 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
DEBUG - 2013-12-01 05:59:06 --> DB Transaction Failure
ERROR - 2013-12-01 05:59:06 --> Query error: Unknown column 'Array' in 'field list'
DEBUG - 2013-12-01 05:59:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:01:14 --> Config Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:01:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:01:14 --> URI Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Router Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Output Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Security Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Input Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:01:14 --> Language Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Loader Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Session Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:01:14 --> Session routines successfully run
DEBUG - 2013-12-01 06:01:14 --> Controller Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:01:14 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:01:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:01:14 --> Model Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Model Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Model Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Model Class Initialized
DEBUG - 2013-12-01 06:01:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:01:15 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:01:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:01:15 --> XSS Filtering completed
ERROR - 2013-12-01 06:01:15 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 138
ERROR - 2013-12-01 06:01:15 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
ERROR - 2013-12-01 06:01:15 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
DEBUG - 2013-12-01 06:01:15 --> DB Transaction Failure
ERROR - 2013-12-01 06:01:15 --> Query error: Unknown column 'Array' in 'field list'
DEBUG - 2013-12-01 06:01:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:01:46 --> Config Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:01:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:01:46 --> URI Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Router Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Output Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Security Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Input Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:01:46 --> Language Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Loader Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Session Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:01:46 --> Session routines successfully run
DEBUG - 2013-12-01 06:01:46 --> Controller Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:01:46 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:01:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:01:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:01:46 --> Model Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Model Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Model Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Model Class Initialized
DEBUG - 2013-12-01 06:01:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:01:47 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:01:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:01:47 --> XSS Filtering completed
ERROR - 2013-12-01 06:01:47 --> Severity: Notice  --> Undefined index: post_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 140
ERROR - 2013-12-01 06:01:47 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
ERROR - 2013-12-01 06:01:47 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
DEBUG - 2013-12-01 06:01:47 --> DB Transaction Failure
ERROR - 2013-12-01 06:01:47 --> Query error: Unknown column 'Array' in 'field list'
DEBUG - 2013-12-01 06:01:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:02:47 --> Config Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:02:47 --> URI Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Router Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Output Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Security Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Input Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:02:47 --> Language Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Loader Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Session Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:02:47 --> Session routines successfully run
DEBUG - 2013-12-01 06:02:47 --> Controller Class Initialized
DEBUG - 2013-12-01 06:02:47 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:02:47 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:02:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:02:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:02:48 --> Model Class Initialized
DEBUG - 2013-12-01 06:02:48 --> Model Class Initialized
DEBUG - 2013-12-01 06:02:48 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:02:48 --> Model Class Initialized
DEBUG - 2013-12-01 06:02:48 --> Model Class Initialized
DEBUG - 2013-12-01 06:02:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:02:48 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:02:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:02:48 --> XSS Filtering completed
ERROR - 2013-12-01 06:02:48 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
ERROR - 2013-12-01 06:02:48 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
DEBUG - 2013-12-01 06:02:48 --> DB Transaction Failure
ERROR - 2013-12-01 06:02:48 --> Query error: Unknown column 'Array' in 'field list'
DEBUG - 2013-12-01 06:02:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:04:00 --> Config Class Initialized
DEBUG - 2013-12-01 06:04:00 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:04:00 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:04:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:04:00 --> URI Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Router Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Output Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Security Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Input Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:04:01 --> Language Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Loader Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Session Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:04:01 --> Session routines successfully run
DEBUG - 2013-12-01 06:04:01 --> Controller Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:04:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:04:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:04:01 --> Model Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Model Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Model Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Model Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:04:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:04:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:04:01 --> XSS Filtering completed
ERROR - 2013-12-01 06:04:02 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
ERROR - 2013-12-01 06:04:02 --> Severity: Notice  --> Array to string conversion C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 552
DEBUG - 2013-12-01 06:04:02 --> DB Transaction Failure
ERROR - 2013-12-01 06:04:02 --> Query error: Unknown column 'Array' in 'field list'
DEBUG - 2013-12-01 06:04:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:04:59 --> Config Class Initialized
DEBUG - 2013-12-01 06:04:59 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:05:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:05:00 --> URI Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Router Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Output Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Security Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Input Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:05:00 --> Language Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Loader Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Session Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:05:00 --> Session routines successfully run
DEBUG - 2013-12-01 06:05:00 --> Controller Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:05:00 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:05:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:05:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:05:00 --> Model Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Model Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Model Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Model Class Initialized
DEBUG - 2013-12-01 06:05:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:05:00 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:05:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:05:01 --> XSS Filtering completed
ERROR - 2013-12-01 06:05:01 --> Severity: Notice  --> Undefined variable: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 132
ERROR - 2013-12-01 06:05:01 --> Severity: Notice  --> Undefined variable: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 132
DEBUG - 2013-12-01 06:05:01 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:05:01 --> Final output sent to browser
DEBUG - 2013-12-01 06:05:01 --> Total execution time: 1.3161
DEBUG - 2013-12-01 06:05:29 --> Config Class Initialized
DEBUG - 2013-12-01 06:05:29 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:05:29 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:05:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:05:29 --> URI Class Initialized
DEBUG - 2013-12-01 06:05:29 --> Router Class Initialized
DEBUG - 2013-12-01 06:05:29 --> Output Class Initialized
DEBUG - 2013-12-01 06:05:29 --> Security Class Initialized
DEBUG - 2013-12-01 06:05:29 --> Input Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:05:30 --> Language Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Loader Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Session Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:05:30 --> Session routines successfully run
DEBUG - 2013-12-01 06:05:30 --> Controller Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:05:30 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:05:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:05:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:05:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:05:30 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:05:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:05:30 --> XSS Filtering completed
ERROR - 2013-12-01 06:05:30 --> Severity: Notice  --> Undefined variable: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 132
ERROR - 2013-12-01 06:05:31 --> Severity: Notice  --> Undefined variable: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 132
DEBUG - 2013-12-01 06:05:31 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:05:31 --> Final output sent to browser
DEBUG - 2013-12-01 06:05:31 --> Total execution time: 1.4171
DEBUG - 2013-12-01 06:06:02 --> Config Class Initialized
DEBUG - 2013-12-01 06:06:02 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:06:02 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:06:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:06:02 --> URI Class Initialized
DEBUG - 2013-12-01 06:06:02 --> Router Class Initialized
DEBUG - 2013-12-01 06:06:02 --> Output Class Initialized
DEBUG - 2013-12-01 06:06:02 --> Security Class Initialized
DEBUG - 2013-12-01 06:06:02 --> Input Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:06:03 --> Language Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Loader Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Session Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:06:03 --> Session routines successfully run
DEBUG - 2013-12-01 06:06:03 --> Controller Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:06:03 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:06:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:06:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:06:03 --> Model Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Model Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Model Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Model Class Initialized
DEBUG - 2013-12-01 06:06:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:06:03 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:06:03 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:06:04 --> Final output sent to browser
DEBUG - 2013-12-01 06:06:04 --> Total execution time: 1.2821
DEBUG - 2013-12-01 06:06:11 --> Config Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:06:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:06:11 --> URI Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Router Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Output Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Security Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Input Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:06:11 --> Language Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Loader Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Session Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:06:11 --> Session routines successfully run
DEBUG - 2013-12-01 06:06:11 --> Controller Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:06:11 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:06:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:06:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:06:11 --> Model Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Model Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Model Class Initialized
DEBUG - 2013-12-01 06:06:11 --> Model Class Initialized
DEBUG - 2013-12-01 06:06:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:06:12 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:06:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:06:12 --> XSS Filtering completed
DEBUG - 2013-12-01 06:06:12 --> DB Transaction Failure
ERROR - 2013-12-01 06:06:12 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 06:06:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:07:53 --> Config Class Initialized
DEBUG - 2013-12-01 06:07:53 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:07:53 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:07:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:07:53 --> URI Class Initialized
DEBUG - 2013-12-01 06:07:53 --> Router Class Initialized
DEBUG - 2013-12-01 06:07:53 --> Output Class Initialized
DEBUG - 2013-12-01 06:07:53 --> Security Class Initialized
DEBUG - 2013-12-01 06:07:53 --> Input Class Initialized
DEBUG - 2013-12-01 06:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:07:54 --> Language Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Loader Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Session Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:07:54 --> Session routines successfully run
DEBUG - 2013-12-01 06:07:54 --> Controller Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:07:54 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:07:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:07:54 --> Model Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Model Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Model Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Model Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:07:54 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:07:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:07:54 --> XSS Filtering completed
DEBUG - 2013-12-01 06:07:54 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:07:54 --> Final output sent to browser
DEBUG - 2013-12-01 06:07:54 --> Total execution time: 1.2991
DEBUG - 2013-12-01 06:08:26 --> Config Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:08:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:08:26 --> URI Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Router Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Output Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Security Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Input Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:08:26 --> Language Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Loader Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Session Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:08:26 --> Session garbage collection performed.
DEBUG - 2013-12-01 06:08:26 --> Session routines successfully run
DEBUG - 2013-12-01 06:08:26 --> Controller Class Initialized
DEBUG - 2013-12-01 06:08:26 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:08:26 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:08:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:08:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:08:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:08:27 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:08:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:08:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:08:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:08:27 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:08:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:08:27 --> XSS Filtering completed
DEBUG - 2013-12-01 06:08:27 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:08:27 --> Final output sent to browser
DEBUG - 2013-12-01 06:08:27 --> Total execution time: 1.2831
DEBUG - 2013-12-01 06:08:37 --> Config Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:08:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:08:37 --> URI Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Router Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Output Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Security Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Input Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:08:37 --> Language Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Loader Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:08:37 --> Session Class Initialized
DEBUG - 2013-12-01 06:08:38 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:08:38 --> Session routines successfully run
DEBUG - 2013-12-01 06:08:38 --> Controller Class Initialized
DEBUG - 2013-12-01 06:08:38 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:08:38 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:08:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:08:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:08:38 --> Model Class Initialized
DEBUG - 2013-12-01 06:08:38 --> Model Class Initialized
DEBUG - 2013-12-01 06:08:38 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:08:38 --> Model Class Initialized
DEBUG - 2013-12-01 06:08:38 --> Model Class Initialized
DEBUG - 2013-12-01 06:08:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:08:38 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:08:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:08:38 --> XSS Filtering completed
DEBUG - 2013-12-01 06:08:38 --> DB Transaction Failure
ERROR - 2013-12-01 06:08:38 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 06:08:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:09:42 --> Config Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:09:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:09:42 --> URI Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Router Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Output Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Security Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Input Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:09:42 --> Language Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Loader Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Session Class Initialized
DEBUG - 2013-12-01 06:09:42 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:09:42 --> Session routines successfully run
DEBUG - 2013-12-01 06:09:43 --> Controller Class Initialized
DEBUG - 2013-12-01 06:09:43 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:09:43 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:09:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:09:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:09:43 --> Model Class Initialized
DEBUG - 2013-12-01 06:09:43 --> Model Class Initialized
DEBUG - 2013-12-01 06:09:43 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:09:43 --> Model Class Initialized
DEBUG - 2013-12-01 06:09:43 --> Model Class Initialized
DEBUG - 2013-12-01 06:09:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:09:43 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:09:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:09:43 --> XSS Filtering completed
DEBUG - 2013-12-01 06:09:43 --> DB Transaction Failure
ERROR - 2013-12-01 06:09:43 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 06:09:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:09:58 --> Config Class Initialized
DEBUG - 2013-12-01 06:09:58 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:09:58 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:09:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:09:58 --> URI Class Initialized
DEBUG - 2013-12-01 06:09:58 --> Router Class Initialized
DEBUG - 2013-12-01 06:09:58 --> Output Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Security Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Input Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:09:59 --> Language Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Loader Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Session Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:09:59 --> Session routines successfully run
DEBUG - 2013-12-01 06:09:59 --> Controller Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:09:59 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:09:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:09:59 --> Model Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Model Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Model Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Model Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:09:59 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:09:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:09:59 --> XSS Filtering completed
DEBUG - 2013-12-01 06:10:00 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:10:00 --> Final output sent to browser
DEBUG - 2013-12-01 06:10:00 --> Total execution time: 1.3591
DEBUG - 2013-12-01 06:10:10 --> Config Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:10:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:10:10 --> URI Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Router Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Output Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Security Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Input Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:10:10 --> Language Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Loader Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Session Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:10:10 --> Session routines successfully run
DEBUG - 2013-12-01 06:10:10 --> Controller Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:10:10 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:10:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:10:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:10:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:10:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:10:11 --> Model Class Initialized
DEBUG - 2013-12-01 06:10:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:10:11 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:10:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:10:11 --> XSS Filtering completed
DEBUG - 2013-12-01 06:10:11 --> DB Transaction Failure
ERROR - 2013-12-01 06:10:11 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 06:10:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:12:35 --> Config Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:12:35 --> URI Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Router Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Output Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Security Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Input Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:12:35 --> Language Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Loader Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Session Class Initialized
DEBUG - 2013-12-01 06:12:35 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:12:35 --> Session routines successfully run
DEBUG - 2013-12-01 06:12:35 --> Controller Class Initialized
DEBUG - 2013-12-01 06:12:36 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:12:36 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:12:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:12:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:12:36 --> Model Class Initialized
DEBUG - 2013-12-01 06:12:36 --> Model Class Initialized
DEBUG - 2013-12-01 06:12:36 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:12:36 --> Model Class Initialized
DEBUG - 2013-12-01 06:12:36 --> Model Class Initialized
DEBUG - 2013-12-01 06:12:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:12:36 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:12:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:12:36 --> XSS Filtering completed
DEBUG - 2013-12-01 06:12:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:12:36 --> Final output sent to browser
DEBUG - 2013-12-01 06:12:37 --> Total execution time: 1.5631
DEBUG - 2013-12-01 06:12:41 --> Config Class Initialized
DEBUG - 2013-12-01 06:12:41 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:12:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:12:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:12:42 --> URI Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Router Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Output Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Security Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Input Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:12:42 --> Language Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Loader Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Session Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:12:42 --> Session routines successfully run
DEBUG - 2013-12-01 06:12:42 --> Controller Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:12:42 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:12:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:12:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:12:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:12:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:12:43 --> Model Class Initialized
DEBUG - 2013-12-01 06:12:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:12:43 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:12:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:12:43 --> XSS Filtering completed
DEBUG - 2013-12-01 06:12:43 --> DB Transaction Failure
ERROR - 2013-12-01 06:12:43 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 06:12:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:13:08 --> Config Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:13:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:13:08 --> URI Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Router Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Output Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Security Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Input Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:13:08 --> Language Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Loader Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Session Class Initialized
DEBUG - 2013-12-01 06:13:08 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:13:08 --> Session routines successfully run
DEBUG - 2013-12-01 06:13:08 --> Controller Class Initialized
DEBUG - 2013-12-01 06:13:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:13:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:13:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:13:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:13:09 --> Model Class Initialized
DEBUG - 2013-12-01 06:13:09 --> Model Class Initialized
DEBUG - 2013-12-01 06:13:09 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:13:09 --> Model Class Initialized
DEBUG - 2013-12-01 06:13:09 --> Model Class Initialized
DEBUG - 2013-12-01 06:13:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:13:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:13:09 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:13:09 --> Final output sent to browser
DEBUG - 2013-12-01 06:13:09 --> Total execution time: 1.4921
DEBUG - 2013-12-01 06:13:13 --> Config Class Initialized
DEBUG - 2013-12-01 06:13:13 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:13:13 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:13:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:13:13 --> URI Class Initialized
DEBUG - 2013-12-01 06:13:13 --> Router Class Initialized
DEBUG - 2013-12-01 06:13:13 --> Output Class Initialized
DEBUG - 2013-12-01 06:13:13 --> Security Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Input Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:13:14 --> Language Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Loader Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Session Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:13:14 --> Session routines successfully run
DEBUG - 2013-12-01 06:13:14 --> Controller Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:13:14 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:13:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:13:14 --> Model Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Model Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Model Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Model Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:13:14 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:13:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:13:15 --> XSS Filtering completed
DEBUG - 2013-12-01 06:13:15 --> DB Transaction Failure
ERROR - 2013-12-01 06:13:15 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 06:13:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:21:26 --> Config Class Initialized
DEBUG - 2013-12-01 06:21:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:21:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:21:27 --> URI Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Router Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Output Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Security Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Input Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:21:27 --> Language Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Loader Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Session Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:21:27 --> Session routines successfully run
DEBUG - 2013-12-01 06:21:27 --> Controller Class Initialized
DEBUG - 2013-12-01 06:21:27 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:21:27 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:21:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:21:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:21:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:21:28 --> Model Class Initialized
DEBUG - 2013-12-01 06:21:28 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:21:28 --> Model Class Initialized
DEBUG - 2013-12-01 06:21:28 --> Model Class Initialized
DEBUG - 2013-12-01 06:21:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:21:28 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:21:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:21:28 --> XSS Filtering completed
DEBUG - 2013-12-01 06:22:32 --> Config Class Initialized
DEBUG - 2013-12-01 06:22:32 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:22:32 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:22:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:22:32 --> URI Class Initialized
DEBUG - 2013-12-01 06:22:32 --> Router Class Initialized
DEBUG - 2013-12-01 06:22:32 --> Output Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Security Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Input Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:22:33 --> Language Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Loader Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Session Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:22:33 --> Session routines successfully run
DEBUG - 2013-12-01 06:22:33 --> Controller Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:22:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:22:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:22:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:22:33 --> Model Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Model Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Model Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Model Class Initialized
DEBUG - 2013-12-01 06:22:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:22:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:22:33 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:22:33 --> Final output sent to browser
DEBUG - 2013-12-01 06:22:34 --> Total execution time: 1.1891
DEBUG - 2013-12-01 06:22:41 --> Config Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:22:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:22:41 --> URI Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Router Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Output Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Security Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Input Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:22:41 --> Language Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Loader Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Session Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:22:41 --> Session routines successfully run
DEBUG - 2013-12-01 06:22:41 --> Controller Class Initialized
DEBUG - 2013-12-01 06:22:41 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:22:41 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:22:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:22:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:22:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:22:42 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:22:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:22:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:22:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:22:42 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:22:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:22:42 --> XSS Filtering completed
DEBUG - 2013-12-01 06:23:09 --> Config Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:23:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:23:09 --> URI Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Router Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Output Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Security Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Input Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:23:09 --> Language Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Loader Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Session Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:23:09 --> Session routines successfully run
DEBUG - 2013-12-01 06:23:09 --> Controller Class Initialized
DEBUG - 2013-12-01 06:23:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:23:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:23:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:23:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:23:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:23:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:23:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:23:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:23:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:23:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:23:10 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:23:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:23:10 --> XSS Filtering completed
DEBUG - 2013-12-01 06:23:19 --> Config Class Initialized
DEBUG - 2013-12-01 06:23:19 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:23:19 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:23:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:23:19 --> URI Class Initialized
DEBUG - 2013-12-01 06:23:19 --> Router Class Initialized
DEBUG - 2013-12-01 06:23:19 --> Output Class Initialized
DEBUG - 2013-12-01 06:23:19 --> Security Class Initialized
DEBUG - 2013-12-01 06:23:19 --> Input Class Initialized
DEBUG - 2013-12-01 06:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:23:19 --> Language Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Loader Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Session Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:23:20 --> Session routines successfully run
DEBUG - 2013-12-01 06:23:20 --> Controller Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:23:20 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:23:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:23:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:23:20 --> Model Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Model Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Model Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Model Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:23:20 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:23:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:23:20 --> XSS Filtering completed
DEBUG - 2013-12-01 06:32:37 --> Config Class Initialized
DEBUG - 2013-12-01 06:32:37 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:32:37 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:32:37 --> URI Class Initialized
DEBUG - 2013-12-01 06:32:37 --> Router Class Initialized
DEBUG - 2013-12-01 06:32:37 --> Output Class Initialized
DEBUG - 2013-12-01 06:32:37 --> Security Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Input Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:32:38 --> Language Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Loader Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Session Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:32:38 --> Session routines successfully run
DEBUG - 2013-12-01 06:32:38 --> Controller Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:32:38 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:32:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:32:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:32:38 --> Model Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Model Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Model Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Model Class Initialized
DEBUG - 2013-12-01 06:32:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:32:39 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:32:39 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:32:39 --> Final output sent to browser
DEBUG - 2013-12-01 06:32:39 --> Total execution time: 1.5031
DEBUG - 2013-12-01 06:32:49 --> Config Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:32:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:32:49 --> URI Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Router Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Output Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Security Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Input Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:32:49 --> Language Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Loader Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Session Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:32:49 --> Session routines successfully run
DEBUG - 2013-12-01 06:32:49 --> Controller Class Initialized
DEBUG - 2013-12-01 06:32:49 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:32:49 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:32:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:32:50 --> Model Class Initialized
DEBUG - 2013-12-01 06:32:50 --> Model Class Initialized
DEBUG - 2013-12-01 06:32:50 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:32:50 --> Model Class Initialized
DEBUG - 2013-12-01 06:32:50 --> Model Class Initialized
DEBUG - 2013-12-01 06:32:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:32:50 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:32:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:32:50 --> XSS Filtering completed
ERROR - 2013-12-01 06:32:50 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 139
ERROR - 2013-12-01 06:32:50 --> Severity: Notice  --> Undefined index: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 145
DEBUG - 2013-12-01 06:32:50 --> DB Transaction Failure
ERROR - 2013-12-01 06:32:50 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 06:32:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:33:04 --> Config Class Initialized
DEBUG - 2013-12-01 06:33:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:33:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:33:04 --> URI Class Initialized
DEBUG - 2013-12-01 06:33:04 --> Router Class Initialized
DEBUG - 2013-12-01 06:33:04 --> Output Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Security Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Input Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:33:05 --> Language Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Loader Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Session Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:33:05 --> Session routines successfully run
DEBUG - 2013-12-01 06:33:05 --> Controller Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:33:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:33:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:33:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:33:05 --> Model Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Model Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Model Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Model Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:33:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:33:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:33:05 --> XSS Filtering completed
ERROR - 2013-12-01 06:33:06 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 139
DEBUG - 2013-12-01 06:33:06 --> DB Transaction Failure
ERROR - 2013-12-01 06:33:06 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:33:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:33:21 --> Config Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:33:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:33:21 --> URI Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Router Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Output Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Security Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Input Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:33:21 --> Language Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Loader Class Initialized
DEBUG - 2013-12-01 06:33:21 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Session Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:33:22 --> Session routines successfully run
DEBUG - 2013-12-01 06:33:22 --> Controller Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:33:22 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:33:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:33:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:33:22 --> Model Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Model Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Model Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Model Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:33:22 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:33:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:33:22 --> XSS Filtering completed
ERROR - 2013-12-01 06:33:22 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 139
DEBUG - 2013-12-01 06:33:23 --> DB Transaction Failure
ERROR - 2013-12-01 06:33:23 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:33:23 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:34:09 --> Config Class Initialized
DEBUG - 2013-12-01 06:34:09 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:34:09 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:34:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:34:10 --> URI Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Router Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Output Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Security Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Input Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:34:10 --> Language Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Loader Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Session Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:34:10 --> Session routines successfully run
DEBUG - 2013-12-01 06:34:10 --> Controller Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:34:10 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:34:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:34:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:34:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:34:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:34:10 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:34:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:34:11 --> Final output sent to browser
DEBUG - 2013-12-01 06:34:11 --> Total execution time: 1.2231
DEBUG - 2013-12-01 06:34:20 --> Config Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:34:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:34:20 --> URI Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Router Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Output Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Security Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Input Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:34:20 --> Language Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Loader Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Session Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:34:20 --> Session routines successfully run
DEBUG - 2013-12-01 06:34:20 --> Controller Class Initialized
DEBUG - 2013-12-01 06:34:20 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:34:20 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:34:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:34:21 --> Model Class Initialized
DEBUG - 2013-12-01 06:34:21 --> Model Class Initialized
DEBUG - 2013-12-01 06:34:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:34:21 --> Model Class Initialized
DEBUG - 2013-12-01 06:34:21 --> Model Class Initialized
DEBUG - 2013-12-01 06:34:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:34:21 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:34:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:34:21 --> XSS Filtering completed
ERROR - 2013-12-01 06:34:21 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 141
DEBUG - 2013-12-01 06:34:21 --> DB Transaction Failure
ERROR - 2013-12-01 06:34:21 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:34:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:35:30 --> Config Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:35:30 --> URI Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Router Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Output Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Security Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Input Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:35:30 --> Language Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Loader Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Session Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:35:30 --> Session routines successfully run
DEBUG - 2013-12-01 06:35:30 --> Controller Class Initialized
DEBUG - 2013-12-01 06:35:30 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:35:31 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:35:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:35:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:35:31 --> Model Class Initialized
DEBUG - 2013-12-01 06:35:31 --> Model Class Initialized
DEBUG - 2013-12-01 06:35:31 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:35:31 --> Model Class Initialized
DEBUG - 2013-12-01 06:35:31 --> Model Class Initialized
DEBUG - 2013-12-01 06:35:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:35:31 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:35:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:35:31 --> XSS Filtering completed
ERROR - 2013-12-01 06:35:31 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 142
DEBUG - 2013-12-01 06:35:31 --> DB Transaction Failure
ERROR - 2013-12-01 06:35:31 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:35:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:35:57 --> Config Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:35:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:35:57 --> URI Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Router Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Output Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Security Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Input Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:35:57 --> Language Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Loader Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:35:57 --> Session Class Initialized
DEBUG - 2013-12-01 06:35:58 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:35:58 --> Session routines successfully run
DEBUG - 2013-12-01 06:35:58 --> Controller Class Initialized
DEBUG - 2013-12-01 06:35:58 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:35:58 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:35:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:35:58 --> Model Class Initialized
DEBUG - 2013-12-01 06:35:58 --> Model Class Initialized
DEBUG - 2013-12-01 06:35:58 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:35:58 --> Model Class Initialized
DEBUG - 2013-12-01 06:35:58 --> Model Class Initialized
DEBUG - 2013-12-01 06:35:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:35:58 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:35:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:35:58 --> XSS Filtering completed
ERROR - 2013-12-01 06:35:58 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 143
DEBUG - 2013-12-01 06:35:58 --> DB Transaction Failure
ERROR - 2013-12-01 06:35:58 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:35:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:38:00 --> Config Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:38:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:38:00 --> URI Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Router Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Output Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Security Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Input Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:38:00 --> Language Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Loader Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Session Class Initialized
DEBUG - 2013-12-01 06:38:00 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:38:01 --> Session routines successfully run
DEBUG - 2013-12-01 06:38:01 --> Controller Class Initialized
DEBUG - 2013-12-01 06:38:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:38:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:38:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:38:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:38:01 --> Model Class Initialized
DEBUG - 2013-12-01 06:38:01 --> Model Class Initialized
DEBUG - 2013-12-01 06:38:01 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:38:01 --> Model Class Initialized
DEBUG - 2013-12-01 06:38:01 --> Model Class Initialized
DEBUG - 2013-12-01 06:38:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:38:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:38:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:38:01 --> XSS Filtering completed
ERROR - 2013-12-01 06:38:01 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 139
DEBUG - 2013-12-01 06:38:01 --> DB Transaction Failure
ERROR - 2013-12-01 06:38:01 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:38:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:38:57 --> Config Class Initialized
DEBUG - 2013-12-01 06:38:57 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:38:57 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:38:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:38:57 --> URI Class Initialized
DEBUG - 2013-12-01 06:38:57 --> Router Class Initialized
DEBUG - 2013-12-01 06:38:57 --> Output Class Initialized
DEBUG - 2013-12-01 06:38:57 --> Security Class Initialized
DEBUG - 2013-12-01 06:38:57 --> Input Class Initialized
DEBUG - 2013-12-01 06:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:38:57 --> Language Class Initialized
DEBUG - 2013-12-01 06:38:57 --> Loader Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Session Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:38:58 --> Session routines successfully run
DEBUG - 2013-12-01 06:38:58 --> Controller Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:38:58 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:38:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:38:58 --> Model Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Model Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Model Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Model Class Initialized
DEBUG - 2013-12-01 06:38:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:38:58 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:38:58 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:38:58 --> Final output sent to browser
DEBUG - 2013-12-01 06:38:58 --> Total execution time: 1.2941
DEBUG - 2013-12-01 06:39:09 --> Config Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:39:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:39:09 --> URI Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Router Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Output Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Security Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Input Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:39:09 --> Language Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Loader Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Session Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:39:09 --> Session routines successfully run
DEBUG - 2013-12-01 06:39:09 --> Controller Class Initialized
DEBUG - 2013-12-01 06:39:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:39:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:39:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:39:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:39:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:39:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:10 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:39:10 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:39:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:39:10 --> XSS Filtering completed
ERROR - 2013-12-01 06:39:10 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 139
ERROR - 2013-12-01 06:39:10 --> Severity: Notice  --> Undefined index: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 145
DEBUG - 2013-12-01 06:39:10 --> DB Transaction Failure
ERROR - 2013-12-01 06:39:10 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 06:39:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:39:26 --> Config Class Initialized
DEBUG - 2013-12-01 06:39:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:39:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:39:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:39:26 --> URI Class Initialized
DEBUG - 2013-12-01 06:39:26 --> Router Class Initialized
DEBUG - 2013-12-01 06:39:26 --> Output Class Initialized
DEBUG - 2013-12-01 06:39:26 --> Security Class Initialized
DEBUG - 2013-12-01 06:39:26 --> Input Class Initialized
DEBUG - 2013-12-01 06:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:39:26 --> Language Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Loader Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Session Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:39:27 --> Session routines successfully run
DEBUG - 2013-12-01 06:39:27 --> Controller Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:39:27 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:39:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:39:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:39:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:39:27 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:39:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:39:27 --> XSS Filtering completed
ERROR - 2013-12-01 06:39:28 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 139
DEBUG - 2013-12-01 06:39:28 --> DB Transaction Failure
ERROR - 2013-12-01 06:39:28 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:39:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:39:31 --> Config Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:39:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:39:31 --> URI Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Router Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Output Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Security Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Input Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:39:31 --> Language Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Loader Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Session Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:39:31 --> Session routines successfully run
DEBUG - 2013-12-01 06:39:31 --> Controller Class Initialized
DEBUG - 2013-12-01 06:39:31 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:39:31 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:39:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:39:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:39:32 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:32 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:32 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:39:32 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:32 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:32 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:39:32 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:39:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:39:32 --> XSS Filtering completed
ERROR - 2013-12-01 06:39:32 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 139
DEBUG - 2013-12-01 06:39:32 --> DB Transaction Failure
ERROR - 2013-12-01 06:39:32 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:39:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:39:42 --> Config Class Initialized
DEBUG - 2013-12-01 06:39:42 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:39:42 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:39:43 --> URI Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Router Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Output Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Security Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Input Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:39:43 --> Language Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Loader Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Session Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:39:43 --> Session routines successfully run
DEBUG - 2013-12-01 06:39:43 --> Controller Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:39:43 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:39:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:39:43 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:39:43 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:44 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:39:44 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:39:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:39:44 --> XSS Filtering completed
DEBUG - 2013-12-01 06:39:44 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:39:44 --> Final output sent to browser
DEBUG - 2013-12-01 06:39:44 --> Total execution time: 1.4401
DEBUG - 2013-12-01 06:39:50 --> Config Class Initialized
DEBUG - 2013-12-01 06:39:50 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:39:50 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:39:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:39:50 --> URI Class Initialized
DEBUG - 2013-12-01 06:39:50 --> Router Class Initialized
DEBUG - 2013-12-01 06:39:50 --> Output Class Initialized
DEBUG - 2013-12-01 06:39:50 --> Security Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Input Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:39:51 --> Language Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Loader Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Session Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:39:51 --> Session routines successfully run
DEBUG - 2013-12-01 06:39:51 --> Controller Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:39:51 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:39:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:39:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:39:51 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:39:51 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:52 --> Model Class Initialized
DEBUG - 2013-12-01 06:39:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:39:52 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:39:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:39:52 --> XSS Filtering completed
ERROR - 2013-12-01 06:39:52 --> Severity: Notice  --> Undefined variable: hashtag_word C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 139
DEBUG - 2013-12-01 06:39:52 --> DB Transaction Failure
ERROR - 2013-12-01 06:39:52 --> Query error: Duplicate entry '' for key 'hashtag'
DEBUG - 2013-12-01 06:39:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:40:29 --> Config Class Initialized
DEBUG - 2013-12-01 06:40:29 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:40:29 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:40:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:40:30 --> URI Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Router Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Output Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Security Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Input Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:40:30 --> Language Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Loader Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Session Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:40:30 --> Session routines successfully run
DEBUG - 2013-12-01 06:40:30 --> Controller Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:40:30 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:40:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:40:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:40:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:40:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:40:31 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:40:31 --> Model Class Initialized
DEBUG - 2013-12-01 06:40:31 --> Model Class Initialized
DEBUG - 2013-12-01 06:40:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:40:31 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:40:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:40:31 --> XSS Filtering completed
DEBUG - 2013-12-01 06:40:31 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:40:31 --> Final output sent to browser
DEBUG - 2013-12-01 06:40:31 --> Total execution time: 1.6021
DEBUG - 2013-12-01 06:40:41 --> Config Class Initialized
DEBUG - 2013-12-01 06:40:41 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:40:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:40:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:40:41 --> URI Class Initialized
DEBUG - 2013-12-01 06:40:41 --> Router Class Initialized
DEBUG - 2013-12-01 06:40:41 --> Output Class Initialized
DEBUG - 2013-12-01 06:40:41 --> Security Class Initialized
DEBUG - 2013-12-01 06:40:41 --> Input Class Initialized
DEBUG - 2013-12-01 06:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:40:41 --> Language Class Initialized
DEBUG - 2013-12-01 06:40:41 --> Loader Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Session Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:40:42 --> Session routines successfully run
DEBUG - 2013-12-01 06:40:42 --> Controller Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:40:42 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:40:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:40:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:40:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Model Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:40:42 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:40:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:40:42 --> XSS Filtering completed
DEBUG - 2013-12-01 06:40:42 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:40:43 --> Final output sent to browser
DEBUG - 2013-12-01 06:40:43 --> Total execution time: 1.5351
DEBUG - 2013-12-01 06:41:18 --> Config Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:41:18 --> URI Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Router Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Output Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Security Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Input Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:41:18 --> Language Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Loader Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Session Class Initialized
DEBUG - 2013-12-01 06:41:18 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:41:19 --> Session routines successfully run
DEBUG - 2013-12-01 06:41:19 --> Controller Class Initialized
DEBUG - 2013-12-01 06:41:19 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:41:19 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:41:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:41:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:41:19 --> Model Class Initialized
DEBUG - 2013-12-01 06:41:19 --> Model Class Initialized
DEBUG - 2013-12-01 06:41:19 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:41:19 --> Model Class Initialized
DEBUG - 2013-12-01 06:41:19 --> Model Class Initialized
DEBUG - 2013-12-01 06:41:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:41:19 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:41:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:41:19 --> XSS Filtering completed
DEBUG - 2013-12-01 06:41:20 --> DB Transaction Failure
ERROR - 2013-12-01 06:41:20 --> Query error: Duplicate entry 'waanttt' for key 'hashtag'
DEBUG - 2013-12-01 06:41:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:42:45 --> Config Class Initialized
DEBUG - 2013-12-01 06:42:45 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:42:45 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:42:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:42:45 --> URI Class Initialized
DEBUG - 2013-12-01 06:42:45 --> Router Class Initialized
DEBUG - 2013-12-01 06:42:45 --> Output Class Initialized
DEBUG - 2013-12-01 06:42:45 --> Security Class Initialized
DEBUG - 2013-12-01 06:42:45 --> Input Class Initialized
DEBUG - 2013-12-01 06:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:42:45 --> Language Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Loader Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Session Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:42:46 --> Session routines successfully run
DEBUG - 2013-12-01 06:42:46 --> Controller Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:42:46 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:42:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:42:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:42:46 --> Model Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Model Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Model Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Model Class Initialized
DEBUG - 2013-12-01 06:42:46 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:42:46 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:42:46 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 06:42:46 --> Final output sent to browser
DEBUG - 2013-12-01 06:42:46 --> Total execution time: 1.3961
DEBUG - 2013-12-01 06:42:51 --> Config Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:42:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:42:51 --> URI Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Router Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Output Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Security Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Input Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:42:51 --> Language Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Loader Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Session Class Initialized
DEBUG - 2013-12-01 06:42:51 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:42:52 --> Session routines successfully run
DEBUG - 2013-12-01 06:42:52 --> Controller Class Initialized
DEBUG - 2013-12-01 06:42:52 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:42:52 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:42:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:42:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:42:52 --> Model Class Initialized
DEBUG - 2013-12-01 06:42:52 --> Model Class Initialized
DEBUG - 2013-12-01 06:42:52 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:42:52 --> Model Class Initialized
DEBUG - 2013-12-01 06:42:52 --> Model Class Initialized
DEBUG - 2013-12-01 06:42:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:42:52 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:42:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:42:52 --> XSS Filtering completed
DEBUG - 2013-12-01 06:42:52 --> DB Transaction Failure
ERROR - 2013-12-01 06:42:52 --> Query error: Duplicate entry 'waanttt' for key 'hashtag'
DEBUG - 2013-12-01 06:42:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 06:43:29 --> Config Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Hooks Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Utf8 Class Initialized
DEBUG - 2013-12-01 06:43:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 06:43:29 --> URI Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Router Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Output Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Security Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Input Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 06:43:29 --> Language Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Loader Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Database Driver Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Session Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Helper loaded: string_helper
DEBUG - 2013-12-01 06:43:29 --> Session routines successfully run
DEBUG - 2013-12-01 06:43:29 --> Controller Class Initialized
DEBUG - 2013-12-01 06:43:29 --> Helper loaded: form_helper
DEBUG - 2013-12-01 06:43:29 --> Helper loaded: url_helper
DEBUG - 2013-12-01 06:43:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 06:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 06:43:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:43:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:43:30 --> Image Lib Class Initialized
DEBUG - 2013-12-01 06:43:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:43:30 --> Model Class Initialized
DEBUG - 2013-12-01 06:43:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 06:43:30 --> Form Validation Class Initialized
DEBUG - 2013-12-01 06:43:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 06:43:30 --> XSS Filtering completed
DEBUG - 2013-12-01 06:43:30 --> DB Transaction Failure
ERROR - 2013-12-01 06:43:30 --> Query error: Duplicate entry 'waanttt' for key 'hashtag'
DEBUG - 2013-12-01 06:43:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 07:25:03 --> Config Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:25:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:25:03 --> URI Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Router Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Output Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Security Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Input Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:25:03 --> Language Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Loader Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Session Class Initialized
DEBUG - 2013-12-01 07:25:03 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:25:04 --> Session routines successfully run
DEBUG - 2013-12-01 07:25:04 --> Controller Class Initialized
DEBUG - 2013-12-01 07:25:04 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:25:04 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:25:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:25:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:25:04 --> Model Class Initialized
DEBUG - 2013-12-01 07:25:04 --> Model Class Initialized
DEBUG - 2013-12-01 07:25:04 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:25:04 --> Model Class Initialized
DEBUG - 2013-12-01 07:25:04 --> Model Class Initialized
DEBUG - 2013-12-01 07:25:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:25:04 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:25:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:25:04 --> XSS Filtering completed
DEBUG - 2013-12-01 07:25:16 --> Config Class Initialized
DEBUG - 2013-12-01 07:25:16 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:25:16 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:25:16 --> URI Class Initialized
DEBUG - 2013-12-01 07:25:16 --> Router Class Initialized
DEBUG - 2013-12-01 07:25:16 --> Output Class Initialized
DEBUG - 2013-12-01 07:25:16 --> Security Class Initialized
DEBUG - 2013-12-01 07:25:16 --> Input Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:25:17 --> Language Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Loader Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Session Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:25:17 --> Session routines successfully run
DEBUG - 2013-12-01 07:25:17 --> Controller Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:25:17 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:25:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:25:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:25:17 --> Model Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Model Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Model Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Model Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:25:17 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:25:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:25:18 --> XSS Filtering completed
ERROR - 2013-12-01 07:25:18 --> Severity: Notice  --> Undefined variable: hashtag C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 132
DEBUG - 2013-12-01 07:25:18 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:25:18 --> Final output sent to browser
DEBUG - 2013-12-01 07:25:18 --> Total execution time: 1.5851
DEBUG - 2013-12-01 07:26:19 --> Config Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:26:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:26:19 --> URI Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Router Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Output Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Security Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Input Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:26:19 --> Language Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Loader Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Session Class Initialized
DEBUG - 2013-12-01 07:26:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:26:20 --> Session routines successfully run
DEBUG - 2013-12-01 07:26:20 --> Controller Class Initialized
DEBUG - 2013-12-01 07:26:20 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:26:20 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:26:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:26:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:26:20 --> Model Class Initialized
DEBUG - 2013-12-01 07:26:20 --> Model Class Initialized
DEBUG - 2013-12-01 07:26:20 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:26:20 --> Model Class Initialized
DEBUG - 2013-12-01 07:26:20 --> Model Class Initialized
DEBUG - 2013-12-01 07:26:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:26:20 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:26:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:26:20 --> XSS Filtering completed
ERROR - 2013-12-01 07:26:20 --> Severity: Notice  --> Undefined index: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 141
DEBUG - 2013-12-01 07:26:20 --> DB Transaction Failure
ERROR - 2013-12-01 07:26:21 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 07:26:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 07:27:05 --> Config Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:27:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:27:05 --> URI Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Router Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Output Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Security Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Input Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:27:05 --> Language Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Loader Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Session Class Initialized
DEBUG - 2013-12-01 07:27:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:27:06 --> Session routines successfully run
DEBUG - 2013-12-01 07:27:06 --> Controller Class Initialized
DEBUG - 2013-12-01 07:27:06 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:27:06 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:27:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:27:06 --> Model Class Initialized
DEBUG - 2013-12-01 07:27:06 --> Model Class Initialized
DEBUG - 2013-12-01 07:27:06 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:27:06 --> Model Class Initialized
DEBUG - 2013-12-01 07:27:06 --> Model Class Initialized
DEBUG - 2013-12-01 07:27:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:27:06 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:27:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:27:06 --> XSS Filtering completed
ERROR - 2013-12-01 07:27:06 --> Severity: Notice  --> Undefined variable: hashtag C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 132
DEBUG - 2013-12-01 07:27:06 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:27:06 --> Final output sent to browser
DEBUG - 2013-12-01 07:27:07 --> Total execution time: 1.6331
DEBUG - 2013-12-01 07:27:28 --> Config Class Initialized
DEBUG - 2013-12-01 07:27:28 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:27:28 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:27:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:27:28 --> URI Class Initialized
DEBUG - 2013-12-01 07:27:28 --> Router Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Output Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Security Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Input Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:27:29 --> Language Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Loader Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Session Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:27:29 --> Session routines successfully run
DEBUG - 2013-12-01 07:27:29 --> Controller Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:27:29 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:27:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:27:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:27:29 --> Model Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Model Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Model Class Initialized
DEBUG - 2013-12-01 07:27:29 --> Model Class Initialized
DEBUG - 2013-12-01 07:27:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:27:30 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:27:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:27:30 --> XSS Filtering completed
ERROR - 2013-12-01 07:27:30 --> Severity: Notice  --> Undefined index: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 141
DEBUG - 2013-12-01 07:27:30 --> DB Transaction Failure
ERROR - 2013-12-01 07:27:30 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 07:27:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 07:27:59 --> Config Class Initialized
DEBUG - 2013-12-01 07:27:59 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:27:59 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:27:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:27:59 --> URI Class Initialized
DEBUG - 2013-12-01 07:27:59 --> Router Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Output Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Security Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Input Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:28:00 --> Language Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Loader Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Session Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:28:00 --> Session garbage collection performed.
DEBUG - 2013-12-01 07:28:00 --> Session routines successfully run
DEBUG - 2013-12-01 07:28:00 --> Controller Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:28:00 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:28:00 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:28:00 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:28:00 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:01 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:01 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:28:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:28:01 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:28:01 --> Final output sent to browser
DEBUG - 2013-12-01 07:28:01 --> Total execution time: 1.5231
DEBUG - 2013-12-01 07:28:08 --> Config Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:28:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:28:08 --> URI Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Router Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Output Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Security Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Input Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:28:08 --> Language Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Loader Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Session Class Initialized
DEBUG - 2013-12-01 07:28:08 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:28:09 --> Session routines successfully run
DEBUG - 2013-12-01 07:28:09 --> Controller Class Initialized
DEBUG - 2013-12-01 07:28:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:28:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:28:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:28:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:28:09 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:09 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:09 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:28:09 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:09 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:28:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:28:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:28:09 --> XSS Filtering completed
ERROR - 2013-12-01 07:28:09 --> Severity: Notice  --> Undefined variable: hashtag C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 123
ERROR - 2013-12-01 07:28:09 --> Severity: Notice  --> Undefined index: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 143
DEBUG - 2013-12-01 07:28:10 --> DB Transaction Failure
ERROR - 2013-12-01 07:28:10 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 07:28:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 07:28:28 --> Config Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:28:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:28:28 --> URI Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Router Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Output Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Security Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Input Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:28:28 --> Language Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Loader Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Session Class Initialized
DEBUG - 2013-12-01 07:28:28 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:28:28 --> Session garbage collection performed.
DEBUG - 2013-12-01 07:28:28 --> Session routines successfully run
DEBUG - 2013-12-01 07:28:28 --> Controller Class Initialized
DEBUG - 2013-12-01 07:28:29 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:28:29 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:28:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:28:29 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:29 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:29 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:28:29 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:29 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:28:29 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:28:29 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:28:29 --> Final output sent to browser
DEBUG - 2013-12-01 07:28:29 --> Total execution time: 1.6371
DEBUG - 2013-12-01 07:28:34 --> Config Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:28:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:28:34 --> URI Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Router Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Output Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Security Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Input Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:28:34 --> Language Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Loader Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:28:34 --> Session Class Initialized
DEBUG - 2013-12-01 07:28:35 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:28:35 --> Session routines successfully run
DEBUG - 2013-12-01 07:28:35 --> Controller Class Initialized
DEBUG - 2013-12-01 07:28:35 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:28:35 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:28:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:28:35 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:35 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:35 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:28:35 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:35 --> Model Class Initialized
DEBUG - 2013-12-01 07:28:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:28:35 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:28:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:28:36 --> XSS Filtering completed
ERROR - 2013-12-01 07:28:36 --> Severity: Notice  --> Undefined index: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 143
DEBUG - 2013-12-01 07:28:36 --> DB Transaction Failure
ERROR - 2013-12-01 07:28:36 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 07:28:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 07:29:25 --> Config Class Initialized
DEBUG - 2013-12-01 07:29:25 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:29:25 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:29:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:29:26 --> URI Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Router Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Output Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Security Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Input Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:29:26 --> Language Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Loader Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Session Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:29:26 --> Session routines successfully run
DEBUG - 2013-12-01 07:29:26 --> Controller Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:29:26 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:29:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:29:26 --> Model Class Initialized
DEBUG - 2013-12-01 07:29:26 --> Model Class Initialized
DEBUG - 2013-12-01 07:29:27 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:29:27 --> Model Class Initialized
DEBUG - 2013-12-01 07:29:27 --> Model Class Initialized
DEBUG - 2013-12-01 07:29:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:29:27 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:29:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:29:27 --> XSS Filtering completed
ERROR - 2013-12-01 07:29:27 --> Severity: Notice  --> Undefined index: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 143
DEBUG - 2013-12-01 07:29:27 --> DB Transaction Failure
ERROR - 2013-12-01 07:29:27 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 07:29:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 07:30:24 --> Config Class Initialized
DEBUG - 2013-12-01 07:30:24 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:30:24 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:30:24 --> URI Class Initialized
DEBUG - 2013-12-01 07:30:24 --> Router Class Initialized
DEBUG - 2013-12-01 07:30:24 --> Output Class Initialized
DEBUG - 2013-12-01 07:30:24 --> Security Class Initialized
DEBUG - 2013-12-01 07:30:24 --> Input Class Initialized
DEBUG - 2013-12-01 07:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:30:24 --> Language Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Loader Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Session Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:30:25 --> Session routines successfully run
DEBUG - 2013-12-01 07:30:25 --> Controller Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:30:25 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:30:25 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:30:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:30:25 --> Model Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Model Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Model Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Model Class Initialized
DEBUG - 2013-12-01 07:30:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:30:26 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:30:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:30:26 --> XSS Filtering completed
DEBUG - 2013-12-01 07:30:26 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:30:26 --> Final output sent to browser
DEBUG - 2013-12-01 07:30:26 --> Total execution time: 1.9591
DEBUG - 2013-12-01 07:30:38 --> Config Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:30:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:30:38 --> URI Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Router Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Output Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Security Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Input Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:30:38 --> Language Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Loader Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Session Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:30:38 --> Session routines successfully run
DEBUG - 2013-12-01 07:30:38 --> Controller Class Initialized
DEBUG - 2013-12-01 07:30:38 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:30:39 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:30:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:30:39 --> Model Class Initialized
DEBUG - 2013-12-01 07:30:39 --> Model Class Initialized
DEBUG - 2013-12-01 07:30:39 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:30:39 --> Model Class Initialized
DEBUG - 2013-12-01 07:30:39 --> Model Class Initialized
DEBUG - 2013-12-01 07:30:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:30:39 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:30:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:30:39 --> XSS Filtering completed
ERROR - 2013-12-01 07:30:39 --> Severity: Notice  --> Undefined index: hashtag_id C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 145
DEBUG - 2013-12-01 07:30:39 --> DB Transaction Failure
ERROR - 2013-12-01 07:30:39 --> Query error: Column 'hashtag_id' cannot be null
DEBUG - 2013-12-01 07:30:39 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 07:31:43 --> Config Class Initialized
DEBUG - 2013-12-01 07:31:43 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:31:43 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:31:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:31:43 --> URI Class Initialized
DEBUG - 2013-12-01 07:31:43 --> Router Class Initialized
DEBUG - 2013-12-01 07:31:43 --> Output Class Initialized
DEBUG - 2013-12-01 07:31:43 --> Security Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Input Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:31:44 --> Language Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Loader Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Session Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:31:44 --> Session routines successfully run
DEBUG - 2013-12-01 07:31:44 --> Controller Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:31:44 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:31:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:31:44 --> Model Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Model Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Model Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Model Class Initialized
DEBUG - 2013-12-01 07:31:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:31:44 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:31:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:31:45 --> XSS Filtering completed
DEBUG - 2013-12-01 07:31:45 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:31:45 --> Final output sent to browser
DEBUG - 2013-12-01 07:31:45 --> Total execution time: 1.7671
DEBUG - 2013-12-01 07:32:41 --> Config Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:32:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:32:41 --> URI Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Router Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Output Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Security Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Input Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:32:41 --> Language Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Loader Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Session Class Initialized
DEBUG - 2013-12-01 07:32:41 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:32:42 --> Session routines successfully run
DEBUG - 2013-12-01 07:32:42 --> Controller Class Initialized
DEBUG - 2013-12-01 07:32:42 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:32:42 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:32:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:32:42 --> Model Class Initialized
DEBUG - 2013-12-01 07:32:42 --> Model Class Initialized
DEBUG - 2013-12-01 07:32:42 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:32:42 --> Model Class Initialized
DEBUG - 2013-12-01 07:32:42 --> Model Class Initialized
DEBUG - 2013-12-01 07:32:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:32:42 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:32:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:32:42 --> XSS Filtering completed
DEBUG - 2013-12-01 07:32:42 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:32:42 --> Final output sent to browser
DEBUG - 2013-12-01 07:32:43 --> Total execution time: 1.7131
DEBUG - 2013-12-01 07:34:34 --> Config Class Initialized
DEBUG - 2013-12-01 07:34:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:34:35 --> URI Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Router Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Output Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Security Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Input Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:34:35 --> Language Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Loader Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Session Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:34:35 --> Session routines successfully run
DEBUG - 2013-12-01 07:34:35 --> Controller Class Initialized
DEBUG - 2013-12-01 07:34:35 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:34:35 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:34:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:34:36 --> Model Class Initialized
DEBUG - 2013-12-01 07:34:36 --> Model Class Initialized
DEBUG - 2013-12-01 07:34:36 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:34:36 --> Model Class Initialized
DEBUG - 2013-12-01 07:34:36 --> Model Class Initialized
DEBUG - 2013-12-01 07:34:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:34:36 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:34:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:34:36 --> XSS Filtering completed
DEBUG - 2013-12-01 07:34:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:34:36 --> Final output sent to browser
DEBUG - 2013-12-01 07:34:36 --> Total execution time: 1.6281
DEBUG - 2013-12-01 07:34:45 --> Config Class Initialized
DEBUG - 2013-12-01 07:34:45 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:34:45 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:34:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:34:46 --> URI Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Router Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Output Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Security Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Input Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:34:46 --> Language Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Loader Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Session Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:34:46 --> Session routines successfully run
DEBUG - 2013-12-01 07:34:46 --> Controller Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:34:46 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:34:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:34:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:34:46 --> Model Class Initialized
DEBUG - 2013-12-01 07:34:46 --> Model Class Initialized
DEBUG - 2013-12-01 07:34:47 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:34:47 --> Model Class Initialized
DEBUG - 2013-12-01 07:34:47 --> Model Class Initialized
DEBUG - 2013-12-01 07:34:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:34:47 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:34:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:34:47 --> XSS Filtering completed
DEBUG - 2013-12-01 07:34:47 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:34:47 --> Final output sent to browser
DEBUG - 2013-12-01 07:34:47 --> Total execution time: 1.6471
DEBUG - 2013-12-01 07:36:42 --> Config Class Initialized
DEBUG - 2013-12-01 07:36:42 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:36:42 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:36:42 --> URI Class Initialized
DEBUG - 2013-12-01 07:36:42 --> Router Class Initialized
DEBUG - 2013-12-01 07:36:42 --> Output Class Initialized
DEBUG - 2013-12-01 07:36:42 --> Security Class Initialized
DEBUG - 2013-12-01 07:36:42 --> Input Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:36:43 --> Language Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Loader Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Session Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:36:43 --> Session routines successfully run
DEBUG - 2013-12-01 07:36:43 --> Controller Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:36:43 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:36:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:36:43 --> Model Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Model Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Model Class Initialized
DEBUG - 2013-12-01 07:36:43 --> Model Class Initialized
DEBUG - 2013-12-01 07:36:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:36:44 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:36:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:36:44 --> XSS Filtering completed
DEBUG - 2013-12-01 07:36:44 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:36:44 --> Final output sent to browser
DEBUG - 2013-12-01 07:36:44 --> Total execution time: 1.6911
DEBUG - 2013-12-01 07:42:34 --> Config Class Initialized
DEBUG - 2013-12-01 07:42:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:42:34 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:42:34 --> URI Class Initialized
DEBUG - 2013-12-01 07:42:34 --> Router Class Initialized
DEBUG - 2013-12-01 07:42:34 --> Output Class Initialized
DEBUG - 2013-12-01 07:42:34 --> Security Class Initialized
DEBUG - 2013-12-01 07:42:34 --> Input Class Initialized
DEBUG - 2013-12-01 07:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:42:34 --> Language Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Loader Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Session Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:42:35 --> Session routines successfully run
DEBUG - 2013-12-01 07:42:35 --> Controller Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:42:35 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:42:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:42:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:42:35 --> Model Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Model Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Model Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Model Class Initialized
DEBUG - 2013-12-01 07:42:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:42:35 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:42:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:42:36 --> XSS Filtering completed
ERROR - 2013-12-01 07:42:36 --> Severity: Notice  --> Undefined index: errors C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 53
DEBUG - 2013-12-01 07:42:36 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:42:36 --> Final output sent to browser
DEBUG - 2013-12-01 07:42:36 --> Total execution time: 1.7901
DEBUG - 2013-12-01 07:43:08 --> Config Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:43:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:43:09 --> URI Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Router Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Output Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Security Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Input Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:43:09 --> Language Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Loader Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Session Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:43:09 --> Session routines successfully run
DEBUG - 2013-12-01 07:43:09 --> Controller Class Initialized
DEBUG - 2013-12-01 07:43:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:43:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:43:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:43:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:43:10 --> Model Class Initialized
DEBUG - 2013-12-01 07:43:10 --> Model Class Initialized
DEBUG - 2013-12-01 07:43:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:43:10 --> Model Class Initialized
DEBUG - 2013-12-01 07:43:10 --> Model Class Initialized
DEBUG - 2013-12-01 07:43:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:43:10 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:43:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:43:10 --> XSS Filtering completed
DEBUG - 2013-12-01 07:43:10 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:43:10 --> Final output sent to browser
DEBUG - 2013-12-01 07:43:10 --> Total execution time: 1.7821
DEBUG - 2013-12-01 07:45:12 --> Config Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:45:12 --> URI Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Router Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Output Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Security Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Input Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:45:12 --> Language Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Loader Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Session Class Initialized
DEBUG - 2013-12-01 07:45:12 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:45:13 --> Session routines successfully run
DEBUG - 2013-12-01 07:45:13 --> Controller Class Initialized
DEBUG - 2013-12-01 07:45:13 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:45:13 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:45:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:45:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:45:13 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:13 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:13 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:45:13 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:13 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:45:13 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:45:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:45:14 --> XSS Filtering completed
DEBUG - 2013-12-01 07:45:14 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:45:14 --> Final output sent to browser
DEBUG - 2013-12-01 07:45:14 --> Total execution time: 2.0541
DEBUG - 2013-12-01 07:45:30 --> Config Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:45:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:45:30 --> URI Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Router Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Output Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Security Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Input Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:45:30 --> Language Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Loader Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Session Class Initialized
DEBUG - 2013-12-01 07:45:30 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:45:31 --> Session routines successfully run
DEBUG - 2013-12-01 07:45:31 --> Controller Class Initialized
DEBUG - 2013-12-01 07:45:31 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:45:31 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:45:31 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:45:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:45:31 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:31 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:31 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:45:31 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:31 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:45:31 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:45:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:45:31 --> XSS Filtering completed
DEBUG - 2013-12-01 07:45:31 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:45:31 --> Final output sent to browser
DEBUG - 2013-12-01 07:45:32 --> Total execution time: 1.7681
DEBUG - 2013-12-01 07:45:43 --> Config Class Initialized
DEBUG - 2013-12-01 07:45:43 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:45:43 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:45:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:45:43 --> URI Class Initialized
DEBUG - 2013-12-01 07:45:43 --> Router Class Initialized
DEBUG - 2013-12-01 07:45:43 --> Output Class Initialized
DEBUG - 2013-12-01 07:45:43 --> Security Class Initialized
DEBUG - 2013-12-01 07:45:43 --> Input Class Initialized
DEBUG - 2013-12-01 07:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:45:44 --> Language Class Initialized
DEBUG - 2013-12-01 07:45:44 --> Loader Class Initialized
DEBUG - 2013-12-01 07:45:44 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:45:44 --> Session Class Initialized
DEBUG - 2013-12-01 07:45:44 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:45:44 --> Session routines successfully run
DEBUG - 2013-12-01 07:45:44 --> Controller Class Initialized
DEBUG - 2013-12-01 07:45:44 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:45:44 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:45:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:45:44 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:44 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:44 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:45:45 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:45 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:45:45 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:45:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:45:45 --> XSS Filtering completed
DEBUG - 2013-12-01 07:45:45 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:45:45 --> Final output sent to browser
DEBUG - 2013-12-01 07:45:45 --> Total execution time: 1.9031
DEBUG - 2013-12-01 07:45:53 --> Config Class Initialized
DEBUG - 2013-12-01 07:45:53 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:45:53 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:45:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:45:54 --> URI Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Router Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Output Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Security Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Input Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:45:54 --> Language Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Loader Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Session Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:45:54 --> Session routines successfully run
DEBUG - 2013-12-01 07:45:54 --> Controller Class Initialized
DEBUG - 2013-12-01 07:45:54 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:45:54 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:45:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:45:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:45:55 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:55 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:55 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:45:55 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:55 --> Model Class Initialized
DEBUG - 2013-12-01 07:45:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:45:55 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:45:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:45:55 --> XSS Filtering completed
ERROR - 2013-12-01 07:45:55 --> Severity: Notice  --> Undefined variable: data C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 150
ERROR - 2013-12-01 07:45:55 --> Severity: Notice  --> Undefined index: errors C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 53
DEBUG - 2013-12-01 07:45:55 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:45:55 --> Final output sent to browser
DEBUG - 2013-12-01 07:45:55 --> Total execution time: 1.9671
DEBUG - 2013-12-01 07:46:29 --> Config Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:46:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:46:29 --> URI Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Router Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Output Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Security Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Input Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:46:29 --> Language Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Loader Class Initialized
DEBUG - 2013-12-01 07:46:29 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:46:30 --> Session Class Initialized
DEBUG - 2013-12-01 07:46:30 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:46:30 --> Session routines successfully run
DEBUG - 2013-12-01 07:46:30 --> Controller Class Initialized
DEBUG - 2013-12-01 07:46:30 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:46:30 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:46:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:46:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:46:30 --> Model Class Initialized
DEBUG - 2013-12-01 07:46:30 --> Model Class Initialized
DEBUG - 2013-12-01 07:46:30 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:46:30 --> Model Class Initialized
DEBUG - 2013-12-01 07:46:30 --> Model Class Initialized
DEBUG - 2013-12-01 07:46:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:46:31 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:46:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:46:31 --> XSS Filtering completed
ERROR - 2013-12-01 07:46:31 --> Severity: Notice  --> Undefined variable: data C:\Program Files (x86)\Ampps\www\project\application\controllers\home.php 149
DEBUG - 2013-12-01 07:46:31 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:46:31 --> Final output sent to browser
DEBUG - 2013-12-01 07:46:31 --> Total execution time: 2.3701
DEBUG - 2013-12-01 07:47:20 --> Config Class Initialized
DEBUG - 2013-12-01 07:47:20 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:47:20 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:47:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:47:20 --> URI Class Initialized
DEBUG - 2013-12-01 07:47:20 --> Router Class Initialized
DEBUG - 2013-12-01 07:47:20 --> Output Class Initialized
DEBUG - 2013-12-01 07:47:20 --> Security Class Initialized
DEBUG - 2013-12-01 07:47:20 --> Input Class Initialized
DEBUG - 2013-12-01 07:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:47:20 --> Language Class Initialized
DEBUG - 2013-12-01 07:47:20 --> Loader Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Session Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:47:21 --> Session routines successfully run
DEBUG - 2013-12-01 07:47:21 --> Controller Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:47:21 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:47:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:47:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:47:21 --> Model Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Model Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Model Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Model Class Initialized
DEBUG - 2013-12-01 07:47:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:47:22 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:47:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:47:22 --> XSS Filtering completed
DEBUG - 2013-12-01 07:47:22 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:47:22 --> Final output sent to browser
DEBUG - 2013-12-01 07:47:22 --> Total execution time: 2.0181
DEBUG - 2013-12-01 07:48:45 --> Config Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Hooks Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Utf8 Class Initialized
DEBUG - 2013-12-01 07:48:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 07:48:46 --> URI Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Router Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Output Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Security Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Input Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 07:48:46 --> Language Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Loader Class Initialized
DEBUG - 2013-12-01 07:48:46 --> Database Driver Class Initialized
DEBUG - 2013-12-01 07:48:47 --> Session Class Initialized
DEBUG - 2013-12-01 07:48:47 --> Helper loaded: string_helper
DEBUG - 2013-12-01 07:48:47 --> Session routines successfully run
DEBUG - 2013-12-01 07:48:47 --> Controller Class Initialized
DEBUG - 2013-12-01 07:48:47 --> Helper loaded: form_helper
DEBUG - 2013-12-01 07:48:47 --> Helper loaded: url_helper
DEBUG - 2013-12-01 07:48:47 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 07:48:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 07:48:47 --> Model Class Initialized
DEBUG - 2013-12-01 07:48:47 --> Model Class Initialized
DEBUG - 2013-12-01 07:48:47 --> Image Lib Class Initialized
DEBUG - 2013-12-01 07:48:47 --> Model Class Initialized
DEBUG - 2013-12-01 07:48:48 --> Model Class Initialized
DEBUG - 2013-12-01 07:48:48 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 07:48:48 --> Form Validation Class Initialized
DEBUG - 2013-12-01 07:48:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 07:48:48 --> XSS Filtering completed
DEBUG - 2013-12-01 07:48:48 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 07:48:48 --> Final output sent to browser
DEBUG - 2013-12-01 07:48:48 --> Total execution time: 2.5751
DEBUG - 2013-12-01 08:04:09 --> Config Class Initialized
DEBUG - 2013-12-01 08:04:09 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:04:09 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:04:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:04:09 --> URI Class Initialized
DEBUG - 2013-12-01 08:04:09 --> Router Class Initialized
DEBUG - 2013-12-01 08:04:09 --> Output Class Initialized
DEBUG - 2013-12-01 08:04:09 --> Security Class Initialized
DEBUG - 2013-12-01 08:04:09 --> Input Class Initialized
DEBUG - 2013-12-01 08:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:04:10 --> Language Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Loader Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Session Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:04:10 --> Session routines successfully run
DEBUG - 2013-12-01 08:04:10 --> Controller Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:04:10 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:04:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:04:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:04:10 --> Model Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Model Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Model Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Model Class Initialized
DEBUG - 2013-12-01 08:04:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:04:11 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:04:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 08:04:11 --> XSS Filtering completed
DEBUG - 2013-12-01 08:04:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:04:11 --> Final output sent to browser
DEBUG - 2013-12-01 08:04:11 --> Total execution time: 1.8991
DEBUG - 2013-12-01 08:04:18 --> Config Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:04:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:04:18 --> URI Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Router Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Output Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Security Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Input Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:04:18 --> Language Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Loader Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:04:18 --> Session Class Initialized
DEBUG - 2013-12-01 08:04:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:04:19 --> Session garbage collection performed.
DEBUG - 2013-12-01 08:04:19 --> Session routines successfully run
DEBUG - 2013-12-01 08:04:19 --> Controller Class Initialized
DEBUG - 2013-12-01 08:04:19 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:04:19 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:04:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:04:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:04:19 --> Model Class Initialized
DEBUG - 2013-12-01 08:04:19 --> Model Class Initialized
DEBUG - 2013-12-01 08:04:19 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:04:19 --> Model Class Initialized
DEBUG - 2013-12-01 08:04:19 --> Model Class Initialized
DEBUG - 2013-12-01 08:04:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:04:19 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:04:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 08:04:19 --> XSS Filtering completed
DEBUG - 2013-12-01 08:04:20 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:04:20 --> Final output sent to browser
DEBUG - 2013-12-01 08:04:20 --> Total execution time: 1.9351
DEBUG - 2013-12-01 08:26:26 --> Config Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:26:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:26:26 --> URI Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Router Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Output Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Security Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Input Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:26:26 --> Language Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Loader Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Session Class Initialized
DEBUG - 2013-12-01 08:26:26 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:26:26 --> Session routines successfully run
DEBUG - 2013-12-01 08:26:26 --> Controller Class Initialized
DEBUG - 2013-12-01 08:26:27 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:26:27 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:26:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:26:27 --> Model Class Initialized
DEBUG - 2013-12-01 08:26:27 --> Model Class Initialized
DEBUG - 2013-12-01 08:26:27 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:26:27 --> Model Class Initialized
DEBUG - 2013-12-01 08:26:27 --> Model Class Initialized
DEBUG - 2013-12-01 08:26:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:26:27 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:26:27 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:26:28 --> Final output sent to browser
DEBUG - 2013-12-01 08:26:28 --> Total execution time: 1.7581
DEBUG - 2013-12-01 08:26:43 --> Config Class Initialized
DEBUG - 2013-12-01 08:26:43 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:26:43 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:26:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:26:43 --> URI Class Initialized
DEBUG - 2013-12-01 08:26:43 --> Router Class Initialized
DEBUG - 2013-12-01 08:26:43 --> Output Class Initialized
DEBUG - 2013-12-01 08:26:43 --> Security Class Initialized
DEBUG - 2013-12-01 08:26:43 --> Input Class Initialized
DEBUG - 2013-12-01 08:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:26:43 --> Language Class Initialized
DEBUG - 2013-12-01 08:26:43 --> Loader Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Session Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:26:44 --> Session routines successfully run
DEBUG - 2013-12-01 08:26:44 --> Controller Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:26:44 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:26:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:26:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:26:44 --> Model Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Model Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Model Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Model Class Initialized
DEBUG - 2013-12-01 08:26:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:26:44 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:26:45 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:26:45 --> Final output sent to browser
DEBUG - 2013-12-01 08:26:45 --> Total execution time: 1.9441
DEBUG - 2013-12-01 08:28:07 --> Config Class Initialized
DEBUG - 2013-12-01 08:28:07 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:28:07 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:28:07 --> URI Class Initialized
DEBUG - 2013-12-01 08:28:07 --> Router Class Initialized
DEBUG - 2013-12-01 08:28:07 --> Output Class Initialized
DEBUG - 2013-12-01 08:28:07 --> Security Class Initialized
DEBUG - 2013-12-01 08:28:07 --> Input Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:28:08 --> Language Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Loader Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Session Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:28:08 --> Session routines successfully run
DEBUG - 2013-12-01 08:28:08 --> Controller Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:28:08 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:28:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:28:08 --> Model Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Model Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:28:08 --> Model Class Initialized
DEBUG - 2013-12-01 08:28:09 --> Model Class Initialized
DEBUG - 2013-12-01 08:28:09 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:28:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:28:09 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:28:09 --> Final output sent to browser
DEBUG - 2013-12-01 08:28:09 --> Total execution time: 1.9231
DEBUG - 2013-12-01 08:28:48 --> Config Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:28:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:28:48 --> URI Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Router Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Output Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Security Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Input Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:28:48 --> Language Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Loader Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:28:48 --> Session Class Initialized
DEBUG - 2013-12-01 08:28:49 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:28:49 --> Session routines successfully run
DEBUG - 2013-12-01 08:28:49 --> Controller Class Initialized
DEBUG - 2013-12-01 08:28:49 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:28:49 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:28:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:28:49 --> Model Class Initialized
DEBUG - 2013-12-01 08:28:49 --> Model Class Initialized
DEBUG - 2013-12-01 08:28:49 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:28:49 --> Model Class Initialized
DEBUG - 2013-12-01 08:28:49 --> Model Class Initialized
DEBUG - 2013-12-01 08:28:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:28:49 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:28:49 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:28:50 --> Final output sent to browser
DEBUG - 2013-12-01 08:28:50 --> Total execution time: 1.7591
DEBUG - 2013-12-01 08:29:13 --> Config Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:29:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:29:13 --> URI Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Router Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Output Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Security Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Input Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:29:13 --> Language Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Loader Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Session Class Initialized
DEBUG - 2013-12-01 08:29:13 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:29:14 --> Session routines successfully run
DEBUG - 2013-12-01 08:29:14 --> Controller Class Initialized
DEBUG - 2013-12-01 08:29:14 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:29:14 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:29:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:29:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:29:14 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:14 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:29:14 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:14 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:29:14 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:29:15 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:29:15 --> Final output sent to browser
DEBUG - 2013-12-01 08:29:15 --> Total execution time: 2.1181
DEBUG - 2013-12-01 08:29:20 --> Config Class Initialized
DEBUG - 2013-12-01 08:29:20 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:29:20 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:29:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:29:20 --> URI Class Initialized
DEBUG - 2013-12-01 08:29:20 --> Router Class Initialized
DEBUG - 2013-12-01 08:29:20 --> Output Class Initialized
DEBUG - 2013-12-01 08:29:20 --> Security Class Initialized
DEBUG - 2013-12-01 08:29:20 --> Input Class Initialized
DEBUG - 2013-12-01 08:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:29:21 --> Language Class Initialized
DEBUG - 2013-12-01 08:29:21 --> Loader Class Initialized
DEBUG - 2013-12-01 08:29:21 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:29:21 --> Session Class Initialized
DEBUG - 2013-12-01 08:29:21 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:29:21 --> Session routines successfully run
DEBUG - 2013-12-01 08:29:21 --> Controller Class Initialized
DEBUG - 2013-12-01 08:29:21 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:29:21 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:29:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:29:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:29:21 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:21 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:29:22 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:22 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:29:22 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:29:22 --> Final output sent to browser
DEBUG - 2013-12-01 08:29:22 --> Total execution time: 1.8551
DEBUG - 2013-12-01 08:29:58 --> Config Class Initialized
DEBUG - 2013-12-01 08:29:58 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:29:58 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:29:58 --> URI Class Initialized
DEBUG - 2013-12-01 08:29:58 --> Router Class Initialized
DEBUG - 2013-12-01 08:29:58 --> Output Class Initialized
DEBUG - 2013-12-01 08:29:58 --> Security Class Initialized
DEBUG - 2013-12-01 08:29:58 --> Input Class Initialized
DEBUG - 2013-12-01 08:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:29:58 --> Language Class Initialized
DEBUG - 2013-12-01 08:29:59 --> Loader Class Initialized
DEBUG - 2013-12-01 08:29:59 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:29:59 --> Session Class Initialized
DEBUG - 2013-12-01 08:29:59 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:29:59 --> Session routines successfully run
DEBUG - 2013-12-01 08:29:59 --> Controller Class Initialized
DEBUG - 2013-12-01 08:29:59 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:29:59 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:29:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:29:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:29:59 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:59 --> Model Class Initialized
DEBUG - 2013-12-01 08:29:59 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:29:59 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:00 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:30:00 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:30:00 --> Final output sent to browser
DEBUG - 2013-12-01 08:30:00 --> Total execution time: 1.8611
DEBUG - 2013-12-01 08:30:32 --> Config Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:30:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:30:32 --> URI Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Router Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Output Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Security Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Input Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:30:32 --> Language Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Loader Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Session Class Initialized
DEBUG - 2013-12-01 08:30:32 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:30:33 --> Session routines successfully run
DEBUG - 2013-12-01 08:30:33 --> Controller Class Initialized
DEBUG - 2013-12-01 08:30:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:30:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:30:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:30:33 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:33 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:30:33 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:33 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:30:34 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:30:34 --> Final output sent to browser
DEBUG - 2013-12-01 08:30:34 --> Total execution time: 1.9561
DEBUG - 2013-12-01 08:30:38 --> Config Class Initialized
DEBUG - 2013-12-01 08:30:38 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:30:38 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:30:38 --> URI Class Initialized
DEBUG - 2013-12-01 08:30:38 --> Router Class Initialized
DEBUG - 2013-12-01 08:30:38 --> Output Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Security Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Input Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:30:39 --> Language Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Loader Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Session Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:30:39 --> Session routines successfully run
DEBUG - 2013-12-01 08:30:39 --> Controller Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:30:39 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:30:39 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:30:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:30:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:30:40 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:40 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:40 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:30:40 --> Upload Class Initialized
DEBUG - 2013-12-01 08:30:40 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:30:40 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:30:40 --> Helper loaded: cookie_helper
ERROR - 2013-12-01 08:30:40 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 08:30:40 --> Severity: Notice  --> Undefined index: ip_address C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 08:30:40 --> Severity: Notice  --> Undefined index: user_agent C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 08:30:40 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 08:30:40 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 288
ERROR - 2013-12-01 08:30:40 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 289
DEBUG - 2013-12-01 08:30:41 --> Config Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:30:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:30:41 --> URI Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Router Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Output Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Security Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Input Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:30:41 --> Language Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Loader Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:30:41 --> Session Class Initialized
DEBUG - 2013-12-01 08:30:42 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:30:42 --> Session routines successfully run
DEBUG - 2013-12-01 08:30:42 --> Controller Class Initialized
DEBUG - 2013-12-01 08:30:42 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:30:42 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:30:42 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:30:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:30:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:30:42 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:42 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:42 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:30:42 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 08:30:42 --> Upload Class Initialized
DEBUG - 2013-12-01 08:30:42 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:30:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:30:43 --> Config Class Initialized
DEBUG - 2013-12-01 08:30:43 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:30:43 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:30:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:30:43 --> URI Class Initialized
DEBUG - 2013-12-01 08:30:43 --> Router Class Initialized
DEBUG - 2013-12-01 08:30:43 --> Output Class Initialized
DEBUG - 2013-12-01 08:30:43 --> Security Class Initialized
DEBUG - 2013-12-01 08:30:43 --> Input Class Initialized
DEBUG - 2013-12-01 08:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:30:43 --> Language Class Initialized
DEBUG - 2013-12-01 08:30:43 --> Loader Class Initialized
DEBUG - 2013-12-01 08:30:44 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:30:44 --> Session Class Initialized
DEBUG - 2013-12-01 08:30:44 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:30:44 --> Session routines successfully run
DEBUG - 2013-12-01 08:30:44 --> Controller Class Initialized
DEBUG - 2013-12-01 08:30:44 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:30:44 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:30:44 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:30:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:30:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:30:44 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:44 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:44 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:30:44 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 08:30:44 --> Upload Class Initialized
DEBUG - 2013-12-01 08:30:45 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:30:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:30:45 --> Model Class Initialized
DEBUG - 2013-12-01 08:30:45 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 08:30:45 --> Final output sent to browser
DEBUG - 2013-12-01 08:30:45 --> Total execution time: 2.2051
DEBUG - 2013-12-01 08:31:15 --> Config Class Initialized
DEBUG - 2013-12-01 08:31:15 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:31:15 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:31:15 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:31:15 --> URI Class Initialized
DEBUG - 2013-12-01 08:31:15 --> Router Class Initialized
DEBUG - 2013-12-01 08:31:15 --> Output Class Initialized
DEBUG - 2013-12-01 08:31:15 --> Security Class Initialized
DEBUG - 2013-12-01 08:31:15 --> Input Class Initialized
DEBUG - 2013-12-01 08:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:31:16 --> Language Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Loader Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Session Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:31:16 --> Session routines successfully run
DEBUG - 2013-12-01 08:31:16 --> Controller Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:31:16 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:31:16 --> Form Validation Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:31:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:31:16 --> Model Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Model Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:31:16 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 08:31:17 --> Upload Class Initialized
DEBUG - 2013-12-01 08:31:17 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:31:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:31:17 --> XSS Filtering completed
DEBUG - 2013-12-01 08:31:17 --> Model Class Initialized
DEBUG - 2013-12-01 08:31:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 08:31:17 --> XSS Filtering completed
DEBUG - 2013-12-01 08:31:17 --> XSS Filtering completed
DEBUG - 2013-12-01 08:31:18 --> Config Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 08:31:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 08:31:18 --> URI Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Router Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Output Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Security Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Input Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 08:31:18 --> Language Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Loader Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Database Driver Class Initialized
DEBUG - 2013-12-01 08:31:18 --> Session Class Initialized
DEBUG - 2013-12-01 08:31:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 08:31:19 --> Session routines successfully run
DEBUG - 2013-12-01 08:31:19 --> Controller Class Initialized
DEBUG - 2013-12-01 08:31:19 --> Helper loaded: form_helper
DEBUG - 2013-12-01 08:31:19 --> Helper loaded: url_helper
DEBUG - 2013-12-01 08:31:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 08:31:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 08:31:19 --> Model Class Initialized
DEBUG - 2013-12-01 08:31:19 --> Model Class Initialized
DEBUG - 2013-12-01 08:31:19 --> Image Lib Class Initialized
DEBUG - 2013-12-01 08:31:19 --> Model Class Initialized
DEBUG - 2013-12-01 08:31:19 --> Model Class Initialized
DEBUG - 2013-12-01 08:31:19 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 08:31:19 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 08:31:20 --> Final output sent to browser
DEBUG - 2013-12-01 08:31:20 --> Total execution time: 1.7811
DEBUG - 2013-12-01 19:02:58 --> Config Class Initialized
DEBUG - 2013-12-01 19:02:58 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:02:58 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:02:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:02:58 --> URI Class Initialized
DEBUG - 2013-12-01 19:02:58 --> Router Class Initialized
DEBUG - 2013-12-01 19:02:58 --> Output Class Initialized
DEBUG - 2013-12-01 19:02:58 --> Security Class Initialized
DEBUG - 2013-12-01 19:02:58 --> Input Class Initialized
DEBUG - 2013-12-01 19:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:02:58 --> Language Class Initialized
DEBUG - 2013-12-01 19:02:58 --> Loader Class Initialized
DEBUG - 2013-12-01 19:02:59 --> Database Driver Class Initialized
ERROR - 2013-12-01 19:02:59 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-12-01 19:02:59 --> Session Class Initialized
DEBUG - 2013-12-01 19:02:59 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:02:59 --> Session routines successfully run
DEBUG - 2013-12-01 19:02:59 --> Controller Class Initialized
DEBUG - 2013-12-01 19:02:59 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:02:59 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:02:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:02:59 --> Model Class Initialized
DEBUG - 2013-12-01 19:02:59 --> Model Class Initialized
DEBUG - 2013-12-01 19:02:59 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:02:59 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 19:03:00 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:03:00 --> Config Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:03:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:03:00 --> URI Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Router Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Output Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Security Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Input Class Initialized
DEBUG - 2013-12-01 19:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:03:01 --> Language Class Initialized
DEBUG - 2013-12-01 19:03:01 --> Loader Class Initialized
DEBUG - 2013-12-01 19:03:01 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:03:01 --> Session Class Initialized
DEBUG - 2013-12-01 19:03:01 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:03:01 --> A session cookie was not found.
DEBUG - 2013-12-01 19:03:01 --> Session routines successfully run
DEBUG - 2013-12-01 19:03:01 --> Controller Class Initialized
DEBUG - 2013-12-01 19:03:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:03:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:03:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:03:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:02 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:02 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:02 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:03:02 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 19:03:02 --> Upload Class Initialized
DEBUG - 2013-12-01 19:03:02 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:03:02 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:02 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 19:03:02 --> Final output sent to browser
DEBUG - 2013-12-01 19:03:02 --> Total execution time: 2.5151
DEBUG - 2013-12-01 19:03:08 --> Config Class Initialized
DEBUG - 2013-12-01 19:03:08 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:03:08 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:03:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:03:08 --> URI Class Initialized
DEBUG - 2013-12-01 19:03:08 --> Router Class Initialized
DEBUG - 2013-12-01 19:03:08 --> Output Class Initialized
DEBUG - 2013-12-01 19:03:08 --> Security Class Initialized
DEBUG - 2013-12-01 19:03:08 --> Input Class Initialized
DEBUG - 2013-12-01 19:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:03:08 --> Language Class Initialized
DEBUG - 2013-12-01 19:03:08 --> Loader Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Session Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:03:09 --> Session routines successfully run
DEBUG - 2013-12-01 19:03:09 --> Controller Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:03:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:03:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:09 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 19:03:09 --> Upload Class Initialized
DEBUG - 2013-12-01 19:03:09 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:03:10 --> XSS Filtering completed
DEBUG - 2013-12-01 19:03:10 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 19:03:10 --> XSS Filtering completed
DEBUG - 2013-12-01 19:03:10 --> XSS Filtering completed
DEBUG - 2013-12-01 19:03:10 --> Config Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:03:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:03:11 --> URI Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Router Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Output Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Security Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Input Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:03:11 --> Language Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Loader Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Session Class Initialized
DEBUG - 2013-12-01 19:03:11 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:03:11 --> Session routines successfully run
DEBUG - 2013-12-01 19:03:12 --> Controller Class Initialized
DEBUG - 2013-12-01 19:03:12 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:03:12 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:03:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:03:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:12 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:12 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:12 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:03:12 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:12 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:03:13 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 19:03:13 --> Final output sent to browser
DEBUG - 2013-12-01 19:03:13 --> Total execution time: 2.1661
DEBUG - 2013-12-01 19:03:19 --> Config Class Initialized
DEBUG - 2013-12-01 19:03:19 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:03:19 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:03:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:03:19 --> URI Class Initialized
DEBUG - 2013-12-01 19:03:19 --> Router Class Initialized
DEBUG - 2013-12-01 19:03:19 --> Output Class Initialized
DEBUG - 2013-12-01 19:03:19 --> Security Class Initialized
DEBUG - 2013-12-01 19:03:19 --> Input Class Initialized
DEBUG - 2013-12-01 19:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:03:19 --> Language Class Initialized
DEBUG - 2013-12-01 19:03:20 --> Loader Class Initialized
DEBUG - 2013-12-01 19:03:20 --> Database Driver Class Initialized
ERROR - 2013-12-01 19:03:20 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-12-01 19:03:20 --> Session Class Initialized
DEBUG - 2013-12-01 19:03:20 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:03:20 --> Session routines successfully run
DEBUG - 2013-12-01 19:03:20 --> Controller Class Initialized
DEBUG - 2013-12-01 19:03:20 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:03:20 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:03:20 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:03:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:03:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:20 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:20 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:03:21 --> Upload Class Initialized
DEBUG - 2013-12-01 19:03:21 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:21 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 19:03:21 --> 404 Page Not Found --> errors/page_missing
DEBUG - 2013-12-01 19:03:38 --> Config Class Initialized
DEBUG - 2013-12-01 19:03:38 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:03:38 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:03:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:03:38 --> URI Class Initialized
DEBUG - 2013-12-01 19:03:38 --> Router Class Initialized
DEBUG - 2013-12-01 19:03:38 --> Output Class Initialized
DEBUG - 2013-12-01 19:03:38 --> Security Class Initialized
DEBUG - 2013-12-01 19:03:38 --> Input Class Initialized
DEBUG - 2013-12-01 19:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:03:38 --> Language Class Initialized
DEBUG - 2013-12-01 19:03:39 --> Loader Class Initialized
DEBUG - 2013-12-01 19:03:39 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:03:39 --> Session Class Initialized
DEBUG - 2013-12-01 19:03:39 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:03:39 --> Session routines successfully run
DEBUG - 2013-12-01 19:03:39 --> Controller Class Initialized
DEBUG - 2013-12-01 19:03:39 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:03:39 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:03:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:39 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:03:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:40 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:40 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:03:40 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 19:03:40 --> Final output sent to browser
DEBUG - 2013-12-01 19:03:40 --> Total execution time: 1.9601
DEBUG - 2013-12-01 19:03:41 --> Config Class Initialized
DEBUG - 2013-12-01 19:03:41 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:03:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:03:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:03:41 --> URI Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Router Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Output Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Security Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Input Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:03:42 --> Language Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Loader Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Session Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:03:42 --> Session routines successfully run
DEBUG - 2013-12-01 19:03:42 --> Controller Class Initialized
DEBUG - 2013-12-01 19:03:42 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:03:42 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:03:43 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:03:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:43 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:43 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:43 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:03:43 --> Upload Class Initialized
DEBUG - 2013-12-01 19:03:43 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:03:58 --> Config Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:03:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:03:58 --> URI Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Router Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Output Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Security Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Input Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:03:58 --> Language Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Loader Class Initialized
DEBUG - 2013-12-01 19:03:58 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:03:59 --> Session Class Initialized
DEBUG - 2013-12-01 19:03:59 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:03:59 --> Session routines successfully run
DEBUG - 2013-12-01 19:03:59 --> Controller Class Initialized
DEBUG - 2013-12-01 19:03:59 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:03:59 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:03:59 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:03:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:03:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:03:59 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:59 --> Model Class Initialized
DEBUG - 2013-12-01 19:03:59 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:03:59 --> Upload Class Initialized
DEBUG - 2013-12-01 19:03:59 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:04:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:04:16 --> Config Class Initialized
DEBUG - 2013-12-01 19:04:16 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:04:16 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:04:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:04:16 --> URI Class Initialized
DEBUG - 2013-12-01 19:04:16 --> Router Class Initialized
DEBUG - 2013-12-01 19:04:16 --> Output Class Initialized
DEBUG - 2013-12-01 19:04:16 --> Security Class Initialized
DEBUG - 2013-12-01 19:04:16 --> Input Class Initialized
DEBUG - 2013-12-01 19:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:04:16 --> Language Class Initialized
DEBUG - 2013-12-01 19:04:16 --> Loader Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Session Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:04:17 --> Session routines successfully run
DEBUG - 2013-12-01 19:04:17 --> Controller Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:04:17 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:04:17 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:04:17 --> Model Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Model Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Upload Class Initialized
DEBUG - 2013-12-01 19:04:17 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:04:18 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: user C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 5
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: user C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 26
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: user C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 44
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: user C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 56
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: user C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 60
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: user C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 60
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: use_username C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 86
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 109
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 110
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 111
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 114
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 115
ERROR - 2013-12-01 19:04:18 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 116
ERROR - 2013-12-01 19:04:19 --> Severity: Notice  --> Undefined variable: captcha_registration C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 129
DEBUG - 2013-12-01 19:04:19 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:04:19 --> Final output sent to browser
DEBUG - 2013-12-01 19:04:19 --> Total execution time: 2.8582
DEBUG - 2013-12-01 19:15:38 --> Config Class Initialized
DEBUG - 2013-12-01 19:15:38 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:15:38 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:15:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:15:38 --> URI Class Initialized
DEBUG - 2013-12-01 19:15:38 --> Router Class Initialized
DEBUG - 2013-12-01 19:15:38 --> Output Class Initialized
DEBUG - 2013-12-01 19:15:38 --> Security Class Initialized
DEBUG - 2013-12-01 19:15:38 --> Input Class Initialized
DEBUG - 2013-12-01 19:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:15:39 --> Language Class Initialized
DEBUG - 2013-12-01 19:15:39 --> Loader Class Initialized
DEBUG - 2013-12-01 19:15:39 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:15:39 --> Session Class Initialized
DEBUG - 2013-12-01 19:15:39 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:15:39 --> Session routines successfully run
DEBUG - 2013-12-01 19:15:39 --> Controller Class Initialized
DEBUG - 2013-12-01 19:15:39 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:15:39 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:15:39 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:15:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:15:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:15:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:15:39 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:15:40 --> Upload Class Initialized
DEBUG - 2013-12-01 19:15:40 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:15:40 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 19:15:40 --> Severity: Warning  --> Missing argument 2 for Users::get_user_by_id(), called in C:\Program Files (x86)\Ampps\www\project\application\controllers\auth.php on line 626 and defined C:\Program Files (x86)\Ampps\www\project\application\models\tank_auth\users.php 34
ERROR - 2013-12-01 19:15:40 --> Severity: Notice  --> Undefined variable: activated C:\Program Files (x86)\Ampps\www\project\application\models\tank_auth\users.php 40
DEBUG - 2013-12-01 19:15:40 --> DB Transaction Failure
ERROR - 2013-12-01 19:15:40 --> Query error: Not unique table/alias: 'users'
DEBUG - 2013-12-01 19:15:40 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 19:16:00 --> Config Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:16:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:16:00 --> URI Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Router Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Output Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Security Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Input Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:16:00 --> Language Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Loader Class Initialized
DEBUG - 2013-12-01 19:16:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:16:01 --> Session Class Initialized
DEBUG - 2013-12-01 19:16:01 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:16:01 --> Session routines successfully run
DEBUG - 2013-12-01 19:16:01 --> Controller Class Initialized
DEBUG - 2013-12-01 19:16:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:16:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:16:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:16:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:16:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:16:01 --> Model Class Initialized
DEBUG - 2013-12-01 19:16:01 --> Model Class Initialized
DEBUG - 2013-12-01 19:16:01 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:16:01 --> Upload Class Initialized
DEBUG - 2013-12-01 19:16:01 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:16:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:16:02 --> DB Transaction Failure
ERROR - 2013-12-01 19:16:02 --> Query error: Not unique table/alias: 'users'
DEBUG - 2013-12-01 19:16:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 19:27:12 --> Config Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:27:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:27:13 --> URI Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Router Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Output Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Security Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Input Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:27:13 --> Language Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Loader Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Session Class Initialized
DEBUG - 2013-12-01 19:27:13 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:27:13 --> Session routines successfully run
DEBUG - 2013-12-01 19:27:13 --> Controller Class Initialized
DEBUG - 2013-12-01 19:27:14 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:27:14 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:27:14 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:27:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:27:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:27:14 --> Model Class Initialized
DEBUG - 2013-12-01 19:27:14 --> Model Class Initialized
DEBUG - 2013-12-01 19:27:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:27:14 --> Upload Class Initialized
DEBUG - 2013-12-01 19:27:14 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:27:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:27:14 --> DB Transaction Failure
ERROR - 2013-12-01 19:27:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1
DEBUG - 2013-12-01 19:27:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 19:28:28 --> Config Class Initialized
DEBUG - 2013-12-01 19:28:28 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:28:28 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:28:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:28:28 --> URI Class Initialized
DEBUG - 2013-12-01 19:28:28 --> Router Class Initialized
DEBUG - 2013-12-01 19:28:28 --> Output Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Security Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Input Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:28:29 --> Language Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Loader Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Session Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:28:29 --> Session routines successfully run
DEBUG - 2013-12-01 19:28:29 --> Controller Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:28:29 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:28:29 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:28:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:28:30 --> Model Class Initialized
DEBUG - 2013-12-01 19:28:30 --> Model Class Initialized
DEBUG - 2013-12-01 19:28:30 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:28:30 --> Upload Class Initialized
DEBUG - 2013-12-01 19:28:30 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:28:30 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:28:30 --> DB Transaction Failure
ERROR - 2013-12-01 19:28:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1
DEBUG - 2013-12-01 19:28:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 19:28:51 --> Config Class Initialized
DEBUG - 2013-12-01 19:28:51 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:28:51 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:28:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:28:51 --> URI Class Initialized
DEBUG - 2013-12-01 19:28:51 --> Router Class Initialized
DEBUG - 2013-12-01 19:28:51 --> Output Class Initialized
DEBUG - 2013-12-01 19:28:51 --> Security Class Initialized
DEBUG - 2013-12-01 19:28:51 --> Input Class Initialized
DEBUG - 2013-12-01 19:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:28:51 --> Language Class Initialized
DEBUG - 2013-12-01 19:28:51 --> Loader Class Initialized
DEBUG - 2013-12-01 19:28:52 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:28:52 --> Session Class Initialized
DEBUG - 2013-12-01 19:28:52 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:28:52 --> Session routines successfully run
DEBUG - 2013-12-01 19:28:52 --> Controller Class Initialized
DEBUG - 2013-12-01 19:28:52 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:28:52 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:28:52 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:28:52 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:28:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:28:52 --> Model Class Initialized
DEBUG - 2013-12-01 19:28:52 --> Model Class Initialized
DEBUG - 2013-12-01 19:28:52 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:28:53 --> Upload Class Initialized
DEBUG - 2013-12-01 19:28:53 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:28:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:28:53 --> DB Transaction Failure
ERROR - 2013-12-01 19:28:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1
DEBUG - 2013-12-01 19:28:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 19:29:08 --> Config Class Initialized
DEBUG - 2013-12-01 19:29:08 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:29:08 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:29:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:29:08 --> URI Class Initialized
DEBUG - 2013-12-01 19:29:08 --> Router Class Initialized
DEBUG - 2013-12-01 19:29:08 --> Output Class Initialized
DEBUG - 2013-12-01 19:29:08 --> Security Class Initialized
DEBUG - 2013-12-01 19:29:08 --> Input Class Initialized
DEBUG - 2013-12-01 19:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:29:08 --> Language Class Initialized
DEBUG - 2013-12-01 19:29:08 --> Loader Class Initialized
DEBUG - 2013-12-01 19:29:09 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:29:09 --> Session Class Initialized
DEBUG - 2013-12-01 19:29:09 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:29:09 --> Session routines successfully run
DEBUG - 2013-12-01 19:29:09 --> Controller Class Initialized
DEBUG - 2013-12-01 19:29:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:29:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:29:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:29:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:29:09 --> Model Class Initialized
DEBUG - 2013-12-01 19:29:09 --> Model Class Initialized
DEBUG - 2013-12-01 19:29:09 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:29:10 --> Upload Class Initialized
DEBUG - 2013-12-01 19:29:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:29:10 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 19:29:10 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string C:\Program Files (x86)\Ampps\www\project\application\models\tank_auth\users.php 41
ERROR - 2013-12-01 19:29:10 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 199
ERROR - 2013-12-01 19:29:10 --> Severity: Warning  --> mysql_query() expects parameter 1 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2013-12-01 19:29:10 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\DB_driver.php 622
ERROR - 2013-12-01 19:29:10 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2013-12-01 19:29:10 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2013-12-01 19:29:10 --> Severity: Notice  --> Undefined variable: use_username C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 86
ERROR - 2013-12-01 19:29:10 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 109
ERROR - 2013-12-01 19:29:10 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 110
ERROR - 2013-12-01 19:29:10 --> Severity: Notice  --> Undefined variable: first_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 111
ERROR - 2013-12-01 19:29:10 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 114
ERROR - 2013-12-01 19:29:11 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 115
ERROR - 2013-12-01 19:29:11 --> Severity: Notice  --> Undefined variable: last_name C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 116
ERROR - 2013-12-01 19:29:11 --> Severity: Notice  --> Undefined variable: captcha_registration C:\Program Files (x86)\Ampps\www\project\application\views\auth\change_profile_form.php 129
DEBUG - 2013-12-01 19:29:11 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:29:11 --> Final output sent to browser
DEBUG - 2013-12-01 19:29:11 --> Total execution time: 3.0752
DEBUG - 2013-12-01 19:30:10 --> Config Class Initialized
DEBUG - 2013-12-01 19:30:10 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:30:10 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:30:10 --> URI Class Initialized
DEBUG - 2013-12-01 19:30:10 --> Router Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Output Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Security Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Input Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:30:11 --> Language Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Loader Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Session Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:30:11 --> Session routines successfully run
DEBUG - 2013-12-01 19:30:11 --> Controller Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:30:11 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:30:11 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:30:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:30:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:30:12 --> Model Class Initialized
DEBUG - 2013-12-01 19:30:12 --> Model Class Initialized
DEBUG - 2013-12-01 19:30:12 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:30:12 --> Upload Class Initialized
DEBUG - 2013-12-01 19:30:12 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:30:12 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 19:30:12 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string C:\Program Files (x86)\Ampps\www\project\application\models\tank_auth\users.php 41
ERROR - 2013-12-01 19:30:12 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 199
ERROR - 2013-12-01 19:30:12 --> Severity: Warning  --> mysql_query() expects parameter 1 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2013-12-01 19:30:12 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\DB_driver.php 622
ERROR - 2013-12-01 19:30:12 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2013-12-01 19:30:13 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_result.php 37
DEBUG - 2013-12-01 19:30:13 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:30:13 --> Final output sent to browser
DEBUG - 2013-12-01 19:30:13 --> Total execution time: 2.5271
DEBUG - 2013-12-01 19:30:38 --> Config Class Initialized
DEBUG - 2013-12-01 19:30:38 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:30:38 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:30:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:30:38 --> URI Class Initialized
DEBUG - 2013-12-01 19:30:38 --> Router Class Initialized
DEBUG - 2013-12-01 19:30:38 --> Output Class Initialized
DEBUG - 2013-12-01 19:30:38 --> Security Class Initialized
DEBUG - 2013-12-01 19:30:38 --> Input Class Initialized
DEBUG - 2013-12-01 19:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:30:38 --> Language Class Initialized
DEBUG - 2013-12-01 19:30:38 --> Loader Class Initialized
DEBUG - 2013-12-01 19:30:39 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:30:39 --> Session Class Initialized
DEBUG - 2013-12-01 19:30:39 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:30:39 --> Session routines successfully run
DEBUG - 2013-12-01 19:30:39 --> Controller Class Initialized
DEBUG - 2013-12-01 19:30:39 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:30:39 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:30:39 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:30:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:30:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:30:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:30:39 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:30:39 --> Upload Class Initialized
DEBUG - 2013-12-01 19:30:40 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:30:40 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 19:30:40 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 199
ERROR - 2013-12-01 19:30:40 --> Severity: Warning  --> mysql_query() expects parameter 1 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 179
ERROR - 2013-12-01 19:30:40 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, object given C:\Program Files (x86)\Ampps\www\project\system\database\DB_driver.php 622
ERROR - 2013-12-01 19:30:40 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_result.php 37
ERROR - 2013-12-01 19:30:40 --> Severity: Warning  --> mysql_num_rows() expects parameter 1 to be resource, null given C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_result.php 37
DEBUG - 2013-12-01 19:30:40 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:30:40 --> Final output sent to browser
DEBUG - 2013-12-01 19:30:40 --> Total execution time: 2.4791
DEBUG - 2013-12-01 19:31:09 --> Config Class Initialized
DEBUG - 2013-12-01 19:31:09 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:31:09 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:31:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:31:09 --> URI Class Initialized
DEBUG - 2013-12-01 19:31:09 --> Router Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Output Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Security Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Input Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:31:10 --> Language Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Loader Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Session Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:31:10 --> Session routines successfully run
DEBUG - 2013-12-01 19:31:10 --> Controller Class Initialized
DEBUG - 2013-12-01 19:31:10 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:31:10 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:31:10 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:31:11 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:31:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:31:11 --> Model Class Initialized
DEBUG - 2013-12-01 19:31:11 --> Model Class Initialized
DEBUG - 2013-12-01 19:31:11 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:31:11 --> Upload Class Initialized
DEBUG - 2013-12-01 19:31:11 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:31:11 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 19:31:11 --> Severity: Notice  --> Undefined variable: query C:\Program Files (x86)\Ampps\www\project\application\models\tank_auth\users.php 50
DEBUG - 2013-12-01 19:31:20 --> Config Class Initialized
DEBUG - 2013-12-01 19:31:20 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:31:20 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:31:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:31:20 --> URI Class Initialized
DEBUG - 2013-12-01 19:31:20 --> Router Class Initialized
DEBUG - 2013-12-01 19:31:20 --> Output Class Initialized
DEBUG - 2013-12-01 19:31:20 --> Security Class Initialized
DEBUG - 2013-12-01 19:31:20 --> Input Class Initialized
DEBUG - 2013-12-01 19:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:31:21 --> Language Class Initialized
DEBUG - 2013-12-01 19:31:21 --> Loader Class Initialized
DEBUG - 2013-12-01 19:31:21 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:31:21 --> Session Class Initialized
DEBUG - 2013-12-01 19:31:21 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:31:21 --> Session routines successfully run
DEBUG - 2013-12-01 19:31:21 --> Controller Class Initialized
DEBUG - 2013-12-01 19:31:21 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:31:21 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:31:21 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:31:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:31:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:31:21 --> Model Class Initialized
DEBUG - 2013-12-01 19:31:21 --> Model Class Initialized
DEBUG - 2013-12-01 19:31:22 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:31:22 --> Upload Class Initialized
DEBUG - 2013-12-01 19:31:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:31:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:32:04 --> Config Class Initialized
DEBUG - 2013-12-01 19:32:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:32:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:32:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:32:04 --> URI Class Initialized
DEBUG - 2013-12-01 19:32:04 --> Router Class Initialized
DEBUG - 2013-12-01 19:32:04 --> Output Class Initialized
DEBUG - 2013-12-01 19:32:04 --> Security Class Initialized
DEBUG - 2013-12-01 19:32:04 --> Input Class Initialized
DEBUG - 2013-12-01 19:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:32:05 --> Language Class Initialized
DEBUG - 2013-12-01 19:32:05 --> Loader Class Initialized
DEBUG - 2013-12-01 19:32:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:32:05 --> Session Class Initialized
DEBUG - 2013-12-01 19:32:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:32:05 --> Session routines successfully run
DEBUG - 2013-12-01 19:32:05 --> Controller Class Initialized
DEBUG - 2013-12-01 19:32:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:32:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:32:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:32:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:32:05 --> Model Class Initialized
DEBUG - 2013-12-01 19:32:06 --> Model Class Initialized
DEBUG - 2013-12-01 19:32:06 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:32:06 --> Upload Class Initialized
DEBUG - 2013-12-01 19:32:06 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:32:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:32:37 --> Config Class Initialized
DEBUG - 2013-12-01 19:32:37 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:32:37 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:32:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:32:37 --> URI Class Initialized
DEBUG - 2013-12-01 19:32:37 --> Router Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Output Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Security Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Input Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:32:38 --> Language Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Loader Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Session Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:32:38 --> Session routines successfully run
DEBUG - 2013-12-01 19:32:38 --> Controller Class Initialized
DEBUG - 2013-12-01 19:32:38 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:32:38 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:32:38 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:32:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:32:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:32:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:32:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:32:39 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:32:39 --> Upload Class Initialized
DEBUG - 2013-12-01 19:32:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:32:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:33:06 --> Config Class Initialized
DEBUG - 2013-12-01 19:33:06 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:33:06 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:33:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:33:07 --> URI Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Router Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Output Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Security Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Input Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:33:07 --> Language Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Loader Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Session Class Initialized
DEBUG - 2013-12-01 19:33:07 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:33:07 --> Session routines successfully run
DEBUG - 2013-12-01 19:33:07 --> Controller Class Initialized
DEBUG - 2013-12-01 19:33:08 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:33:08 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:33:08 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:33:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:33:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:33:08 --> Model Class Initialized
DEBUG - 2013-12-01 19:33:08 --> Model Class Initialized
DEBUG - 2013-12-01 19:33:08 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:33:08 --> Upload Class Initialized
DEBUG - 2013-12-01 19:33:08 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:33:08 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:33:16 --> Config Class Initialized
DEBUG - 2013-12-01 19:33:16 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:33:16 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:33:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:33:16 --> URI Class Initialized
DEBUG - 2013-12-01 19:33:16 --> Router Class Initialized
DEBUG - 2013-12-01 19:33:16 --> Output Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Security Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Input Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:33:17 --> Language Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Loader Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Session Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:33:17 --> Session routines successfully run
DEBUG - 2013-12-01 19:33:17 --> Controller Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:33:17 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:33:17 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:33:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:33:18 --> Model Class Initialized
DEBUG - 2013-12-01 19:33:18 --> Model Class Initialized
DEBUG - 2013-12-01 19:33:18 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:33:18 --> Upload Class Initialized
DEBUG - 2013-12-01 19:33:18 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:33:18 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:33:25 --> Config Class Initialized
DEBUG - 2013-12-01 19:33:25 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:33:25 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:33:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:33:26 --> URI Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Router Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Output Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Security Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Input Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:33:26 --> Language Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Loader Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Session Class Initialized
DEBUG - 2013-12-01 19:33:26 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:33:26 --> Session routines successfully run
DEBUG - 2013-12-01 19:33:26 --> Controller Class Initialized
DEBUG - 2013-12-01 19:33:27 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:33:27 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:33:27 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:33:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:33:27 --> Model Class Initialized
DEBUG - 2013-12-01 19:33:27 --> Model Class Initialized
DEBUG - 2013-12-01 19:33:27 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:33:27 --> Upload Class Initialized
DEBUG - 2013-12-01 19:33:27 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:33:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:33:55 --> Config Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:33:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:33:55 --> URI Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Router Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Output Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Security Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Input Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:33:55 --> Language Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Loader Class Initialized
DEBUG - 2013-12-01 19:33:55 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:33:56 --> Session Class Initialized
DEBUG - 2013-12-01 19:33:56 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:33:56 --> Session routines successfully run
DEBUG - 2013-12-01 19:33:56 --> Controller Class Initialized
DEBUG - 2013-12-01 19:33:56 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:33:56 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:33:56 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:33:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:33:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:33:56 --> Model Class Initialized
DEBUG - 2013-12-01 19:33:56 --> Model Class Initialized
DEBUG - 2013-12-01 19:33:56 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:33:57 --> Upload Class Initialized
DEBUG - 2013-12-01 19:33:57 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:33:57 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:35:21 --> Config Class Initialized
DEBUG - 2013-12-01 19:35:21 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:35:21 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:35:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:35:21 --> URI Class Initialized
DEBUG - 2013-12-01 19:35:21 --> Router Class Initialized
DEBUG - 2013-12-01 19:35:21 --> Output Class Initialized
DEBUG - 2013-12-01 19:35:21 --> Security Class Initialized
DEBUG - 2013-12-01 19:35:21 --> Input Class Initialized
DEBUG - 2013-12-01 19:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:35:21 --> Language Class Initialized
DEBUG - 2013-12-01 19:35:22 --> Loader Class Initialized
DEBUG - 2013-12-01 19:35:22 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:35:22 --> Session Class Initialized
DEBUG - 2013-12-01 19:35:22 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:35:22 --> Session routines successfully run
DEBUG - 2013-12-01 19:35:22 --> Controller Class Initialized
DEBUG - 2013-12-01 19:35:22 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:35:22 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:35:22 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:35:22 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:35:22 --> Model Class Initialized
DEBUG - 2013-12-01 19:35:22 --> Model Class Initialized
DEBUG - 2013-12-01 19:35:23 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:35:23 --> Upload Class Initialized
DEBUG - 2013-12-01 19:35:23 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:35:23 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:35:54 --> Config Class Initialized
DEBUG - 2013-12-01 19:35:54 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:35:54 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:35:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:35:54 --> URI Class Initialized
DEBUG - 2013-12-01 19:35:54 --> Router Class Initialized
DEBUG - 2013-12-01 19:35:54 --> Output Class Initialized
DEBUG - 2013-12-01 19:35:55 --> Security Class Initialized
DEBUG - 2013-12-01 19:35:55 --> Input Class Initialized
DEBUG - 2013-12-01 19:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:35:55 --> Language Class Initialized
DEBUG - 2013-12-01 19:35:55 --> Loader Class Initialized
DEBUG - 2013-12-01 19:35:55 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:35:55 --> Session Class Initialized
DEBUG - 2013-12-01 19:35:55 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:35:55 --> Session routines successfully run
DEBUG - 2013-12-01 19:35:55 --> Controller Class Initialized
DEBUG - 2013-12-01 19:35:55 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:35:55 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:35:55 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:35:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:35:56 --> Model Class Initialized
DEBUG - 2013-12-01 19:35:56 --> Model Class Initialized
DEBUG - 2013-12-01 19:35:56 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:35:56 --> Upload Class Initialized
DEBUG - 2013-12-01 19:35:56 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:35:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:36:34 --> Config Class Initialized
DEBUG - 2013-12-01 19:36:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:36:34 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:36:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:36:34 --> URI Class Initialized
DEBUG - 2013-12-01 19:36:34 --> Router Class Initialized
DEBUG - 2013-12-01 19:36:34 --> Output Class Initialized
DEBUG - 2013-12-01 19:36:34 --> Security Class Initialized
DEBUG - 2013-12-01 19:36:34 --> Input Class Initialized
DEBUG - 2013-12-01 19:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:36:35 --> Language Class Initialized
DEBUG - 2013-12-01 19:36:35 --> Loader Class Initialized
DEBUG - 2013-12-01 19:36:35 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:36:35 --> Session Class Initialized
DEBUG - 2013-12-01 19:36:35 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:36:35 --> Session routines successfully run
DEBUG - 2013-12-01 19:36:35 --> Controller Class Initialized
DEBUG - 2013-12-01 19:36:35 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:36:35 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:36:35 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:36:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:36:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:36:35 --> Model Class Initialized
DEBUG - 2013-12-01 19:36:36 --> Model Class Initialized
DEBUG - 2013-12-01 19:36:36 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:36:36 --> Upload Class Initialized
DEBUG - 2013-12-01 19:36:36 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:36:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:37:06 --> Config Class Initialized
DEBUG - 2013-12-01 19:37:06 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:37:06 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:37:07 --> URI Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Router Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Output Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Security Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Input Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:37:07 --> Language Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Loader Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Session Class Initialized
DEBUG - 2013-12-01 19:37:07 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:37:07 --> Session routines successfully run
DEBUG - 2013-12-01 19:37:07 --> Controller Class Initialized
DEBUG - 2013-12-01 19:37:08 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:37:08 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:37:08 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:37:08 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:37:08 --> Model Class Initialized
DEBUG - 2013-12-01 19:37:08 --> Model Class Initialized
DEBUG - 2013-12-01 19:37:08 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:37:08 --> Upload Class Initialized
DEBUG - 2013-12-01 19:37:08 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:37:08 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:37:26 --> Config Class Initialized
DEBUG - 2013-12-01 19:37:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:37:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:37:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:37:26 --> URI Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Router Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Output Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Security Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Input Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:37:27 --> Language Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Loader Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Session Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:37:27 --> Session routines successfully run
DEBUG - 2013-12-01 19:37:27 --> Controller Class Initialized
DEBUG - 2013-12-01 19:37:27 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:37:27 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:37:28 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:37:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:37:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:37:31 --> Model Class Initialized
DEBUG - 2013-12-01 19:37:31 --> Model Class Initialized
DEBUG - 2013-12-01 19:37:31 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:37:31 --> Upload Class Initialized
DEBUG - 2013-12-01 19:37:31 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:37:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:37:56 --> Config Class Initialized
DEBUG - 2013-12-01 19:37:56 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:37:56 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:37:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:37:56 --> URI Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Router Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Output Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Security Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Input Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:37:57 --> Language Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Loader Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Session Class Initialized
DEBUG - 2013-12-01 19:37:57 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:37:57 --> Session routines successfully run
DEBUG - 2013-12-01 19:37:57 --> Controller Class Initialized
DEBUG - 2013-12-01 19:37:58 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:37:58 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:37:58 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:37:58 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:37:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:37:58 --> Model Class Initialized
DEBUG - 2013-12-01 19:37:58 --> Model Class Initialized
DEBUG - 2013-12-01 19:37:58 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:37:58 --> Upload Class Initialized
DEBUG - 2013-12-01 19:37:58 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:37:58 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:38:18 --> Config Class Initialized
DEBUG - 2013-12-01 19:38:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:38:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:38:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:38:18 --> URI Class Initialized
DEBUG - 2013-12-01 19:38:18 --> Router Class Initialized
DEBUG - 2013-12-01 19:38:19 --> Output Class Initialized
DEBUG - 2013-12-01 19:38:19 --> Security Class Initialized
DEBUG - 2013-12-01 19:38:19 --> Input Class Initialized
DEBUG - 2013-12-01 19:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:38:19 --> Language Class Initialized
DEBUG - 2013-12-01 19:38:19 --> Loader Class Initialized
DEBUG - 2013-12-01 19:38:19 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:38:19 --> Session Class Initialized
DEBUG - 2013-12-01 19:38:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:38:19 --> Session garbage collection performed.
DEBUG - 2013-12-01 19:38:19 --> Session routines successfully run
DEBUG - 2013-12-01 19:38:19 --> Controller Class Initialized
DEBUG - 2013-12-01 19:38:20 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:38:20 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:38:20 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:38:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:38:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:38:20 --> Model Class Initialized
DEBUG - 2013-12-01 19:38:20 --> Model Class Initialized
DEBUG - 2013-12-01 19:38:20 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:38:20 --> Upload Class Initialized
DEBUG - 2013-12-01 19:38:20 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:38:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:38:37 --> Config Class Initialized
DEBUG - 2013-12-01 19:38:37 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:38:37 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:38:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:38:37 --> URI Class Initialized
DEBUG - 2013-12-01 19:38:37 --> Router Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Output Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Security Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Input Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:38:38 --> Language Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Loader Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Session Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:38:38 --> Session routines successfully run
DEBUG - 2013-12-01 19:38:38 --> Controller Class Initialized
DEBUG - 2013-12-01 19:38:38 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:38:38 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:38:38 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:38:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:38:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:38:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:38:39 --> Model Class Initialized
DEBUG - 2013-12-01 19:38:39 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:38:39 --> Upload Class Initialized
DEBUG - 2013-12-01 19:38:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:38:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:39:31 --> Config Class Initialized
DEBUG - 2013-12-01 19:39:31 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:39:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:39:32 --> URI Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Router Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Output Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Security Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Input Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:39:32 --> Language Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Loader Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Session Class Initialized
DEBUG - 2013-12-01 19:39:32 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:39:32 --> Session routines successfully run
DEBUG - 2013-12-01 19:39:33 --> Controller Class Initialized
DEBUG - 2013-12-01 19:39:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:39:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:39:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:39:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:39:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:39:33 --> Model Class Initialized
DEBUG - 2013-12-01 19:39:33 --> Model Class Initialized
DEBUG - 2013-12-01 19:39:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:39:34 --> Upload Class Initialized
DEBUG - 2013-12-01 19:39:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:39:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:39:34 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:39:34 --> Final output sent to browser
DEBUG - 2013-12-01 19:39:34 --> Total execution time: 2.4641
DEBUG - 2013-12-01 19:40:03 --> Config Class Initialized
DEBUG - 2013-12-01 19:40:03 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:40:03 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:40:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:40:03 --> URI Class Initialized
DEBUG - 2013-12-01 19:40:03 --> Router Class Initialized
DEBUG - 2013-12-01 19:40:03 --> Output Class Initialized
DEBUG - 2013-12-01 19:40:03 --> Security Class Initialized
DEBUG - 2013-12-01 19:40:04 --> Input Class Initialized
DEBUG - 2013-12-01 19:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:40:04 --> Language Class Initialized
DEBUG - 2013-12-01 19:40:04 --> Loader Class Initialized
DEBUG - 2013-12-01 19:40:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:40:04 --> Session Class Initialized
DEBUG - 2013-12-01 19:40:04 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:40:04 --> Session routines successfully run
DEBUG - 2013-12-01 19:40:04 --> Controller Class Initialized
DEBUG - 2013-12-01 19:40:04 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:40:04 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:40:04 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:40:04 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:40:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:40:05 --> Model Class Initialized
DEBUG - 2013-12-01 19:40:05 --> Model Class Initialized
DEBUG - 2013-12-01 19:40:05 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:40:05 --> Upload Class Initialized
DEBUG - 2013-12-01 19:40:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:40:05 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:40:05 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:40:05 --> Final output sent to browser
DEBUG - 2013-12-01 19:40:05 --> Total execution time: 2.3011
DEBUG - 2013-12-01 19:47:32 --> Config Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:47:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:47:32 --> URI Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Router Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Output Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Security Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Input Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:47:32 --> Language Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Loader Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:47:32 --> Session Class Initialized
DEBUG - 2013-12-01 19:47:33 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:47:33 --> Session routines successfully run
DEBUG - 2013-12-01 19:47:33 --> Controller Class Initialized
DEBUG - 2013-12-01 19:47:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:47:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:47:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:47:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:47:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:47:33 --> Model Class Initialized
DEBUG - 2013-12-01 19:47:33 --> Model Class Initialized
DEBUG - 2013-12-01 19:47:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:47:34 --> Upload Class Initialized
DEBUG - 2013-12-01 19:47:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:47:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:47:34 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:47:34 --> Final output sent to browser
DEBUG - 2013-12-01 19:47:34 --> Total execution time: 2.4001
DEBUG - 2013-12-01 19:51:44 --> Config Class Initialized
DEBUG - 2013-12-01 19:51:44 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:51:44 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:51:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:51:45 --> URI Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Router Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Output Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Security Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Input Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:51:45 --> Language Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Loader Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Session Class Initialized
DEBUG - 2013-12-01 19:51:45 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:51:45 --> Session routines successfully run
DEBUG - 2013-12-01 19:51:46 --> Controller Class Initialized
DEBUG - 2013-12-01 19:51:46 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:51:46 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:51:46 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:51:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:51:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:51:46 --> Model Class Initialized
DEBUG - 2013-12-01 19:51:46 --> Model Class Initialized
DEBUG - 2013-12-01 19:51:46 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:51:47 --> Upload Class Initialized
DEBUG - 2013-12-01 19:51:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:51:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:51:47 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:51:47 --> Final output sent to browser
DEBUG - 2013-12-01 19:51:47 --> Total execution time: 2.6021
DEBUG - 2013-12-01 19:52:07 --> Config Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:52:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:52:08 --> URI Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Router Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Output Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Security Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Input Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:52:08 --> Language Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Loader Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Session Class Initialized
DEBUG - 2013-12-01 19:52:08 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:52:09 --> Session routines successfully run
DEBUG - 2013-12-01 19:52:09 --> Controller Class Initialized
DEBUG - 2013-12-01 19:52:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:52:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:52:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:52:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:52:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:52:09 --> Model Class Initialized
DEBUG - 2013-12-01 19:52:09 --> Model Class Initialized
DEBUG - 2013-12-01 19:52:09 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:52:09 --> Upload Class Initialized
DEBUG - 2013-12-01 19:52:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:52:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:52:10 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:52:10 --> Final output sent to browser
DEBUG - 2013-12-01 19:52:10 --> Total execution time: 2.3201
DEBUG - 2013-12-01 19:52:23 --> Config Class Initialized
DEBUG - 2013-12-01 19:52:23 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:52:23 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:52:23 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:52:23 --> URI Class Initialized
DEBUG - 2013-12-01 19:52:23 --> Router Class Initialized
DEBUG - 2013-12-01 19:52:23 --> Output Class Initialized
DEBUG - 2013-12-01 19:52:23 --> Security Class Initialized
DEBUG - 2013-12-01 19:52:23 --> Input Class Initialized
DEBUG - 2013-12-01 19:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:52:24 --> Language Class Initialized
DEBUG - 2013-12-01 19:52:24 --> Loader Class Initialized
DEBUG - 2013-12-01 19:52:24 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:52:24 --> Session Class Initialized
DEBUG - 2013-12-01 19:52:24 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:52:24 --> Session routines successfully run
DEBUG - 2013-12-01 19:52:24 --> Controller Class Initialized
DEBUG - 2013-12-01 19:52:24 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:52:24 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:52:24 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:52:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:52:25 --> Model Class Initialized
DEBUG - 2013-12-01 19:52:25 --> Model Class Initialized
DEBUG - 2013-12-01 19:52:25 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:52:25 --> Upload Class Initialized
DEBUG - 2013-12-01 19:52:25 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:52:25 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:52:25 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:52:25 --> Final output sent to browser
DEBUG - 2013-12-01 19:52:25 --> Total execution time: 2.2701
DEBUG - 2013-12-01 19:52:49 --> Config Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:52:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:52:49 --> URI Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Router Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Output Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Security Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Input Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:52:49 --> Language Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Loader Class Initialized
DEBUG - 2013-12-01 19:52:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:52:50 --> Session Class Initialized
DEBUG - 2013-12-01 19:52:50 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:52:50 --> Session routines successfully run
DEBUG - 2013-12-01 19:52:50 --> Controller Class Initialized
DEBUG - 2013-12-01 19:52:50 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:52:50 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:52:50 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:52:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:52:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:52:50 --> Model Class Initialized
DEBUG - 2013-12-01 19:52:50 --> Model Class Initialized
DEBUG - 2013-12-01 19:52:51 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:52:51 --> Upload Class Initialized
DEBUG - 2013-12-01 19:52:51 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:52:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:52:51 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:52:51 --> Final output sent to browser
DEBUG - 2013-12-01 19:52:51 --> Total execution time: 2.4081
DEBUG - 2013-12-01 19:53:29 --> Config Class Initialized
DEBUG - 2013-12-01 19:53:29 --> Hooks Class Initialized
DEBUG - 2013-12-01 19:53:29 --> Utf8 Class Initialized
DEBUG - 2013-12-01 19:53:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 19:53:29 --> URI Class Initialized
DEBUG - 2013-12-01 19:53:29 --> Router Class Initialized
DEBUG - 2013-12-01 19:53:29 --> Output Class Initialized
DEBUG - 2013-12-01 19:53:29 --> Security Class Initialized
DEBUG - 2013-12-01 19:53:29 --> Input Class Initialized
DEBUG - 2013-12-01 19:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 19:53:30 --> Language Class Initialized
DEBUG - 2013-12-01 19:53:30 --> Loader Class Initialized
DEBUG - 2013-12-01 19:53:30 --> Database Driver Class Initialized
DEBUG - 2013-12-01 19:53:30 --> Session Class Initialized
DEBUG - 2013-12-01 19:53:30 --> Helper loaded: string_helper
DEBUG - 2013-12-01 19:53:30 --> Session garbage collection performed.
DEBUG - 2013-12-01 19:53:30 --> Session routines successfully run
DEBUG - 2013-12-01 19:53:30 --> Controller Class Initialized
DEBUG - 2013-12-01 19:53:30 --> Helper loaded: form_helper
DEBUG - 2013-12-01 19:53:30 --> Helper loaded: url_helper
DEBUG - 2013-12-01 19:53:30 --> Form Validation Class Initialized
DEBUG - 2013-12-01 19:53:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 19:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:53:31 --> Model Class Initialized
DEBUG - 2013-12-01 19:53:31 --> Model Class Initialized
DEBUG - 2013-12-01 19:53:31 --> Image Lib Class Initialized
DEBUG - 2013-12-01 19:53:31 --> Upload Class Initialized
DEBUG - 2013-12-01 19:53:31 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 19:53:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 19:53:31 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 19:53:31 --> Final output sent to browser
DEBUG - 2013-12-01 19:53:31 --> Total execution time: 2.5651
DEBUG - 2013-12-01 20:03:36 --> Config Class Initialized
DEBUG - 2013-12-01 20:03:36 --> Hooks Class Initialized
DEBUG - 2013-12-01 20:03:36 --> Utf8 Class Initialized
DEBUG - 2013-12-01 20:03:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 20:03:36 --> URI Class Initialized
DEBUG - 2013-12-01 20:03:36 --> Router Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Output Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Security Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Input Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 20:03:37 --> Language Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Loader Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Database Driver Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Session Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Helper loaded: string_helper
DEBUG - 2013-12-01 20:03:37 --> Session routines successfully run
DEBUG - 2013-12-01 20:03:37 --> Controller Class Initialized
DEBUG - 2013-12-01 20:03:37 --> Helper loaded: form_helper
DEBUG - 2013-12-01 20:03:37 --> Helper loaded: url_helper
DEBUG - 2013-12-01 20:03:38 --> Form Validation Class Initialized
DEBUG - 2013-12-01 20:03:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 20:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 20:03:38 --> Model Class Initialized
DEBUG - 2013-12-01 20:03:38 --> Model Class Initialized
DEBUG - 2013-12-01 20:03:38 --> Image Lib Class Initialized
DEBUG - 2013-12-01 20:03:38 --> Upload Class Initialized
DEBUG - 2013-12-01 20:03:38 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 20:03:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 20:03:38 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 20:03:38 --> Final output sent to browser
DEBUG - 2013-12-01 20:03:39 --> Total execution time: 2.3691
DEBUG - 2013-12-01 20:04:00 --> Config Class Initialized
DEBUG - 2013-12-01 20:04:00 --> Hooks Class Initialized
DEBUG - 2013-12-01 20:04:00 --> Utf8 Class Initialized
DEBUG - 2013-12-01 20:04:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 20:04:00 --> URI Class Initialized
DEBUG - 2013-12-01 20:04:00 --> Router Class Initialized
DEBUG - 2013-12-01 20:04:00 --> Output Class Initialized
DEBUG - 2013-12-01 20:04:01 --> Security Class Initialized
DEBUG - 2013-12-01 20:04:01 --> Input Class Initialized
DEBUG - 2013-12-01 20:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 20:04:01 --> Language Class Initialized
DEBUG - 2013-12-01 20:04:01 --> Loader Class Initialized
DEBUG - 2013-12-01 20:04:01 --> Database Driver Class Initialized
DEBUG - 2013-12-01 20:04:01 --> Session Class Initialized
DEBUG - 2013-12-01 20:04:01 --> Helper loaded: string_helper
DEBUG - 2013-12-01 20:04:01 --> Session routines successfully run
DEBUG - 2013-12-01 20:04:01 --> Controller Class Initialized
DEBUG - 2013-12-01 20:04:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 20:04:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 20:04:02 --> Form Validation Class Initialized
DEBUG - 2013-12-01 20:04:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 20:04:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 20:04:02 --> Model Class Initialized
DEBUG - 2013-12-01 20:04:02 --> Model Class Initialized
DEBUG - 2013-12-01 20:04:02 --> Image Lib Class Initialized
DEBUG - 2013-12-01 20:04:02 --> Upload Class Initialized
DEBUG - 2013-12-01 20:04:02 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 20:04:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 20:04:02 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 20:04:03 --> Final output sent to browser
DEBUG - 2013-12-01 20:04:03 --> Total execution time: 2.5021
DEBUG - 2013-12-01 20:04:26 --> Config Class Initialized
DEBUG - 2013-12-01 20:04:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 20:04:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 20:04:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 20:04:26 --> URI Class Initialized
DEBUG - 2013-12-01 20:04:26 --> Router Class Initialized
DEBUG - 2013-12-01 20:04:26 --> Output Class Initialized
DEBUG - 2013-12-01 20:04:26 --> Security Class Initialized
DEBUG - 2013-12-01 20:04:26 --> Input Class Initialized
DEBUG - 2013-12-01 20:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 20:04:26 --> Language Class Initialized
DEBUG - 2013-12-01 20:04:27 --> Loader Class Initialized
DEBUG - 2013-12-01 20:04:27 --> Database Driver Class Initialized
DEBUG - 2013-12-01 20:04:27 --> Session Class Initialized
DEBUG - 2013-12-01 20:04:27 --> Helper loaded: string_helper
DEBUG - 2013-12-01 20:04:27 --> Session routines successfully run
DEBUG - 2013-12-01 20:04:27 --> Controller Class Initialized
DEBUG - 2013-12-01 20:04:27 --> Helper loaded: form_helper
DEBUG - 2013-12-01 20:04:27 --> Helper loaded: url_helper
DEBUG - 2013-12-01 20:04:27 --> Form Validation Class Initialized
DEBUG - 2013-12-01 20:04:27 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 20:04:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 20:04:27 --> Model Class Initialized
DEBUG - 2013-12-01 20:04:28 --> Model Class Initialized
DEBUG - 2013-12-01 20:04:28 --> Image Lib Class Initialized
DEBUG - 2013-12-01 20:04:28 --> Upload Class Initialized
DEBUG - 2013-12-01 20:04:28 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 20:04:28 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 20:04:28 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 20:04:28 --> Final output sent to browser
DEBUG - 2013-12-01 20:04:28 --> Total execution time: 2.3951
DEBUG - 2013-12-01 20:04:31 --> Config Class Initialized
DEBUG - 2013-12-01 20:04:31 --> Hooks Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Utf8 Class Initialized
DEBUG - 2013-12-01 20:04:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 20:04:32 --> URI Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Router Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Output Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Security Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Input Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 20:04:32 --> Language Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Loader Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Database Driver Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Session Class Initialized
DEBUG - 2013-12-01 20:04:32 --> Helper loaded: string_helper
DEBUG - 2013-12-01 20:04:33 --> Session routines successfully run
DEBUG - 2013-12-01 20:04:33 --> Controller Class Initialized
DEBUG - 2013-12-01 20:04:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 20:04:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 20:04:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 20:04:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 20:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 20:04:33 --> Model Class Initialized
DEBUG - 2013-12-01 20:04:33 --> Model Class Initialized
DEBUG - 2013-12-01 20:04:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 20:04:33 --> Upload Class Initialized
DEBUG - 2013-12-01 20:04:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 20:04:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 20:04:34 --> File loaded: application/views/auth/change_email_form.php
DEBUG - 2013-12-01 20:04:34 --> Final output sent to browser
DEBUG - 2013-12-01 20:04:34 --> Total execution time: 2.4231
DEBUG - 2013-12-01 21:04:37 --> Config Class Initialized
DEBUG - 2013-12-01 21:04:37 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:04:37 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:04:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:04:38 --> URI Class Initialized
DEBUG - 2013-12-01 21:04:38 --> Router Class Initialized
DEBUG - 2013-12-01 21:04:38 --> Output Class Initialized
DEBUG - 2013-12-01 21:04:38 --> Security Class Initialized
DEBUG - 2013-12-01 21:04:38 --> Input Class Initialized
DEBUG - 2013-12-01 21:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:04:38 --> Language Class Initialized
DEBUG - 2013-12-01 21:04:38 --> Loader Class Initialized
DEBUG - 2013-12-01 21:04:38 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:04:39 --> Session Class Initialized
DEBUG - 2013-12-01 21:04:39 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:04:39 --> Session routines successfully run
DEBUG - 2013-12-01 21:04:39 --> Controller Class Initialized
DEBUG - 2013-12-01 21:04:39 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:04:39 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:04:39 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:04:39 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:04:39 --> Model Class Initialized
DEBUG - 2013-12-01 21:04:39 --> Model Class Initialized
DEBUG - 2013-12-01 21:04:40 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:04:40 --> Upload Class Initialized
DEBUG - 2013-12-01 21:04:40 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:04:40 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:04:40 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 21:04:40 --> Final output sent to browser
DEBUG - 2013-12-01 21:04:40 --> Total execution time: 2.7362
DEBUG - 2013-12-01 21:04:48 --> Config Class Initialized
DEBUG - 2013-12-01 21:04:48 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:04:48 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:04:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:04:48 --> URI Class Initialized
DEBUG - 2013-12-01 21:04:48 --> Router Class Initialized
DEBUG - 2013-12-01 21:04:48 --> Output Class Initialized
DEBUG - 2013-12-01 21:04:49 --> Security Class Initialized
DEBUG - 2013-12-01 21:04:49 --> Input Class Initialized
DEBUG - 2013-12-01 21:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:04:49 --> Language Class Initialized
DEBUG - 2013-12-01 21:04:49 --> Loader Class Initialized
DEBUG - 2013-12-01 21:04:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:04:49 --> Session Class Initialized
DEBUG - 2013-12-01 21:04:49 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:04:49 --> Session routines successfully run
DEBUG - 2013-12-01 21:04:49 --> Controller Class Initialized
DEBUG - 2013-12-01 21:04:49 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:04:49 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:04:49 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:04:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:04:50 --> Model Class Initialized
DEBUG - 2013-12-01 21:04:50 --> Model Class Initialized
DEBUG - 2013-12-01 21:04:50 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:04:50 --> Upload Class Initialized
DEBUG - 2013-12-01 21:04:50 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:04:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:04:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 21:04:50 --> XSS Filtering completed
DEBUG - 2013-12-01 21:04:51 --> XSS Filtering completed
DEBUG - 2013-12-01 21:04:51 --> XSS Filtering completed
ERROR - 2013-12-01 21:04:51 --> Severity: Notice  --> Undefined property: stdClass::$password C:\Program Files (x86)\Ampps\www\project\application\libraries\Tank_auth.php 430
DEBUG - 2013-12-01 21:04:51 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 21:04:51 --> Final output sent to browser
DEBUG - 2013-12-01 21:04:51 --> Total execution time: 2.9822
DEBUG - 2013-12-01 21:05:05 --> Config Class Initialized
DEBUG - 2013-12-01 21:05:05 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:05:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:05:06 --> URI Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Router Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Output Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Security Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Input Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:05:06 --> Language Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Loader Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:05:06 --> Session Class Initialized
DEBUG - 2013-12-01 21:05:07 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:05:07 --> Session routines successfully run
DEBUG - 2013-12-01 21:05:07 --> Controller Class Initialized
DEBUG - 2013-12-01 21:05:07 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:05:07 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:05:07 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:05:07 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:05:07 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:07 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:08 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:05:08 --> Upload Class Initialized
DEBUG - 2013-12-01 21:05:08 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:05:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:05:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 21:05:12 --> XSS Filtering completed
DEBUG - 2013-12-01 21:05:12 --> XSS Filtering completed
DEBUG - 2013-12-01 21:05:12 --> XSS Filtering completed
ERROR - 2013-12-01 21:05:12 --> Severity: Notice  --> Undefined property: stdClass::$password C:\Program Files (x86)\Ampps\www\project\application\libraries\Tank_auth.php 430
DEBUG - 2013-12-01 21:05:12 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 21:05:12 --> Final output sent to browser
DEBUG - 2013-12-01 21:05:12 --> Total execution time: 6.5084
DEBUG - 2013-12-01 21:05:21 --> Config Class Initialized
DEBUG - 2013-12-01 21:05:21 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:05:21 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:05:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:05:21 --> URI Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Router Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Output Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Security Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Input Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:05:22 --> Language Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Loader Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Session Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:05:22 --> Session routines successfully run
DEBUG - 2013-12-01 21:05:22 --> Controller Class Initialized
DEBUG - 2013-12-01 21:05:22 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:05:23 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:05:23 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:05:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:05:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:05:23 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:23 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:23 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:05:23 --> Upload Class Initialized
DEBUG - 2013-12-01 21:05:23 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:05:23 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:05:24 --> Helper loaded: cookie_helper
ERROR - 2013-12-01 21:05:26 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 21:05:26 --> Severity: Notice  --> Undefined index: ip_address C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 21:05:27 --> Severity: Notice  --> Undefined index: user_agent C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 21:05:27 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 21:05:27 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 288
ERROR - 2013-12-01 21:05:27 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 289
DEBUG - 2013-12-01 21:05:27 --> Config Class Initialized
DEBUG - 2013-12-01 21:05:27 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:05:27 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:05:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:05:27 --> URI Class Initialized
DEBUG - 2013-12-01 21:05:27 --> Router Class Initialized
DEBUG - 2013-12-01 21:05:27 --> Output Class Initialized
DEBUG - 2013-12-01 21:05:27 --> Security Class Initialized
DEBUG - 2013-12-01 21:05:28 --> Input Class Initialized
DEBUG - 2013-12-01 21:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:05:28 --> Language Class Initialized
DEBUG - 2013-12-01 21:05:28 --> Loader Class Initialized
DEBUG - 2013-12-01 21:05:28 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:05:28 --> Session Class Initialized
DEBUG - 2013-12-01 21:05:28 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:05:31 --> Session routines successfully run
DEBUG - 2013-12-01 21:05:32 --> Controller Class Initialized
DEBUG - 2013-12-01 21:05:32 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:05:32 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:05:32 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:05:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:05:32 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:32 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:32 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:05:32 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 21:05:32 --> Upload Class Initialized
DEBUG - 2013-12-01 21:05:32 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:05:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:05:33 --> Config Class Initialized
DEBUG - 2013-12-01 21:05:33 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:05:33 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:05:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:05:33 --> URI Class Initialized
DEBUG - 2013-12-01 21:05:33 --> Router Class Initialized
DEBUG - 2013-12-01 21:05:33 --> Output Class Initialized
DEBUG - 2013-12-01 21:05:33 --> Security Class Initialized
DEBUG - 2013-12-01 21:05:33 --> Input Class Initialized
DEBUG - 2013-12-01 21:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:05:34 --> Language Class Initialized
DEBUG - 2013-12-01 21:05:34 --> Loader Class Initialized
DEBUG - 2013-12-01 21:05:34 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:05:34 --> Session Class Initialized
DEBUG - 2013-12-01 21:05:34 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:05:34 --> Session routines successfully run
DEBUG - 2013-12-01 21:05:34 --> Controller Class Initialized
DEBUG - 2013-12-01 21:05:34 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:05:34 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:05:34 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:05:35 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:05:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:05:35 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:35 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:35 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:05:35 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 21:05:35 --> Upload Class Initialized
DEBUG - 2013-12-01 21:05:35 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:05:35 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:05:35 --> Model Class Initialized
DEBUG - 2013-12-01 21:05:35 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 21:05:36 --> Final output sent to browser
DEBUG - 2013-12-01 21:05:36 --> Total execution time: 2.9142
DEBUG - 2013-12-01 21:07:12 --> Config Class Initialized
DEBUG - 2013-12-01 21:07:12 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:07:12 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:07:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:07:12 --> URI Class Initialized
DEBUG - 2013-12-01 21:07:12 --> Router Class Initialized
DEBUG - 2013-12-01 21:07:12 --> Output Class Initialized
DEBUG - 2013-12-01 21:07:12 --> Security Class Initialized
DEBUG - 2013-12-01 21:07:12 --> Input Class Initialized
DEBUG - 2013-12-01 21:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:07:12 --> Language Class Initialized
DEBUG - 2013-12-01 21:07:12 --> Loader Class Initialized
DEBUG - 2013-12-01 21:07:13 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:07:13 --> Session Class Initialized
DEBUG - 2013-12-01 21:07:13 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:07:13 --> Session routines successfully run
DEBUG - 2013-12-01 21:07:13 --> Controller Class Initialized
DEBUG - 2013-12-01 21:07:13 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:07:13 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:07:13 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:07:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:07:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:13 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:14 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:07:14 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 21:07:14 --> Upload Class Initialized
DEBUG - 2013-12-01 21:07:14 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:07:14 --> XSS Filtering completed
DEBUG - 2013-12-01 21:07:14 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 21:07:14 --> XSS Filtering completed
DEBUG - 2013-12-01 21:07:14 --> XSS Filtering completed
DEBUG - 2013-12-01 21:07:15 --> Config Class Initialized
DEBUG - 2013-12-01 21:07:15 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:07:15 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:07:15 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:07:15 --> URI Class Initialized
DEBUG - 2013-12-01 21:07:15 --> Router Class Initialized
DEBUG - 2013-12-01 21:07:15 --> Output Class Initialized
DEBUG - 2013-12-01 21:07:15 --> Security Class Initialized
DEBUG - 2013-12-01 21:07:16 --> Input Class Initialized
DEBUG - 2013-12-01 21:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:07:16 --> Language Class Initialized
DEBUG - 2013-12-01 21:07:16 --> Loader Class Initialized
DEBUG - 2013-12-01 21:07:16 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:07:16 --> Session Class Initialized
DEBUG - 2013-12-01 21:07:16 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:07:16 --> Session routines successfully run
DEBUG - 2013-12-01 21:07:16 --> Controller Class Initialized
DEBUG - 2013-12-01 21:07:16 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:07:16 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:07:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:17 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:17 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:17 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:07:17 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:17 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:07:17 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 21:07:17 --> Final output sent to browser
DEBUG - 2013-12-01 21:07:17 --> Total execution time: 2.4091
DEBUG - 2013-12-01 21:07:21 --> Config Class Initialized
DEBUG - 2013-12-01 21:07:21 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:07:21 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:07:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:07:21 --> URI Class Initialized
DEBUG - 2013-12-01 21:07:21 --> Router Class Initialized
DEBUG - 2013-12-01 21:07:21 --> Output Class Initialized
DEBUG - 2013-12-01 21:07:21 --> Security Class Initialized
DEBUG - 2013-12-01 21:07:21 --> Input Class Initialized
DEBUG - 2013-12-01 21:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:07:21 --> Language Class Initialized
DEBUG - 2013-12-01 21:07:22 --> Loader Class Initialized
DEBUG - 2013-12-01 21:07:22 --> Database Driver Class Initialized
ERROR - 2013-12-01 21:07:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\Program Files (x86)\Ampps\www\project\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-12-01 21:07:22 --> Session Class Initialized
DEBUG - 2013-12-01 21:07:22 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:07:22 --> Session routines successfully run
DEBUG - 2013-12-01 21:07:22 --> Controller Class Initialized
DEBUG - 2013-12-01 21:07:23 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:07:23 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:07:23 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:07:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:07:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:23 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:23 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:23 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:07:23 --> Upload Class Initialized
DEBUG - 2013-12-01 21:07:23 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:23 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:07:24 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 21:07:24 --> Final output sent to browser
DEBUG - 2013-12-01 21:07:24 --> Total execution time: 2.9972
DEBUG - 2013-12-01 21:07:27 --> Config Class Initialized
DEBUG - 2013-12-01 21:07:27 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:07:27 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:07:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:07:27 --> URI Class Initialized
DEBUG - 2013-12-01 21:07:27 --> Router Class Initialized
DEBUG - 2013-12-01 21:07:27 --> Output Class Initialized
DEBUG - 2013-12-01 21:07:27 --> Security Class Initialized
DEBUG - 2013-12-01 21:07:27 --> Input Class Initialized
DEBUG - 2013-12-01 21:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:07:28 --> Language Class Initialized
DEBUG - 2013-12-01 21:07:28 --> Loader Class Initialized
DEBUG - 2013-12-01 21:07:28 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:07:28 --> Session Class Initialized
DEBUG - 2013-12-01 21:07:28 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:07:28 --> Session routines successfully run
DEBUG - 2013-12-01 21:07:28 --> Controller Class Initialized
DEBUG - 2013-12-01 21:07:28 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:07:28 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:07:28 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:07:28 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:07:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:29 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:29 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:29 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:07:29 --> Upload Class Initialized
DEBUG - 2013-12-01 21:07:29 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:07:29 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 21:07:29 --> Final output sent to browser
DEBUG - 2013-12-01 21:07:29 --> Total execution time: 2.5381
DEBUG - 2013-12-01 21:07:40 --> Config Class Initialized
DEBUG - 2013-12-01 21:07:40 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:07:40 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:07:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:07:40 --> URI Class Initialized
DEBUG - 2013-12-01 21:07:40 --> Router Class Initialized
DEBUG - 2013-12-01 21:07:40 --> Output Class Initialized
DEBUG - 2013-12-01 21:07:40 --> Security Class Initialized
DEBUG - 2013-12-01 21:07:41 --> Input Class Initialized
DEBUG - 2013-12-01 21:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:07:41 --> Language Class Initialized
DEBUG - 2013-12-01 21:07:41 --> Loader Class Initialized
DEBUG - 2013-12-01 21:07:41 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:07:41 --> Session Class Initialized
DEBUG - 2013-12-01 21:07:41 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:07:41 --> Session routines successfully run
DEBUG - 2013-12-01 21:07:41 --> Controller Class Initialized
DEBUG - 2013-12-01 21:07:41 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:07:41 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:07:41 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:07:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:07:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:42 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:42 --> Model Class Initialized
DEBUG - 2013-12-01 21:07:42 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:07:42 --> Upload Class Initialized
DEBUG - 2013-12-01 21:07:42 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:07:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:07:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 21:07:43 --> XSS Filtering completed
DEBUG - 2013-12-01 21:07:43 --> XSS Filtering completed
DEBUG - 2013-12-01 21:07:43 --> XSS Filtering completed
ERROR - 2013-12-01 21:07:43 --> Severity: Notice  --> Undefined property: stdClass::$password C:\Program Files (x86)\Ampps\www\project\application\libraries\Tank_auth.php 430
DEBUG - 2013-12-01 21:07:43 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 21:07:43 --> Final output sent to browser
DEBUG - 2013-12-01 21:07:43 --> Total execution time: 3.0272
DEBUG - 2013-12-01 21:08:39 --> Config Class Initialized
DEBUG - 2013-12-01 21:08:40 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:08:40 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:08:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:08:40 --> URI Class Initialized
DEBUG - 2013-12-01 21:08:40 --> Router Class Initialized
DEBUG - 2013-12-01 21:08:40 --> Output Class Initialized
DEBUG - 2013-12-01 21:08:40 --> Security Class Initialized
DEBUG - 2013-12-01 21:08:40 --> Input Class Initialized
DEBUG - 2013-12-01 21:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:08:40 --> Language Class Initialized
DEBUG - 2013-12-01 21:08:40 --> Loader Class Initialized
DEBUG - 2013-12-01 21:08:41 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:08:41 --> Session Class Initialized
DEBUG - 2013-12-01 21:08:41 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:08:41 --> Session routines successfully run
DEBUG - 2013-12-01 21:08:41 --> Controller Class Initialized
DEBUG - 2013-12-01 21:08:41 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:08:41 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:08:41 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:08:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:08:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:08:42 --> Model Class Initialized
DEBUG - 2013-12-01 21:08:42 --> Model Class Initialized
DEBUG - 2013-12-01 21:08:42 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:08:42 --> Upload Class Initialized
DEBUG - 2013-12-01 21:08:42 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:08:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:08:42 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 21:08:42 --> Final output sent to browser
DEBUG - 2013-12-01 21:08:42 --> Total execution time: 2.8102
DEBUG - 2013-12-01 21:08:48 --> Config Class Initialized
DEBUG - 2013-12-01 21:08:48 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:08:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:08:49 --> URI Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Router Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Output Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Security Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Input Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:08:49 --> Language Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Loader Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:08:49 --> Session Class Initialized
DEBUG - 2013-12-01 21:08:50 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:08:50 --> Session routines successfully run
DEBUG - 2013-12-01 21:08:50 --> Controller Class Initialized
DEBUG - 2013-12-01 21:08:50 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:08:50 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:08:50 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:08:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:08:50 --> Model Class Initialized
DEBUG - 2013-12-01 21:08:50 --> Model Class Initialized
DEBUG - 2013-12-01 21:08:51 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:08:51 --> Upload Class Initialized
DEBUG - 2013-12-01 21:08:51 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:08:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:08:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 21:08:51 --> XSS Filtering completed
DEBUG - 2013-12-01 21:08:51 --> XSS Filtering completed
DEBUG - 2013-12-01 21:08:51 --> XSS Filtering completed
DEBUG - 2013-12-01 21:08:51 --> DB Transaction Failure
ERROR - 2013-12-01 21:08:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'user_profiles.biography, user_profiles.first_name, user_profiles.last_name, user' at line 1
DEBUG - 2013-12-01 21:08:51 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-01 21:09:43 --> Config Class Initialized
DEBUG - 2013-12-01 21:09:43 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:09:43 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:09:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:09:43 --> URI Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Router Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Output Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Security Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Input Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:09:44 --> Language Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Loader Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Session Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:09:44 --> Session routines successfully run
DEBUG - 2013-12-01 21:09:44 --> Controller Class Initialized
DEBUG - 2013-12-01 21:09:44 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:09:45 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:09:45 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:09:45 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:09:45 --> Model Class Initialized
DEBUG - 2013-12-01 21:09:45 --> Model Class Initialized
DEBUG - 2013-12-01 21:09:45 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:09:45 --> Upload Class Initialized
DEBUG - 2013-12-01 21:09:45 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:09:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:09:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 21:09:46 --> XSS Filtering completed
DEBUG - 2013-12-01 21:09:46 --> XSS Filtering completed
DEBUG - 2013-12-01 21:09:46 --> XSS Filtering completed
ERROR - 2013-12-01 21:09:46 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 21:09:47 --> Config Class Initialized
DEBUG - 2013-12-01 21:09:47 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:09:47 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:09:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:09:47 --> URI Class Initialized
DEBUG - 2013-12-01 21:09:47 --> Router Class Initialized
DEBUG - 2013-12-01 21:09:47 --> Output Class Initialized
DEBUG - 2013-12-01 21:09:47 --> Security Class Initialized
DEBUG - 2013-12-01 21:09:47 --> Input Class Initialized
DEBUG - 2013-12-01 21:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:09:47 --> Language Class Initialized
DEBUG - 2013-12-01 21:09:48 --> Loader Class Initialized
DEBUG - 2013-12-01 21:09:48 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:09:48 --> Session Class Initialized
DEBUG - 2013-12-01 21:09:48 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:09:48 --> Session routines successfully run
DEBUG - 2013-12-01 21:09:48 --> Controller Class Initialized
DEBUG - 2013-12-01 21:09:48 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:09:48 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:09:48 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:09:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:09:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:09:49 --> Model Class Initialized
DEBUG - 2013-12-01 21:09:49 --> Model Class Initialized
DEBUG - 2013-12-01 21:09:49 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:09:49 --> Upload Class Initialized
DEBUG - 2013-12-01 21:09:49 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:09:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:09:49 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 21:09:50 --> Final output sent to browser
DEBUG - 2013-12-01 21:09:50 --> Total execution time: 2.8332
DEBUG - 2013-12-01 21:12:18 --> Config Class Initialized
DEBUG - 2013-12-01 21:12:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:12:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:12:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:12:18 --> URI Class Initialized
DEBUG - 2013-12-01 21:12:18 --> Router Class Initialized
DEBUG - 2013-12-01 21:12:18 --> Output Class Initialized
DEBUG - 2013-12-01 21:12:18 --> Security Class Initialized
DEBUG - 2013-12-01 21:12:18 --> Input Class Initialized
DEBUG - 2013-12-01 21:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:12:19 --> Language Class Initialized
DEBUG - 2013-12-01 21:12:19 --> Loader Class Initialized
DEBUG - 2013-12-01 21:12:19 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:12:19 --> Session Class Initialized
DEBUG - 2013-12-01 21:12:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:12:19 --> Session routines successfully run
DEBUG - 2013-12-01 21:12:19 --> Controller Class Initialized
DEBUG - 2013-12-01 21:12:19 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:12:19 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:12:19 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:12:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:12:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:12:20 --> Model Class Initialized
DEBUG - 2013-12-01 21:12:20 --> Model Class Initialized
DEBUG - 2013-12-01 21:12:20 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:12:20 --> Upload Class Initialized
DEBUG - 2013-12-01 21:12:20 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:12:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:12:20 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 21:12:20 --> Final output sent to browser
DEBUG - 2013-12-01 21:12:20 --> Total execution time: 2.5731
DEBUG - 2013-12-01 21:12:28 --> Config Class Initialized
DEBUG - 2013-12-01 21:12:28 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:12:28 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:12:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:12:28 --> URI Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Router Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Output Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Security Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Input Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:12:29 --> Language Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Loader Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Session Class Initialized
DEBUG - 2013-12-01 21:12:29 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:12:29 --> Session routines successfully run
DEBUG - 2013-12-01 21:12:29 --> Controller Class Initialized
DEBUG - 2013-12-01 21:12:30 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:12:30 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:12:30 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:12:30 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:12:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:12:30 --> Model Class Initialized
DEBUG - 2013-12-01 21:12:30 --> Model Class Initialized
DEBUG - 2013-12-01 21:12:30 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:12:30 --> Upload Class Initialized
DEBUG - 2013-12-01 21:12:30 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:12:31 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:12:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 21:12:31 --> XSS Filtering completed
DEBUG - 2013-12-01 21:12:31 --> XSS Filtering completed
DEBUG - 2013-12-01 21:12:31 --> XSS Filtering completed
ERROR - 2013-12-01 21:12:31 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 21:12:32 --> Config Class Initialized
DEBUG - 2013-12-01 21:12:32 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:12:32 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:12:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:12:32 --> URI Class Initialized
DEBUG - 2013-12-01 21:12:32 --> Router Class Initialized
DEBUG - 2013-12-01 21:12:32 --> Output Class Initialized
DEBUG - 2013-12-01 21:12:32 --> Security Class Initialized
DEBUG - 2013-12-01 21:12:32 --> Input Class Initialized
DEBUG - 2013-12-01 21:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:12:33 --> Language Class Initialized
DEBUG - 2013-12-01 21:12:33 --> Loader Class Initialized
DEBUG - 2013-12-01 21:12:33 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:12:33 --> Session Class Initialized
DEBUG - 2013-12-01 21:12:33 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:12:33 --> Session routines successfully run
DEBUG - 2013-12-01 21:12:33 --> Controller Class Initialized
DEBUG - 2013-12-01 21:12:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:12:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:12:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:12:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:12:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:12:34 --> Model Class Initialized
DEBUG - 2013-12-01 21:12:34 --> Model Class Initialized
DEBUG - 2013-12-01 21:12:34 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:12:34 --> Upload Class Initialized
DEBUG - 2013-12-01 21:12:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:12:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:12:34 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 21:12:34 --> Final output sent to browser
DEBUG - 2013-12-01 21:12:34 --> Total execution time: 2.6352
DEBUG - 2013-12-01 21:12:45 --> Config Class Initialized
DEBUG - 2013-12-01 21:12:45 --> Hooks Class Initialized
DEBUG - 2013-12-01 21:12:45 --> Utf8 Class Initialized
DEBUG - 2013-12-01 21:12:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 21:12:45 --> URI Class Initialized
DEBUG - 2013-12-01 21:12:45 --> Router Class Initialized
DEBUG - 2013-12-01 21:12:45 --> Output Class Initialized
DEBUG - 2013-12-01 21:12:45 --> Security Class Initialized
DEBUG - 2013-12-01 21:12:45 --> Input Class Initialized
DEBUG - 2013-12-01 21:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 21:12:45 --> Language Class Initialized
DEBUG - 2013-12-01 21:12:46 --> Loader Class Initialized
DEBUG - 2013-12-01 21:12:46 --> Database Driver Class Initialized
DEBUG - 2013-12-01 21:12:46 --> Session Class Initialized
DEBUG - 2013-12-01 21:12:46 --> Helper loaded: string_helper
DEBUG - 2013-12-01 21:12:46 --> Session routines successfully run
DEBUG - 2013-12-01 21:12:46 --> Controller Class Initialized
DEBUG - 2013-12-01 21:12:46 --> Helper loaded: form_helper
DEBUG - 2013-12-01 21:12:46 --> Helper loaded: url_helper
DEBUG - 2013-12-01 21:12:46 --> Form Validation Class Initialized
DEBUG - 2013-12-01 21:12:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 21:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:12:47 --> Model Class Initialized
DEBUG - 2013-12-01 21:12:47 --> Model Class Initialized
DEBUG - 2013-12-01 21:12:47 --> Image Lib Class Initialized
DEBUG - 2013-12-01 21:12:47 --> Upload Class Initialized
DEBUG - 2013-12-01 21:12:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 21:12:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 21:12:47 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 21:12:47 --> Final output sent to browser
DEBUG - 2013-12-01 21:12:47 --> Total execution time: 2.6232
DEBUG - 2013-12-01 22:51:07 --> Config Class Initialized
DEBUG - 2013-12-01 22:51:07 --> Hooks Class Initialized
DEBUG - 2013-12-01 22:51:07 --> Utf8 Class Initialized
DEBUG - 2013-12-01 22:51:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 22:51:08 --> URI Class Initialized
DEBUG - 2013-12-01 22:51:08 --> Router Class Initialized
DEBUG - 2013-12-01 22:51:08 --> Output Class Initialized
DEBUG - 2013-12-01 22:51:08 --> Security Class Initialized
DEBUG - 2013-12-01 22:51:08 --> Input Class Initialized
DEBUG - 2013-12-01 22:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 22:51:08 --> Language Class Initialized
DEBUG - 2013-12-01 22:51:08 --> Loader Class Initialized
DEBUG - 2013-12-01 22:51:09 --> Database Driver Class Initialized
DEBUG - 2013-12-01 22:51:09 --> Session Class Initialized
DEBUG - 2013-12-01 22:51:09 --> Helper loaded: string_helper
DEBUG - 2013-12-01 22:51:09 --> Session routines successfully run
DEBUG - 2013-12-01 22:51:09 --> Controller Class Initialized
DEBUG - 2013-12-01 22:51:10 --> Config Class Initialized
DEBUG - 2013-12-01 22:51:10 --> Helper loaded: form_helper
DEBUG - 2013-12-01 22:51:10 --> Hooks Class Initialized
DEBUG - 2013-12-01 22:51:10 --> Helper loaded: url_helper
DEBUG - 2013-12-01 22:51:10 --> Utf8 Class Initialized
DEBUG - 2013-12-01 22:51:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 22:51:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 22:51:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:51:11 --> URI Class Initialized
DEBUG - 2013-12-01 22:51:11 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:11 --> Router Class Initialized
DEBUG - 2013-12-01 22:51:11 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:11 --> Output Class Initialized
DEBUG - 2013-12-01 22:51:11 --> Image Lib Class Initialized
DEBUG - 2013-12-01 22:51:11 --> Security Class Initialized
DEBUG - 2013-12-01 22:51:12 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:12 --> Input Class Initialized
DEBUG - 2013-12-01 22:51:12 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 22:51:12 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 22:51:12 --> Language Class Initialized
DEBUG - 2013-12-01 22:51:12 --> Loader Class Initialized
DEBUG - 2013-12-01 22:51:13 --> Database Driver Class Initialized
DEBUG - 2013-12-01 22:51:13 --> Session Class Initialized
DEBUG - 2013-12-01 22:51:13 --> Helper loaded: string_helper
DEBUG - 2013-12-01 22:51:13 --> Session routines successfully run
DEBUG - 2013-12-01 22:51:13 --> Controller Class Initialized
DEBUG - 2013-12-01 22:51:14 --> Helper loaded: form_helper
DEBUG - 2013-12-01 22:51:14 --> Helper loaded: url_helper
DEBUG - 2013-12-01 22:51:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 22:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:51:14 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:14 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 22:51:15 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 22:51:15 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:15 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:15 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 22:51:15 --> Final output sent to browser
DEBUG - 2013-12-01 22:51:15 --> Total execution time: 5.5953
DEBUG - 2013-12-01 22:51:21 --> Config Class Initialized
DEBUG - 2013-12-01 22:51:21 --> Hooks Class Initialized
DEBUG - 2013-12-01 22:51:21 --> Utf8 Class Initialized
DEBUG - 2013-12-01 22:51:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 22:51:22 --> URI Class Initialized
DEBUG - 2013-12-01 22:51:22 --> Router Class Initialized
DEBUG - 2013-12-01 22:51:22 --> Output Class Initialized
DEBUG - 2013-12-01 22:51:22 --> Security Class Initialized
DEBUG - 2013-12-01 22:51:22 --> Input Class Initialized
DEBUG - 2013-12-01 22:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 22:51:22 --> Language Class Initialized
DEBUG - 2013-12-01 22:51:22 --> Loader Class Initialized
DEBUG - 2013-12-01 22:51:23 --> Database Driver Class Initialized
DEBUG - 2013-12-01 22:51:23 --> Session Class Initialized
DEBUG - 2013-12-01 22:51:23 --> Helper loaded: string_helper
DEBUG - 2013-12-01 22:51:23 --> Session routines successfully run
DEBUG - 2013-12-01 22:51:23 --> Controller Class Initialized
DEBUG - 2013-12-01 22:51:23 --> Helper loaded: form_helper
DEBUG - 2013-12-01 22:51:24 --> Helper loaded: url_helper
DEBUG - 2013-12-01 22:51:24 --> Form Validation Class Initialized
DEBUG - 2013-12-01 22:51:24 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 22:51:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:51:24 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:24 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:24 --> Image Lib Class Initialized
DEBUG - 2013-12-01 22:51:25 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 22:51:25 --> Upload Class Initialized
DEBUG - 2013-12-01 22:51:25 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:51:25 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 22:51:25 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 22:51:25 --> Severity: Notice  --> Undefined index: ip_address C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 22:51:25 --> Severity: Notice  --> Undefined index: user_agent C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 22:51:25 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 22:51:26 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 288
ERROR - 2013-12-01 22:51:26 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 289
DEBUG - 2013-12-01 22:51:26 --> Config Class Initialized
DEBUG - 2013-12-01 22:51:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 22:51:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 22:51:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 22:51:26 --> URI Class Initialized
DEBUG - 2013-12-01 22:51:27 --> Router Class Initialized
DEBUG - 2013-12-01 22:51:27 --> Output Class Initialized
DEBUG - 2013-12-01 22:51:27 --> Security Class Initialized
DEBUG - 2013-12-01 22:51:27 --> Input Class Initialized
DEBUG - 2013-12-01 22:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 22:51:27 --> Language Class Initialized
DEBUG - 2013-12-01 22:51:27 --> Loader Class Initialized
DEBUG - 2013-12-01 22:51:27 --> Database Driver Class Initialized
DEBUG - 2013-12-01 22:51:28 --> Session Class Initialized
DEBUG - 2013-12-01 22:51:28 --> Helper loaded: string_helper
DEBUG - 2013-12-01 22:51:31 --> Session routines successfully run
DEBUG - 2013-12-01 22:51:31 --> Controller Class Initialized
DEBUG - 2013-12-01 22:51:31 --> Helper loaded: form_helper
DEBUG - 2013-12-01 22:51:32 --> Helper loaded: url_helper
DEBUG - 2013-12-01 22:51:32 --> Form Validation Class Initialized
DEBUG - 2013-12-01 22:51:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 22:51:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:51:32 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:32 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 22:51:33 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 22:51:33 --> Upload Class Initialized
DEBUG - 2013-12-01 22:51:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:51:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 22:51:34 --> Config Class Initialized
DEBUG - 2013-12-01 22:51:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 22:51:34 --> Utf8 Class Initialized
DEBUG - 2013-12-01 22:51:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 22:51:34 --> URI Class Initialized
DEBUG - 2013-12-01 22:51:34 --> Router Class Initialized
DEBUG - 2013-12-01 22:51:34 --> Output Class Initialized
DEBUG - 2013-12-01 22:51:35 --> Security Class Initialized
DEBUG - 2013-12-01 22:51:35 --> Input Class Initialized
DEBUG - 2013-12-01 22:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 22:51:35 --> Language Class Initialized
DEBUG - 2013-12-01 22:51:35 --> Loader Class Initialized
DEBUG - 2013-12-01 22:51:36 --> Database Driver Class Initialized
DEBUG - 2013-12-01 22:51:36 --> Session Class Initialized
DEBUG - 2013-12-01 22:51:36 --> Helper loaded: string_helper
DEBUG - 2013-12-01 22:51:36 --> Session routines successfully run
DEBUG - 2013-12-01 22:51:36 --> Controller Class Initialized
DEBUG - 2013-12-01 22:51:36 --> Helper loaded: form_helper
DEBUG - 2013-12-01 22:51:36 --> Helper loaded: url_helper
DEBUG - 2013-12-01 22:51:37 --> Form Validation Class Initialized
DEBUG - 2013-12-01 22:51:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 22:51:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:51:37 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:37 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:37 --> Image Lib Class Initialized
DEBUG - 2013-12-01 22:51:37 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 22:51:38 --> Upload Class Initialized
DEBUG - 2013-12-01 22:51:38 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:51:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 22:51:38 --> Model Class Initialized
DEBUG - 2013-12-01 22:51:38 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 22:51:38 --> Final output sent to browser
DEBUG - 2013-12-01 22:51:38 --> Total execution time: 4.6603
DEBUG - 2013-12-01 22:53:59 --> Config Class Initialized
DEBUG - 2013-12-01 22:53:59 --> Hooks Class Initialized
DEBUG - 2013-12-01 22:53:59 --> Utf8 Class Initialized
DEBUG - 2013-12-01 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 22:54:00 --> URI Class Initialized
DEBUG - 2013-12-01 22:54:00 --> Router Class Initialized
DEBUG - 2013-12-01 22:54:00 --> Output Class Initialized
DEBUG - 2013-12-01 22:54:00 --> Security Class Initialized
DEBUG - 2013-12-01 22:54:00 --> Input Class Initialized
DEBUG - 2013-12-01 22:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 22:54:00 --> Language Class Initialized
DEBUG - 2013-12-01 22:54:00 --> Loader Class Initialized
DEBUG - 2013-12-01 22:54:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 22:54:01 --> Session Class Initialized
DEBUG - 2013-12-01 22:54:01 --> Helper loaded: string_helper
DEBUG - 2013-12-01 22:54:01 --> Session routines successfully run
DEBUG - 2013-12-01 22:54:01 --> Controller Class Initialized
DEBUG - 2013-12-01 22:54:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 22:54:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 22:54:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 22:54:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 22:54:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:54:02 --> Model Class Initialized
DEBUG - 2013-12-01 22:54:02 --> Model Class Initialized
DEBUG - 2013-12-01 22:54:02 --> Image Lib Class Initialized
DEBUG - 2013-12-01 22:54:02 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 22:54:02 --> Upload Class Initialized
DEBUG - 2013-12-01 22:54:02 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:54:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 22:54:02 --> XSS Filtering completed
DEBUG - 2013-12-01 22:54:02 --> Model Class Initialized
DEBUG - 2013-12-01 22:54:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 22:54:03 --> XSS Filtering completed
DEBUG - 2013-12-01 22:54:03 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 22:54:03 --> Final output sent to browser
DEBUG - 2013-12-01 22:54:03 --> Total execution time: 3.4572
DEBUG - 2013-12-01 22:58:59 --> Config Class Initialized
DEBUG - 2013-12-01 22:58:59 --> Hooks Class Initialized
DEBUG - 2013-12-01 22:58:59 --> Utf8 Class Initialized
DEBUG - 2013-12-01 22:58:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 22:58:59 --> URI Class Initialized
DEBUG - 2013-12-01 22:58:59 --> Router Class Initialized
DEBUG - 2013-12-01 22:58:59 --> Output Class Initialized
DEBUG - 2013-12-01 22:59:00 --> Security Class Initialized
DEBUG - 2013-12-01 22:59:00 --> Input Class Initialized
DEBUG - 2013-12-01 22:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 22:59:00 --> Language Class Initialized
DEBUG - 2013-12-01 22:59:00 --> Loader Class Initialized
DEBUG - 2013-12-01 22:59:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 22:59:00 --> Session Class Initialized
DEBUG - 2013-12-01 22:59:00 --> Helper loaded: string_helper
DEBUG - 2013-12-01 22:59:01 --> Session routines successfully run
DEBUG - 2013-12-01 22:59:01 --> Controller Class Initialized
DEBUG - 2013-12-01 22:59:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 22:59:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 22:59:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 22:59:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 22:59:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:59:01 --> Model Class Initialized
DEBUG - 2013-12-01 22:59:02 --> Model Class Initialized
DEBUG - 2013-12-01 22:59:02 --> Image Lib Class Initialized
DEBUG - 2013-12-01 22:59:02 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 22:59:02 --> Upload Class Initialized
DEBUG - 2013-12-01 22:59:02 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 22:59:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 22:59:02 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 22:59:02 --> Final output sent to browser
DEBUG - 2013-12-01 22:59:02 --> Total execution time: 3.7542
DEBUG - 2013-12-01 23:05:41 --> Config Class Initialized
DEBUG - 2013-12-01 23:05:41 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:05:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:05:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:05:41 --> URI Class Initialized
DEBUG - 2013-12-01 23:05:41 --> Router Class Initialized
DEBUG - 2013-12-01 23:05:41 --> Output Class Initialized
DEBUG - 2013-12-01 23:05:41 --> Security Class Initialized
DEBUG - 2013-12-01 23:05:41 --> Input Class Initialized
DEBUG - 2013-12-01 23:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:05:42 --> Language Class Initialized
DEBUG - 2013-12-01 23:05:42 --> Loader Class Initialized
DEBUG - 2013-12-01 23:05:42 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:05:42 --> Session Class Initialized
DEBUG - 2013-12-01 23:05:42 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:05:43 --> Session routines successfully run
DEBUG - 2013-12-01 23:05:43 --> Controller Class Initialized
DEBUG - 2013-12-01 23:05:43 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:05:43 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:05:43 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:05:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:05:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:05:43 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:44 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:44 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:05:44 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:05:44 --> Upload Class Initialized
DEBUG - 2013-12-01 23:05:44 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:05:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:05:44 --> XSS Filtering completed
DEBUG - 2013-12-01 23:05:44 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:05:45 --> XSS Filtering completed
DEBUG - 2013-12-01 23:05:45 --> XSS Filtering completed
DEBUG - 2013-12-01 23:05:45 --> Config Class Initialized
DEBUG - 2013-12-01 23:05:45 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:05:46 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:05:46 --> URI Class Initialized
DEBUG - 2013-12-01 23:05:46 --> Router Class Initialized
DEBUG - 2013-12-01 23:05:46 --> Output Class Initialized
DEBUG - 2013-12-01 23:05:46 --> Security Class Initialized
DEBUG - 2013-12-01 23:05:46 --> Input Class Initialized
DEBUG - 2013-12-01 23:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:05:46 --> Language Class Initialized
DEBUG - 2013-12-01 23:05:47 --> Loader Class Initialized
DEBUG - 2013-12-01 23:05:47 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:05:47 --> Session Class Initialized
DEBUG - 2013-12-01 23:05:47 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:05:47 --> Session routines successfully run
DEBUG - 2013-12-01 23:05:47 --> Controller Class Initialized
DEBUG - 2013-12-01 23:05:48 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:05:48 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:05:48 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:05:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:05:48 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:48 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:48 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:05:48 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:49 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:49 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:05:49 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 23:05:49 --> Final output sent to browser
DEBUG - 2013-12-01 23:05:49 --> Total execution time: 3.6992
DEBUG - 2013-12-01 23:05:53 --> Config Class Initialized
DEBUG - 2013-12-01 23:05:53 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:05:54 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:05:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:05:54 --> URI Class Initialized
DEBUG - 2013-12-01 23:05:54 --> Router Class Initialized
DEBUG - 2013-12-01 23:05:54 --> Output Class Initialized
DEBUG - 2013-12-01 23:05:54 --> Security Class Initialized
DEBUG - 2013-12-01 23:05:54 --> Input Class Initialized
DEBUG - 2013-12-01 23:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:05:54 --> Language Class Initialized
DEBUG - 2013-12-01 23:05:55 --> Loader Class Initialized
DEBUG - 2013-12-01 23:05:55 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:05:55 --> Session Class Initialized
DEBUG - 2013-12-01 23:05:55 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:05:55 --> Session routines successfully run
DEBUG - 2013-12-01 23:05:55 --> Controller Class Initialized
DEBUG - 2013-12-01 23:05:56 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:05:56 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:05:56 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:05:56 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:05:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:05:56 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:56 --> Model Class Initialized
DEBUG - 2013-12-01 23:05:56 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:05:57 --> Upload Class Initialized
DEBUG - 2013-12-01 23:05:57 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:05:57 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:05:57 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:05:57 --> Final output sent to browser
DEBUG - 2013-12-01 23:05:57 --> Total execution time: 3.6702
DEBUG - 2013-12-01 23:06:03 --> Config Class Initialized
DEBUG - 2013-12-01 23:06:03 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:06:03 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:06:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:06:04 --> URI Class Initialized
DEBUG - 2013-12-01 23:06:04 --> Router Class Initialized
DEBUG - 2013-12-01 23:06:04 --> Output Class Initialized
DEBUG - 2013-12-01 23:06:04 --> Security Class Initialized
DEBUG - 2013-12-01 23:06:04 --> Input Class Initialized
DEBUG - 2013-12-01 23:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:06:04 --> Language Class Initialized
DEBUG - 2013-12-01 23:06:04 --> Loader Class Initialized
DEBUG - 2013-12-01 23:06:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:06:04 --> Session Class Initialized
DEBUG - 2013-12-01 23:06:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:06:05 --> Session routines successfully run
DEBUG - 2013-12-01 23:06:05 --> Controller Class Initialized
DEBUG - 2013-12-01 23:06:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:06:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:06:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:06:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:06:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:06 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:06 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:06 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:06:06 --> Upload Class Initialized
DEBUG - 2013-12-01 23:06:06 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:06:06 --> File loaded: application/views/auth/change_password_form.php
DEBUG - 2013-12-01 23:06:06 --> Final output sent to browser
DEBUG - 2013-12-01 23:06:07 --> Total execution time: 3.3982
DEBUG - 2013-12-01 23:06:13 --> Config Class Initialized
DEBUG - 2013-12-01 23:06:13 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:06:14 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:06:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:06:14 --> URI Class Initialized
DEBUG - 2013-12-01 23:06:14 --> Router Class Initialized
DEBUG - 2013-12-01 23:06:14 --> Output Class Initialized
DEBUG - 2013-12-01 23:06:14 --> Security Class Initialized
DEBUG - 2013-12-01 23:06:14 --> Input Class Initialized
DEBUG - 2013-12-01 23:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:06:14 --> Language Class Initialized
DEBUG - 2013-12-01 23:06:14 --> Loader Class Initialized
DEBUG - 2013-12-01 23:06:15 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:06:15 --> Session Class Initialized
DEBUG - 2013-12-01 23:06:15 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:06:15 --> Session routines successfully run
DEBUG - 2013-12-01 23:06:15 --> Controller Class Initialized
DEBUG - 2013-12-01 23:06:15 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:06:15 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:06:15 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:06:16 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:06:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:16 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:16 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:16 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:06:16 --> Upload Class Initialized
DEBUG - 2013-12-01 23:06:16 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:16 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:06:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:06:16 --> XSS Filtering completed
DEBUG - 2013-12-01 23:06:17 --> XSS Filtering completed
DEBUG - 2013-12-01 23:06:17 --> XSS Filtering completed
ERROR - 2013-12-01 23:06:17 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 23:06:18 --> Config Class Initialized
DEBUG - 2013-12-01 23:06:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:06:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:06:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:06:18 --> URI Class Initialized
DEBUG - 2013-12-01 23:06:18 --> Router Class Initialized
DEBUG - 2013-12-01 23:06:18 --> Output Class Initialized
DEBUG - 2013-12-01 23:06:18 --> Security Class Initialized
DEBUG - 2013-12-01 23:06:18 --> Input Class Initialized
DEBUG - 2013-12-01 23:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:06:19 --> Language Class Initialized
DEBUG - 2013-12-01 23:06:19 --> Loader Class Initialized
DEBUG - 2013-12-01 23:06:19 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:06:19 --> Session Class Initialized
DEBUG - 2013-12-01 23:06:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:06:19 --> Session routines successfully run
DEBUG - 2013-12-01 23:06:19 --> Controller Class Initialized
DEBUG - 2013-12-01 23:06:19 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:06:20 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:06:20 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:06:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:20 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:20 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:20 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:06:20 --> Upload Class Initialized
DEBUG - 2013-12-01 23:06:20 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:21 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 23:06:21 --> Severity: Notice  --> Undefined index: HTTP_REFERRER C:\Program Files (x86)\Ampps\www\project\application\controllers\auth.php 34
DEBUG - 2013-12-01 23:06:21 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 23:06:21 --> Final output sent to browser
DEBUG - 2013-12-01 23:06:21 --> Total execution time: 3.2292
DEBUG - 2013-12-01 23:06:26 --> Config Class Initialized
DEBUG - 2013-12-01 23:06:26 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:06:26 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:06:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:06:27 --> URI Class Initialized
DEBUG - 2013-12-01 23:06:27 --> Router Class Initialized
DEBUG - 2013-12-01 23:06:27 --> Output Class Initialized
DEBUG - 2013-12-01 23:06:27 --> Security Class Initialized
DEBUG - 2013-12-01 23:06:27 --> Input Class Initialized
DEBUG - 2013-12-01 23:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:06:27 --> Language Class Initialized
DEBUG - 2013-12-01 23:06:27 --> Loader Class Initialized
DEBUG - 2013-12-01 23:06:27 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:06:28 --> Session Class Initialized
DEBUG - 2013-12-01 23:06:28 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:06:28 --> Session routines successfully run
DEBUG - 2013-12-01 23:06:28 --> Controller Class Initialized
DEBUG - 2013-12-01 23:06:28 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:06:28 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:06:29 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:06:29 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:06:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:29 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:29 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:29 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:06:29 --> Upload Class Initialized
DEBUG - 2013-12-01 23:06:29 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:29 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:06:30 --> Config Class Initialized
DEBUG - 2013-12-01 23:06:30 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:06:30 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:06:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:06:30 --> URI Class Initialized
DEBUG - 2013-12-01 23:06:30 --> Router Class Initialized
DEBUG - 2013-12-01 23:06:30 --> Output Class Initialized
DEBUG - 2013-12-01 23:06:30 --> Security Class Initialized
DEBUG - 2013-12-01 23:06:30 --> Input Class Initialized
DEBUG - 2013-12-01 23:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:06:31 --> Language Class Initialized
DEBUG - 2013-12-01 23:06:31 --> Loader Class Initialized
DEBUG - 2013-12-01 23:06:31 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:06:31 --> Session Class Initialized
DEBUG - 2013-12-01 23:06:31 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:06:31 --> Session routines successfully run
DEBUG - 2013-12-01 23:06:31 --> Controller Class Initialized
DEBUG - 2013-12-01 23:06:31 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:06:32 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:06:32 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:06:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:06:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:32 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:32 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:32 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:06:32 --> Upload Class Initialized
DEBUG - 2013-12-01 23:06:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:06:33 --> Config Class Initialized
DEBUG - 2013-12-01 23:06:33 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:06:33 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:06:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:06:33 --> URI Class Initialized
DEBUG - 2013-12-01 23:06:34 --> Router Class Initialized
DEBUG - 2013-12-01 23:06:34 --> Output Class Initialized
DEBUG - 2013-12-01 23:06:34 --> Security Class Initialized
DEBUG - 2013-12-01 23:06:34 --> Input Class Initialized
DEBUG - 2013-12-01 23:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:06:34 --> Language Class Initialized
DEBUG - 2013-12-01 23:06:34 --> Loader Class Initialized
DEBUG - 2013-12-01 23:06:35 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:06:35 --> Session Class Initialized
DEBUG - 2013-12-01 23:06:35 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:06:35 --> Session routines successfully run
DEBUG - 2013-12-01 23:06:35 --> Controller Class Initialized
DEBUG - 2013-12-01 23:06:35 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:06:35 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:06:36 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:06:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:06:36 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:36 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:36 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:06:36 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:36 --> Model Class Initialized
DEBUG - 2013-12-01 23:06:36 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:06:37 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 23:06:37 --> Final output sent to browser
DEBUG - 2013-12-01 23:06:37 --> Total execution time: 3.7122
DEBUG - 2013-12-01 23:10:19 --> Config Class Initialized
DEBUG - 2013-12-01 23:10:19 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:10:19 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:10:19 --> URI Class Initialized
DEBUG - 2013-12-01 23:10:19 --> Router Class Initialized
DEBUG - 2013-12-01 23:10:19 --> Output Class Initialized
DEBUG - 2013-12-01 23:10:20 --> Security Class Initialized
DEBUG - 2013-12-01 23:10:20 --> Input Class Initialized
DEBUG - 2013-12-01 23:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:10:20 --> Language Class Initialized
DEBUG - 2013-12-01 23:10:20 --> Loader Class Initialized
DEBUG - 2013-12-01 23:10:20 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:10:20 --> Session Class Initialized
DEBUG - 2013-12-01 23:10:20 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:10:21 --> Session routines successfully run
DEBUG - 2013-12-01 23:10:21 --> Controller Class Initialized
DEBUG - 2013-12-01 23:10:21 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:10:21 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:10:21 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:10:21 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:10:22 --> Model Class Initialized
DEBUG - 2013-12-01 23:10:22 --> Model Class Initialized
DEBUG - 2013-12-01 23:10:22 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:10:22 --> Upload Class Initialized
DEBUG - 2013-12-01 23:10:22 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:10:22 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:10:22 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:10:23 --> Config Class Initialized
DEBUG - 2013-12-01 23:10:23 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:10:23 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:10:23 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:10:23 --> URI Class Initialized
DEBUG - 2013-12-01 23:10:23 --> Router Class Initialized
DEBUG - 2013-12-01 23:10:23 --> Output Class Initialized
DEBUG - 2013-12-01 23:10:23 --> Security Class Initialized
DEBUG - 2013-12-01 23:10:23 --> Input Class Initialized
DEBUG - 2013-12-01 23:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:10:24 --> Language Class Initialized
DEBUG - 2013-12-01 23:10:43 --> Config Class Initialized
DEBUG - 2013-12-01 23:10:43 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:10:44 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:10:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:10:44 --> URI Class Initialized
DEBUG - 2013-12-01 23:10:44 --> Router Class Initialized
DEBUG - 2013-12-01 23:10:44 --> Output Class Initialized
DEBUG - 2013-12-01 23:10:44 --> Security Class Initialized
DEBUG - 2013-12-01 23:10:44 --> Input Class Initialized
DEBUG - 2013-12-01 23:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:10:44 --> Language Class Initialized
DEBUG - 2013-12-01 23:10:45 --> Loader Class Initialized
DEBUG - 2013-12-01 23:10:45 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:10:45 --> Session Class Initialized
DEBUG - 2013-12-01 23:10:45 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:10:45 --> A session cookie was not found.
DEBUG - 2013-12-01 23:10:45 --> Session routines successfully run
DEBUG - 2013-12-01 23:10:45 --> Controller Class Initialized
DEBUG - 2013-12-01 23:10:46 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:10:46 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:10:46 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:10:46 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:10:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:10:46 --> Model Class Initialized
DEBUG - 2013-12-01 23:10:46 --> Model Class Initialized
DEBUG - 2013-12-01 23:10:46 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:10:47 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:10:47 --> Upload Class Initialized
DEBUG - 2013-12-01 23:10:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:10:47 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:10:47 --> Model Class Initialized
DEBUG - 2013-12-01 23:10:47 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 23:10:47 --> Final output sent to browser
DEBUG - 2013-12-01 23:10:47 --> Total execution time: 3.8792
DEBUG - 2013-12-01 23:10:51 --> Config Class Initialized
DEBUG - 2013-12-01 23:10:51 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:10:51 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:10:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:10:52 --> URI Class Initialized
DEBUG - 2013-12-01 23:10:52 --> Router Class Initialized
DEBUG - 2013-12-01 23:10:52 --> Output Class Initialized
DEBUG - 2013-12-01 23:10:52 --> Security Class Initialized
DEBUG - 2013-12-01 23:10:52 --> Input Class Initialized
DEBUG - 2013-12-01 23:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:10:52 --> Language Class Initialized
DEBUG - 2013-12-01 23:10:52 --> Loader Class Initialized
DEBUG - 2013-12-01 23:10:53 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:10:53 --> Session Class Initialized
DEBUG - 2013-12-01 23:10:53 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:10:53 --> Session routines successfully run
DEBUG - 2013-12-01 23:10:53 --> Controller Class Initialized
DEBUG - 2013-12-01 23:10:53 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:10:53 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:10:54 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:10:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:10:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:10:54 --> Model Class Initialized
DEBUG - 2013-12-01 23:10:54 --> Model Class Initialized
DEBUG - 2013-12-01 23:10:54 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:10:54 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:10:54 --> Upload Class Initialized
DEBUG - 2013-12-01 23:10:55 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:10:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:10:55 --> XSS Filtering completed
DEBUG - 2013-12-01 23:10:55 --> Model Class Initialized
DEBUG - 2013-12-01 23:10:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:10:55 --> XSS Filtering completed
DEBUG - 2013-12-01 23:10:55 --> XSS Filtering completed
DEBUG - 2013-12-01 23:10:57 --> Config Class Initialized
DEBUG - 2013-12-01 23:10:57 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:10:57 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:10:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:10:57 --> URI Class Initialized
DEBUG - 2013-12-01 23:10:57 --> Router Class Initialized
DEBUG - 2013-12-01 23:10:57 --> Output Class Initialized
DEBUG - 2013-12-01 23:10:57 --> Security Class Initialized
DEBUG - 2013-12-01 23:10:58 --> Input Class Initialized
DEBUG - 2013-12-01 23:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:10:58 --> Language Class Initialized
DEBUG - 2013-12-01 23:10:58 --> Loader Class Initialized
DEBUG - 2013-12-01 23:10:58 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:10:58 --> Session Class Initialized
DEBUG - 2013-12-01 23:10:58 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:10:59 --> Session routines successfully run
DEBUG - 2013-12-01 23:10:59 --> Controller Class Initialized
DEBUG - 2013-12-01 23:10:59 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:10:59 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:10:59 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:10:59 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:00 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:00 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:11:00 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:00 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:00 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:11:00 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 23:11:00 --> Final output sent to browser
DEBUG - 2013-12-01 23:11:00 --> Total execution time: 3.7162
DEBUG - 2013-12-01 23:11:03 --> Config Class Initialized
DEBUG - 2013-12-01 23:11:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:11:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:11:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:11:04 --> URI Class Initialized
DEBUG - 2013-12-01 23:11:04 --> Router Class Initialized
DEBUG - 2013-12-01 23:11:04 --> Output Class Initialized
DEBUG - 2013-12-01 23:11:04 --> Security Class Initialized
DEBUG - 2013-12-01 23:11:04 --> Input Class Initialized
DEBUG - 2013-12-01 23:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:11:04 --> Language Class Initialized
DEBUG - 2013-12-01 23:11:05 --> Loader Class Initialized
DEBUG - 2013-12-01 23:11:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:11:05 --> Session Class Initialized
DEBUG - 2013-12-01 23:11:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:11:05 --> Session routines successfully run
DEBUG - 2013-12-01 23:11:05 --> Controller Class Initialized
DEBUG - 2013-12-01 23:11:06 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:11:06 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:11:06 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:11:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:11:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:11:06 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:06 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:06 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:11:07 --> Upload Class Initialized
DEBUG - 2013-12-01 23:11:07 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:11:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:11:07 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:11:07 --> Config Class Initialized
DEBUG - 2013-12-01 23:11:07 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:11:07 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:11:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:11:08 --> URI Class Initialized
DEBUG - 2013-12-01 23:11:08 --> Router Class Initialized
DEBUG - 2013-12-01 23:11:08 --> Output Class Initialized
DEBUG - 2013-12-01 23:11:08 --> Security Class Initialized
DEBUG - 2013-12-01 23:11:08 --> Input Class Initialized
DEBUG - 2013-12-01 23:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:11:08 --> Language Class Initialized
DEBUG - 2013-12-01 23:11:08 --> Loader Class Initialized
DEBUG - 2013-12-01 23:11:08 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:11:09 --> Session Class Initialized
DEBUG - 2013-12-01 23:11:09 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:11:09 --> A session cookie was not found.
DEBUG - 2013-12-01 23:11:09 --> Session routines successfully run
DEBUG - 2013-12-01 23:11:09 --> Controller Class Initialized
DEBUG - 2013-12-01 23:11:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:11:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:11:10 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:11:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:11:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:11:10 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:10 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:11:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:11:10 --> Upload Class Initialized
DEBUG - 2013-12-01 23:11:11 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:11:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:11:11 --> Model Class Initialized
DEBUG - 2013-12-01 23:11:11 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 23:11:11 --> Final output sent to browser
DEBUG - 2013-12-01 23:11:11 --> Total execution time: 3.9212
DEBUG - 2013-12-01 23:17:30 --> Config Class Initialized
DEBUG - 2013-12-01 23:17:31 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:17:31 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:17:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:17:31 --> URI Class Initialized
DEBUG - 2013-12-01 23:17:31 --> Router Class Initialized
DEBUG - 2013-12-01 23:17:31 --> Output Class Initialized
DEBUG - 2013-12-01 23:17:31 --> Security Class Initialized
DEBUG - 2013-12-01 23:17:31 --> Input Class Initialized
DEBUG - 2013-12-01 23:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:17:31 --> Language Class Initialized
DEBUG - 2013-12-01 23:17:32 --> Loader Class Initialized
DEBUG - 2013-12-01 23:17:32 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:17:32 --> Session Class Initialized
DEBUG - 2013-12-01 23:17:32 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:17:32 --> Session routines successfully run
DEBUG - 2013-12-01 23:17:32 --> Controller Class Initialized
DEBUG - 2013-12-01 23:17:32 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:17:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:17:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:17:33 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:17:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:17:33 --> Model Class Initialized
DEBUG - 2013-12-01 23:17:33 --> Model Class Initialized
DEBUG - 2013-12-01 23:17:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:17:33 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:17:34 --> Upload Class Initialized
DEBUG - 2013-12-01 23:17:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:17:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:17:34 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 23:17:34 --> Final output sent to browser
DEBUG - 2013-12-01 23:17:34 --> Total execution time: 3.5592
DEBUG - 2013-12-01 23:17:49 --> Config Class Initialized
DEBUG - 2013-12-01 23:17:49 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:17:49 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:17:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:17:49 --> URI Class Initialized
DEBUG - 2013-12-01 23:17:49 --> Router Class Initialized
DEBUG - 2013-12-01 23:17:50 --> Output Class Initialized
DEBUG - 2013-12-01 23:17:50 --> Security Class Initialized
DEBUG - 2013-12-01 23:17:50 --> Input Class Initialized
DEBUG - 2013-12-01 23:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:17:50 --> Language Class Initialized
DEBUG - 2013-12-01 23:17:50 --> Loader Class Initialized
DEBUG - 2013-12-01 23:17:50 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:17:50 --> Session Class Initialized
DEBUG - 2013-12-01 23:17:50 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:17:50 --> Session routines successfully run
DEBUG - 2013-12-01 23:17:51 --> Controller Class Initialized
DEBUG - 2013-12-01 23:17:51 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:17:51 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:17:51 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:17:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:17:51 --> Model Class Initialized
DEBUG - 2013-12-01 23:17:51 --> Model Class Initialized
DEBUG - 2013-12-01 23:17:52 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:17:52 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:17:52 --> Upload Class Initialized
DEBUG - 2013-12-01 23:17:52 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:17:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:17:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:17:52 --> XSS Filtering completed
DEBUG - 2013-12-01 23:17:52 --> XSS Filtering completed
DEBUG - 2013-12-01 23:17:52 --> XSS Filtering completed
DEBUG - 2013-12-01 23:17:53 --> XSS Filtering completed
DEBUG - 2013-12-01 23:17:53 --> XSS Filtering completed
DEBUG - 2013-12-01 23:17:53 --> XSS Filtering completed
ERROR - 2013-12-01 23:17:53 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 23:17:54 --> Email Class Initialized
DEBUG - 2013-12-01 23:17:54 --> File loaded: application/views/email/activate-html.php
DEBUG - 2013-12-01 23:17:54 --> File loaded: application/views/email/activate-txt.php
DEBUG - 2013-12-01 23:17:55 --> Language file loaded: language/english/email_lang.php
ERROR - 2013-12-01 23:17:56 --> Severity: 4096  --> Object of class Auth could not be converted to string C:\Program Files (x86)\Ampps\www\project\application\controllers\auth.php 204
ERROR - 2013-12-01 23:17:56 --> Severity: Notice  --> Object of class Auth to string conversion C:\Program Files (x86)\Ampps\www\project\application\controllers\auth.php 204
ERROR - 2013-12-01 23:17:56 --> Severity: Notice  --> Undefined property: Auth::$Object C:\Program Files (x86)\Ampps\www\project\application\controllers\auth.php 204
DEBUG - 2013-12-01 23:20:06 --> Config Class Initialized
DEBUG - 2013-12-01 23:20:07 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:20:07 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:20:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:20:07 --> URI Class Initialized
DEBUG - 2013-12-01 23:20:07 --> Router Class Initialized
DEBUG - 2013-12-01 23:20:07 --> Output Class Initialized
DEBUG - 2013-12-01 23:20:07 --> Security Class Initialized
DEBUG - 2013-12-01 23:20:07 --> Input Class Initialized
DEBUG - 2013-12-01 23:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:20:07 --> Language Class Initialized
DEBUG - 2013-12-01 23:20:08 --> Loader Class Initialized
DEBUG - 2013-12-01 23:20:08 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:20:08 --> Session Class Initialized
DEBUG - 2013-12-01 23:20:08 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:20:08 --> Session routines successfully run
DEBUG - 2013-12-01 23:20:08 --> Controller Class Initialized
DEBUG - 2013-12-01 23:20:08 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:20:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:20:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:20:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:20:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:20:09 --> Model Class Initialized
DEBUG - 2013-12-01 23:20:09 --> Model Class Initialized
DEBUG - 2013-12-01 23:20:09 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:20:09 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:20:09 --> Upload Class Initialized
DEBUG - 2013-12-01 23:20:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:20:10 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 23:20:10 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 23:20:10 --> Severity: Notice  --> Undefined index: ip_address C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 23:20:10 --> Severity: Notice  --> Undefined index: user_agent C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 23:20:10 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 23:20:10 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 288
ERROR - 2013-12-01 23:20:10 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 289
DEBUG - 2013-12-01 23:20:11 --> Config Class Initialized
DEBUG - 2013-12-01 23:20:11 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:20:11 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:20:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:20:11 --> URI Class Initialized
DEBUG - 2013-12-01 23:20:11 --> Router Class Initialized
DEBUG - 2013-12-01 23:20:11 --> Output Class Initialized
DEBUG - 2013-12-01 23:20:11 --> Security Class Initialized
DEBUG - 2013-12-01 23:20:11 --> Input Class Initialized
DEBUG - 2013-12-01 23:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:20:12 --> Language Class Initialized
DEBUG - 2013-12-01 23:20:12 --> Loader Class Initialized
DEBUG - 2013-12-01 23:20:12 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:20:12 --> Session Class Initialized
DEBUG - 2013-12-01 23:20:12 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:20:13 --> Session routines successfully run
DEBUG - 2013-12-01 23:20:13 --> Controller Class Initialized
DEBUG - 2013-12-01 23:20:13 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:20:13 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:20:13 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:20:13 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:20:13 --> Model Class Initialized
DEBUG - 2013-12-01 23:20:13 --> Model Class Initialized
DEBUG - 2013-12-01 23:20:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:20:14 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:20:14 --> Upload Class Initialized
DEBUG - 2013-12-01 23:20:14 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:20:14 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:20:14 --> Config Class Initialized
DEBUG - 2013-12-01 23:20:14 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:20:14 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:20:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:20:15 --> URI Class Initialized
DEBUG - 2013-12-01 23:20:15 --> Router Class Initialized
DEBUG - 2013-12-01 23:20:15 --> Output Class Initialized
DEBUG - 2013-12-01 23:20:15 --> Security Class Initialized
DEBUG - 2013-12-01 23:20:15 --> Input Class Initialized
DEBUG - 2013-12-01 23:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:20:15 --> Language Class Initialized
DEBUG - 2013-12-01 23:20:15 --> Loader Class Initialized
DEBUG - 2013-12-01 23:20:16 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:20:16 --> Session Class Initialized
DEBUG - 2013-12-01 23:20:16 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:20:16 --> Session routines successfully run
DEBUG - 2013-12-01 23:20:16 --> Controller Class Initialized
DEBUG - 2013-12-01 23:20:16 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:20:16 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:20:16 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:20:17 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:20:17 --> Model Class Initialized
DEBUG - 2013-12-01 23:20:17 --> Model Class Initialized
DEBUG - 2013-12-01 23:20:17 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:20:17 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:20:17 --> Upload Class Initialized
DEBUG - 2013-12-01 23:20:17 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:20:17 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:20:18 --> Model Class Initialized
DEBUG - 2013-12-01 23:20:18 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 23:20:18 --> Final output sent to browser
DEBUG - 2013-12-01 23:20:18 --> Total execution time: 3.6102
DEBUG - 2013-12-01 23:23:29 --> Config Class Initialized
DEBUG - 2013-12-01 23:23:30 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:23:30 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:23:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:23:30 --> URI Class Initialized
DEBUG - 2013-12-01 23:23:30 --> Router Class Initialized
DEBUG - 2013-12-01 23:23:30 --> Output Class Initialized
DEBUG - 2013-12-01 23:23:30 --> Security Class Initialized
DEBUG - 2013-12-01 23:23:30 --> Input Class Initialized
DEBUG - 2013-12-01 23:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:23:31 --> Language Class Initialized
DEBUG - 2013-12-01 23:23:31 --> Loader Class Initialized
DEBUG - 2013-12-01 23:23:31 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:23:31 --> Session Class Initialized
DEBUG - 2013-12-01 23:23:31 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:23:32 --> Session routines successfully run
DEBUG - 2013-12-01 23:23:32 --> Controller Class Initialized
DEBUG - 2013-12-01 23:23:32 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:23:32 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:23:32 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:23:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:23:33 --> Model Class Initialized
DEBUG - 2013-12-01 23:23:33 --> Model Class Initialized
DEBUG - 2013-12-01 23:23:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:23:33 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:23:33 --> Upload Class Initialized
DEBUG - 2013-12-01 23:23:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:23:33 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:23:33 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 23:23:34 --> Final output sent to browser
DEBUG - 2013-12-01 23:23:34 --> Total execution time: 4.2102
DEBUG - 2013-12-01 23:23:39 --> Config Class Initialized
DEBUG - 2013-12-01 23:23:39 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:23:39 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:23:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:23:39 --> URI Class Initialized
DEBUG - 2013-12-01 23:23:39 --> Router Class Initialized
DEBUG - 2013-12-01 23:23:39 --> Output Class Initialized
DEBUG - 2013-12-01 23:23:39 --> Security Class Initialized
DEBUG - 2013-12-01 23:23:39 --> Input Class Initialized
DEBUG - 2013-12-01 23:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:23:40 --> Language Class Initialized
DEBUG - 2013-12-01 23:23:40 --> Loader Class Initialized
DEBUG - 2013-12-01 23:23:40 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:23:40 --> Session Class Initialized
DEBUG - 2013-12-01 23:23:40 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:23:41 --> Session routines successfully run
DEBUG - 2013-12-01 23:23:41 --> Controller Class Initialized
DEBUG - 2013-12-01 23:23:41 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:23:41 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:23:41 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:23:41 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:23:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:23:42 --> Model Class Initialized
DEBUG - 2013-12-01 23:23:42 --> Model Class Initialized
DEBUG - 2013-12-01 23:23:42 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:23:42 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:23:42 --> Upload Class Initialized
DEBUG - 2013-12-01 23:23:42 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:23:42 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:23:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:23:43 --> XSS Filtering completed
DEBUG - 2013-12-01 23:23:43 --> XSS Filtering completed
DEBUG - 2013-12-01 23:23:43 --> XSS Filtering completed
DEBUG - 2013-12-01 23:23:43 --> XSS Filtering completed
DEBUG - 2013-12-01 23:23:43 --> XSS Filtering completed
DEBUG - 2013-12-01 23:23:43 --> XSS Filtering completed
ERROR - 2013-12-01 23:23:43 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 23:23:44 --> Email Class Initialized
DEBUG - 2013-12-01 23:23:44 --> File loaded: application/views/email/activate-html.php
DEBUG - 2013-12-01 23:23:44 --> File loaded: application/views/email/activate-txt.php
DEBUG - 2013-12-01 23:23:45 --> Language file loaded: language/english/email_lang.php
DEBUG - 2013-12-01 23:23:46 --> Config Class Initialized
DEBUG - 2013-12-01 23:23:46 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:23:46 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:23:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:23:46 --> URI Class Initialized
DEBUG - 2013-12-01 23:23:47 --> Router Class Initialized
DEBUG - 2013-12-01 23:23:47 --> Output Class Initialized
DEBUG - 2013-12-01 23:23:47 --> Security Class Initialized
DEBUG - 2013-12-01 23:23:47 --> Input Class Initialized
DEBUG - 2013-12-01 23:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:23:47 --> Language Class Initialized
DEBUG - 2013-12-01 23:23:47 --> Loader Class Initialized
DEBUG - 2013-12-01 23:23:47 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:23:48 --> Session Class Initialized
DEBUG - 2013-12-01 23:23:48 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:23:49 --> Session routines successfully run
DEBUG - 2013-12-01 23:23:49 --> Controller Class Initialized
DEBUG - 2013-12-01 23:23:49 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:23:49 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:23:49 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:23:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:23:50 --> Model Class Initialized
DEBUG - 2013-12-01 23:23:50 --> Model Class Initialized
DEBUG - 2013-12-01 23:23:50 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:23:50 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:23:50 --> Upload Class Initialized
DEBUG - 2013-12-01 23:23:50 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:23:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:23:51 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 23:23:51 --> Final output sent to browser
DEBUG - 2013-12-01 23:23:51 --> Total execution time: 4.9723
DEBUG - 2013-12-01 23:24:49 --> Config Class Initialized
DEBUG - 2013-12-01 23:24:49 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:24:49 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:24:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:24:49 --> URI Class Initialized
DEBUG - 2013-12-01 23:24:49 --> Router Class Initialized
DEBUG - 2013-12-01 23:24:49 --> Output Class Initialized
DEBUG - 2013-12-01 23:24:49 --> Security Class Initialized
DEBUG - 2013-12-01 23:24:49 --> Input Class Initialized
DEBUG - 2013-12-01 23:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:24:50 --> Language Class Initialized
DEBUG - 2013-12-01 23:24:50 --> Loader Class Initialized
DEBUG - 2013-12-01 23:24:50 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:24:50 --> Session Class Initialized
DEBUG - 2013-12-01 23:24:50 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:24:50 --> Session routines successfully run
DEBUG - 2013-12-01 23:24:51 --> Controller Class Initialized
DEBUG - 2013-12-01 23:24:51 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:24:51 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:24:51 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:24:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:24:51 --> Model Class Initialized
DEBUG - 2013-12-01 23:24:52 --> Model Class Initialized
DEBUG - 2013-12-01 23:24:52 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:24:52 --> Config Class Initialized
DEBUG - 2013-12-01 23:24:52 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:24:52 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:24:52 --> Upload Class Initialized
DEBUG - 2013-12-01 23:24:52 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:24:52 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:24:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:24:53 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:24:53 --> URI Class Initialized
DEBUG - 2013-12-01 23:24:53 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 23:24:53 --> Router Class Initialized
DEBUG - 2013-12-01 23:24:53 --> Final output sent to browser
DEBUG - 2013-12-01 23:24:53 --> Output Class Initialized
DEBUG - 2013-12-01 23:24:53 --> Total execution time: 4.5573
DEBUG - 2013-12-01 23:24:54 --> Security Class Initialized
DEBUG - 2013-12-01 23:24:54 --> Input Class Initialized
DEBUG - 2013-12-01 23:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:24:54 --> Language Class Initialized
DEBUG - 2013-12-01 23:24:54 --> Loader Class Initialized
DEBUG - 2013-12-01 23:24:54 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:24:54 --> Session Class Initialized
DEBUG - 2013-12-01 23:24:54 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:24:55 --> Session routines successfully run
DEBUG - 2013-12-01 23:24:55 --> Controller Class Initialized
DEBUG - 2013-12-01 23:24:55 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:24:55 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:24:55 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:24:55 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:24:55 --> Model Class Initialized
DEBUG - 2013-12-01 23:24:56 --> Model Class Initialized
DEBUG - 2013-12-01 23:24:56 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:24:56 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:24:56 --> Upload Class Initialized
DEBUG - 2013-12-01 23:24:56 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:24:56 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:24:56 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 23:24:56 --> Final output sent to browser
DEBUG - 2013-12-01 23:24:56 --> Total execution time: 4.6503
DEBUG - 2013-12-01 23:25:03 --> Config Class Initialized
DEBUG - 2013-12-01 23:25:03 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:25:03 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:25:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:25:03 --> URI Class Initialized
DEBUG - 2013-12-01 23:25:03 --> Router Class Initialized
DEBUG - 2013-12-01 23:25:03 --> Output Class Initialized
DEBUG - 2013-12-01 23:25:03 --> Security Class Initialized
DEBUG - 2013-12-01 23:25:03 --> Input Class Initialized
DEBUG - 2013-12-01 23:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:25:04 --> Language Class Initialized
DEBUG - 2013-12-01 23:25:04 --> Loader Class Initialized
DEBUG - 2013-12-01 23:25:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:25:04 --> Session Class Initialized
DEBUG - 2013-12-01 23:25:04 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:25:04 --> Session routines successfully run
DEBUG - 2013-12-01 23:25:04 --> Controller Class Initialized
DEBUG - 2013-12-01 23:25:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:25:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:25:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:25:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:25:05 --> Model Class Initialized
DEBUG - 2013-12-01 23:25:05 --> Model Class Initialized
DEBUG - 2013-12-01 23:25:05 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:25:05 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:25:06 --> Upload Class Initialized
DEBUG - 2013-12-01 23:25:06 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:25:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:25:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:25:06 --> XSS Filtering completed
DEBUG - 2013-12-01 23:25:06 --> XSS Filtering completed
DEBUG - 2013-12-01 23:25:06 --> XSS Filtering completed
DEBUG - 2013-12-01 23:25:06 --> XSS Filtering completed
DEBUG - 2013-12-01 23:25:06 --> XSS Filtering completed
DEBUG - 2013-12-01 23:25:07 --> XSS Filtering completed
ERROR - 2013-12-01 23:25:07 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 23:25:07 --> Email Class Initialized
DEBUG - 2013-12-01 23:25:07 --> File loaded: application/views/email/activate-html.php
DEBUG - 2013-12-01 23:25:07 --> File loaded: application/views/email/activate-txt.php
DEBUG - 2013-12-01 23:25:08 --> Language file loaded: language/english/email_lang.php
DEBUG - 2013-12-01 23:25:09 --> Config Class Initialized
DEBUG - 2013-12-01 23:25:09 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:25:09 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:25:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:25:10 --> URI Class Initialized
DEBUG - 2013-12-01 23:25:10 --> Router Class Initialized
DEBUG - 2013-12-01 23:25:10 --> Output Class Initialized
DEBUG - 2013-12-01 23:25:10 --> Security Class Initialized
DEBUG - 2013-12-01 23:25:10 --> Input Class Initialized
DEBUG - 2013-12-01 23:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:25:10 --> Language Class Initialized
DEBUG - 2013-12-01 23:25:10 --> Loader Class Initialized
DEBUG - 2013-12-01 23:25:10 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:25:11 --> Session Class Initialized
DEBUG - 2013-12-01 23:25:11 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:25:11 --> Session garbage collection performed.
DEBUG - 2013-12-01 23:25:11 --> Session routines successfully run
DEBUG - 2013-12-01 23:25:11 --> Controller Class Initialized
DEBUG - 2013-12-01 23:25:11 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:25:12 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:25:12 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:25:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:25:12 --> Model Class Initialized
DEBUG - 2013-12-01 23:25:12 --> Model Class Initialized
DEBUG - 2013-12-01 23:25:12 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:25:12 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:25:13 --> Upload Class Initialized
DEBUG - 2013-12-01 23:25:13 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:25:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:25:13 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 23:25:13 --> Final output sent to browser
DEBUG - 2013-12-01 23:25:13 --> Total execution time: 3.8652
DEBUG - 2013-12-01 23:25:18 --> Config Class Initialized
DEBUG - 2013-12-01 23:25:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:25:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:25:19 --> URI Class Initialized
DEBUG - 2013-12-01 23:25:19 --> Router Class Initialized
DEBUG - 2013-12-01 23:25:19 --> Output Class Initialized
DEBUG - 2013-12-01 23:25:19 --> Security Class Initialized
DEBUG - 2013-12-01 23:25:19 --> Input Class Initialized
DEBUG - 2013-12-01 23:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:25:19 --> Language Class Initialized
DEBUG - 2013-12-01 23:26:04 --> Config Class Initialized
DEBUG - 2013-12-01 23:26:04 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:26:04 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:26:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:26:04 --> URI Class Initialized
DEBUG - 2013-12-01 23:26:04 --> Router Class Initialized
DEBUG - 2013-12-01 23:26:04 --> Output Class Initialized
DEBUG - 2013-12-01 23:26:04 --> Security Class Initialized
DEBUG - 2013-12-01 23:26:04 --> Input Class Initialized
DEBUG - 2013-12-01 23:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:26:05 --> Language Class Initialized
DEBUG - 2013-12-01 23:26:05 --> Loader Class Initialized
DEBUG - 2013-12-01 23:26:05 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:26:05 --> Session Class Initialized
DEBUG - 2013-12-01 23:26:05 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:26:05 --> Session routines successfully run
DEBUG - 2013-12-01 23:26:06 --> Controller Class Initialized
DEBUG - 2013-12-01 23:26:06 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:26:06 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:26:06 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:26:06 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:26:06 --> Model Class Initialized
DEBUG - 2013-12-01 23:26:06 --> Model Class Initialized
DEBUG - 2013-12-01 23:26:07 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:26:07 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:26:07 --> Upload Class Initialized
DEBUG - 2013-12-01 23:26:07 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:26:07 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:26:07 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 23:26:07 --> Final output sent to browser
DEBUG - 2013-12-01 23:26:07 --> Total execution time: 3.6082
DEBUG - 2013-12-01 23:26:12 --> Config Class Initialized
DEBUG - 2013-12-01 23:26:12 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:26:12 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:26:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:26:12 --> URI Class Initialized
DEBUG - 2013-12-01 23:26:12 --> Router Class Initialized
DEBUG - 2013-12-01 23:26:12 --> Output Class Initialized
DEBUG - 2013-12-01 23:26:12 --> Security Class Initialized
DEBUG - 2013-12-01 23:26:12 --> Input Class Initialized
DEBUG - 2013-12-01 23:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:26:13 --> Language Class Initialized
DEBUG - 2013-12-01 23:26:13 --> Loader Class Initialized
DEBUG - 2013-12-01 23:26:13 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:26:13 --> Session Class Initialized
DEBUG - 2013-12-01 23:26:13 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:26:13 --> Session routines successfully run
DEBUG - 2013-12-01 23:26:13 --> Controller Class Initialized
DEBUG - 2013-12-01 23:26:14 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:26:14 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:26:14 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:26:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:26:14 --> Model Class Initialized
DEBUG - 2013-12-01 23:26:14 --> Model Class Initialized
DEBUG - 2013-12-01 23:26:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:26:14 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:26:15 --> Upload Class Initialized
DEBUG - 2013-12-01 23:26:15 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:26:15 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:26:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:26:15 --> XSS Filtering completed
DEBUG - 2013-12-01 23:26:15 --> XSS Filtering completed
DEBUG - 2013-12-01 23:26:15 --> XSS Filtering completed
DEBUG - 2013-12-01 23:26:15 --> XSS Filtering completed
DEBUG - 2013-12-01 23:26:15 --> XSS Filtering completed
DEBUG - 2013-12-01 23:26:16 --> XSS Filtering completed
ERROR - 2013-12-01 23:26:16 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 23:26:16 --> Email Class Initialized
DEBUG - 2013-12-01 23:26:16 --> File loaded: application/views/email/activate-html.php
DEBUG - 2013-12-01 23:26:16 --> File loaded: application/views/email/activate-txt.php
DEBUG - 2013-12-01 23:26:17 --> Language file loaded: language/english/email_lang.php
DEBUG - 2013-12-01 23:26:18 --> Config Class Initialized
DEBUG - 2013-12-01 23:26:18 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:26:18 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:26:18 --> URI Class Initialized
DEBUG - 2013-12-01 23:26:18 --> Router Class Initialized
DEBUG - 2013-12-01 23:26:19 --> Output Class Initialized
DEBUG - 2013-12-01 23:26:19 --> Security Class Initialized
DEBUG - 2013-12-01 23:26:19 --> Input Class Initialized
DEBUG - 2013-12-01 23:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:26:19 --> Language Class Initialized
DEBUG - 2013-12-01 23:26:19 --> Loader Class Initialized
DEBUG - 2013-12-01 23:26:19 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:26:19 --> Session Class Initialized
DEBUG - 2013-12-01 23:26:19 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:26:20 --> Session routines successfully run
DEBUG - 2013-12-01 23:26:20 --> Controller Class Initialized
DEBUG - 2013-12-01 23:26:20 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:26:20 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:26:20 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:26:20 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:26:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:26:21 --> Model Class Initialized
DEBUG - 2013-12-01 23:26:21 --> Model Class Initialized
DEBUG - 2013-12-01 23:26:21 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:26:21 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:26:21 --> Upload Class Initialized
DEBUG - 2013-12-01 23:26:21 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:26:21 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:26:22 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 23:26:22 --> Final output sent to browser
DEBUG - 2013-12-01 23:26:22 --> Total execution time: 3.6952
DEBUG - 2013-12-01 23:26:27 --> Config Class Initialized
DEBUG - 2013-12-01 23:26:27 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:26:27 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:26:28 --> URI Class Initialized
DEBUG - 2013-12-01 23:26:28 --> Router Class Initialized
DEBUG - 2013-12-01 23:26:28 --> Output Class Initialized
DEBUG - 2013-12-01 23:26:28 --> Security Class Initialized
DEBUG - 2013-12-01 23:26:29 --> Input Class Initialized
DEBUG - 2013-12-01 23:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:26:29 --> Language Class Initialized
DEBUG - 2013-12-01 23:26:47 --> Config Class Initialized
DEBUG - 2013-12-01 23:26:47 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:26:48 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:26:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:26:48 --> URI Class Initialized
DEBUG - 2013-12-01 23:26:48 --> Router Class Initialized
DEBUG - 2013-12-01 23:26:48 --> Output Class Initialized
DEBUG - 2013-12-01 23:26:48 --> Security Class Initialized
DEBUG - 2013-12-01 23:26:48 --> Input Class Initialized
DEBUG - 2013-12-01 23:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:26:49 --> Language Class Initialized
DEBUG - 2013-12-01 23:26:49 --> Loader Class Initialized
DEBUG - 2013-12-01 23:26:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:26:49 --> Session Class Initialized
DEBUG - 2013-12-01 23:26:50 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:26:50 --> Session routines successfully run
DEBUG - 2013-12-01 23:26:50 --> Controller Class Initialized
DEBUG - 2013-12-01 23:26:50 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:26:50 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:26:50 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:26:51 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:26:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:26:51 --> Model Class Initialized
DEBUG - 2013-12-01 23:26:51 --> Model Class Initialized
DEBUG - 2013-12-01 23:26:51 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:26:52 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:26:52 --> Upload Class Initialized
DEBUG - 2013-12-01 23:26:52 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:26:52 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:26:52 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 23:26:53 --> Final output sent to browser
DEBUG - 2013-12-01 23:26:53 --> Total execution time: 5.2153
DEBUG - 2013-12-01 23:27:07 --> Config Class Initialized
DEBUG - 2013-12-01 23:27:07 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:27:07 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:27:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:27:07 --> URI Class Initialized
DEBUG - 2013-12-01 23:27:07 --> Router Class Initialized
DEBUG - 2013-12-01 23:27:07 --> Output Class Initialized
DEBUG - 2013-12-01 23:27:07 --> Security Class Initialized
DEBUG - 2013-12-01 23:27:08 --> Input Class Initialized
DEBUG - 2013-12-01 23:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:27:08 --> Language Class Initialized
DEBUG - 2013-12-01 23:27:08 --> Loader Class Initialized
DEBUG - 2013-12-01 23:27:08 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:27:08 --> Session Class Initialized
DEBUG - 2013-12-01 23:27:09 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:27:09 --> Session routines successfully run
DEBUG - 2013-12-01 23:27:09 --> Controller Class Initialized
DEBUG - 2013-12-01 23:27:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:27:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:27:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:27:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:27:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:27:10 --> Model Class Initialized
DEBUG - 2013-12-01 23:27:10 --> Model Class Initialized
DEBUG - 2013-12-01 23:27:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:27:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:27:10 --> Upload Class Initialized
DEBUG - 2013-12-01 23:27:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:27:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:27:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:27:11 --> XSS Filtering completed
DEBUG - 2013-12-01 23:27:11 --> XSS Filtering completed
DEBUG - 2013-12-01 23:27:11 --> XSS Filtering completed
DEBUG - 2013-12-01 23:27:11 --> XSS Filtering completed
DEBUG - 2013-12-01 23:27:11 --> XSS Filtering completed
DEBUG - 2013-12-01 23:27:11 --> XSS Filtering completed
ERROR - 2013-12-01 23:27:11 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 23:27:13 --> Email Class Initialized
DEBUG - 2013-12-01 23:27:13 --> File loaded: application/views/email/activate-html.php
DEBUG - 2013-12-01 23:27:13 --> File loaded: application/views/email/activate-txt.php
DEBUG - 2013-12-01 23:27:14 --> Language file loaded: language/english/email_lang.php
DEBUG - 2013-12-01 23:27:16 --> Config Class Initialized
DEBUG - 2013-12-01 23:27:16 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:27:16 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:27:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:27:16 --> URI Class Initialized
DEBUG - 2013-12-01 23:27:16 --> Router Class Initialized
DEBUG - 2013-12-01 23:27:16 --> Output Class Initialized
DEBUG - 2013-12-01 23:27:17 --> Security Class Initialized
DEBUG - 2013-12-01 23:27:17 --> Input Class Initialized
DEBUG - 2013-12-01 23:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:27:17 --> Language Class Initialized
DEBUG - 2013-12-01 23:27:17 --> Loader Class Initialized
DEBUG - 2013-12-01 23:27:17 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:27:17 --> Session Class Initialized
DEBUG - 2013-12-01 23:27:18 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:27:18 --> Session routines successfully run
DEBUG - 2013-12-01 23:27:18 --> Controller Class Initialized
DEBUG - 2013-12-01 23:27:18 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:27:18 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:27:18 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:27:19 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:27:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:27:19 --> Model Class Initialized
DEBUG - 2013-12-01 23:27:19 --> Model Class Initialized
DEBUG - 2013-12-01 23:27:19 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:27:19 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:27:19 --> Upload Class Initialized
DEBUG - 2013-12-01 23:27:20 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:27:20 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:27:20 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 23:27:20 --> Final output sent to browser
DEBUG - 2013-12-01 23:27:20 --> Total execution time: 4.3342
DEBUG - 2013-12-01 23:29:06 --> Config Class Initialized
DEBUG - 2013-12-01 23:29:06 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:29:07 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:29:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:29:07 --> URI Class Initialized
DEBUG - 2013-12-01 23:29:07 --> Router Class Initialized
DEBUG - 2013-12-01 23:29:07 --> Output Class Initialized
DEBUG - 2013-12-01 23:29:07 --> Security Class Initialized
DEBUG - 2013-12-01 23:29:08 --> Input Class Initialized
DEBUG - 2013-12-01 23:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:29:08 --> Language Class Initialized
DEBUG - 2013-12-01 23:29:28 --> Config Class Initialized
DEBUG - 2013-12-01 23:29:28 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:29:28 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:29:28 --> URI Class Initialized
DEBUG - 2013-12-01 23:29:29 --> Router Class Initialized
DEBUG - 2013-12-01 23:29:29 --> Output Class Initialized
DEBUG - 2013-12-01 23:29:29 --> Security Class Initialized
DEBUG - 2013-12-01 23:29:29 --> Input Class Initialized
DEBUG - 2013-12-01 23:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:29:29 --> Language Class Initialized
DEBUG - 2013-12-01 23:29:40 --> Config Class Initialized
DEBUG - 2013-12-01 23:29:40 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:29:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:29:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:29:41 --> URI Class Initialized
DEBUG - 2013-12-01 23:29:41 --> Router Class Initialized
DEBUG - 2013-12-01 23:29:41 --> Output Class Initialized
DEBUG - 2013-12-01 23:29:41 --> Security Class Initialized
DEBUG - 2013-12-01 23:29:41 --> Input Class Initialized
DEBUG - 2013-12-01 23:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:29:42 --> Language Class Initialized
DEBUG - 2013-12-01 23:29:42 --> Loader Class Initialized
DEBUG - 2013-12-01 23:29:42 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:29:42 --> Session Class Initialized
DEBUG - 2013-12-01 23:29:43 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:29:43 --> Session routines successfully run
DEBUG - 2013-12-01 23:29:43 --> Controller Class Initialized
DEBUG - 2013-12-01 23:29:43 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:29:44 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:29:44 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:29:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:29:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:29:44 --> Model Class Initialized
DEBUG - 2013-12-01 23:29:44 --> Model Class Initialized
DEBUG - 2013-12-01 23:29:45 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:29:45 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:29:45 --> Upload Class Initialized
DEBUG - 2013-12-01 23:29:45 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:29:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:29:45 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 23:29:46 --> Final output sent to browser
DEBUG - 2013-12-01 23:29:46 --> Total execution time: 5.2993
DEBUG - 2013-12-01 23:29:58 --> Config Class Initialized
DEBUG - 2013-12-01 23:29:58 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:29:58 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:29:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:29:58 --> URI Class Initialized
DEBUG - 2013-12-01 23:29:59 --> Router Class Initialized
DEBUG - 2013-12-01 23:29:59 --> Output Class Initialized
DEBUG - 2013-12-01 23:29:59 --> Security Class Initialized
DEBUG - 2013-12-01 23:29:59 --> Input Class Initialized
DEBUG - 2013-12-01 23:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:29:59 --> Language Class Initialized
DEBUG - 2013-12-01 23:29:59 --> Loader Class Initialized
DEBUG - 2013-12-01 23:30:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:30:00 --> Session Class Initialized
DEBUG - 2013-12-01 23:30:00 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:30:00 --> Session routines successfully run
DEBUG - 2013-12-01 23:30:00 --> Controller Class Initialized
DEBUG - 2013-12-01 23:30:00 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:30:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:30:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:30:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:30:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:30:01 --> Model Class Initialized
DEBUG - 2013-12-01 23:30:01 --> Model Class Initialized
DEBUG - 2013-12-01 23:30:01 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:30:02 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:30:02 --> Upload Class Initialized
DEBUG - 2013-12-01 23:30:02 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:30:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:30:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:30:02 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:02 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:02 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:03 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:03 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:03 --> XSS Filtering completed
ERROR - 2013-12-01 23:30:03 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 23:30:04 --> Email Class Initialized
DEBUG - 2013-12-01 23:30:04 --> File loaded: application/views/email/activate-html.php
DEBUG - 2013-12-01 23:30:04 --> File loaded: application/views/email/activate-txt.php
DEBUG - 2013-12-01 23:30:04 --> Language file loaded: language/english/email_lang.php
DEBUG - 2013-12-01 23:30:06 --> Config Class Initialized
DEBUG - 2013-12-01 23:30:06 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:30:06 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:30:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:30:06 --> URI Class Initialized
DEBUG - 2013-12-01 23:30:06 --> Router Class Initialized
DEBUG - 2013-12-01 23:30:06 --> Output Class Initialized
DEBUG - 2013-12-01 23:30:06 --> Security Class Initialized
DEBUG - 2013-12-01 23:30:07 --> Input Class Initialized
DEBUG - 2013-12-01 23:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:30:07 --> Language Class Initialized
DEBUG - 2013-12-01 23:30:07 --> Loader Class Initialized
DEBUG - 2013-12-01 23:30:07 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:30:07 --> Session Class Initialized
DEBUG - 2013-12-01 23:30:08 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:30:08 --> Session routines successfully run
DEBUG - 2013-12-01 23:30:08 --> Controller Class Initialized
DEBUG - 2013-12-01 23:30:08 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:30:08 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:30:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:30:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:30:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:30:09 --> Model Class Initialized
DEBUG - 2013-12-01 23:30:09 --> Model Class Initialized
DEBUG - 2013-12-01 23:30:09 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:30:09 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:30:10 --> Upload Class Initialized
DEBUG - 2013-12-01 23:30:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:30:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:30:10 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 23:30:10 --> Final output sent to browser
DEBUG - 2013-12-01 23:30:10 --> Total execution time: 4.4673
DEBUG - 2013-12-01 23:30:34 --> Config Class Initialized
DEBUG - 2013-12-01 23:30:34 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:30:35 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:30:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:30:35 --> URI Class Initialized
DEBUG - 2013-12-01 23:30:35 --> Router Class Initialized
DEBUG - 2013-12-01 23:30:35 --> Output Class Initialized
DEBUG - 2013-12-01 23:30:35 --> Security Class Initialized
DEBUG - 2013-12-01 23:30:35 --> Input Class Initialized
DEBUG - 2013-12-01 23:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:30:36 --> Language Class Initialized
DEBUG - 2013-12-01 23:30:36 --> Loader Class Initialized
DEBUG - 2013-12-01 23:30:36 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:30:36 --> Session Class Initialized
DEBUG - 2013-12-01 23:30:37 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:30:37 --> Session routines successfully run
DEBUG - 2013-12-01 23:30:37 --> Controller Class Initialized
DEBUG - 2013-12-01 23:30:37 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:30:37 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:30:38 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:30:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:30:38 --> Model Class Initialized
DEBUG - 2013-12-01 23:30:38 --> Model Class Initialized
DEBUG - 2013-12-01 23:30:38 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:30:39 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:30:39 --> Upload Class Initialized
DEBUG - 2013-12-01 23:30:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:30:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:30:39 --> File loaded: application/views/auth/register_form.php
DEBUG - 2013-12-01 23:30:40 --> Final output sent to browser
DEBUG - 2013-12-01 23:30:40 --> Total execution time: 5.2573
DEBUG - 2013-12-01 23:30:51 --> Config Class Initialized
DEBUG - 2013-12-01 23:30:51 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:30:51 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:30:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:30:51 --> URI Class Initialized
DEBUG - 2013-12-01 23:30:51 --> Router Class Initialized
DEBUG - 2013-12-01 23:30:51 --> Output Class Initialized
DEBUG - 2013-12-01 23:30:52 --> Security Class Initialized
DEBUG - 2013-12-01 23:30:52 --> Input Class Initialized
DEBUG - 2013-12-01 23:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:30:52 --> Language Class Initialized
DEBUG - 2013-12-01 23:30:52 --> Loader Class Initialized
DEBUG - 2013-12-01 23:30:52 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:30:52 --> Session Class Initialized
DEBUG - 2013-12-01 23:30:53 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:30:53 --> Session routines successfully run
DEBUG - 2013-12-01 23:30:53 --> Controller Class Initialized
DEBUG - 2013-12-01 23:30:53 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:30:53 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:30:53 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:30:54 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:30:54 --> Model Class Initialized
DEBUG - 2013-12-01 23:30:54 --> Model Class Initialized
DEBUG - 2013-12-01 23:30:54 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:30:54 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:30:54 --> Upload Class Initialized
DEBUG - 2013-12-01 23:30:55 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:30:55 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:30:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:30:55 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:55 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:55 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:55 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:56 --> XSS Filtering completed
DEBUG - 2013-12-01 23:30:56 --> XSS Filtering completed
ERROR - 2013-12-01 23:30:56 --> Severity: Warning  --> fopen(/dev/urandom) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory C:\Program Files (x86)\Ampps\www\project\application\libraries\phpass-0.1\PasswordHash.php 49
DEBUG - 2013-12-01 23:30:56 --> Email Class Initialized
DEBUG - 2013-12-01 23:30:56 --> File loaded: application/views/email/activate-html.php
DEBUG - 2013-12-01 23:30:57 --> File loaded: application/views/email/activate-txt.php
DEBUG - 2013-12-01 23:30:57 --> Language file loaded: language/english/email_lang.php
DEBUG - 2013-12-01 23:30:58 --> Config Class Initialized
DEBUG - 2013-12-01 23:30:58 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:30:58 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:30:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:30:59 --> URI Class Initialized
DEBUG - 2013-12-01 23:30:59 --> Router Class Initialized
DEBUG - 2013-12-01 23:30:59 --> Output Class Initialized
DEBUG - 2013-12-01 23:30:59 --> Security Class Initialized
DEBUG - 2013-12-01 23:30:59 --> Input Class Initialized
DEBUG - 2013-12-01 23:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:30:59 --> Language Class Initialized
DEBUG - 2013-12-01 23:31:00 --> Loader Class Initialized
DEBUG - 2013-12-01 23:31:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:31:00 --> Session Class Initialized
DEBUG - 2013-12-01 23:31:00 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:31:00 --> Session routines successfully run
DEBUG - 2013-12-01 23:31:01 --> Controller Class Initialized
DEBUG - 2013-12-01 23:31:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:31:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:31:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:31:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:31:02 --> Model Class Initialized
DEBUG - 2013-12-01 23:31:02 --> Model Class Initialized
DEBUG - 2013-12-01 23:31:02 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:31:02 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:31:02 --> Upload Class Initialized
DEBUG - 2013-12-01 23:31:02 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:31:02 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:31:03 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 23:31:03 --> Final output sent to browser
DEBUG - 2013-12-01 23:31:03 --> Total execution time: 4.5593
DEBUG - 2013-12-01 23:31:08 --> Config Class Initialized
DEBUG - 2013-12-01 23:31:08 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:31:08 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:31:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:31:09 --> URI Class Initialized
DEBUG - 2013-12-01 23:31:09 --> Router Class Initialized
DEBUG - 2013-12-01 23:31:09 --> Output Class Initialized
DEBUG - 2013-12-01 23:31:09 --> Security Class Initialized
DEBUG - 2013-12-01 23:31:09 --> Input Class Initialized
DEBUG - 2013-12-01 23:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:31:09 --> Language Class Initialized
DEBUG - 2013-12-01 23:31:10 --> Loader Class Initialized
DEBUG - 2013-12-01 23:31:10 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:31:10 --> Session Class Initialized
DEBUG - 2013-12-01 23:31:10 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:31:11 --> Session routines successfully run
DEBUG - 2013-12-01 23:31:11 --> Controller Class Initialized
DEBUG - 2013-12-01 23:31:11 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:31:11 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:31:11 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:31:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:31:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:31:12 --> Model Class Initialized
DEBUG - 2013-12-01 23:31:12 --> Model Class Initialized
DEBUG - 2013-12-01 23:31:12 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:31:12 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:31:12 --> Upload Class Initialized
DEBUG - 2013-12-01 23:31:13 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:31:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:31:13 --> Model Class Initialized
DEBUG - 2013-12-01 23:31:13 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 23:31:13 --> Final output sent to browser
DEBUG - 2013-12-01 23:31:13 --> Total execution time: 4.9173
DEBUG - 2013-12-01 23:38:06 --> Config Class Initialized
DEBUG - 2013-12-01 23:38:06 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:38:06 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:38:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:38:07 --> URI Class Initialized
DEBUG - 2013-12-01 23:38:07 --> Router Class Initialized
DEBUG - 2013-12-01 23:38:07 --> Output Class Initialized
DEBUG - 2013-12-01 23:38:07 --> Security Class Initialized
DEBUG - 2013-12-01 23:38:07 --> Input Class Initialized
DEBUG - 2013-12-01 23:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:38:07 --> Language Class Initialized
DEBUG - 2013-12-01 23:38:07 --> Loader Class Initialized
DEBUG - 2013-12-01 23:38:08 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:38:08 --> Session Class Initialized
DEBUG - 2013-12-01 23:38:08 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:38:08 --> Session routines successfully run
DEBUG - 2013-12-01 23:38:08 --> Controller Class Initialized
DEBUG - 2013-12-01 23:38:09 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:38:09 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:38:09 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:38:09 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:38:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:09 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:10 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:10 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:38:10 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:38:10 --> Upload Class Initialized
DEBUG - 2013-12-01 23:38:10 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:10 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:38:11 --> Config Class Initialized
DEBUG - 2013-12-01 23:38:11 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:38:11 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:38:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:38:11 --> URI Class Initialized
DEBUG - 2013-12-01 23:38:11 --> Router Class Initialized
DEBUG - 2013-12-01 23:38:12 --> Output Class Initialized
DEBUG - 2013-12-01 23:38:12 --> Security Class Initialized
DEBUG - 2013-12-01 23:38:12 --> Input Class Initialized
DEBUG - 2013-12-01 23:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:38:12 --> Language Class Initialized
DEBUG - 2013-12-01 23:38:12 --> Loader Class Initialized
DEBUG - 2013-12-01 23:38:13 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:38:13 --> Session Class Initialized
DEBUG - 2013-12-01 23:38:13 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:38:13 --> Session routines successfully run
DEBUG - 2013-12-01 23:38:13 --> Controller Class Initialized
DEBUG - 2013-12-01 23:38:14 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:38:14 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:38:14 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:38:14 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:38:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:14 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:14 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:14 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:38:14 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:38:15 --> Upload Class Initialized
DEBUG - 2013-12-01 23:38:15 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:15 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:38:15 --> File loaded: application/views/auth/general_message.php
DEBUG - 2013-12-01 23:38:15 --> Final output sent to browser
DEBUG - 2013-12-01 23:38:15 --> Total execution time: 4.4183
DEBUG - 2013-12-01 23:38:21 --> Config Class Initialized
DEBUG - 2013-12-01 23:38:21 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:38:21 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:38:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:38:21 --> URI Class Initialized
DEBUG - 2013-12-01 23:38:21 --> Router Class Initialized
DEBUG - 2013-12-01 23:38:21 --> Output Class Initialized
DEBUG - 2013-12-01 23:38:21 --> Security Class Initialized
DEBUG - 2013-12-01 23:38:22 --> Input Class Initialized
DEBUG - 2013-12-01 23:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:38:22 --> Language Class Initialized
DEBUG - 2013-12-01 23:38:22 --> Loader Class Initialized
DEBUG - 2013-12-01 23:38:22 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:38:22 --> Session Class Initialized
DEBUG - 2013-12-01 23:38:22 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:38:22 --> Session routines successfully run
DEBUG - 2013-12-01 23:38:23 --> Controller Class Initialized
DEBUG - 2013-12-01 23:38:23 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:38:23 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:38:23 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:38:23 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:38:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:24 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:24 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:24 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:38:24 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:38:24 --> Upload Class Initialized
DEBUG - 2013-12-01 23:38:24 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:24 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:38:25 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:25 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 23:38:25 --> Final output sent to browser
DEBUG - 2013-12-01 23:38:25 --> Total execution time: 4.3182
DEBUG - 2013-12-01 23:38:29 --> Config Class Initialized
DEBUG - 2013-12-01 23:38:29 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:38:29 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:38:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:38:29 --> URI Class Initialized
DEBUG - 2013-12-01 23:38:29 --> Router Class Initialized
DEBUG - 2013-12-01 23:38:30 --> Output Class Initialized
DEBUG - 2013-12-01 23:38:30 --> Security Class Initialized
DEBUG - 2013-12-01 23:38:30 --> Input Class Initialized
DEBUG - 2013-12-01 23:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:38:30 --> Language Class Initialized
DEBUG - 2013-12-01 23:38:30 --> Loader Class Initialized
DEBUG - 2013-12-01 23:38:30 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:38:31 --> Session Class Initialized
DEBUG - 2013-12-01 23:38:31 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:38:31 --> Session routines successfully run
DEBUG - 2013-12-01 23:38:31 --> Controller Class Initialized
DEBUG - 2013-12-01 23:38:31 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:38:32 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:38:32 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:38:32 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:38:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:32 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:32 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:33 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:38:33 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:38:33 --> Upload Class Initialized
DEBUG - 2013-12-01 23:38:33 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:33 --> Language file loaded: language/english/tank_auth_lang.php
ERROR - 2013-12-01 23:38:33 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 23:38:34 --> Severity: Notice  --> Undefined index: ip_address C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 23:38:34 --> Severity: Notice  --> Undefined index: user_agent C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 23:38:34 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 272
ERROR - 2013-12-01 23:38:34 --> Severity: Notice  --> Undefined index: session_id C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 288
ERROR - 2013-12-01 23:38:34 --> Severity: Notice  --> Undefined index: last_activity C:\Program Files (x86)\Ampps\www\project\system\libraries\Session.php 289
DEBUG - 2013-12-01 23:38:35 --> Config Class Initialized
DEBUG - 2013-12-01 23:38:35 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:38:35 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:38:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:38:35 --> URI Class Initialized
DEBUG - 2013-12-01 23:38:35 --> Router Class Initialized
DEBUG - 2013-12-01 23:38:35 --> Output Class Initialized
DEBUG - 2013-12-01 23:38:36 --> Security Class Initialized
DEBUG - 2013-12-01 23:38:36 --> Input Class Initialized
DEBUG - 2013-12-01 23:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:38:36 --> Language Class Initialized
DEBUG - 2013-12-01 23:38:36 --> Loader Class Initialized
DEBUG - 2013-12-01 23:38:36 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:38:37 --> Session Class Initialized
DEBUG - 2013-12-01 23:38:37 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:38:37 --> Session routines successfully run
DEBUG - 2013-12-01 23:38:37 --> Controller Class Initialized
DEBUG - 2013-12-01 23:38:38 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:38:38 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:38:38 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:38:38 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:38:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:38 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:39 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:39 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:38:39 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:38:39 --> Upload Class Initialized
DEBUG - 2013-12-01 23:38:39 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:39 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:38:40 --> Config Class Initialized
DEBUG - 2013-12-01 23:38:40 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:38:40 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:38:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:38:40 --> URI Class Initialized
DEBUG - 2013-12-01 23:38:40 --> Router Class Initialized
DEBUG - 2013-12-01 23:38:40 --> Output Class Initialized
DEBUG - 2013-12-01 23:38:41 --> Security Class Initialized
DEBUG - 2013-12-01 23:38:41 --> Input Class Initialized
DEBUG - 2013-12-01 23:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:38:41 --> Language Class Initialized
DEBUG - 2013-12-01 23:38:41 --> Loader Class Initialized
DEBUG - 2013-12-01 23:38:41 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:38:41 --> Session Class Initialized
DEBUG - 2013-12-01 23:38:41 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:38:42 --> Session routines successfully run
DEBUG - 2013-12-01 23:38:42 --> Controller Class Initialized
DEBUG - 2013-12-01 23:38:42 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:38:42 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:38:42 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:38:42 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:43 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:43 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:43 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:38:43 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:38:43 --> Upload Class Initialized
DEBUG - 2013-12-01 23:38:43 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:38:43 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:38:44 --> Model Class Initialized
DEBUG - 2013-12-01 23:38:44 --> File loaded: application/views/auth/login_form.php
DEBUG - 2013-12-01 23:38:44 --> Final output sent to browser
DEBUG - 2013-12-01 23:38:44 --> Total execution time: 4.1532
DEBUG - 2013-12-01 23:39:02 --> Config Class Initialized
DEBUG - 2013-12-01 23:39:02 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:39:02 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:39:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:39:03 --> URI Class Initialized
DEBUG - 2013-12-01 23:39:03 --> Router Class Initialized
DEBUG - 2013-12-01 23:39:03 --> Output Class Initialized
DEBUG - 2013-12-01 23:39:03 --> Security Class Initialized
DEBUG - 2013-12-01 23:39:03 --> Input Class Initialized
DEBUG - 2013-12-01 23:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:39:03 --> Language Class Initialized
DEBUG - 2013-12-01 23:39:03 --> Loader Class Initialized
DEBUG - 2013-12-01 23:39:04 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:39:04 --> Session Class Initialized
DEBUG - 2013-12-01 23:39:04 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:39:04 --> Session routines successfully run
DEBUG - 2013-12-01 23:39:04 --> Controller Class Initialized
DEBUG - 2013-12-01 23:39:05 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:39:05 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:39:05 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:39:05 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:39:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:39:05 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:06 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:06 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:39:06 --> Helper loaded: cookie_helper
DEBUG - 2013-12-01 23:39:06 --> Upload Class Initialized
DEBUG - 2013-12-01 23:39:06 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:39:06 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:39:06 --> XSS Filtering completed
DEBUG - 2013-12-01 23:39:06 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:39:07 --> XSS Filtering completed
DEBUG - 2013-12-01 23:39:07 --> XSS Filtering completed
DEBUG - 2013-12-01 23:39:07 --> Config Class Initialized
DEBUG - 2013-12-01 23:39:08 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:39:08 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:39:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:39:08 --> URI Class Initialized
DEBUG - 2013-12-01 23:39:08 --> Router Class Initialized
DEBUG - 2013-12-01 23:39:08 --> Output Class Initialized
DEBUG - 2013-12-01 23:39:08 --> Security Class Initialized
DEBUG - 2013-12-01 23:39:08 --> Input Class Initialized
DEBUG - 2013-12-01 23:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:39:09 --> Language Class Initialized
DEBUG - 2013-12-01 23:39:09 --> Loader Class Initialized
DEBUG - 2013-12-01 23:39:09 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:39:09 --> Session Class Initialized
DEBUG - 2013-12-01 23:39:10 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:39:10 --> Session routines successfully run
DEBUG - 2013-12-01 23:39:10 --> Controller Class Initialized
DEBUG - 2013-12-01 23:39:10 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:39:10 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:39:10 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:39:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:39:11 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:11 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:11 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:39:11 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:11 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:11 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:39:11 --> File loaded: application/views/home/postsview.php
DEBUG - 2013-12-01 23:39:12 --> Final output sent to browser
DEBUG - 2013-12-01 23:39:12 --> Total execution time: 4.2382
DEBUG - 2013-12-01 23:39:31 --> Config Class Initialized
DEBUG - 2013-12-01 23:39:31 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:39:31 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:39:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:39:31 --> URI Class Initialized
DEBUG - 2013-12-01 23:39:31 --> Router Class Initialized
DEBUG - 2013-12-01 23:39:31 --> Output Class Initialized
DEBUG - 2013-12-01 23:39:32 --> Security Class Initialized
DEBUG - 2013-12-01 23:39:32 --> Input Class Initialized
DEBUG - 2013-12-01 23:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:39:32 --> Language Class Initialized
DEBUG - 2013-12-01 23:39:32 --> Loader Class Initialized
DEBUG - 2013-12-01 23:39:32 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:39:32 --> Session Class Initialized
DEBUG - 2013-12-01 23:39:32 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:39:33 --> Session routines successfully run
DEBUG - 2013-12-01 23:39:33 --> Controller Class Initialized
DEBUG - 2013-12-01 23:39:33 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:39:33 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:39:33 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:39:34 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:39:34 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:34 --> Model Class Initialized
DEBUG - 2013-12-01 23:39:34 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:39:34 --> Upload Class Initialized
DEBUG - 2013-12-01 23:39:34 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:39:34 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:39:34 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:39:35 --> Final output sent to browser
DEBUG - 2013-12-01 23:39:35 --> Total execution time: 3.7702
DEBUG - 2013-12-01 23:51:56 --> Config Class Initialized
DEBUG - 2013-12-01 23:51:56 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:51:56 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:51:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:51:56 --> URI Class Initialized
DEBUG - 2013-12-01 23:51:56 --> Router Class Initialized
DEBUG - 2013-12-01 23:51:56 --> Output Class Initialized
DEBUG - 2013-12-01 23:51:57 --> Security Class Initialized
DEBUG - 2013-12-01 23:51:57 --> Input Class Initialized
DEBUG - 2013-12-01 23:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:51:57 --> Language Class Initialized
DEBUG - 2013-12-01 23:51:57 --> Loader Class Initialized
DEBUG - 2013-12-01 23:51:57 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:51:57 --> Session Class Initialized
DEBUG - 2013-12-01 23:51:58 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:52:01 --> Session routines successfully run
DEBUG - 2013-12-01 23:52:01 --> Controller Class Initialized
DEBUG - 2013-12-01 23:52:01 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:52:01 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:52:01 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:52:01 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:52:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:52:02 --> Model Class Initialized
DEBUG - 2013-12-01 23:52:02 --> Model Class Initialized
DEBUG - 2013-12-01 23:52:02 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:52:02 --> Upload Class Initialized
DEBUG - 2013-12-01 23:52:03 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:52:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:52:03 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:52:03 --> Final output sent to browser
DEBUG - 2013-12-01 23:52:03 --> Total execution time: 7.2624
DEBUG - 2013-12-01 23:52:23 --> Config Class Initialized
DEBUG - 2013-12-01 23:52:23 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:52:24 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:52:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:52:24 --> URI Class Initialized
DEBUG - 2013-12-01 23:52:24 --> Router Class Initialized
DEBUG - 2013-12-01 23:52:24 --> Output Class Initialized
DEBUG - 2013-12-01 23:52:24 --> Security Class Initialized
DEBUG - 2013-12-01 23:52:24 --> Input Class Initialized
DEBUG - 2013-12-01 23:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:52:25 --> Language Class Initialized
DEBUG - 2013-12-01 23:52:25 --> Loader Class Initialized
DEBUG - 2013-12-01 23:52:25 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:52:25 --> Session Class Initialized
DEBUG - 2013-12-01 23:52:25 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:52:25 --> Session routines successfully run
DEBUG - 2013-12-01 23:52:26 --> Controller Class Initialized
DEBUG - 2013-12-01 23:52:26 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:52:26 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:52:26 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:52:26 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:52:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:52:26 --> Model Class Initialized
DEBUG - 2013-12-01 23:52:27 --> Model Class Initialized
DEBUG - 2013-12-01 23:52:27 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:52:27 --> Upload Class Initialized
DEBUG - 2013-12-01 23:52:27 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:52:27 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:52:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:52:32 --> XSS Filtering completed
ERROR - 2013-12-01 23:52:32 --> Severity: Notice  --> Undefined property: Auth::$user C:\Program Files (x86)\Ampps\www\project\application\controllers\auth.php 644
DEBUG - 2013-12-01 23:52:45 --> Config Class Initialized
DEBUG - 2013-12-01 23:52:45 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:52:46 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:52:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:52:46 --> URI Class Initialized
DEBUG - 2013-12-01 23:52:46 --> Router Class Initialized
DEBUG - 2013-12-01 23:52:46 --> Output Class Initialized
DEBUG - 2013-12-01 23:52:46 --> Security Class Initialized
DEBUG - 2013-12-01 23:52:47 --> Input Class Initialized
DEBUG - 2013-12-01 23:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:52:47 --> Language Class Initialized
DEBUG - 2013-12-01 23:52:47 --> Loader Class Initialized
DEBUG - 2013-12-01 23:52:48 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:52:48 --> Session Class Initialized
DEBUG - 2013-12-01 23:52:48 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:52:48 --> Session routines successfully run
DEBUG - 2013-12-01 23:52:48 --> Controller Class Initialized
DEBUG - 2013-12-01 23:52:49 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:52:49 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:52:49 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:52:49 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:52:49 --> Model Class Initialized
DEBUG - 2013-12-01 23:52:50 --> Model Class Initialized
DEBUG - 2013-12-01 23:52:50 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:52:50 --> Upload Class Initialized
DEBUG - 2013-12-01 23:52:50 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:52:50 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:52:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:52:51 --> XSS Filtering completed
DEBUG - 2013-12-01 23:52:51 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:52:51 --> Final output sent to browser
DEBUG - 2013-12-01 23:52:51 --> Total execution time: 5.8193
DEBUG - 2013-12-01 23:52:58 --> Config Class Initialized
DEBUG - 2013-12-01 23:52:59 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:52:59 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:52:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:52:59 --> URI Class Initialized
DEBUG - 2013-12-01 23:52:59 --> Router Class Initialized
DEBUG - 2013-12-01 23:52:59 --> Output Class Initialized
DEBUG - 2013-12-01 23:52:59 --> Security Class Initialized
DEBUG - 2013-12-01 23:53:00 --> Input Class Initialized
DEBUG - 2013-12-01 23:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:53:00 --> Language Class Initialized
DEBUG - 2013-12-01 23:53:00 --> Loader Class Initialized
DEBUG - 2013-12-01 23:53:00 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:53:01 --> Session Class Initialized
DEBUG - 2013-12-01 23:53:01 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:53:01 --> Session routines successfully run
DEBUG - 2013-12-01 23:53:01 --> Controller Class Initialized
DEBUG - 2013-12-01 23:53:02 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:53:02 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:53:02 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:53:02 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:53:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:53:02 --> Model Class Initialized
DEBUG - 2013-12-01 23:53:03 --> Model Class Initialized
DEBUG - 2013-12-01 23:53:03 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:53:03 --> Upload Class Initialized
DEBUG - 2013-12-01 23:53:03 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:53:03 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:53:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:53:04 --> XSS Filtering completed
DEBUG - 2013-12-01 23:53:04 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:53:04 --> Final output sent to browser
DEBUG - 2013-12-01 23:53:04 --> Total execution time: 5.5633
DEBUG - 2013-12-01 23:53:41 --> Config Class Initialized
DEBUG - 2013-12-01 23:53:41 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:53:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:53:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:53:41 --> URI Class Initialized
DEBUG - 2013-12-01 23:53:41 --> Router Class Initialized
DEBUG - 2013-12-01 23:53:42 --> Output Class Initialized
DEBUG - 2013-12-01 23:53:42 --> Security Class Initialized
DEBUG - 2013-12-01 23:53:42 --> Input Class Initialized
DEBUG - 2013-12-01 23:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:53:42 --> Language Class Initialized
DEBUG - 2013-12-01 23:53:42 --> Loader Class Initialized
DEBUG - 2013-12-01 23:53:43 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:53:43 --> Session Class Initialized
DEBUG - 2013-12-01 23:53:43 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:53:43 --> Session routines successfully run
DEBUG - 2013-12-01 23:53:44 --> Controller Class Initialized
DEBUG - 2013-12-01 23:53:44 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:53:44 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:53:44 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:53:44 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:53:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:53:45 --> Model Class Initialized
DEBUG - 2013-12-01 23:53:45 --> Model Class Initialized
DEBUG - 2013-12-01 23:53:45 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:53:45 --> Upload Class Initialized
DEBUG - 2013-12-01 23:53:45 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:53:45 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:53:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:53:46 --> XSS Filtering completed
DEBUG - 2013-12-01 23:53:46 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:53:46 --> Final output sent to browser
DEBUG - 2013-12-01 23:53:47 --> Total execution time: 5.7823
DEBUG - 2013-12-01 23:54:46 --> Config Class Initialized
DEBUG - 2013-12-01 23:54:47 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:54:47 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:54:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:54:47 --> URI Class Initialized
DEBUG - 2013-12-01 23:54:47 --> Router Class Initialized
DEBUG - 2013-12-01 23:54:47 --> Output Class Initialized
DEBUG - 2013-12-01 23:54:47 --> Security Class Initialized
DEBUG - 2013-12-01 23:54:48 --> Input Class Initialized
DEBUG - 2013-12-01 23:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:54:48 --> Language Class Initialized
DEBUG - 2013-12-01 23:54:48 --> Loader Class Initialized
DEBUG - 2013-12-01 23:54:49 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:54:49 --> Session Class Initialized
DEBUG - 2013-12-01 23:54:49 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:54:49 --> Session routines successfully run
DEBUG - 2013-12-01 23:54:49 --> Controller Class Initialized
DEBUG - 2013-12-01 23:54:50 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:54:50 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:54:50 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:54:50 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:54:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:54:50 --> Model Class Initialized
DEBUG - 2013-12-01 23:54:51 --> Model Class Initialized
DEBUG - 2013-12-01 23:54:51 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:54:51 --> Upload Class Initialized
DEBUG - 2013-12-01 23:54:51 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:54:51 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:54:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:54:51 --> XSS Filtering completed
DEBUG - 2013-12-01 23:54:52 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:54:52 --> Final output sent to browser
DEBUG - 2013-12-01 23:54:52 --> Total execution time: 5.5763
DEBUG - 2013-12-01 23:54:59 --> Config Class Initialized
DEBUG - 2013-12-01 23:54:59 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:54:59 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:55:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:55:00 --> URI Class Initialized
DEBUG - 2013-12-01 23:55:00 --> Router Class Initialized
DEBUG - 2013-12-01 23:55:00 --> Output Class Initialized
DEBUG - 2013-12-01 23:55:00 --> Security Class Initialized
DEBUG - 2013-12-01 23:55:00 --> Input Class Initialized
DEBUG - 2013-12-01 23:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:55:01 --> Language Class Initialized
DEBUG - 2013-12-01 23:55:01 --> Loader Class Initialized
DEBUG - 2013-12-01 23:55:01 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:55:01 --> Session Class Initialized
DEBUG - 2013-12-01 23:55:01 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:55:02 --> Session routines successfully run
DEBUG - 2013-12-01 23:55:02 --> Controller Class Initialized
DEBUG - 2013-12-01 23:55:02 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:55:02 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:55:02 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:55:03 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:55:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:55:03 --> Model Class Initialized
DEBUG - 2013-12-01 23:55:03 --> Model Class Initialized
DEBUG - 2013-12-01 23:55:03 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:55:03 --> Upload Class Initialized
DEBUG - 2013-12-01 23:55:04 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:55:04 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:55:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:55:04 --> XSS Filtering completed
DEBUG - 2013-12-01 23:55:04 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:55:04 --> Final output sent to browser
DEBUG - 2013-12-01 23:55:04 --> Total execution time: 5.2123
DEBUG - 2013-12-01 23:55:08 --> Config Class Initialized
DEBUG - 2013-12-01 23:55:08 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:55:08 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:55:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:55:09 --> URI Class Initialized
DEBUG - 2013-12-01 23:55:09 --> Router Class Initialized
DEBUG - 2013-12-01 23:55:09 --> Output Class Initialized
DEBUG - 2013-12-01 23:55:09 --> Security Class Initialized
DEBUG - 2013-12-01 23:55:09 --> Input Class Initialized
DEBUG - 2013-12-01 23:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:55:10 --> Language Class Initialized
DEBUG - 2013-12-01 23:55:10 --> Loader Class Initialized
DEBUG - 2013-12-01 23:55:11 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:55:11 --> Session Class Initialized
DEBUG - 2013-12-01 23:55:11 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:55:11 --> Session garbage collection performed.
DEBUG - 2013-12-01 23:55:11 --> Session routines successfully run
DEBUG - 2013-12-01 23:55:12 --> Controller Class Initialized
DEBUG - 2013-12-01 23:55:12 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:55:12 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:55:12 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:55:12 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:55:13 --> Model Class Initialized
DEBUG - 2013-12-01 23:55:13 --> Model Class Initialized
DEBUG - 2013-12-01 23:55:13 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:55:13 --> Upload Class Initialized
DEBUG - 2013-12-01 23:55:13 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:55:13 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:55:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:55:14 --> XSS Filtering completed
DEBUG - 2013-12-01 23:55:14 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:55:14 --> Final output sent to browser
DEBUG - 2013-12-01 23:55:14 --> Total execution time: 5.8253
DEBUG - 2013-12-01 23:56:31 --> Config Class Initialized
DEBUG - 2013-12-01 23:56:31 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:56:31 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:56:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:56:31 --> URI Class Initialized
DEBUG - 2013-12-01 23:56:31 --> Router Class Initialized
DEBUG - 2013-12-01 23:56:32 --> Output Class Initialized
DEBUG - 2013-12-01 23:56:35 --> Security Class Initialized
DEBUG - 2013-12-01 23:56:35 --> Input Class Initialized
DEBUG - 2013-12-01 23:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:56:35 --> Language Class Initialized
DEBUG - 2013-12-01 23:56:36 --> Loader Class Initialized
DEBUG - 2013-12-01 23:56:36 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:56:36 --> Session Class Initialized
DEBUG - 2013-12-01 23:56:36 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:56:36 --> Session routines successfully run
DEBUG - 2013-12-01 23:56:36 --> Controller Class Initialized
DEBUG - 2013-12-01 23:56:37 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:56:37 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:56:37 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:56:37 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:56:37 --> Model Class Initialized
DEBUG - 2013-12-01 23:56:37 --> Model Class Initialized
DEBUG - 2013-12-01 23:56:37 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:56:37 --> Upload Class Initialized
DEBUG - 2013-12-01 23:56:38 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:56:38 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:56:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-12-01 23:56:38 --> XSS Filtering completed
DEBUG - 2013-12-01 23:56:40 --> Config Class Initialized
DEBUG - 2013-12-01 23:56:40 --> Hooks Class Initialized
DEBUG - 2013-12-01 23:56:41 --> Utf8 Class Initialized
DEBUG - 2013-12-01 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-01 23:56:41 --> URI Class Initialized
DEBUG - 2013-12-01 23:56:41 --> Router Class Initialized
DEBUG - 2013-12-01 23:56:41 --> Output Class Initialized
DEBUG - 2013-12-01 23:56:41 --> Security Class Initialized
DEBUG - 2013-12-01 23:56:41 --> Input Class Initialized
DEBUG - 2013-12-01 23:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-01 23:56:42 --> Language Class Initialized
DEBUG - 2013-12-01 23:56:42 --> Loader Class Initialized
DEBUG - 2013-12-01 23:56:42 --> Database Driver Class Initialized
DEBUG - 2013-12-01 23:56:42 --> Session Class Initialized
DEBUG - 2013-12-01 23:56:42 --> Helper loaded: string_helper
DEBUG - 2013-12-01 23:56:43 --> Session routines successfully run
DEBUG - 2013-12-01 23:56:43 --> Controller Class Initialized
DEBUG - 2013-12-01 23:56:43 --> Helper loaded: form_helper
DEBUG - 2013-12-01 23:56:43 --> Helper loaded: url_helper
DEBUG - 2013-12-01 23:56:43 --> Form Validation Class Initialized
DEBUG - 2013-12-01 23:56:43 --> Config file loaded: application/config/tank_auth.php
DEBUG - 2013-12-01 23:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:56:43 --> Model Class Initialized
DEBUG - 2013-12-01 23:56:43 --> Model Class Initialized
DEBUG - 2013-12-01 23:56:44 --> Image Lib Class Initialized
DEBUG - 2013-12-01 23:56:44 --> Upload Class Initialized
DEBUG - 2013-12-01 23:56:44 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2013-12-01 23:56:44 --> Language file loaded: language/english/tank_auth_lang.php
DEBUG - 2013-12-01 23:56:44 --> File loaded: application/views/auth/change_profile_form.php
DEBUG - 2013-12-01 23:56:44 --> Final output sent to browser
DEBUG - 2013-12-01 23:56:44 --> Total execution time: 3.8372
